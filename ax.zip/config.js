/**
   * Create By Dika Ardnt.
   * Contact Me on wa.me/6288292024190
   * Follow https://github.com/DikaArdnt
*/

const fs = require('fs')
const chalk = require('chalk')

// Website Api
global.APIs = {
	zenz: 'https://api.zahwazein.xyz',
	lolkey: 'https://api.lolhuman.xyz',
	XZN: 'https://xzn.wtf',
	aemt: 'https://aemt.me',
}

//if api key expire, u can generate one from here: https://beta.openai.com/account/api-keys
global.keyopenai = "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"
//global
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa
// Apikey Website Api
global.APIKeys = {
	'https://api.zahwazein.xyz': 'zenzkey_94e9997864a8',
	'https://xzn.wtf': 'alzak',
}
//
global.apikey = 'skuy33'
global.thumb = 'https://telegra.ph/file/43ace7977b35fe6811bad.jpg'
// Other 
global.owner = ["33189310806","628386484120"]
global.premium = ['33451220170']
global.packname = 'AvoskyBot'
global.petakbom = {};
global.petakteka = {};
global.petakmystery = {};
global.ytname = "Avosky" //ur yt chanel name
global.socialm = "GitHub: Avosky" //ur github or insta name
global.location = "Indonesia, bumi" //ur location
global.author = 'WhatsApp Bot'
global.botNumber = ['6282297308628']
global.sessionName = 'sky'
global.ownername = 'Mr.Avosky'
global.botname = "Avosky Bot MD V2"
global.ownerweb = "https://youtube.com/@avosky"
global.websitex = "www.xnxx.com"
global.wagc = "https://chat.whatsapp.com/FvrzXkSKH1vKbeX2c2qK"

global.prefa = ['','!','.','🐦','🐤','🗿']
global.sp = '⭔'
global.mess = {
    success: '✓ Success',
    admin: 'Fitur Khusus Admin Group!',
    botAdmin: 'Bot Harus Menjadi Admin Terlebih Dahulu!',
    owner: 'Fitur Khusus Owner Bot',
    group: 'Fitur Digunakan Hanya Untuk Group!',
    private: 'Fitur Digunakan Hanya Untuk Private Chat!',
    bot: 'Fitur Khusus Pengguna Nomor Bot',
    wait: 'please wait a while :/',
    endLimit: 'Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12',
    endBalance: 'Balance Mu Sudah Abis',
}
global.limitawal = {
    premium: 1000000,
    free: 100
}
global.balanceawal = {
    premium: 20000,
    free: 1000
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
