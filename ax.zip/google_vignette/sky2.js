require('./config')
require('./menu2')
const {
	downloadContentFromMessage,
    BufferJSON,
    WA_DEFAULT_EPHEMERAL,
    generateWAMessageFromContent,
    proto,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia,
    areJidsSameUser,
    InteractiveMessage,
    getContentType
} = require('@whiskeysockets/baileys')
const fs = require('fs')
const fsx = require('fs-extra')
const util = require('util')
const BodyForm = require('form-data')
const yts = require('yt-search')
const { fromBuffer } = require('file-type')
const chalk = require('chalk')
const { v4: uuidv4 } = require('uuid')
const { exec, spawn, execSync } = require("child_process")
const axios = require('axios')
const path = require('path')
const users = {};
const emojiRegex = /\p{Emoji}/u;
const notes = {}; // Objek untuk menyimpan catatan pengguna
const pasienSakit = {};

const obatTersedia = ['Paracetamol', 'Antibiotik', 'Vitamin C', 'Obat Pusing'];
const obatDokter = {};
const StickerXeon = JSON.parse(fs.readFileSync('./database/xeonsticker.json'))
const os = require('os')
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const moment = require('moment-timezone')
const { JSDOM } = require('jsdom')
let { Image } = require('node-webpmux')
const { smims } = require('./lib/uploadImage')
const crypto = require('crypto');
const caseCount = {};
const Jimp = require('jimp');
const photooxy = require('./lib/photooxy');
const { webp2mp4File } = require('./lib/uploader')
const { mediafireDl } = require('./lib/mediafire.js')
const { fetchBuffer, GIFBufferToVideoBuffer, buffergif, pickRandom } = require("./lib/myfunc2")
const speed = require('performance-now')

const { performance } = require('perf_hooks')
const { Primbon } = require('scrape-primbon')
const anon = require('./lib/menfess')
const ytdl = require('ytdl-core')
const { addExif } = require('./lib/exif')
const primbon = new Primbon()
const { smsg, formatp, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, fetchJson, getBuffer, jsonformat, format, parseMention, getRandom, getGroupAdmins } = require('./lib/myfunc')

// read database
let tebaklagu = db.data.game.tebaklagu = []
let _family100 = db.data.game.family100 = []
let kuismath = db.data.game.math = []
let tebakgambar = db.data.game.tebakgambar = []
let tebakkata = db.data.game.tebakkata = []
let tebakbendera = db.data.game.tebakbendera = []
let caklontong = db.data.game.lontong = []
let caklontong_desk = db.data.game.lontong_desk = []
let tebakkalimat = db.data.game.kalimat = []
let tebaklirik = db.data.game.lirik = []
let tebaktebakan = db.data.game.tebakan = []
let isGameActive = false;
let isactiveFishingGames = false;
let players = null; // Daftar ID pemain dalam permainan
let impostorId = null; //ID
let secretWord = null; // Kata yang akan ditebak
let tagCount = {}; // Menyimpan jumlah tag yang telah dikirim
let tagQueue = {}; // Menyimpan antrian tag untuk setiap 
const activeGames = {};
let requiredClaps = 0;
const activeFishingGames = {};
let players1 = {};
let totalClaps = 0;
let keyQuest = {};
let conversationState = null;
let kirimpesan = true;
let registeredUsers = {};
let gameInProgress = false;
let playerAlive = true;
let intervalID
let spamCounter = {};
const adventures = [
    "Anda menemukan gua yang misterius. Apakah Anda akan masuk? (ya/tidak)",
    "Anda bertemu monster di hutan. Apakah Anda akan melawan? (ya/tidak)",
    "Anda menemukan harta karun yang tersembunyi. Apakah Anda akan mengambilnya? (ya/tidak)"
];
const chatURL = 'https://beta.character.ai/chat2?char=-p04V7wg7AT5CcJumGnEB2LVWdjvuJEfVjs1P3LOSwo';  

const results = [
    "Selamat! Anda berhasil menemukan harta yang berlimpah.",
    "Sayang sekali, Anda kalah dalam pertarungan melawan monster.",
    "Anda mendapat kutukan setelah mengambil harta karun. Sebaiknya hati-hati."
];

//DB
let { pinterest } = require('./lib/scraper');
const banned = JSON.parse(fs.readFileSync('./database/banned.json'))
const prem = JSON.parse(fs.readFileSync('./database/premium.json'))
module.exports = sky = async (sky, m, chatUpdate, store) => {
    try {
       const body = (m && m?.mtype) ? (
    m?.mtype === 'conversation' ? m?.message?.conversation :
    m?.mtype === 'imageMessage' ? m?.message?.imageMessage?.caption :
    m?.mtype === 'videoMessage' ? m?.message?.videoMessage?.caption :
    m?.mtype === 'extendedTextMessage' ? m?.message?.extendedTextMessage?.text :
    m?.mtype === 'buttonsResponseMessage' ? m?.message?.buttonsResponseMessage?.selectedButtonId :
    m?.mtype === 'listResponseMessage' ? m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
    m?.mtype === 'templateButtonReplyMessage' ? m?.message?.templateButtonReplyMessage?.selectedId :
    m?.mtype === 'messageContextInfo' ? (
        m?.message?.buttonsResponseMessage?.selectedButtonId || 
        m?.message?.listResponseMessage?.singleSelectReply?.selectedRowId || 
        m?.text
    ) : ''
) : '';

        var budy = (typeof m.text == 'string' ? m.text : '')
        var prefix = prefa ? /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi.test(body) ? body.match(/^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#$%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
        global.prefix = prefix
        const isCmd = body.startsWith(prefix)
        const from = m.key.remoteJid
        const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()        
        var args = body.trim().split(/ +/).slice(1)
        var args1 = body.trim().split(/ +/).slice(1)
        args = args.concat(['','','','','',''])
        const totalFitur = () =>{
            var mytext = fs.readFileSync("./sky.js").toString()
            var numUpper = (mytext.match(/case '/g) || []).length;
            return numUpper
        }
        const pushname = m.pushName || "No Name"
        const botNumber = await sky.decodeJid(sky.user.id)
        const isCreator = [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)
        const itsMe = m.sender == botNumber ? true : false
        const text = q = args.join(" ").trim()
        const isGroup = from.endsWith("@g.us");        
        const isBan = banned.includes(m.sender)
        const xeonymisc = (m.quoted || m)
        const quoted = (xeonymisc.mtype == 'buttonsMessage') ? xeonymisc[Object.keys(xeonymisc)[1]] : (xeonymisc.mtype == 'templateMessage') ? xeonymisc.hydratedTemplate[Object.keys(xeonymisc.hydratedTemplate)[1]] : (xeonymisc.mtype == 'product') ? xeonymisc[Object.keys(xeonymisc)[0]] : m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const mentionByTag = m.sender
        const mentionByReply = m.sender
        const sender = m.isGroup ? (m.key.participant ? m.key.participant : m.participant) : m.key.remoteJid
        const isMedia = /image|video|sticker|audio/.test(mime)
// Group
let groupMetadata, participants, groupAdmins, isBotAdmins, isAdmins;

if (m.isGroup) {
    try {
        groupMetadata = await sky.groupMetadata(m.chat);      
        participants = groupMetadata.participants || [];
        groupAdmins = getGroupAdmins(participants) || [];
        isBotAdmins = groupAdmins.includes(botNumber);
        isAdmins = groupAdmins.includes(m.sender);
    } catch (error) {
        console.error('Error fetching group metadata:', error);
    }
}
        const isPrem = prem.includes(m.sender)
    	const isPremium = isCreator || global.premium.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender) || false
	try {
            let isNumber = x => typeof x === 'number' && !isNaN(x)
            let limitUser = isPremium ? global.limitawal.premium : global.limitawal.free
            let BalanceUser = isPremium ? global.balanceawal.premium : global.balanceawal.free
            let user = db.data.users[m.sender];
if (typeof user !== 'object') db.data.users[m.sender] = {};
if (user) {    
    if (!isNumber(user.limit)) user.limit = limitUser;
    if (!isNumber(user.balance)) user.balance = BalanceUser;
    if (!isNumber(user.gold)) user.gold = 0;
    if (!isNumber(user.silver)) user.silver = 0;
    if (!isNumber(user.emerald)) user.emerald = 0;
    if (!isNumber(user.potion)) user.potion = 0;
} else {
    global.db.data.users[m.sender] = {        
        limit: limitUser,
        balance: BalanceUser,
        gold: 0,
        silver: 0,
        emerald: 0,
        potion: 0,
        premium: false
    };
}            
 // Days
        const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
        const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
        const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
        const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')


        const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'Selamat Malam 🏙️'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'Selamat Petang 🌆'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'Selamat Sore 🌇'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'Selamat Siang 🌤️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'Selamat Pagi 🌄'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'Selamat Subuh 🌆'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'Selamat Tengah Malam 🌃'
        }    
            let chats = db.data.chats[m.chat]
            if (typeof chats !== 'object') db.data.chats[m.chat] = {}
            if (chats) {
                if (!('mute' in chats)) chats.mute = false
                if (!('antilink' in chats)) chats.antilink = false
                if (!('antipushkontakv1' in chats)) chats.antivirtex = true
                if (!('antipushkontakv2' in chats)) chats.antivirtex = true
            } else global.db.data.chats[m.chat] = {
                mute: false,
                antilink: false,
                antipushkontakv1: false,
                antipushkontakv2: false,
            }
	    let setting = db.data.settings[botNumber]
        if (typeof setting !== 'object') db.data.settings[botNumber] = {}
	    if (setting) {
    	    if (!('anticall' in setting)) setting.anticall = true
    		if (!isNumber(setting.status)) setting.status = 0
    		if (!('autobio' in setting)) setting.autobio = false
	    } else global.db.data.settings[botNumber] = {
    	    anticall: true,
    		status: 0,
    		autobio: false
	    }
	    
        } catch (err) {
            console.error(err)
        }
	      const fkontak = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                'contactMessage': {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${botname},;;;\nFN:${botname}\nitem1.TEL;waid=${owner}:+${owner}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': thumb,
                    thumbnail: thumb,
                    sendEphemeral: true
                }   
            }
        }
        const ftroli = {key: {fromMe: false,"participant":"0@s.whatsapp.net", "remoteJid": "status@broadcast"}, "message": {orderMessage: {itemCount: 2022,status: 200, thumbnail: thumb, surface: 200, message: botname, orderTitle: "avosky", sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999,"isForwarded":true},sendEphemeral: true}
        
 if (m.chat.endsWith('@s.whatsapp.net') && !isCmd) {
let room = Object.values(anon.anonymous).find(p => p.state == "CHATTING" && p.check(sender))
if (room) {
let other = room.other(sender)
m.copyNForward(other, true, m.quoted && m.quoted.fromMe ? {
contextInfo: {
...m.msg.contextInfo,
forwardingScore: 0,
isForwarded: true,
participant: other
}
} : {})
}
}
//SENDBUTTON
function sendButton(chatId, text, buttonText, buttonId) {
    let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys');
    
    let msg = generateWAMessageFromContent(chatId, {
        viewOnceMessage: {
            message: {
                "messageContextInfo": {
                    "deviceListMetadata": {},
                    "deviceListMetadataVersion": 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: text
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: `© avosky`
                    }), 
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                "name": "quick_reply",
                                "buttonParamsJson": `{"display_text":"${buttonText}","id":"${buttonId}"}`
                            }
                        ]
                    })
                })
            }
        }
    }, {});

    sky.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id
    });
}
function randomNomor(min, max = null){
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}
}
//
const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}
        // Public & Self
        if (!sky.public) {
            if (!m.key.fromMe) return
        } 
const downloadMp4 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp4File = getRandom('.mp4')
console.log(color('Download Video With ytdl-core'))
let nana = ytdl(Link)
.pipe(fs.createWriteStream(mp4File))
.on('finish', async () => {
await sky.sendMessage(from, { video: fs.readFileSync(mp4File), gifPlayback: false }, { quoted: m })
fs.unlinkSync(`./${mp4File}`)
})
} catch (err) {
reply(`${err}`)
}
}

const downloadMp3 = async (Link) => {
try {
await ytdl.getInfo(Link)
let mp3File = getRandom('.mp3')
console.log(color('Download Audio With ytdl-core'))
ytdl(Link, { filter: 'audioonly' })
.pipe(fs.createWriteStream(mp3File))
.on('finish', async () => {
await sky.sendMessage(from, { audio: fs.readFileSync(mp3File), mimetype: 'audio/mp4' }, { quoted: m })
fs.unlinkSync(mp3File)
})
} catch (err) {
reply(`${err}`)
}
}
//gif
async function sendGif(url, chatId, caption) {
    try {
        const response = await axios.get(url, { responseType: 'arraybuffer' });
        const buffer = Buffer.from(response.data, "utf-8");
        const fetchedgif = await GIFBufferToVideoBuffer(buffer);

        await sky.sendMessage(chatId, { video: fetchedgif, gifPlayback: true }, { quoted: m, caption: caption });
    } catch (error) {
        console.log(error);
    }
}

function sendLiveLocation(to, locationData, duration, options = {}) {
    const msg = {
        location: locationData,
        liveLocation: true,
        liveDuration: duration
    };
    sky.sendMessage(to, msg, options);
}

function sendOTP(number) {
  const otp = Math.floor(1000 + Math.random() * 9000);
  registeredUsers[number] = { otp };
    sky.sendText(sender, `OTP untuk ${number}: ${otp}`);
}
//ADDG
async function jarak(from, to) {
	let html = (await axios(`https://www.google.com/search?q=${encodeURIComponent('jarak ' + from + ' to ' + to)}&hl=id`)).data
	let $ = cheerio.load(html), obj = {}
	let img = html.split("var s=\'")?.[1]?.split("\'")?.[0]
	obj.img = /^data:.*?\/.*?;base64,/i.test(img) ? Buffer.from(img.split`,` [1], 'base64') : ''
	obj.desc = $('div.BNeawe.deIvCb.AP7Wnd').text()?.trim()
	return obj
}
async function loading () {
var hawemod = [
"🟨🟨🟨🟨🟨🟨🟨🟨",
"🟨🟦🟦🔲🔲🟦🟦🟨",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽⬜🟦🏽🏽🟦⬜🏽",
"🏽🏽🏽🏽🏽🏽🏽🏽",
"🏽🏽🟫🏽🏽🟫🏽🏽",
"🏽🏽🟫🟫🟫🟫🏽🏽",
"NARUTO",
]
let { key } = await sky.sendMessage(from, {text: 'ʟᴏᴀᴅɪɴɢ...'})//Pengalih isu

for (let i = 0; i < hawemod.length; i++) {
/*await delay(10)*/
await sky.sendMessage(from, {text: hawemod[i], edit: key });//PESAN LEPAS
}
}
async function skysend(chatId, message, options = {}){
    let generate = await generateWAMessage(chatId, message, options)
    let type2 = getContentType(generate.message)
    if ('contextInfo' in options) generate.message[type2].contextInfo = options?.contextInfo
    if ('contextInfo' in message) generate.message[type2].contextInfo = message?.contextInfo
    return await sky.relayMessage(chatId, generate.message, { messageId: generate.key.id })
}
async function getLatestAnime() {
  try {
    const response = await axios.get('https://myanimelist.net/anime/season');
    const $ = cheerio.load(response.data);
    
    const animeList = [];
    
    $('div.seasonal-anime').each((index, element) => {
      const title = $(element).find('div.title-text').text().trim();
      const link = $(element).find('div.title-text a').attr('href');
      
      if (title && link) {
        animeList.push({ title, link });
      }
    });
    
    return animeList;
  } catch (error) {
    console.error('Error fetching latest anime:', error);
    return [];
  }
}
let list = []
for (let i of owner) {
list.push({
	    	displayName: await sky.getName(i),
	    	vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await sky.getName(i)}\nFN:${await sky.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`
	    })
	}
async function getLatestBBCNews() {
  try {
    const response = await axios.get('https://www.bbc.co.uk/news');
    const $ = cheerio.load(response.data);
    
    const news = [];
    
    $('div.gs-c-promo').each((index, element) => {
      const title = $(element).find('h3').text();
      const link = $(element).find('a').attr('href');
      
      if (title && link) {
        news.push({ title, link });
      }
    });
    
    return news;
  } catch (error) {
    console.error('Error fetching BBC news:', error);
    return [];
  }
}
async function performAdvancedBugHunting(url) {
    try {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        const headers = response.headers;
        const status = response.status;
        const contentType = headers['content-type'];

        // Check for insecure HTTP resources
        const insecureResources = [];
        $('*[src^="http://"]').each((index, element) => {
            insecureResources.push($(element).attr('src'));
        });

        // Check for forms without secure attribute
        const formsWithoutSecure = $('form:not([method="post"])');

        // More vulnerability checks can be added here

        const report = `Laporan Bug Hunting untuk ${url}:\nStatus: ${status}\nTipe Konten: ${contentType}\nCek Sumber Tidak Aman\n${insecureResources.join('\n')}\nFormulir Tanpa Atribut Aman\n${formsWithoutSecure.length} formulir tanpa atribut "method" yang aman`;

        return report;
    } catch (error) {
        throw 'Gagal melakukan Bug Hunting.';
    }
}
// Function to fetch quotes from URL
function quotes(input) {
    return new Promise((resolve, reject) => {
        fetch('https://jagokata.com/kata-bijak/kata-' + input.replace(/\s/g, '_') + '.html?page=1')
            .then(res => res.text())
            .then(res => {
                const $ = cheerio.load(res);
                data = [];
                $('div[id="main"]').find('ul[id="citatenrijen"] > li').each(function (index, element) {
                    x = $(this).find('div[class="citatenlijst-auteur"] > a').text().trim();
                    y = $(this).find('span[class="auteur-beschrijving"]').text().trim();
                    z = $(element).find('q[class="fbquote"]').text().trim();
                    data.push({ author: x, bio: y, quote: z });
                });
                data.splice(2, 1);
                if (data.length == 0) return resolve({ creator: '@neoxr - Wildan Izzudin & @ariffb.id - Ariffb', status: false });
                resolve({ creator: '@skyyyy', status: true, data });
            }).catch(reject);
    });
}
async function getIpInfo(ip) {
    try {
        const response = await axios.get(`https://ipinfo.io/${ip}/json`);
        return response.data;
    } catch (error) {
        throw 'Gagal mendapatkan informasi IP.';
    }
}
const replygc = (teks) => {
    sky.sendMessage(from, { 
        text: teks, 
        contextInfo: {
            mentionedJid: [],
            groupMentions: [],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: '0@newsletter',
                newsletterName: "avosky-md",
                serverMessageId: -1
            },
            forwardingScore: 256,
            externalAdReply: {
                showAdAttribution: true,
                title: `avoskh-md`,
                body: `alaaaaooooooo`,
                thumbnailUrl: `avosky.com`,
                sourceUrl: "https://wa.me/33451220170",
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: m })
}
	// auto set bio
	if (db.data.settings[botNumber].autobio) {
	    let setting = global.db.data.settings[botNumber]
	    if (new Date() * 1 - setting.status > 1000) {
		let uptime = await runtime(process.uptime())
		await sky.updateProfileStatus(`${sky.user.name} | Runtime : ${runtime(uptime)}`)
		setting.status = new Date() * 1
	    }
	}
	async function waitForMessage(from, regex, timeout) {
    return new Promise(async (resolve) => {
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
            const messages = await sky.sendMessage(m.chat, { fromMe: false })
            
            for (const message of messages) {
                if (message.sender === from && regex.test(message.content)) {
                    resolve(message);
                    return;
                }
            }

            await new Promise(resolve => setTimeout(resolve, 1000)); // Tunggu selama 1 detik sebelum cek kembali
        }

        resolve(null); // Timeout tercapai
    });
}
function formatSize(bytes) {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function sizeLimit(size, limit) {
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const limitSize = parseFloat(limit);
  const limitUnit = limit.replace(/[\d.]/g, '');
  const limitIndex = sizes.findIndex(unit => unit === limitUnit);
  const currentSize = parseFloat(size);
  const currentUnit = size.replace(/[\d.]/g, '');
  const currentIndex = sizes.findIndex(unit => unit === currentUnit);

  if (currentIndex > limitIndex) {
    return {
      oversize: true,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  } else {
    return {
      oversize: false,
      currentSize: currentSize,
      currentUnit: currentUnit,
      limitSize: limitSize,
      limitUnit: limitUnit
    };
  }
}

function jsonFormat(json) {
  return JSON.stringify(json, null, 2);
}
async function replyprem(teks) {
    m.reply(`sorry fitur ini hanya untuk premium only jika ingin premium bisa ketik .buyprem`)
}	
async function sendNextTag(user) {
  if (tagQueue[user] && tagQueue[user].currentIndex < tagQueue[user].amount) {
    const target = tagQueue[user].target;
    const currentIndex = tagQueue[user].currentIndex;

    // Mengirim tag berikutnya
    sky.sendTextWithMentions(from, `${target}`);
    
    // Menambahkan 1 ke currentIndex dan menjalankan pengiriman tag selanjutnya setelah jeda
    tagQueue[user].currentIndex++;
    setTimeout(() => {
      sendNextTag(user);
    }, 1000); // Jeda 1 detik
  } else {
    // Menghapus antrian tag setelah selesai
    delete tagQueue[user];
  }
}  
// Fungsi untuk mengacak urutan elemen dalam array
function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}
function drawCard() {
    const cards = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
    const randomIndex = Math.floor(Math.random() * cards.length);
    return cards[randomIndex];
}

function calculateScore(hand) {
    let score = 0;
    let numOfAces = 0;

    for (let card of hand) {
        if (card === 'A') {
            numOfAces++;
            score += 11;
        } else if (['K', 'Q', 'J'].includes(card)) {
            score += 10;
        } else {
            score += parseInt(card);
        }
    }

    while (numOfAces > 0 && score > 21) {
        score -= 10;
        numOfAces--;
    }

    return score;
}
        switch(command) {
	    // CASE DI SINI
case 'addcase2': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menambahkan case baru.');
        return;
    }
    if (!text) {
        m.reply('Silakan masukkan isi case.');
        return;
    }
    
    const cases = fs.readFileSync('sky2.js').toString();
    const caseBody = text;
    const caseName = caseBody.match(/case '(.*?)':/)[1]; // Mendapatkan nama case dari teks case baru
    
    // Cari apakah case dengan nama yang sama sudah ada
    const startIndex = cases.indexOf(`case '${caseName}':`);
    if (startIndex !== -1) {
        // Jika ditemukan, hapus case lama sebelum menambahkan yang baru
        const endIndex = cases.indexOf('break', startIndex) + 6; // +6 untuk memasukkan break;
        const updatedCases = cases.slice(0, startIndex) + caseBody + '\n' + cases.slice(endIndex);
        fs.writeFileSync('sky2.js', updatedCases);
        m.reply(`Case '${caseName}' berhasil diperbarui.`);
    } else {
        // Jika tidak ditemukan, tambahkan case baru di akhir file seperti sebelumnya
        const indexOfBreak = cases.lastIndexOf('//ADDF');
        if (indexOfBreak === -1) {
            m.reply('Terjadi kesalahan dalam menemukan tempat untuk menambahkan case.');
            return;
        }
        const newCase = `${caseBody}\n`;
        const updatedCases = cases.slice(0, indexOfBreak) + newCase + cases.slice(indexOfBreak);
        fs.writeFileSync('sky2.js', updatedCases);
        m.reply('Case baru berhasil ditambahkan!');
    }
    }
    break
    case 'deletecase2': {
    if (!isCreator) {
        m.reply('Anda tidak memiliki izin untuk menghapus case.');
        return;
    }

    if (!text) {
        m.reply('Silakan masukkan nama case yang ingin dihapus.');
        return;
    }

    const cases = fs.readFileSync('sky2.js').toString();
    const caseNameToDelete = text;
    const startIndex = cases.indexOf(`case '${caseNameToDelete}':`);

    if (startIndex === -1) {
        m.reply(`Case '${caseNameToDelete}' tidak ditemukan.`);
        return;
    }

    const endIndex = cases.indexOf('break', startIndex);

    if (endIndex === -1) {
        m.reply('Terjadi kesalahan dalam menemukan titik "break;" dalam kode.');
        return;
    }

    // Menghapus hanya bagian case sampai break saja
    const updatedCases = cases.slice(0, startIndex) + cases.slice(endIndex + 6);
    fs.writeFileSync('sky2.js', updatedCases);
    m.reply(`Bagian case '${caseNameToDelete}' berhasil dihapus.`);
    }
    break;	    


case 'listcase2': {
 const fs = require('fs');
 try {
 const mytext = fs.readFileSync('./sky2.js', 'utf8');
 const cases = mytext.match(/case '.*?':/g);
 if (cases) {
 const sortedCases = cases
 .map((caseString) => caseString.replace(/case |:/g, ''))
 .sort();
 const listMessage = `Daftar Case:\n${sortedCases.join('\n')}`;
 m.reply(listMessage);
 } else {
 m.reply('Tidak ada case yang ditemukan dalam file sky2.js.');
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mencoba membaca file sky2.js.');
 }
}
break
case 'generateimg': {
 const axios = require('axios');

 async function generateImages(prompt, model) {
 try {
 const randomIP = `${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
 const userAgentList = [
 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15',
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
 'Mozilla/5.0 (Linux; Android 10; SM-G960U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.77 Mobile Safari/537.36'
 ];
 const randomUserAgent = userAgentList[Math.floor(Math.random() * userAgentList.length)];
 const ngenloot = await axios.post(
 'https://restapi.cutout.pro/web/ai/generateImage/generateAsync',
 {
 prompt: prompt,
 style: model,
 quantity: 3,
 width: 512,
 height: 512
 },
 {
 headers: {
 "Content-Type": "application/json",
 "User-Agent": randomUserAgent,
 "X-Forwarded-For": randomIP,
 "Referer": "https://www.cutout.pro/zh-CN/ai-art-generation/upload"
 }
 }
 );

 if (!ngenloot.data.data || !ngenloot.data.data.batchId) {
 throw new Error(`无法从 POST 响应中检索 batchId ${model}`);
 }
 const batchId = ngenloot.data.data.batchId;
 let kentod_asli = false;
 let nganu_hasil = [];
 while (!kentod_asli) {
 const memanggil_tobrut = await axios.get(
 `https://restapi.cutout.pro/web/ai/generateImage/getGenerateImageTaskResult?batchId=${batchId}`,
 {
 headers: {
 "Accept": "application/json, text/plain, */*",
 "User-Agent": randomUserAgent,
 "X-Forwarded-For": randomIP,
 "Referer": "https://www.cutout.pro/zh-CN/ai-art-generation/upload"
 }
 }
 );
 const gambar_Anu = memanggil_tobrut.data.data.text2ImageVoList;

 kentod_asli = gambar_Anu.every(image => image.status === 1);

 if (kentod_asli) {
 const nganu_model_hasil = gambar_Anu.map((image, index) => ({
 model: model,
 url: image.resultUrl,
 creator_scrape: "INS"
 }));

 nganu_hasil = nganu_hasil.concat(nganu_model_hasil);
 } else {
 await new Promise(resolve => setTimeout(resolve, 1000));
 }
 }
 return nganu_hasil;
 } catch (error) {
 throw error;
 }
 }

 (async () => {
 try {
 const input = args.join(' ').split('|').map(arg => arg.trim());
 const prompt = input[0];
 const model = input[1];
 if (!prompt || !model) {
 m.reply('Silakan berikan prompt dan model yang valid. Contoh: generateimg girl | LoL');
 return;
 }

 const models = [
 "Glowing Forest",
 "Vector Art",
 "Princess",
 "LoL",
 "Realistic Anime",
 "West Coast",
 "Blue Rhapsody",
 "Graffiti",
 "Clown",
 "Elf"
 ];
 if (!models.includes(model)) {
 m.reply(`Model tidak valid. Pilih salah satu dari model berikut: ${models.join(', ')}`);
 return;
 }

 const results = await generateImages(prompt, model);
 for (const result of results) {
 for (const [key, value] of Object.entries(result)) {
 if (key.startsWith('url')) {
 await sky.sendMessage(m.chat, { image: { url: value }, caption: `Gambar dari model ${result.model}` });
 }
 }
 }
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
 })();
 }
 break
     

case 'delacces': {
if (!isCreator) throw mess.owner
if (!args[0]) return m.reply(`Use ${prefix+command} nomor\nExample ${prefix+command} 628`)
ya = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
unp = prem.indexOf(ya)
prem.splice(unp, 1)
fs.writeFileSync('./database/premium.json', JSON.stringify(prem))
m.reply(`succes delete ${ya} acces to bot!`)
}
break
case 'tourl4': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke Catbox
 async function uploadToCatbox(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const form = new FormData();
 form.append('reqtype', 'fileupload');
 form.append('fileToUpload', fs.createReadStream(filePath));

 const response = await axios.post('https://catbox.moe/user/api.php', form, {
 headers: {
 ...form.getHeaders()
 }
 });

 if (response.status === 200 && response.data) {
 return response.data.trim(); // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar
 if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
 let url = await uploadToCatbox(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl5': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 const mime = require('mime-types'); // Importing mime-types library

 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke pomf2.lain.la
 async function uploadToPomf2(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const form = new FormData();
 form.append('files[]', fs.createReadStream(filePath));

 const response = await axios.post('https://pomf2.lain.la/upload.php', form, {
 headers: {
 ...form.getHeaders()
 }
 });

 console.log(`Response Status: ${response.status}`); // Logging status code
 console.log(`Response Data: ${JSON.stringify(response.data)}`); // Logging response data

 if (response.status === 200 && response.data && response.data.files && response.data.files[0]) {
 return response.data.files[0].url; // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 console.error(`Error during upload: ${err.message}`); // Logging error message
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek jenis media menggunakan mime-types
 let mimeType = mime.lookup(media);
 console.log(`Mime Type: ${mimeType}`); // Logging mime type

 if (mimeType && (mimeType.startsWith('image') || mimeType.startsWith('video') || mimeType.startsWith('audio'))) {
 let url = await uploadToPomf2(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 console.error(`Error: ${err.message}`); // Logging error message
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl6': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');

 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke layanan web Uguu
 async function uploadToUguu(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const formData = new FormData();
 formData.append('files[]', fs.createReadStream(filePath));

 const response = await axios.post('https://uguu.se/upload', formData, {
 headers: {
 ...formData.getHeaders(),
 },
 params: {
 output: 'json', // Meminta respons dalam format JSON
 },
 });

 if (response.status === 200 && response.data && response.data.files && response.data.files[0]) {
 return response.data.files[0].url; // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar, video, atau audio
 if (/image/.test(mime) || /video/.test(mime) || /audio/.test(mime)) {
 let url = await uploadToUguu(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'tourl7': {
 const fetch = require('node-fetch');
 const FormData = require('form-data');
 const fs = require('fs');
 const path = require('path');
 const fileType = require('file-type'); // Import modul file-type

 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke layanan web Videy.co
 async function uploadToVidey(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 // Baca file dan dapatkan tipe MIME menggunakan file-type
 const buffer = fs.readFileSync(filePath);
 const fileInfo = await fileType.fromBuffer(buffer);
 if (!fileInfo) {
 throw new Error("Cannot detect file type");
 }

 const formData = new FormData();
 formData.append('file', buffer, {
 filename: path.basename(filePath),
 contentType: fileInfo.mime,
 });

 const response = await fetch('https://videy.co/api/upload', {
 method: 'POST',
 body: formData,
 });

 if (!response.ok) {
 throw new Error(`Upload failed with status: ${response.status}`);
 }

 const videoData = await response.json();
 if (!videoData || !videoData.id) {
 throw new Error('Failed to get video ID from response');
 }

 return `https://cdn.videy.co/${videoData.id}.mp4`;
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar, video, atau audio
 const fileInfo = await fileType.fromFile(media);
 if (fileInfo && (fileInfo.mime.startsWith('image') || fileInfo.mime.startsWith('video') || fileInfo.mime.startsWith('audio'))) {
 let url = await uploadToVidey(media);
 m.reply(`${url}`);
 } else {
 m.reply(`Maaf, hanya gambar, video, atau audio yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'bingimg': {
 let text; // Change from const to let for reassignment
 if (args.length >= 1) {
 text = args.slice(0).join(" ");
 } else if (m.quoted && m.quoted.text) {
 text = m.quoted.text;
 } else {
 return m.m.reply("*Example:* .bingimg 1girl");
 }

 const { BingImageCreator } = require("./lib/bingimg");
 await m.reply("Please wait...");

 try {
 const res = new BingImageCreator({
 cookie: `1OQJWqw84X2IsJ3v0doRxiXup7hGX7xSlWeoaHJfO92u9XBoK2a7GPThQLfnZorFhudCLEJmYzXn6eCsESGejupcnSnfx1BAypz46osaE8OXxdZS4eqQ5FzFt3nXQnL-gmi5MTBf4iQ8te7zSpb3KgwR3BNXM5MU_WgZPNNuTA_pPjaD-CVmpavXtjGChn6w_74gathJf5NZnFQPsarSvug; WLID=mjnAuahThR9MgaUmfnMfZ/fy5VZvHX82hacSw2tYC5OocGKi8oYH7xcaLX2J1xEqLy5LpSiPGMyuSwGTbQi7XyzeqmcL+hDZO66FrMumONA=; _EDGE_S=SID=28563962BAEB61533DFA2DFDBBBD606D` // Ensure this is managed securely
 });

 const data = await res.createImage(text);

 if (data.length > 0) {
 for (let i = 0; i < data.length; i++) {
 try {
 if (!data[i].endsWith(".svg")) {
 await sky.sendFile(
 m.chat,
 data[i],
 "",
 `Image *(${i + 1}/${data.length})*\n\n*Prompt*: ${text}`,
 m,
 false,
 { mentions: [m.sender] }
 );
 }
 } catch (error) {
 console.error(`Error sending file: ${error.message}`);
 await m.reply(`Failed to send image *(${i + 1}/${data.length})*`);
 }
 }
 } else {
 await m.reply("No images found.");
 }
 } catch (error) {
 console.error(`Error in handler: ${error.message}`);
 await m.reply(`${error}\n\n${error.message}`);
 }
};
break
case 'instagram': case 'ringtone': {
if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik')
		if (!text) throw `Example : ${prefix + command} black rover`
 let { ringtone } = require('./lib/scraper')
		let anu = await ringtone(text)
		let result = anu[Math.floor(Math.random() * anu.length)]
		sky.sendMessage(m.chat, { audio: { url: result.audio }, fileName: result.title+'.mp3', mimetype: 'audio/mpeg' }, { quoted: m })
	 }
	 break
case "luminai":{
 if (!text) return m.kirim("halo?");
 try {
 if (quoted && /image/.test(quoted.mimetype)) {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, imageBuffer: await quoted.download(), user: sender })).data.result;
 m.reply(anu);
 } else {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, user: sender })).data.result;
 m.reply(anu);
 }
 } catch (e) {
 m.kirim(e);
 }}
 break
case "luminai": {
 if (!text) return m.kirim("halo?");
 try {
 if (quoted && /image/.test(quoted.mimetype)) {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, imageBuffer: await quoted.download(), user: `namaku adalah avosky aku tingal di gunung` })).data.result;
 m.reply(anu);
 } else {
 let anu = (await axios.post("https://luminai.siputzx.my.id/", { content: text, user: `namaku adalah avosky aku tingal di gunung` })).data.result;
 m.reply(anu);
 }
 } catch (e) {
 m.kirim(e);
 }}
 break
case 'cekjoin': {
 if (!m.isGroup) return m.reply('Hanya bisa digunakan di grup.');
 if (!isBotAdmins) return m.reply('Bot harus menjadi admin untuk melakukan ini.');
 
 const response = await sky.groupRequestParticipantsList(m.chat);
 if (!response || !response.length) {
 sky.sendMessage(m.chat, { text: 'Tidak ada permintaan bergabung tertunda. ✅' }, { quoted: m });
 return;
 }
 
 let replyMessage = `Daftar Permintaan Bergabung:\n`;
 response.forEach((request, index) => {
 const { jid, request_method, request_time } = request;
 
 // Mengambil hanya bagian nomor dari JID
 const jidNumber = jid.split('@')[0]; // Ambil bagian sebelum '@'
 
 const formattedTime = new Date(parseInt(request_time) * 1000).toLocaleString();
 replyMessage += `\n*No.: ${index + 1} Detail Permintaan. 👇*`;
 replyMessage += `\n*Nomor:* ${jidNumber}`;
 replyMessage += `\n*Metode:* ${request_method}`;
 replyMessage += `\n*Waktu:* ${formattedTime}\n`;
 });
 
 sky.sendMessage(m.chat, { text: replyMessage }, { quoted: m });
};
break
case 'acc': {
 const groupId = m.chat;
 const [subCommand, options] = args;
 const joinRequestList = await sky.groupRequestParticipantsList(groupId);

 const formatDate = (timestamp) => new Intl.DateTimeFormat('id-ID', {
 weekday: 'long',
 day: 'numeric',
 month: 'long',
 year: 'numeric'
 }).format(new Date(timestamp * 1000));


 switch (subCommand) {
 case 'list':
 const formattedList = joinRequestList.length > 0 ?
 joinRequestList.map((request, i) => `*${i + 1}.*\n• Nomor: ${request.jid.split('@')[0]}\n• Metode Permintaan: ${request.request_method}\n• Waktu Permintaan: ${formatDate(request.request_time)}\n\n`).join('') :
 "Tidak ada permintaan bergabung yang tertunda.";
 m.reply(`*Daftar Permintaan Bergabung:*\n\n${formattedList}`);
 break;

 case 'reject':
 case 'approve':
 if (options === "all") {
 for (const request of joinRequestList) {
 await sky.groupRequestParticipantsUpdate(groupId, [request.jid], subCommand);
 console.log(`Meng-${subCommand} participant dengan JID: ${request.jid}`);
 }
 m.reply(`*${subCommand === 'approve' ? 'Menyetujui' : 'Menolak'} semua permintaan bergabung.*`);
 } else {
 const actions = options.split('|').map(action => action.trim());
 const participants = actions.map(action => joinRequestList[parseInt(action) - 1]).filter(request => request);
 if (participants.length > 0) {
 let formattedResponse = '';
 for (const request of participants) {
 const response = await sky.groupRequestParticipantsUpdate(groupId, [request.jid], subCommand);
 const status = response[0].status === 'success' ? 'Gagal' : 'Berhasil';
 formattedResponse += `*${participants.indexOf(request) + 1}.*\n• Status: ${status}\n• Nomor: ${request.jid.split('@')[0]}\n\n`;
 console.log(`Meng-${subCommand} participant dengan JID: ${request.jid}`);
 }
 m.reply(`*${subCommand === 'approve' ? 'Menyetujui' : 'Menolak'} Permintaan Bergabung:*\n\n${formattedResponse}`);
 } else {
 m.reply("Tidak ada anggota yang cocok untuk reject/approve.");
 }
 }
 break;

 default:
 m.reply("*Perintah tidak valid.*\nGunakan:\n- *acc list*\n- *acc approve [number]*\n- *acc reject [number]*\n- *acc reject [JID]*\n- *acc reject/approve all* untuk menolak/menyetujui semua permintaan bergabung.");
 }
 }
 break
case 'emojimix2': {
 if (!text) return m.reply(`Example : ${prefix + command} 😅`)
 let anu = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(text)}`)
 for (let res of anu.results) {
 let encmedia = await sky.sendImageAsSticker(m.chat, res.url, m, {
 packname: global.packname,
 author: global.author,
 categories: res.tags
 })
 }
 }
 break
case 'cek': {
 if (!m.isGroup) throw mess.group;

 // Deteksi anggota berdasarkan awalan nomor
 const foreignMembersList = [];
 let indonesiaMembers = 0;

 for (const member of participants) {
 const countryCode = member.id.replace(/[^0-9]/g, '').substring(0, 2);
 if (countryCode !== '62' && countryCode !== '60') {
 foreignMembersList.push(`- ${member.id.split('@')[0]}`);
 } else if (countryCode === '62') {
 indonesiaMembers++;
 }
 }

 // Menampilkan list anggota luar
 if (foreignMembersList.length > 0) {
 const totalMembers = participants.length;
 const totalForeignMembers = foreignMembersList.length;
 const totalIndonesiaMembers = indonesiaMembers;

 const responseText = `🌍 *List Anggota Luar Grup*:\n${foreignMembersList.join('\n')}\n\n👤 *Total Anggota*: ${totalMembers}\n🇮🇩 *Indonesia*: ${totalIndonesiaMembers} anggota\n🌐 *Luar Indonesia*: ${totalForeignMembers} anggota`;
 
 m.reply(responseText);
 } else {
 m.reply('Tidak ada anggota luar di grup ini.');
 }
}
 break
case 'smeme': case 'smim': {
 if (!q) return m.reply(`mana text nya`);
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 const mime = require('mime-types');

 // Fungsi untuk mengunggah file ke pomf2.lain.la
 async function uploadToPomf2(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File not found");
 }

 const form = new FormData();
 form.append('files[]', fs.createReadStream(filePath));

 const response = await axios.post('https://pomf2.lain.la/upload.php', form, {
 headers: {
 ...form.getHeaders()
 }
 });

 if (response.status === 200 && response.data) {
 return response.data.files[0].url; // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload failed with status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload failed: ${err.message}`);
 }
 }
 if (text.length > 30) return m.reply(`Teksnya kebanyakan hadeh kalo ngetik ngotak lah!`);
 m.reply(mess.wait);
 try {
 var media = await sky.downloadAndSaveMediaMessage(quoted, Date.now());
 var media_url = await uploadToPomf2(media); // Menggunakan uploader ke pomf2
 var meme_url = `https://api.memegen.link/images/custom/-/${text}.png?background=${media_url}`;
 sky.sendImageAsSticker(from, meme_url, m, { packname: 'Bot By Avosky', author: `Crate By: ${pushname}` });
 await fs.unlinkSync(media); // Menghapus file sementara
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 } 
 }
break
case 'memgen': {
const fetch = require('node-fetch');
const path = require('path');
const fs = require('fs');

 if (!isCreator) return m.reply(mess.owner);

 const input = args.join(' ').trim().split('|').map(item => item.trim());

 if (input.length !== 3) {
 m.reply('Format yang kamu masukkan salah. Gunakan format: memgen template | text1 | text2\n\nList template yang tersedia:\n1. buzz\n2. y-u-no\n3. grumpycat\n4. wonka\n5. disastergirl\n6. philosoraptor\n7. drevil\n8. interesting\n9. facepalm\n10. afraid\n11. picard\n12. patrick\n13. fry\n14. captain\n15. simply\n16. onedoes\n17. sohappy\n18. noidea\n19. toohigh\n20. angry\n21. spongebob\n22. archer\n23. bender\n24. dwight\n25. morpheus\n26. joker\n27. jw\n28. ll\n29. badchoice\n30. baby\n31. wonka\n32. facepalm\n33. blb\n34. disastergirl\n35. matrix\n36. philosoraptor\n37. rollsafe\n38. success\n39. drevil\n40. afraid\n41. older\n42. patrick\n43. boat\n44. car\n45. disastergirl\n46. matrix\n47. philosoraptor\n48. rollsafe\n49. success\n50. drevil');
 return;
 }

 const template = input[0];
 const topText = encodeURIComponent(input[1]);
 const bottomText = encodeURIComponent(input[2]);

 const memeUrl = `https://api.memegen.link/images/${template}/${topText}/${bottomText}.png`;

 fetch(memeUrl)
 .then(response => response.buffer())
 .then(buffer => {
 const memePath = path.join(__dirname, 'meme.png');
 fs.writeFile(memePath, buffer, (err) => {
 if (err) {
 m.reply('Gagal membuat meme.');
 console.error(err);
 } else {
 sky.sendImageAsSticker(m.chat, memePath, m, { packname: global.packname, author: global.author })
 .then(() => {
 fs.unlinkSync(memePath);
 })
 .catch(err => {
 m.reply('Gagal mengirim stiker.');
 console.error(err);
 });
 }
 });
 })
 .catch(err => {
 m.reply('Terjadi kesalahan saat membuat meme.');
 console.error(err);
 });
}
break
case 'save': {
 if (!isPrem) return replyprem(mess.premium);
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');

 let contacts = [];
 let name = text ? text.split(' ')[1] : sky.getName(m.sender); // Mengambil nama dari input, jika ada
 let numberOfContacts = parseInt(text.split(' ')[0]); // Mengambil jumlah kontak yang akan disimpan dari input

 // Validasi jumlah kontak yang akan disimpan
 if (isNaN(numberOfContacts) || numberOfContacts <= 0) {
 m.reply('Tentukan jumlah kontak yang valid untuk disimpan.');
 return;
 }

 // Mengumpulkan sejumlah anggota grup
 for (let i = 0; i < numberOfContacts && i < participants.length; i++) {
 let member = participants[i];
 let number = member.id.split('@')[0];
 let vcard = `
BEGIN:VCARD
VERSION:3.0
FN:@${number}
TEL;type=CELL;type=VOICE;waid=${number}:${m.sender.split('@')[0]}
END:VCARD`;
 contacts.push({ vcard });
 }

 // Mengirim semua kontak dalam satu pesan
 sky.sendMessage(m.chat, { contacts: { displayName: name, contacts } }, { quoted: fkontak });
}
break
case 'freelimit': {
let { proto, generateWAMessageFromContent } = require('@whiskeysockets/baileys')

let msg = generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 "messageContextInfo": {
 "deviceListMetadata": {},
 "deviceListMetadataVersion": 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({
 text: `be fast`
 }),
 footer: proto.Message.InteractiveMessage.Footer.create({
 text: `klik di sini untuk mendapatkan limit acak 1-5000`
 }), 
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 "name": "quick_reply",
 "buttonParamsJson": `{\"display_text\":\".............................................................................................iyaiya aku emang anak haram maaf ya aku ngaku aku anak haram.........\",\"id\":\".haram\"}`
 }, 
 ],
 })
 })
 }
 }
}, {})

sky.relayMessage(msg.key.remoteJid, msg.message, {
 messageId: msg.key.id
})
}
break

case 'bible': {
const translate = require('translate-google'); // Import translate-google library
 if (!text) throw 'john 3:3'; // Default verse if no specific query provided
 const apiUrl = `https://bible-api.com/${encodeURIComponent(text)}`;

 axios.get(apiUrl)
 .then(response => {
 const bibleVerse = response.data;
 const verseTextEN = bibleVerse.text.trim(); // English verse text

 // Translate to Indonesian
 translate(verseTextEN, { to: 'id' })
 .then(translatedText => {
 const message = `🔃 Sumber: https://www.bible.com\n📖 Ayat Alkitab (${text}):\n\nEN:\n${verseTextEN}\n\nID:\n${translatedText}`;
 m.reply(message);
 })
 .catch(err => {
 console.error('Error translating verse to Indonesian:', err);
 m.reply('Maaf, terjadi kesalahan saat menerjemahkan teks.');
 });
 })
 .catch(error => {
 console.error('Error fetching Bible verse:', error);
 m.reply('Maaf, terjadi kesalahan dalam mengambil ayat Alkitab.');
 });
}
break
case 'gpt4': {

 if (!text) throw `Hello ${pushname}, may I help you?`;

 const { key } = await sky.sendMessage(from, { text: '_Please Wait..._', previewType: 0 });

 try {
 const { data } = await axios.get(`https://itzpire.com/ai/gpt?model=gpt-4&q=${encodeURIComponent(text)}`);
 await sky.sendMessage(from, { text: `${data.data.response}`.trim(), edit: key });
 } catch (error) {
 await sky.sendMessage(from, { text: 'An error occurred while processing your request.', edit: key });
 }
}
break
case 'obfuscate': {
 if (!args[0]) {
 m.reply('Harap masukkan teks yang ingin diobfuscate.');
 return;
 }

 const inputText = args.join(' ');

 function obfuscate(text) {
 let obfuscated = '';
 for (let i = 0; i < text.length; i++) {
 obfuscated += '\\u' + ('000' + text.charCodeAt(i).toString(16)).slice(-4);
 }
 return obfuscated;
 }

 const obfuscatedText = obfuscate(inputText);

 m.reply(`Teks yang diobfuscate:\n${obfuscatedText}`);
}
 break
case 'deobfuscate': {
 if (!args[0]) {
 m.reply('Harap masukkan teks yang ingin dideobfuscate.');
 return;
 }

 const inputText = args.join(' ');

 function deobfuscate(text) {
 return text.replace(/\\u([\dA-Fa-f]{4})/g, function (match, grp) {
 return String.fromCharCode(parseInt(grp, 16));
 });
 }

 const deobfuscatedText = deobfuscate(inputText);

 m.reply(`Teks yang dideobfuscate:\n${deobfuscatedText}`);
}
 break
case 'obfuscate2': {
const JavaScriptObfuscator = require('javascript-obfuscator');

 if (!isCreator) return m.reply(mess.owner);

 // Mengambil kode yang akan diobfuscate dari argumen
 const code = args.join(' ');
 if (!code) {
 m.reply('Tolong berikan kode yang ingin diobfuscate.');
 return;
 }

 // Mengobfuscate kode menggunakan JavaScript Obfuscator
 const obfuscatedCode = JavaScriptObfuscator.obfuscate(
 code,
 {
 compact: true,
 controlFlowFlattening: true,
 }
 ).getObfuscatedCode();

 // Mengirimkan kode yang telah diobfuscate kepada pengguna
 m.reply(`Kode yang telah diobfuscate:\n\n${obfuscatedCode}`);
}
break
case 'deobfuscate2': {
 if (!args[0]) {
 m.reply('Harap masukkan teks yang ingin dideobfuscate.');
 return;
 }

 const inputText = args.join(' ');

 try {
 const deobfuscate = (text) => {
 try {
 const decoded = eval(text); // Berbahaya, hanya untuk contoh
 return decoded;
 } catch (error) {
 throw new Error('Tidak dapat mendekode teks yang diberikan.');
 }
 }

 const deobfuscatedText = deobfuscate(inputText);
 m.reply(`Teks yang dideobfuscate:\n${deobfuscatedText}`);
 } catch (error) {
 m.reply(`Terjadi kesalahan saat mendekode teks: ${error.message}`);
 }
}
 break
case 'ytaudio': case 'tinyurl': {
 const targetUrl = args.join(' ');
 if (!targetUrl) {
 return m.reply('Silakan masukkan URL yang ingin diperpendek.');
 }

 const shortenUrl = async (url) => {
 try {
 const response = await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`);
 const shortenedUrl = await response.text();
 return shortenedUrl;
 } catch (error) {
 console.error(error);
 return null;
 }
 };

 shortenUrl(targetUrl).then((shortenedUrl) => {
 if (shortenedUrl) {
 m.reply(`Berhasil memperpendek URL: ${shortenedUrl}`);
 } else {
 m.reply('Terjadi kesalahan saat memperpendek URL.');
 }
 });
}
 break
 case 'gsmarena': {
 if (args.length === 0) {
 m.reply('Silakan masukkan nama perangkat yang ingin dicari.');
 return;
 }

 async function gsmSearch(q) {
 try {
 const response = await axios({
 method: "get",
 url: `https://gsmarena.com/results.php3?sQuickSearch=yes&sName=${q}`
 });
 const $ = cheerio.load(response.data);
 const result = [];
 
 const device = $(".makers").find("li");
 device.each((i, e) => {
 const img = $(e).find("img");
 result.push({
 id: $(e).find("a").attr("href").replace(".php", ""),
 name: $(e).find("span").html().split("<br>").join(" "),
 description: img.attr("title")
 });
 });
 return result;
 } catch (error) {
 console.error(error);
 throw error;
 }
 }

 gsmSearch(q).then(results => {
 if (results.length === 0) {
 m.reply('Tidak ada hasil yang ditemukan.');
 return;
 }
 
 let replyText = `Hasil pencarian untuk "${q}":\n\n`;
 results.forEach((device, index) => {
 replyText += `${index + 1}. ${device.name}\nDeskripsi: ${device.description}\nLink: https://gsmarena.com/${device.id}.php\n\n`;
 });
 
 m.reply(replyText);
 }).catch(error => {
 m.reply('Terjadi kesalahan saat mencari perangkat.');
 console.error(error);
 });
}
break

case 'smoke': {
m.reply(mess.wait)
if (!q) return m.reply(`Example : ${prefix + command} Kayla`);
let link;
if (/smoke/.test(command))
link =
 'https://photooxy.com/other-design/create-an-easy-smoke-type-effect-390.html';
 let dehe = await photooxy.photoOxy(link, q);
sky.sendMessage(
m.chat,
{ image: { url: dehe }, caption: `done`},
{ quoted: m }
);
}
break
case 'photooxy': {
 m.reply(mess.wait); // Mengirim pesan menunggu

 const [url, text] = q.split('|'); // Memisahkan URL dan teks input dari pengguna

 if (!url || !text) return m.reply(`Contoh: .photooxy <url>|<teks>`); // Memastikan ada URL dan teks yang diberikan

 const photooxy = async (url, text) => {
 const axios = require('axios');
 const FormData = require('form-data');
 const cheerio = require('cheerio');

 try {
 let form = new FormData();
 let gT = await axios.get(url, {
 headers: {
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 },
 });
 let $ = cheerio.load(gT.data);
 let token = $('input[name=token]').val();
 let build_server = $('input[name=build_server]').val();
 let build_server_id = $('input[name=build_server_id]').val();
 form.append('text[]', text);
 form.append('token', token);
 form.append('build_server', build_server);
 form.append('build_server_id', build_server_id);
 let res = await axios({
 url: url,
 method: 'POST',
 data: form,
 headers: {
 Accept: '*/*',
 'Accept-Language': 'en-US,en;q=0.9',
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 cookie: gT.headers['set-cookie']?.join('; '),
 ...form.getHeaders(),
 },
 });

 // Check if response data is empty or not valid
 if (!res.data) {
 throw new Error('Empty response or invalid JSON data');
 }

 // Parse JSON data
 let $$ = cheerio.load(res.data);
 let json = JSON.parse($$('input[name=form_value_input]').val());

 // Handle empty JSON or unexpected format
 if (!json || typeof json !== 'object') {
 throw new Error('Invalid JSON data received');
 }

 json['text[]'] = json.text;
 delete json.text;
 let { data } = await axios.post(
 'https://www.photooxy.com/effect/create-image',
 new URLSearchParams(json),
 {
 headers: {
 'user-agent':
 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
 cookie: gT.headers['set-cookie'].join('; '),
 },
 }
 );
 return build_server + data.image;
 } catch (error) {
 console.error(error);
 throw new Error('Error generating image!');
 }
 };

 try {
 let imageUrl = await photooxy(url.trim(), text.trim()); // Menghasilkan gambar dengan teks yang diberikan
 sky.sendMessage(
 m.chat,
 { image: { url: imageUrl }, caption: 'Selesai' }, // Mengirimkan gambar hasil ke pengguna
 { quoted: m }
 );
 } catch (e) {
 m.reply("Error menghasilkan gambar!"); // Menangani kesalahan dan mengirim pesan error
 console.error(e); // Log error untuk debugging
 }
}
 break
case 'obf': {
const JavaScriptObfuscator = require('javascript-obfuscator');

// Fungsi untuk menghasilkan kode JavaScript yang terenkripsi
function obfuscateCode(code) {
 const obfuscationResult = JavaScriptObfuscator.obfuscate(
 code,
 {
 compact: true,
 controlFlowFlattening: true,
 controlFlowFlatteningThreshold: 0.75,
 numbersToExpressions: true,
 simplify: true,
 shuffleStringArray: true,
 splitStrings: true,
 stringArrayThreshold: 1
 }
 );
 return obfuscationResult.getObfuscatedCode();
}
 const code = args.join(' ');
 if (!code) {
 return m.reply('Silakan masukkan kode JavaScript yang ingin Anda enkripsi.');
 }
 try {
 const obfuscatedCode = obfuscateCode(code);
 m.reply(`${obfuscatedCode}`);
 } catch (error) {
 m.reply('Terjadi kesalahan dalam melakukan enkripsi kode JavaScript.');
 }
 }
 break
case 'deobf': {
 const JavaScriptObfuscator = require('javascript-obfuscator');

 // Fungsi untuk mengembalikan kode JavaScript yang telah dienkripsi
 function deobfuscateCode(obfuscatedCode) {
 try {
 const deobfuscationResult = JavaScriptObfuscator.obfuscate(obfuscatedCode, { 
 // opsi disini
 });
 return deobfuscationResult.getObfuscatedCode(); // Mengembalikan kode yang dideobfuscate
 } catch (error) {
 return `Gagal mengembalikan kode dari obfuscation. Pesan kesalahan: ${error.message}`;
 }
 }

 const obfuscatedCode = args.join(' ');
 if (!obfuscatedCode) {
 return m.reply('Silakan masukkan kode JavaScript yang telah dienkripsi.');
 }

 try {
 const deobfuscatedCode = deobfuscateCode(obfuscatedCode);
 m.reply(`${deobfuscatedCode}`);
 } catch (error) {
 m.reply(`Terjadi kesalahan dalam melakukan deobfuscation kode JavaScript: ${error.message}`);
 }
}
break

case 'ttaudio': case 'tiktokaudio': {
try {
if (!text) return m.reply(`Example : ${prefix + command} link`)
m.reply(mess.wait)
axios.get(`https://widipe.com/download/ttdl?url=${q}`).then(({ data }) => {
				sky.sendMessage(from, { audio: { url: data.result.audio[0] }, mimetype: "audio/mp4", fileName: "Audio" }, { quoted: m })
			})			
} catch (err) {
console.log(err)
m.reply('Terjadi Kesalahan')
}
}
break
 case 'backup': {
 if (!isCreator) return m.reply('Perintah ini hanya bisa digunakan oleh creator');
 
 let jir = m.mentionedJid[0] || m.sender || sky.parseMention(args[0]) || (args[0].replace(/[@.+-]/g, '').replace(' ', '') + '@s.whatsapp.net') || '';
 
 // Mengirim pesan load
 await m.reply('Load...');

 const { execSync } = require("child_process");
 const fs = require('fs');
 
 // Mendapatkan daftar direktori dan file
 const ls = execSync("ls").toString().split("\n").filter((pe) =>
 pe != "node_modules" &&
 pe != "session" &&
 pe != "package-lock.json" &&
 pe != "yarn.lock" &&
 pe != ""
 );

 // Mengirim pesan proses backup
 await m.reply('Backup akan dimulai');

 try {
 // Membuat backup zip
 execSync(`zip -r Backup.zip ${ls.join(" ")}`);

 // Membaca file zip dan mengirimnya
 const backupFile = fs.readFileSync("./Backup.zip");
 await sky.sendMessage(jir, {
 document: backupFile,
 mimetype: "application/zip",
 fileName: "Backup.zip",
 }, { quoted: m });

 // Menghapus file zip setelah dikirim
 execSync("rm -rf Backup.zip");
 } catch (error) {
 console.error("Terjadi kesalahan saat membuat atau mengirim backup:", error);
 await m.reply('Terjadi kesalahan saat membuat backup.');
 }
}
break
case 'delhome': {
 if (!isCreator) return m.reply('Perintah ini hanya bisa digunakan oleh creator');

 let directoryPath = path.join('./'); // Jika ingin memeriksa direktori lain, sesuaikan path-nya

 fs.readdir(directoryPath, async function (err, files) {
 if (err) {
 return m.reply('Tidak dapat memindai direktori: ' + err);
 } 

 let filteredArray = files.filter(item => 
 item.endsWith("gif") || 
 item.endsWith("zip") || 
 item.endsWith("png") || 
 item.endsWith("mp3") || 
 item.endsWith("mp4") || 
 item.endsWith("jpg") || 
 item.endsWith("jpeg") || 
 item.endsWith("webp") || 
 item.endsWith("webm")
 );

 let teks = `Terdeteksi ${filteredArray.length} file sampah di direktori home\n\n`;
 if (filteredArray.length == 0) return m.reply(teks);

 filteredArray.forEach(function(e, i) {
 teks += (i + 1) + `. ${e}\n`;
 });

 m.reply(teks);

 await sleep(2000);
 m.reply("_Proses membersihkan home..._");

 let deletedFiles = [];
 filteredArray.forEach(function (file) {
 fs.unlinkSync(path.join(directoryPath, file)); // Menghapus file dari direktori
 deletedFiles.push(file); // Menambahkan file yang dihapus ke dalam daftar
 });

 await sleep(2000);
 
 let deletedTeks = "Berhasil membersihkan file berikut:\n\n";
 deletedFiles.forEach(function(file, i) {
 deletedTeks += (i + 1) + `. ${file}\n`;
 });

 m.reply(deletedTeks);
 });
}
break
case 'infocuaca': {
 const weather = require('weather-js');
 if (!isCreator) return m.reply(mess.owner);

 // Ambil nama kota dari args
 const cityName = args.join(' ');

 // Validasi nama kota
 if (!cityName) {
 m.reply('🌍 Tentukan nama kota untuk mendapatkan informasi cuaca.');
 return;
 }

 // Mengambil data cuaca dari weather-js
 weather.find({ search: cityName, degreeType: 'C' }, function(err, result) {
 if (err) {
 m.reply('❌ Terjadi kesalahan saat mengambil data cuaca.');
 console.error(err);
 return;
 }

 if (!result || result.length === 0) {
 m.reply('❌ Gagal mendapatkan data cuaca. Pastikan nama kota benar.');
 return;
 }

 // Ambil detail cuaca dari result
 const location = result[0].location.name || 'N/A';
 const current = result[0].current;
 const forecast = result[0].forecast[1]; // Ambil prediksi cuaca untuk hari berikutnya

 // Tentukan emotikon berdasarkan kondisi cuaca
 const weatherIcons = {
 'Sunny': '☀️',
 'Clear': '🌕',
 'Partly Cloudy': '⛅',
 'Cloudy': '☁️',
 'Rain': '🌧️',
 'Thunderstorm': '⛈️',
 'Snow': '❄️',
 'Fog': '🌫️'
 };
 const currentIcon = weatherIcons[current.skytext] || '🌈';
 const forecastIcon = weatherIcons[forecast.skytextday] || '🌈';

 // Buat pesan detail cuaca
 const weatherDetail = `🌆 Cuaca di *${location}*:\n\n` +
 `${currentIcon} *Deskripsi:* ${current.skytext || 'N/A'}\n` +
 `🌡️ *Suhu:* ${current.temperature || 'N/A'}°C\n` +
 `🌡️ *Terasa Seperti:* ${current.feelslike || 'N/A'}°C\n` +
 `💧 *Kelembapan:* ${current.humidity || 'N/A'}%\n` +
 `🌬️ *Kecepatan Angin:* ${current.winddisplay || 'N/A'}\n` +
 `🌡️ *Suhu Maksimum:* ${forecast.high || 'N/A'}°C\n` +
 `🌡️ *Suhu Minimum:* ${forecast.low || 'N/A'}°C`;

 // Kirim pesan detail cuaca
 m.reply(weatherDetail);
 });
}
break

case 'volvid': {
 const { TelegraPh } = require('./lib/uploader');
 const ffmpeg = require('fluent-ffmpeg');
 const fs = require('fs');
 
 const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? sky.user.jid : m.sender;
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!mime || !mime.includes('video')) return m.reply(`Mana videonya bang?`);
 
 const volume = parseFloat(args[0]) || 1;
 if (isNaN(volume) || volume <= 0) return m.reply('Tentukan volume yang valid (contoh: 0.5 untuk setengah, 2 untuk dua kali lipat)');
 
 m.reply(mess.wait);
 
 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.mp4';
 
 ffmpeg(media)
 .audioFilters(`volume=${volume}`)
 .on('start', (commandLine) => {
 console.log(`Spawned Ffmpeg with command: ${commandLine}`);
 })
 .on('error', async (err) => {
 console.error(`Error: ${err.message}`);
 await fs.promises.unlink(media).catch(console.error);
 return m.reply(`Error: ${err.message}`);
 })
 .on('end', async () => {
 console.log('Video processed');
 
 try {
 const url = await TelegraPh(output);
 await fs.promises.unlink(output);
 await fs.promises.unlink(media);
 
 sky.sendMessage(m.chat, { caption: `_Success To Change Video Volume_`, video: { url } }, { quoted: m });
 } catch (err) {
 console.error(`Error uploading video: ${err.message}`);
 await fs.promises.unlink(media).catch(console.error);
 return m.reply(`Error uploading video: ${err.message}`);
 }
 })
 .save(output);
 } catch (err) {
 console.error(`Error processing video: ${err.message}`);
 return m.reply(`Error processing video: ${err.message}`);
 }
}
break
case 'sky': {
 if (!text) return m.reply("_lu manggil gua_");

 const axios = require('axios');

 async function luminAi(teks, pengguna = null, prompt = null, modePencarianWeb = false, imageBuffer = null) {
 try {
 const data = { content: teks };
 if (pengguna !== null) data.user = pengguna;
 if (prompt !== null) data.prompt = prompt;
 data.webSearchMode = modePencarianWeb;
 if (imageBuffer !== null) data.imageBuffer = imageBuffer;

 const response = await axios.post("https://luminai.my.id/", data);
 return response.data.result;
 } catch (error) {
 console.error('Terjadi kesalahan saat menggunakan LuminAI:', error);
 throw error; // Rethrow the error to handle it in the caller function
 }
 }

 const teks = args.join(' ');
 const pengguna = `${m.sender.split('@')[0]}`; 
 const prompt = `aku adalah orang yang bernama avosky atau iky aku tinggal di sebuah tempat yang bernama isekai dan aku di temani 100 harem dengan dada yang besar, dan 1 hal yang aku ingat adalah aku tidak akan membalas pesan orang dengan bahasa inggris aku hanya membalas dengan bahasa Indonesia`;
 const modePencarianWeb = false;

 try {
 let result;
 if (quoted && /image/.test(quoted.mimetype)) {
 const imageBuffer = await quoted.download();
 result = await luminAi(teks, pengguna, prompt, modePencarianWeb, imageBuffer);
 } else {
 result = await luminAi(teks, pengguna, prompt, modePencarianWeb);
 }
 m.reply(`${result}`);
 } catch (error) {
 m.reply('Terjadi kesalahan saat menggunakan LuminAI.');
 console.error('Error LuminAI:', error);
 }
}
break

case 'alldl': {
 if (!args.length) return m.reply('Tolong masukkan URL yang valid.');

 const url = args[0];

 async function alldl(url) {
 const req = {
 version: "7.14.6",
 commit: "2f4e43f",
 branch: "current",
 name: "olly",
 url: url,
 cors: 1,
 startTime: Date.now().toString()
 };

 const header = {
 'Accept': 'application/json',
 'Content-Type': 'application/json',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/126.0.0.0 Mobile Safari/537.36',
 'Referer': 'https://cobalt.tools/'
 };

 try {
 const resp = await fetch('https://api.cobalt.tools/api/json', {
 method: 'POST',
 headers: header,
 body: JSON.stringify(req)
 });

 if (resp.ok) {
 const data = await resp.json();
 return data;
 } else {
 const errorData = await resp.text(); // Mendapatkan pesan kesalahan dari respons
 return {
 status: false,
 message: 'Permintaan tidak dapat diproses',
 error: errorData
 };
 }
 } catch (error) {
 return {
 status: false,
 message: 'Kesalahan saat mengirim permintaan',
 error: error.message
 };
 }
 }

 alldl(url).then(result => {
 if (result.status === 'stream' && result.url) {
 sky.sendMessage(from, { 
 audio: { url: result.url }, 
 mimetype: "audio/mp4", 
 fileName: "Audio" 
 }, { quoted: m })
 .then(() => {
 console.log('Audio berhasil dikirim');
 })
 .catch(audioError => {
 console.error('Gagal mengirim audio:', audioError);
 sky.sendMessage(from, { 
 video: { url: result.url }, 
 mimetype: "video/mp4", 
 fileName: "Video" 
 }, { quoted: m })
 .then(() => {
 console.log('Video berhasil dikirim');
 })
 .catch(videoError => {
 console.error('Gagal mengirim video:', videoError);
 m.reply(`Gagal mengirim audio dan video: ${videoError.message}`);
 });
 });
 } else {
 m.reply(`Gagal mendownload audio: ${result.message || result.error}`);
 }
 }).catch(error => {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 });
}
 break
case 'cekallmem': {
 let PhoneNum = require("awesome-phonenumber");
 let regionNames = new Intl.DisplayNames(["en"], {
 type: "region",
 });
 let data = await sky.groupMetadata(m.chat);
 let arr = [];
 for (let i of data.participants) {
 arr.push({
 number: i.id,
 code: regionNames.of(PhoneNum("+" + i.id.split("@")[0]).getRegionCode("internasional")),
 });
 }
 let json = {};
 for (let contact of arr) {
 let country = contact.code;
 json[country] = (json[country] || 0) + 1;
 }
 let countryCounts = Object.keys(json).map((country) => ({
 name: country,
 total: json[country],
 }));
 let totalSum = countryCounts.reduce((acc, country) => acc + country.total, 0);
 let totalRegion = [...new Set(arr.map(a => a.code))]
 let hasil = countryCounts.map(({
 name,
 total
 }) => ({
 name,
 total,
 percentage: ((total / totalSum) * 100).toFixed(2) + '%'
 }));
 let cap = `┌─ _Jumlah Member_
│ > 𝘕𝘢𝘮𝘦 : ${data.subject}
│ > 𝘛𝘰𝘵𝘢𝘭 : ${data.participants.length}
│ > 𝘛𝘰𝘵𝘢𝘭 𝘙𝘦𝘨𝘪𝘰𝘯 : ${totalRegion.length}
└───────────────

┌─ _Asal Member_
${hasil.sort((b, a) => a.total - b.total).map(a => `│ > 𝘙𝘦𝘨𝘪𝘰𝘯 : ${a.name} > [ ${a.percentage} ]
│ > 𝘛𝘰𝘵𝘢𝘭 : ${a.total} 𝘔𝘦𝘮𝘣𝘦𝘳`).join("\n")}
└───────────────`
 m.reply(`${cap}`)
 }
 break
 case 'maker': {
  version = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
  ky = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
  if (!text) {
    m.reply('Harap berikan teks untuk logo\n\n> maker v1 | text.');
    return;
  }
  let url = '';
  switch (version) {
    case 'v1':
      url = `https://dynamic.brandcrowd.com/asset/logo/04ca85c5-a4c1-4582-8296-7fb8cbdf7df1/logo?v=4&text=${ky}`;
      break;
    case 'v2':
      url = `https://dynamic.brandcrowd.com/asset/logo/063a3d53-d7bb-4abb-8b20-3e45ae7c61ac/logo?v=4&text=${ky}`;
      break;
    case 'v3':
      url = `https://dynamic.brandcrowd.com/asset/logo/065b4535-d123-4261-accb-2f21e3eac3cf/logo?v=4&text=${ky}`;
      break;
    case 'v4':
      url = `https://dynamic.brandcrowd.com/asset/logo/09699c93-f687-4c58-b6dc-cb8010de7df9/logo?v=4&text=${ky}`;
      break;
    case 'v5':
      url = `https://dynamic.brandcrowd.com/asset/logo/097b9969-5019-433a-9a3f-d2e097b50e99/logo?v=4&text=${ky}`;
      break;
    case 'v6':
      url = `https://dynamic.brandcrowd.com/asset/logo/0c963355-e735-4cdd-bec8-1373ba2a222e/logo?v=4&text=${ky}`;
      break;
    case 'v7':
      url = `https://dynamic.brandcrowd.com/asset/logo/0cd45dda-e1e6-46bc-9f0d-b49a5d3c3667/logo?v=4&text=${ky}`;
      break;
    case 'v8':
      url = `https://dynamic.brandcrowd.com/asset/logo/10cd8160-2b8d-41c5-87cc-f683a853d5d9/logo?v=4&text=${ky}`;
      break;
    case 'v9':
      url = `https://dynamic.brandcrowd.com/asset/logo/163db786-9e2a-494a-a996-de565ae52f83/logo?v=4&text=${ky}`;
      break;
    case 'v10':
      url = `https://dynamic.brandcrowd.com/asset/logo/1e47fc81-0c56-45d5-aa5e-07006260dfbc/logo?v=4&text=${ky}`;
      break;
    case 'v11':
      url = `https://dynamic.brandcrowd.com/asset/logo/1fd728fb-fdb3-4407-a7da-fe55bfcb5fb0/logo?v=4&text=${ky}`;
      break;
    case 'v12':
      url = `https://dynamic.brandcrowd.com/asset/logo/236a12ee-2b79-4b58-b9e4-5536f5e93db7/logo?v=4&text=${ky}`;
      break;
    case 'v13':
      url = `https://dynamic.brandcrowd.com/asset/logo/2648d66c-fec5-488f-9626-06991ca917e0/logo?v=4&text=${ky}`;
      break;
    case 'v14':
      url = `https://dynamic.brandcrowd.com/asset/logo/362270db-6933-4ccc-8c11-25b2fe97f023/logo?v=4&text=${ky}`;
      break;
    case 'v15':
      url = `https://dynamic.brandcrowd.com/asset/logo/4a0312ef-6f47-421d-9d10-354c27de8e0f/logo?v=4&text=${ky}`;
      break;
    case 'v16':
      url = `https://dynamic.brandcrowd.com/asset/logo/50dd554f-ffed-4496-b770-870fef2aefe5/logo?v=4&text=${ky}`;
      break;
    case 'v17':
      url = `https://dynamic.brandcrowd.com/asset/logo/5ed1f95d-736f-4fe3-9aec-d0a8875dee17/logo?v=4&text=${ky}`;
      break;
    case 'v18':
      url = `https://dynamic.brandcrowd.com/asset/logo/6458e177-55ec-4b2d-8be7-4094431378ad/logo?v=4&text=${ky}`;
      break;
    case 'v19':
      url = `https://dynamic.brandcrowd.com/asset/logo/672fc6e7-e445-47e3-9391-2e1d1452960a/logo?v=4&text=${ky}`;
      break;
    case 'v20':
      url = `https://dynamic.brandcrowd.com/asset/logo/7229c0d6-cc4f-4e47-87b2-3b01285f502d/logo?v=4&text=${ky}`;
      break;
    case 'v21':
      url = `https://dynamic.brandcrowd.com/asset/logo/73113e56-8ac2-484e-9272-06759b7d51e2/logo?v=4&text=${ky}`;
      break;
    case 'v22':
      url = `https://dynamic.brandcrowd.com/asset/logo/7429f9b9-562f-439b-86cd-81f04d76d883/logo?v=4&text=${ky}`;
      break;
    case 'v23':
      url = `https://dynamic.brandcrowd.com/asset/logo/746604d3-8da9-4488-8fa9-bf301d62ea0e/logo?v=4&text=${ky}`;
      break;
    case 'v24':
      url = `https://dynamic.brandcrowd.com/asset/logo/867bea51-793c-4b09-b13f-44c9053b6754/logo?v=4&text=${ky}`;
      break;
    case 'v25':
      url = `https://dynamic.brandcrowd.com/asset/logo/882f41c2-98ee-43f2-bf07-f033cf1c3320/logo?v=4&text=${ky}`;
      break;
    case 'v26':
      url = `https://dynamic.brandcrowd.com/asset/logo/8a2d089b-7b87-4979-906e-7731b594bd4b/logo?v=4&text=${ky}`;
      break;
    case 'v27':
      url = `https://dynamic.brandcrowd.com/asset/logo/8bb23d1a-7fb2-4f5d-ba6c-2a9bd13cc673/logo?v=4&text=${ky}`;
      break;
    case 'v28':
      url = `https://dynamic.brandcrowd.com/asset/logo/8dcc7e92-c12c-40df-8c8b-9f9db93b11a0/logo?v=4&text=${ky}`;
      break;
    case 'v29':
      url = `https://dynamic.brandcrowd.com/asset/logo/8f825f13-dadf-442c-b9e5-a1daa03611c4/logo?v=4&text=${ky}`;
      break;
    case 'v30':
      url = `https://dynamic.brandcrowd.com/asset/logo/8ffdc28c-ea27-4b0c-89c3-3f9a9b40e5fd/logo?v=4&text=${ky}`;
      break;
    case 'v31':
      url = `https://dynamic.brandcrowd.com/asset/logo/912b6462-49d3-435a-959e-5c5f3254d6c4/logo?v=4&text=${ky}`;
      break;
    case 'v32':
      url = `https://dynamic.brandcrowd.com/asset/logo/924d12da-4a2b-46b3-82cd-bc9b38a519d0/logo?v=4&text=${ky}`;
      break;
    case 'v33':
      url = `https://dynamic.brandcrowd.com/asset/logo/9459965a-f378-430a-8cb9-62778fec5713/logo?v=4&text=${ky}`;
      break;
    case 'v34':
      url = `https://dynamic.brandcrowd.com/asset/logo/9608708e-7907-4bae-892c-87964aee0454/logo?v=4&text=${ky}`;
      break;
        case 'v35':
      url = `https://dynamic.brandcrowd.com/asset/logo/963fcb8b-1ba3-46f1-82bd-8e92a5a024d1/logo?v=4&text=${ky}`;
      break;
    case 'v36':
      url = `https://dynamic.brandcrowd.com/asset/logo/99c6feef-cee4-47b3-afc7-1f192e7f48f4/logo?v=4&text=${ky}`;
      break;
    case 'v37':
      url = `https://dynamic.brandcrowd.com/asset/logo/a075034f-0363-4af4-877f-aba47a7c059d/logo?v=4&text=${ky}`;
      break;
    case 'v38':
      url = `https://dynamic.brandcrowd.com/asset/logo/a428ed89-5ed1-4b1d-b095-2ee98ae54b40/logo?v=4&text=${ky}`;
      break;
    case 'v39':
      url = `https://dynamic.brandcrowd.com/asset/logo/afa0be93-d4ae-46d5-b741-64bd3b4b6148/logo?v=4&text=${ky}`;
      break;
    case 'v40':
      url = `https://dynamic.brandcrowd.com/asset/logo/b0fb81f5-59a4-4197-947f-26037441ea2f/logo?v=4&text=${ky}`;
      break;
    case 'v41':
      url = `https://dynamic.brandcrowd.com/asset/logo/b1826077-0a6f-403d-939e-b445c334c470/logo?v=4&text=${ky}`;
      break;
    case 'v42':
      url = `https://dynamic.brandcrowd.com/asset/logo/b3581ffd-a127-465b-b880-bd3770b85aad/logo?v=4&text=${ky}`;
      break;
    case 'v43':
      url = `https://dynamic.brandcrowd.com/asset/logo/b5be66f6-a6a6-42dc-ab67-de8f80e96291/logo?v=4&text=${ky}`;
      break;
    case 'v44':
      url = `https://dynamic.brandcrowd.com/asset/logo/b5e150af-101d-4e96-9518-dff66548dc31/logo?v=4&text=${ky}`;
      break;
    case 'v45':
      url = `https://dynamic.brandcrowd.com/asset/logo/b8b4fc21-d1b6-4ee1-a6f3-4410a49e123a/logo?v=4&text=${ky}`;
      break;
    case 'v46':
      url = `https://dynamic.brandcrowd.com/asset/logo/b95516e4-645d-4249-b81b-b9ca65bd2087/logo?v=4&text=${ky}`;
      break;
    case 'v47':
      url = `https://dynamic.brandcrowd.com/asset/logo/b97103b8-3b7c-4f1d-8c91-451c11e8cde3/logo?v=4&text=${ky}`;
      break;
    case 'v48':
      url = `https://dynamic.brandcrowd.com/asset/logo/bbf8e7fe-13c2-420c-bb2c-9c059744d599/logo?v=4&text=${ky}`;
      break;
    case 'v49':
      url = `https://dynamic.brandcrowd.com/asset/logo/bd9069cc-408d-4f00-90b4-9d6c96bc0b3d/logo?v=4&text=${ky}`;
      break;
    case 'v50':
      url = `https://dynamic.brandcrowd.com/asset/logo/be638691-3065-45cb-b90c-263945cd0177/logo?v=4&text=${ky}`;
      break;
    case 'v51':
      url = `https://dynamic.brandcrowd.com/asset/logo/c054d202-df4b-466d-8477-2b8690030ce5/logo?v=4&text=${ky}`;
      break;
    case 'v52':
      url = `https://dynamic.brandcrowd.com/asset/logo/c1e008df-5207-463e-a6a7-a823174d0bda/logo?v=4&text=${ky}`;
      break;
    case 'v53':
      url = `https://dynamic.brandcrowd.com/asset/logo/cc9a22ce-f65c-40ff-9eac-43c26817f44a/logo?v=4&text=${ky}`;
      break;
    case 'v54':
      url = `https://dynamic.brandcrowd.com/asset/logo/d588330f-b11c-4482-baff-49323323a8c0/logo?v=4&text=${ky}`;
      break;
    case 'v55':
      url = `https://dynamic.brandcrowd.com/asset/logo/e32a0e7e-df48-4b33-bccf-1f74d395d322/logo?v=4&text=${ky}`;
      break;
    case 'v56':
      url = `https://dynamic.brandcrowd.com/asset/logo/ee1930f1-09a8-4d5e-bbe9-e43547bb7f64/logo?v=4&text=${ky}`;
      break;
    case 'v57':
      url = `https://dynamic.brandcrowd.com/asset/logo/fde5293a-c69b-4d77-9ec8-f3d6797d2b15/logo?v=4&text=${ky}`;
      break;
    case 'v58':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=${ky}`;
      break;
    case 'v59':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=${ky}`;
      break;
    case 'v60':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text=${ky}`;
      break;
    case 'v61':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=${ky}`;
      break;
    case 'v62':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=${ky}`;
      break;
    case 'v63':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=arcade-logo&text=${ky}`;
      break;
    case 'v64':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=dance-logo&text=${ky}`;
      break;
    case 'v65':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=emperor-logo&text=${ky}`;
      break;
    case 'v66':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=flame-logo&text=${ky}`;
      break;
    case 'v67':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=matrix-logo&text=${ky}`;
      break;
    case 'v68':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=robot-logo&text=${ky}`;
      break;
        case 'v69':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=robot-logo&text=${ky}`;
      break;
    case 'v70':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=shadow-logo&text=${ky}`;
      break;
    case 'v71':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=silhouette-logo&text=${ky}`;
      break;
    case 'v72':
      url = `https://flamingtext.com/net-fu/proxy_form.cgi?imageoutput=true&script=smooth-logo&text=${ky}`;
      break;
    default:
      m.reply('Versi tidak dikenal. Silakan gunakan versi dari v1 hingga v72.');
      return;
  }  
  sky.sendFile(m.chat, url, 'maker.jpg', `Logo versi ${version}`, m);
}
break
case 'sfull': {
 const { exec } = require('child_process');
 const fs = require('fs');
 const path = require('path');

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime || !mime.includes('image')) return m.reply(`Mana gambarnya bang?`);
 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.webp'; // Nama file output

 // Menggunakan ffmpeg untuk mengonversi gambar menjadi stiker dengan padding
 exec(`ffmpeg -i ${media} -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2" -f webp -frames:v 1 ${output}`, (err, stdout, stderr) => {
 if (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }

 console.log(`Stiker processed: ${stdout}`);

 // Mengirim stiker yang telah dibuat
 sky.sendFile(m.chat, output, 'sticker.webp', '', m, false, { asSticker: true });

 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }
}
break
case 'text2img': {
 const fetch = require('node-fetch');
 
 async function text2img(prompt) {
 const vredenapi = "https://ai-api.magicstudio.com/api/ai-art-generator";
 const body = `prompt=${encodeURIComponent(prompt)}`;

 try {
 const response = await fetch(vredenapi, {
 method: 'POST',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded'
 },
 body: body
 });

 if (response.ok) {
 const imageBuffer = await response.buffer();
 return imageBuffer;
 } else {
 const responseError = await response.text();
 throw new Error(`Gagal mengambil gambar. Kode status: ${response.status}, Error: ${responseError}`);
 }
 } catch (error) {
 throw error;
 }
 }

 // Memanggil fungsi text2img dengan argumen prompt yang diberikan (q)
 text2img(`${q}`).then((imageBuffer) => {
 sky.sendMessage(m.chat, { image: imageBuffer, caption: `_doneeeee_` }, { quoted: m });
 }).catch((error) => {
 m.reply(`Error: ${error.message}`);
 });
}
break
case 'play2': {
 if (!text) return m.reply("_Lagu apa_?");

 const Ytdl = require('./lib/y2mate');
 const yts = require('yt-search');
 const axios = require('axios');
 const stream = require('stream');

 await sky.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

 try {
 // Search for the video using yts
 const searchResults = await yts(text);
 const videos = searchResults.all.filter(v => v.type === 'video');
 if (!videos.length) {
 await sky.sendMessage(m.chat, 'No videos found for your query.', { quoted: m });
 return;
 }

 // Get the first video result
 const video = videos[0];
 const ytdl = new Ytdl();
 const result = await ytdl.play(video.url);
 const title = result.title;

 // Choose the highest quality available audio
 const highestQuality = Object.keys(result.audio).reduce((a, b) => (a > b ? a : b));
 const audioUrl = result.audio[highestQuality].url;

 // Stream the audio directly
 const audioStream = (await axios.get(audioUrl, { responseType: 'stream' })).data;
 const audioBuffer = [];

 audioStream.on('data', chunk => audioBuffer.push(chunk));
 audioStream.on('end', async () => {
 const buffer = Buffer.concat(audioBuffer);
 await sky.sendMessage(m.chat, {
 audio: buffer,
 mimetype: 'audio/mpeg',
 ptt: false, // Set to true if you want to send it as a voice note
 contextInfo: {
 externalAdReply: {
 title: title,
 body: `Audio quality: ${highestQuality}`,
 mediaType: 2,
 mediaUrl: audioUrl,
 sourceUrl: audioUrl,
 renderLargerThumbnail: true
 }
 }
 });

 await sky.sendMessage(m.chat, { react: { text: "✅", key: m.key } });
 });

 } catch (error) {
 console.error('Error:', error);
 if (error.response && error.response.status === 403) {
 await sky.sendMessage(m.chat, 'Download forbidden. Try another video or check your connection.', { quoted: m });
 } else {
 await sky.sendMessage(m.chat, 'Error occurred while processing your request.', { quoted: m });
 }
 }
}
break
case 'openport': {
 const net = require('net');
 const websiteUrl = args[0];

 if (!websiteUrl) {
 m.reply('Tentukan URL website yang ingin diperiksa portnya.');
 return;
 }

 // Daftar port umum dan nama portnya
 const ports = {
 21: 'FTP',
 22: 'SSH',
 23: 'Telnet',
 25: 'SMTP',
 53: 'DNS',
 80: 'HTTP',
 110: 'POP3',
 143: 'IMAP',
 443: 'HTTPS',
 587: 'SMTP (secure)',
 993: 'IMAP (secure)',
 995: 'POP3 (secure)',
 };

 let openPorts = [];

 const checkPort = (port) => {
 return new Promise((resolve) => {
 const socket = new net.Socket();
 const timeout = 2000; // 2 detik

 socket.setTimeout(timeout);
 socket.on('connect', () => {
 openPorts.push(port);
 socket.destroy();
 resolve();
 });
 socket.on('timeout', () => {
 socket.destroy();
 resolve();
 });
 socket.on('error', () => {
 resolve();
 });
 socket.connect(port, websiteUrl);
 });
 };

 const checkAllPorts = async () => {
 for (const port of Object.keys(ports)) {
 await checkPort(port);
 }

 if (openPorts.length === 0) {
 m.reply(`Tidak ada port terbuka pada ${websiteUrl}.`);
 } else {
 let openPortsDetails = openPorts.map(port => `${port} (${ports[port]})`).join('\n');
 m.reply(`Port terbuka pada ${websiteUrl}:\n${openPortsDetails}`);
 }
 };

 checkAllPorts();
}
break
case 'tourl8': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');

 m.reply(mess.wait); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke storage.netorare.codes
 function uploadToNetorare(Path) {
 return new Promise(async (resolve, reject) => {
 if (!fs.existsSync(Path)) return reject(new Error("File not Found"));
 try {
 const form = new FormData();
 form.append("file", fs.createReadStream(Path));

 const response = await axios.post("https://storage.netorare.codes/uploader/file", form, {
 headers: form.getHeaders(),
 });

 if (response.data.status) {
 resolve(response.data.result.url); // Mengembalikan URL file yang diunggah
 } else {
 reject(new Error(response.data.message));
 }
 } catch (err) {
 reject(new Error(String(err)));
 }
 });
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah gambar
 let anu = await uploadToNetorare(media);
 m.reply(util.format(anu));

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break

case 'fully': {
 const sharp = require('sharp');
 const fs = require('fs');

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime || !mime.includes('image')) return m.reply(`Mana gambarnya bang?`);
 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output_square.jpg'; // Nama file output

 // Menggunakan sharp untuk mengubah gambar lonjong menjadi kotak tanpa cropping
 sharp(media)
 .resize(1080, 1080, { fit: 'fill' }) // Resize gambar ke ukuran kotak 1080x1080 piksel tanpa menjaga aspek rasio
 .toFile(output)
 .then(() => {
 // Mengirim gambar yang telah diubah sebagai stiker
 sky.sendFile(m.chat, output, '', '', m)
 .then(() => {
 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 })
 .catch(err => {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 });
 })
 .catch(err => {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 });
 } catch (err) {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 }
}
break
case 'fillvideo': {
 const { TelegraPh } = require('./lib/uploader');
 const ffmpeg = require('fluent-ffmpeg');
 const fs = require('fs');

 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';

 if (!mime || !mime.includes('video')) return m.reply(`Mana videonya bang?`);
 m.reply(mess.wait);

 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const output = 'output.mp4'; // Nama file output

 // Menggunakan ffmpeg untuk mengubah ukuran video menjadi kotak
 ffmpeg(media)
 .videoCodec('libx264')
 .audioCodec('aac')
 .videoFilter([
 'scale=1280:1280:force_original_aspect_ratio=increase',
 'crop=1280:1280'
 ]) // Mengubah ukuran dan memotong video
 .format('mp4')
 .on('end', async () => {
 console.log('Video processing finished.');

 // Mengunggah video yang telah diproses
 const url = await TelegraPh(output);
 sky.sendVideoAsSticker(m.chat, url, m, { packname: global.packname, author: global.author })
 
 // Menghapus file setelah selesai
 fs.unlinkSync(output);
 fs.unlinkSync(media);
 })
 .on('error', (err) => {
 console.error(`Error: ${err.message}`);
 m.reply(`Error: ${err.message}`);
 })
 .save(output);
 } catch (err) {
 console.error(`Error: ${err.message}`);
 return m.reply(`Error: ${err.message}`);
 }
}
break
case 'bukalapak': {
 if (!text) throw `cari apa?`
 function BukaLapak(search) {
 return new Promise(async (resolve, reject) => {
 try {
 const { data } = await axios.get(`https://www.bukalapak.com/products?from=omnisearch&from_keyword_history=false&search[keywords]=${q}&search_source=omnisearch_keyword&source=navbar`, {
 headers: {
 "user-agent": 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0'
 }
 });
 const $ = cheerio.load(data);
 const dat = [];
 $('div.bl-flex-item.mb-8').each((i, u) => {
 const a = $(u).find('observer-tracker > div > div');
 const img = $(a).find('div > a > img').attr('src');
 if (!img) return;

 const link = $(a).find('.bl-thumbnail--slider > div > a').attr('href');
 const title = $(a).find('.bl-product-card__description-name > p > a').text().trim();
 const harga = $(a).find('div.bl-product-card__description-price > p').text().trim();
 const rating = $(a).find('div.bl-product-card__description-rating > p').text().trim();
 const terjual = $(a).find('div.bl-product-card__description-rating-and-sold > p').text().trim();

 const dari = $(a).find('div.bl-product-card__description-store > span:nth-child(1)').text().trim();
 const seller = $(a).find('div.bl-product-card__description-store > span > a').text().trim();
 const link_sel = $(a).find('div.bl-product-card__description-store > span > a').attr('href');

 const res_ = {
 title: title,
 rating: rating ? rating : 'No rating yet',
 terjual: terjual ? terjual : 'Not yet bought',
 harga: harga,
 image: img,
 link: link,
 store: {
 lokasi: dari,
 nama: seller,
 link: link_sel
 }
 };

 dat.push(res_);
 });
 if (dat.every(x => x === undefined)) return resolve({ message: 'Tidak ada result!' });
 resolve(dat);
 } catch (err) {
 console.error(err);
 reject(err);
 }
 });
 }
 BukaLapak(`${q}`).then(results => {
 if (results.message) {
 m.reply(results.message);
 return;
 } 
 let replyText = `Hasil pencarian untuk "${q}":\n\n`;
 results.forEach((item, index) => {
 replyText += `*${index + 1}. ${item.title}*\n`;
 replyText += `Harga: ${item.harga}\n`;
 replyText += `Rating: ${item.rating}\n`;
 replyText += `Terjual: ${item.terjual}\n`;
 replyText += `Link: ${item.link}\n`;
 replyText += `Store: ${item.store.nama} - ${item.store.lokasi}\n`;
 replyText += `Image: ${item.image}\n\n`;
 });
 m.reply(replyText);
 }).catch(err => {
 m.reply('Terjadi kesalahan saat mencari produk.');
 console.error(err);
 });
}
break
case 'textpro': {
 async function textpro(url, text) {
 if (!/^https:\/\/textpro\.me\/.+\.html$/.test(url)) {
 throw new Error("Url Salah!!");
 }

 const geturl = await fetch(url, {
 method: "GET",
 headers: {
 "User-Agent": "GoogleBot",
 },
 });

 const caritoken = await geturl.text();

 // Periksa apakah ada header 'set-cookie'
 const setCookieHeader = geturl.headers.get("set-cookie");
 if (!setCookieHeader) {
 throw new Error("Header 'set-cookie' tidak ditemukan!");
 }

 // Parse cookies dari header 'set-cookie'
 let hasilcookie = setCookieHeader
 .split(",")
 .map((v) => cookie.parse(v))
 .reduce((a, c) => {
 return { ...a, ...c };
 }, {});
 hasilcookie = {
 __cfduid: hasilcookie.__cfduid,
 PHPSESSID: hasilcookie.PHPSESSID,
 };
 hasilcookie = Object.entries(hasilcookie)
 .map(([name, value]) => cookie.serialize(name, value))
 .join("; ");

 const $ = cheerio.load(caritoken);
 const token = $('input[name="token"]').attr("value");
 if (!token) {
 throw new Error("Token tidak ditemukan dalam HTML!");
 }

 const form = new FormData();
 if (typeof text === "string") text = [text];
 for (let texts of text) form.append("text[]", texts);
 form.append("submit", "Go");
 form.append("token", token);
 form.append("build_server", "https://textpro.me");
 form.append("build_server_id", 1);

 const geturl2 = await fetch(url, {
 method: "POST",
 headers: {
 Accept: "*/*",
 "Accept-Language": "en-US,en;q=0.9",
 "User-Agent": "GoogleBot",
 Cookie: hasilcookie,
 ...form.getHeaders(),
 },
 body: form.getBuffer(),
 });

 const caritoken2 = await geturl2.text();
 const token2 = /<div.*?id="form_value".+>(.*?)<\/div>/.exec(caritoken2);
 if (!token2) {
 throw new Error("Token Tidak Ditemukan dalam respons POST!");
 }

 const prosesimage = await fetch(
 "https://textpro.me/create-",
 {
 method: "POST",
 headers: {
 Accept: "application/json",
 "Content-Type": "application/json",
 Cookie: hasilcookie,
 },
 body: JSON.stringify(JSON.parse(token2[1])),
 }
 );

 const hasil = await prosesimage.json();
 return `https://textpro.me${hasil.fullsize_image}`;
 }

 const [url, ...queryParts] = args;
 const query = queryParts.join(" ");
 
 if (!url || !query) {
 m.reply('Harap masukkan URL dan teks untuk diproses.');
 break;
 }

 try {
 const resultUrl = await textpro(url, query);
 // Kirim hasil dengan sky.sendFile
 sky.sendFile(m.chat, resultUrl, 'result.png', 'Hasil dari Textpro', m);
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
 break
case 'tourl9': {
 const fetch = require('node-fetch');
 const fileType = require('file-type');
 const FormData = require('form-data');
 const fs = require('fs');

 async function nullbyte(mediaPath) {
 try {
 const buffer = fs.readFileSync(mediaPath);
 const { ext, mime } = await fileType.fromBuffer(buffer) || {};
 if (!ext || !mime) throw new Error("Cannot detect file type");

 const formData = new FormData();
 formData.append("file", buffer, {
 filename: `file-${Date.now()}.${ext}`,
 contentType: mime,
 });

 const response = await fetch("http://0x0.st", {
 method: "POST",
 body: formData,
 headers: {
 "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
 ...formData.getHeaders(),
 },
 });

 if (!response.ok) {
 const errorText = await response.text();
 throw new Error(`Upload failed with status ${response.status}: ${errorText}`);
 }

 const fileUrl = await response.text();
 return fileUrl;
 } catch (error) {
 throw new Error(`Upload failed: ${error.message}`);
 }
 }

 try {
 m.reply('Sedang memuat...');

 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 if (fs.statSync(media).size > 350000000) {
 m.reply('File terlalu besar, maksimal 350MB');
 return;
 }

 let url = await nullbyte(media);
 m.reply(`Link: ${url}`);

 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Terjadi kesalahan saat mengunggah file: ${err.message}`);
 }
}
break
case 'tourl11': {
 const fetch = require('node-fetch');
 const fileType = require('file-type');
 const FormData = require('form-data');
 const fs = require('fs');

 async function fileDitch(mediaPath) {
 try {
 const buffer = fs.readFileSync(mediaPath);
 const { ext, mime } = await fileType.fromBuffer(buffer) || {};
 if (!ext || !mime) throw new Error("Cannot detect file type");

 const formData = new FormData();
 formData.append("files[]", buffer, {
 filename: `file-${Date.now()}.${ext}`,
 contentType: mime,
 });

 const response = await fetch("https://up1.fileditch.com/upload.php", {
 method: "POST",
 body: formData,
 headers: {
 "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36",
 ...formData.getHeaders(),
 },
 });

 if (!response.ok) {
 const errorText = await response.text();
 throw new Error(`Upload failed with status ${response.status}: ${errorText}`);
 }

 const files = await response.json();
 if (!files.files || !files.files[0] || !files.files[0].url) {
 throw new Error("Failed to retrieve file URL");
 }

 return files.files[0].url;
 } catch (error) {
 throw new Error(`Upload failed: ${error.message}`);
 }
 }

 try {
 m.reply('Sedang memuat...');

 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 if (fs.statSync(media).size > 350000000) {
 m.reply('File terlalu besar, maksimal 350MB');
 return;
 }

 let url = await fileDitch(media);
 m.reply(`Link: ${url}`);

 fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Terjadi kesalahan saat mengunggah file: ${err.message}`);
 }
}
break

case 'qc5': {
 m.reply(mess.wait);

 const TelegraPh = require('./lib/uploadImage');
 const axios = require('axios');
 const fs = require('fs');
 const exec = require('child_process').exec;
 const { getRandom } = require('./lib/myfunc');

 // Function to pick a random item from an array
 function pickRandom(arr) {
 return arr[Math.floor(Math.random() * arr.length)];
 }

 // Array of random colors
 const randomColor = ['#ef1a11', '#89cff0', '#660000', '#87a96b', '#e9f6ff', '#ffe7f7', '#ca86b0', '#83a3ee', '#abcc88', '#80bd76', '#6a84bd', '#5d8d7f', '#530101', '#863434', '#013337', '#133700', '#2f3641', '#cc4291', '#7c4848', '#8a496b', '#722f37', '#0fc163', '#2f3641', '#e7a6cb', '#64c987', '#e6e6fa'];
 const apiColor = pickRandom(randomColor);

 // Function to get profile picture URL
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0]?.attrs?.url || 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return 'https://telegra.ph/file/f3def2b4dba511b19b48a.jpg'; // Fallback URL
 }
 }

 try {
 // Get sender and name
 const dia = (m.quoted?.text ? m.quoted : m).sender;
 const name = await sky.getName(dia);

 // Get text from the quoted message or input
 let teks = m.quoted ? m.quoted.text : q ? q : "";

 // Get avatar
 const avatar = await getPp(sky, dia);

 // Check if the message or quoted message contains an image or sticker
 const isImage = m.mtype === 'imageMessage';
 const isQuotedImage = m.quoted && m.quoted.mtype === 'imageMessage';
 const isQuotedSticker = m.quoted && m.quoted.mtype === 'stickerMessage';

 if (isImage || isQuotedImage) {
 // Handle image message
 let media = await sky.downloadAndSaveMediaMessage(isQuotedImage ? m.quoted : m, 'temp');
 let anu = await TelegraPh(media);
 const json = {
 type: "quote",
 format: "png",
 backgroundColor: apiColor,
 width: 512,
 height: 768,
 scale: 2,
 messages: [{
 entities: [],
 media: { url: anu },
 avatar: true,
 from: {
 id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
 name,
 photo: { url: avatar }
 },
 text: `${teks}`,
 replyMessage: {}
 }]
 };
 const { data } = await axios.post("https://quotly.netorare.codes/generate", json, {
 headers: { "Content-Type": "application/json" }
 }).catch(e => e.response || {});
 if (!data.ok) throw data;
 const buffer = Buffer.from(data.result.image, "base64");
 const filePath = 'temp.png';
 fs.writeFileSync(filePath, buffer);
 await sky.sendImageAsSticker(m.chat, filePath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(media);
 fs.unlinkSync(filePath);
 } else if (isQuotedSticker) {
 // Handle quoted sticker message
 let media = await sky.downloadAndSaveMediaMessage(m.quoted, 'temp');
 let ran = await getRandom('.png');
 exec(`ffmpeg -i ${media} ${ran}`, async (err) => {
 fs.unlinkSync(media);
 if (err) throw err;
 let anuah = await TelegraPh(ran);
 const json = {
 type: "quote",
 format: "png",
 backgroundColor: apiColor,
 width: 512,
 height: 768,
 scale: 2,
 messages: [{
 entities: [],
 media: { url: anuah },
 avatar: true,
 from: {
 id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
 name,
 photo: { url: avatar }
 },
 text: `${teks}`,
 replyMessage: {}
 }]
 };
 const { data } = await axios.post("https://quotly.netorare.codes/generate", json, {
 headers: { "Content-Type": "application/json" }
 }).catch(e => e.response || {});
 if (!data.ok) throw data;
 const buffer = Buffer.from(data.result.image, "base64");
 fs.writeFileSync(ran, buffer);
 await sky.sendImageAsSticker(m.chat, ran, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(ran);
 });
 } else {
 // Handle text message
 const json = {
 type: "quote",
 format: "png",
 backgroundColor: apiColor,
 width: 512,
 height: 768,
 scale: 2,
 messages: [{
 entities: [],
 avatar: true,
 from: {
 id: pickRandom([0, 4, 5, 3, 2, 7, 5, 9, 8, 1, 6, 10, 9, 7, 5, 3, 1, 2, 4, 6, 8, 0, 10]),
 name,
 photo: { url: avatar }
 },
 text: `${teks}`,
 replyMessage: {}
 }]
 };
 const { data } = await axios.post("https://quotly.netorare.codes/generate", json, {
 headers: { "Content-Type": "application/json" }
 }).catch(e => e.response || {});
 if (!data.ok) m.reply(data);
 const buffer = Buffer.from(data.result.image, "base64");
 const filePath = 'temp.png';
 fs.writeFileSync(filePath, buffer);
 await sky.sendImageAsSticker(m.chat, filePath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(filePath);
 }
 } catch (e) {
 m.reply('Sistem eror, coba lagi nanti.');
 console.error(e);
 return;
 }
}
break
case 'alodokter': {
 if (!text) throw `cari apa di alondokter`
axios.get(`https://www.alodokter.com/${q}`)
 .then(response => {
 if (response.status === 200) {
 const $ = cheerio.load(response.data);
 const dataScrap = $('.post-content').text().trim().replace(/\s+/g, ' ');
 const sentenceArr = dataScrap.split(".");
 const firstSentence = sentenceArr[0].trim();
 let wordsArray = dataScrap.split(/\s+/).filter(word => word.length > 0);
 const wordsString = wordsArray.join(' ');
 const wordsCount = wordsArray.length;
 var fileObjectScrap = {
 filename: `${q}`,
 kata: wordsString,
 banyakKata: wordsCount,
 firstSentence: firstSentence,
 similarity: 0
 }; 
 m.reply(`https://www.alodokter.com/${q}\n\n\n${JSON.stringify(fileObjectScrap, null, 2)}`);
 } else {
 m.reply('Gagal mengambil data dari Alodokter.');
 }
 })
 .catch(error => {
 m.reply('Terjadi kesalahan: ' + error.message);
 });
 }
 break
case 'domainfind': {
 const fetch = require('node-fetch');
 const cheerio = require('cheerio');
 const whois = require('whois');

 if (!text) throw `Nyari Domain Apa`;
 const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(text)}&num=10`;

 async function searchDomains(query) {
 try {
 const response = await fetch(query, { headers: { 'User-Agent': 'Mozilla/5.0' } });
 const body = await response.text();
 const $ = cheerio.load(body);

 const results = [];
 $('a').each((i, elem) => {
 const link = $(elem).attr('href');
 if (link && link.startsWith('/url?q=')) {
 const domain = link.split('/url?q=')[1].split('&')[0];
 if (domain.includes(text)) { // Changed `keyword` to `text`
 results.push(domain);
 }
 }
 });

 return results;
 } catch (error) {
 console.error('Error fetching search results:', error);
 return [];
 }
 }

 async function checkDomains(domains) {
 const results = [];
 for (const domain of domains) {
 try {
 // Ensure domain starts with http:// or https://
 const formattedDomain = domain.startsWith('http://') || domain.startsWith('https://')
 ? domain
 : `https://${domain}`;
 
 const info = await new Promise((resolve, reject) => {
 whois.lookup(formattedDomain, (err, data) => {
 if (err) reject(err);
 else resolve(data);
 });
 });

 if (info && !info.includes('No match for')) {
 results.push(formattedDomain);
 }
 } catch (error) {
 console.error(`Error checking domain ${domain}:`, error);
 }
 }
 return results;
 }

 try {
 const searchResults = await searchDomains(searchUrl);
 const activeDomains = await checkDomains(searchResults);

 if (activeDomains.length > 0) {
 const formattedDomains = activeDomains.map((domain, index) => `${index + 1}. \n> ${domain}`).join('\n\n');
 m.reply(`Domain Di Temukan:\n\n${formattedDomains}`);
 } else {
 m.reply(`Tidak ditemukan domain aktif yang mengandung "${text}".`);
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mencari domain.');
 }
}
break
case 'countletters': {
 if (m.quoted && m.quoted.text) {
 const text = m.quoted.text.toLowerCase();
 const charCounts = {};

 for (let char of text) {
 if (/[a-z0-9]/.test(char)) { // Menghitung huruf a-z dan angka 0-9
 if (charCounts[char]) {
 charCounts[char]++;
 } else {
 charCounts[char] = 1;
 }
 }
 }

 let resultMessage = 'Jumlah karakter:\n';
 for (let char in charCounts) {
 resultMessage += `${char} = ${charCounts[char]}\n`;
 }

 m.reply(resultMessage);
 } else {
 m.reply('Silakan reply ke pesan yang mengandung teks.');
 }
}
break
case 'xvideossearch': {
 if (!isPrem) return replyprem(mess.premium);

 async function xvideosSearch(query) {
 return new Promise(async (resolve) => {
 await axios.request(`https://www.xvideos.com/?k=${query}&p=${Math.floor(Math.random() * 9) + 1}`, { method: "get" }).then(async result => {
 let $ = cheerio.load(result.data, { xmlMode: false });
 let title = [];
 let duration = [];
 let quality = [];
 let url = [];
 let thumb = [];
 let results = [];

 $("div.mozaique > div > div.thumb-under > p.title").each(function (a, b) {
 title.push($(this).find("a").attr("title"));
 duration.push($(this).find("span.duration").text());
 url.push("https://www.xvideos.com" + $(this).find("a").attr("href"));
 });

 $("div.mozaique > div > div.thumb-under").each(function (a, b) {
 quality.push($(this).find("span.video-hd-mark").text());
 });

 $("div.mozaique > div > div > div.thumb > a").each(function (a, b) {
 thumb.push($(this).find("img").attr("data-src"));
 });

 for (let i = 0; i < title.length; i++) {
 results.push({
 title: title[i],
 duration: duration[i],
 quality: quality[i],
 thumb: thumb[i],
 url: url[i]
 });
 }
 resolve(results);
 });
 });
 }

 const query = args.join(' ');
 if (!query) {
 m.reply('Tentukan query untuk pencarian.');
 return;
 }

 m.reply('🔍 Mencari video, harap tunggu...');

 xvideosSearch(query).then(response => {
 if (!response || response.length === 0) {
 m.reply('❗ Tidak ada hasil ditemukan.');
 return;
 }

 let results = '📜 *Hasil Pencarian* 📜\n\n';
 response.forEach((item, index) => {
 results += `*${index + 1}. ${item.title}*\n`;
 results += `Durasi: ${item.duration}\n`;
 results += `Kualitas: ${item.quality || 'Tidak tersedia'}\n`;
 results += `![Thumbnail](${item.thumb})\n`;
 results += `[Link Video](${item.url})\n\n`;
 });

 m.reply(results);
 }).catch(error => {
 m.reply('❗ Terjadi kesalahan: ' + error.message);
 });
}
break
case 'xvideosdl': {
 if (!isPrem) return replyprem(mess.premium);

 async function xvideosdl(url) {
 return new Promise((resolve, reject) => {
 fetch(`${url}`, { method: 'get' })
 .then(res => res.text())
 .then(res => {
 let $ = cheerio.load(res, { xmlMode: false });
 const title = $("meta[property='og:title']").attr("content");
 const keyword = $("meta[name='keywords']").attr("content");
 const views = $("div#video-tabs > div > div > div > div > strong.mobile-hide").text() + " views";
 const vote = $("div.rate-infos > span.rating-total-txt").text();
 const likes = $("span.rating-good-nbr").text();
 const deslikes = $("span.rating-bad-nbr").text();
 const thumb = $("meta[property='og:image']").attr("content");
 const videoUrl = $("#html5video > #html5video_base > div > a").attr("href");
 resolve({ status: 200, result: { title, url: videoUrl, keyword, views, vote, likes, deslikes, thumb } });
 })
 .catch(err => reject({ code: 503, status: false, result: err }));
 });
 }

 m.reply('wait');
 let xvideosLink = '';
 if (args[0].includes('xvideos')) {
 xvideosLink = args[0];
 } else {
 const index = parseInt(args[0]) - 1;
 if (index >= 0) {
 if (Array.isArray(global.videoListXXX) && global.videoListXXX.length > 0) {
 const matchingItem = global.videoListXXX.find(item => item.from === m.sender);
 if (matchingItem && index < matchingItem.urls.length) {
 xvideosLink = matchingItem.urls[index];
 }
 }
 }
 }

 if (!xvideosLink) {
 return m.reply(`*[❗] Link tidak valid atau tidak ditemukan. Pastikan Anda telah melakukan pencarian video dengan benar.*`);
 }

 const res = await xvideosdl(xvideosLink);
 const { title, url, keyword, views, vote, likes, deslikes, thumb } = res.result;
 
 sky.sendMessage(m.chat, { video: { url }, caption: `Title: ${title}\nKeyword: ${keyword}\nViews: ${views}\nVotes: ${vote}\nLikes: ${likes}\nDislikes: ${deslikes}\nThumbnail: ${thumb}` }, { quoted: m });
};
break
case 'xvideosplay': {
 if (!isPrem) return replyprem(mess.premium);

 async function xvideosSearch(query) {
 return new Promise(async (resolve) => {
 await axios.request(`https://www.xvideos.com/?k=${query}&p=${Math.floor(Math.random() * 9) + 1}`, { method: "get" })
 .then(async result => {
 let $ = cheerio.load(result.data, { xmlMode: false });
 let title = [];
 let duration = [];
 let quality = [];
 let url = [];
 let thumb = [];
 let hasil = [];

 $("div.mozaique > div > div.thumb-under > p.title").each(function (a, b) {
 title.push($(this).find("a").attr("title"));
 duration.push($(this).find("span.duration").text());
 url.push("https://www.xvideos.com" + $(this).find("a").attr("href"));
 });
 $("div.mozaique > div > div.thumb-under").each(function (a, b) {
 quality.push($(this).find("span.video-hd-mark").text());
 });
 $("div.mozaique > div > div > div.thumb > a").each(function (a, b) {
 thumb.push($(this).find("img").attr("data-src"));
 });
 for (let i = 0; i < title.length; i++) {
 hasil.push({
 title: title[i],
 duration: duration[i],
 quality: quality[i],
 thumb: thumb[i],
 url: url[i]
 });
 }
 resolve(hasil);
 });
 });
 }

 async function xvideosdl(url) {
 return new Promise((resolve, reject) => {
 fetch(`${url}`, { method: 'get' })
 .then(res => res.text())
 .then(res => {
 let $ = cheerio.load(res, { xmlMode: false });
 const title = $("meta[property='og:title']").attr("content");
 const keyword = $("meta[name='keywords']").attr("content");
 const views = $("div#video-tabs > div > div > div > div > strong.mobile-hide").text() + " views";
 const vote = $("div.rate-infos > span.rating-total-txt").text();
 const likes = $("span.rating-good-nbr").text();
 const deslikes = $("span.rating-bad-nbr").text();
 const thumb = $("meta[property='og:image']").attr("content");
 const videoUrl = $("#html5video > #html5video_base > div > a").attr("href");
 resolve({ status: 200, result: { title, url: videoUrl, keyword, views, vote, likes, deslikes, thumb } });
 })
 .catch(err => reject({ code: 503, status: false, result: err }));
 });
 }

 const query = args.join(' ');
 if (!query) {
 m.reply('Tentukan query untuk pencarian.');
 return;
 }

 m.reply('_ywdah tunggu_');

 xvideosSearch(query).then(async response => {
 if (response.length === 0) {
 m.reply('Tidak ditemukan hasil pencarian untuk query tersebut.');
 return;
 }

 // Pilih video acak dari hasil pencarian
 const randomResult = response[Math.floor(Math.random() * response.length)];

 // Download video dari hasil acak
 const res = await xvideosdl(randomResult.url);
 const json = res.result;
 sky.sendMessage(m.chat, { video: { url: json.url }, caption: `Title: ${json.title}\nKeyword: ${json.keyword}\nViews: ${json.views}\nVotes: ${json.vote}\nLikes: ${json.likes}\nDislikes: ${json.deslikes}\nThumbnail: ${json.thumb}` }, { quoted: m });

 }).catch(error => {
 m.reply('Terjadi kesalahan: ' + error.result);
 });
};
break
case 'cerpen': {
 // Definisikan fungsi cerpen di sini
 async function cerpen(category) {
 const axios = require('axios');
 const cheerio = require('cheerio');
 
 return new Promise(async (resolve, reject) => {
 let title = category.toLowerCase().replace(/[()*]/g, "");
 let judul = title.replace(/\s/g, "-");
 let page = Math.floor(Math.random() * 5);
 
 try {
 let get = await axios.get(`http://cerpenmu.com/category/cerpen-${judul}/page/${page}`);
 let $ = cheerio.load(get.data);
 let link = [];
 
 $('article.post').each(function (a, b) {
 link.push($(b).find('a').attr('href'));
 });
 
 if (link.length === 0) {
 // Tidak ada cerpen ditemukan
 resolve({ error: 'Belum cerpen tersedia' });
 return;
 }
 
 let random = link[Math.floor(Math.random() * link.length)];
 let res = await axios.get(random);
 let $$ = cheerio.load(res.data);
 
 // Mengecek apakah elemen yang diharapkan ada
 if ($$('#content > article > h1').length === 0) {
 resolve({ error: 'Cerpen tidak ditemukan' });
 return;
 }
 
 let hasil = {
 title: $$('#content > article > h1').text(),
 author: $$('#content > article').text().split('Cerpen Karangan: ')[1]?.split('Kategori: ')[0] || 'Unknown',
 kategori: $$('#content > article').text().split('Kategori: ')[1]?.split('\n')[0] || 'Unknown',
 lolos: $$('#content > article').text().split('Lolos moderasi pada: ')[1]?.split('\n')[0] || 'Unknown',
 cerita: $$('#content > article > p').text() || 'Cerita tidak tersedia'
 };
 
 resolve(hasil);
 } catch (error) {
 // Tangani kesalahan yang mungkin terjadi
 if (error.response && error.response.status === 404) {
 resolve({ error: 'Cerpen tidak ditemukan' });
 } else {
 reject(error);
 }
 }
 });
 }

 // Pastikan text diisi dengan input judul
 if (!text) throw 'input judul';
 let cerpe = await cerpen(`${q}`);
 
 if (cerpe.error) {
 m.reply(cerpe.error);
 } else {
 m.reply(`⭔ _*Title :*_ ${cerpe.title}\n⭔ _*Author :*_ ${cerpe.author}\n⭔ _*Category :*_ ${cerpe.kategori}\n⭔ _*Pass Moderation :*_ ${cerpe.lolos}\n⭔ _*Story :*_\n${cerpe.cerita}`);
 }
}
break
case 'getbioallmember': {
 // Dapatkan metadata grup dan daftar peserta
 const participants = await groupMetadata.participants;
 
 // Inisialisasi variabel untuk menyimpan nomor dan bio
 let phoneNumbers = [];
 let bios = [];

 // Looping melalui semua anggota
 participants.forEach(participant => {
 // Dapatkan nomor telepon
 const phoneNumber = participant.id.split('@')[0].replace('+62', '0');

 // Simpan nomor telepon jika valid
 if (phoneNumber.length > 8 && !isNaN(phoneNumber)) {
 phoneNumbers.push(phoneNumber);
 }
 });

 // Fungsi untuk mengambil bio dan mengirimkan balasan
 async function fetchAndSendBios() {
 for (const phoneNumber of phoneNumbers) {
 const froms = `${phoneNumber}@s.whatsapp.net`;
 let bio = 'Bio di private!';
 
 try {
 bio = (await sky.fetchStatus(froms)).status || bio;
 } catch (err) {
 console.log(chalk.redBright('[ ERROR ]'), chalk.whiteBright(err));
 }

 bios.push(`${phoneNumber}: ${bio}`);
 }
 
 // Kirim semua bio yang telah diambil
 if (bios.length > 0) {
 m.reply(`Daftar nomor dan bio anggota grup:\n\n${bios.join('\n')}`);
 } else {
 m.reply('Tidak ada bio yang ditemukan di grup ini.');
 }
 }
 
 // Panggil fungsi untuk mengambil dan mengirim bio
 fetchAndSendBios();
}
break
case 'getallppmemberurl': {
 try {
 // Fungsi untuk mendapatkan foto profil
 async function getPp(sky, target) {
 let anu = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return anu.content[0];
 }

 if (!m.isGroup) {
 return m.reply('Perintah ini hanya bisa digunakan di dalam grup.');
 }

 // Mendapatkan metadata grup
 const groupMetadata = await sky.groupMetadata(m.chat);
 const participants = groupMetadata.participants;

 // Inisialisasi variabel untuk menyimpan nomor telepon dan URL hasil
 let phoneNumbers = [];
 let results = [];

 // Looping melalui semua anggota
 participants.forEach(participant => {
 const phoneNumber = participant.id.split('@')[0].replace('+62', '0');
 if (phoneNumber.length > 8 && !isNaN(phoneNumber)) {
 phoneNumbers.push(phoneNumber);
 }
 });

 if (phoneNumbers.length === 0) {
 return m.reply('Tidak ada nomor telepon yang ditemukan di grup ini.');
 }

 // Ambil dan kirim URL foto profil untuk setiap nomor
 for (const number of phoneNumbers) {
 let who = number + "@s.whatsapp.net";
 let onWhatsapp = await sky.onWhatsApp(who);
 let profileData = onWhatsapp.find(item => item.exists);

 if (profileData) {
 let profileJid = profileData.jid;
 let _data = await getPp(sky, profileJid).catch(_ => null);

 if (_data) {
 let _data_url = _data?.attrs?.url || "https://telegra.ph/file/0b113db9d9e244ea22c81.jpg";
 
 // Mengunduh media dari URL
 let { TelegraPh } = require('./lib/uploader');
 const axios = require('axios');
 const fs = require('fs');
 const path = require('path');

 // Unduh media ke file lokal
 let response = await axios({
 url: _data_url,
 method: 'GET',
 responseType: 'stream'
 });

 let localFilePath = path.join(__dirname, `temp_${number}.jpg`);
 response.data.pipe(fs.createWriteStream(localFilePath));

 // Tunggu hingga file selesai diunduh
 await new Promise((resolve, reject) => {
 response.data.on('end', resolve);
 response.data.on('error', reject);
 });

 // Unggah file lokal ke TelegraPh
 let uploadedUrl = await TelegraPh(localFilePath);
 fs.unlinkSync(localFilePath); // Hapus file lokal setelah diunggah

 results.push(`URL foto profil untuk nomor ${number}: ${uploadedUrl}`);
 }
 }
 }

 if (results.length > 0) {
 m.reply(results.join('\n'));
 } else {
 m.reply('Tidak ada foto profil yang ditemukan.');
 }

 } catch (error) {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat memproses permintaan.');
 }
}
break
case 'p': {
 const greetings = [
 "Halo!",
 "Hai!",
 "Selamat datang!",
 "Ada yang bisa saya bantu?",
 "Ada yang perlu ditanyakan?",
 "Ya, ada yang bisa saya bantu?",
 ];

 const randomEmojis = ["😊", "👋", "🤖", "🎉", "💬", "✨", "🚀", "🌟"];

 const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
 const randomEmoji = randomEmojis[Math.floor(Math.random() * randomEmojis.length)];

 const message = `${randomGreeting} ${randomEmoji}`;

 m.reply(message);
}
break
case 'spotifysearch': {
 const query = m.text.slice(13).trim(); // Mengambil query pencarian setelah perintah
 if (!query) {
 m.reply("Silakan masukkan judul lagu yang ingin dicari.");
 }

 const searchSpotifyTracks = async (query) => {
 const clientId = 'acc6302297e040aeb6e4ac1fbdfd62c3';
 const clientSecret = '0e8439a1280a43aba9a5bc0a16f3f009';
 const auth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

 const getToken = async () => {
 const response = await fetch('https://accounts.spotify.com/api/token', {
 method: 'POST',
 timeout: 60000, // 60 seconds
 body: new URLSearchParams({ grant_type: 'client_credentials' }),
 headers: { Authorization: `Basic ${auth}` },
 });
 return (await response.json()).access_token;
 };

 const accessToken = await getToken();
 const offset = 10;
 const searchUrl = `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&offset=${offset}`;
 const response = await fetch(searchUrl, {
 headers: { Authorization: `Bearer ${accessToken}` },
 });
 const data = await response.json();
 return data.tracks.items;
 };

 try {
 const tracks = await searchSpotifyTracks(query);
 if (tracks.length === 0) {
 m.reply("Tidak ada hasil ditemukan.");
 } else {
 const message = tracks.map(track => 
 `${track.name} oleh ${track.artists.map(artist => artist.name).join(', ')}\n${track.external_urls.spotify}`
 ).join('\n\n');
 m.reply(message);
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat mencari lagu.");
 }
}
break
case 'spotifydl': {
 if (!q) return m.reply(`Silakan masukkan URL lagu yang ingin diunduh.`);

 const axios = require('axios');
 const cheerio = require('cheerio');
 const FormData = require('form-data');

 function spotify(url) {
 return new Promise((resolve, reject) => {
 axios.get("https://spotifymate.com/en", {
 headers: {
 cookie: "session_data=o8079end5j9oslm5a7bou84rqc;",
 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
 },
 })
 .then(response => {
 const a = cheerio.load(response.data);
 const b = {
 name: a("form#get_video").find('input[type="hidden"]').attr("name") || "",
 value: a("form#get_video").find('input[type="hidden"]').attr("value") || "",
 };
 const d = new FormData();
 d.append("url", url);
 d.append(b.name, b.value);
 return axios.post("https://spotifymate.com/action", d, {
 headers: Object.assign({ origin: "https://spotifymate.com/en" }, d.getHeaders(), {
 cookie: "session_data=o8079end5j9oslm5a7bou84rqc;",
 "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/127.0.0.0 Safari/537.36",
 }),
 });
 })
 .then(response => {
 if (response.statusText !== "OK") {
 throw new Error("Gagal Mengambil Data");
 }
 const c = cheerio.load(response.data);
 const e = {
 title: c(".dlvideos").find('h3[itemprop="name"]').text().trim(),
 author: c(".dlvideos").find(".spotifymate-downloader-middle > p > span").text().trim(),
 thumbnail: c(".dlvideos").find("img").attr("src") || "",
 cover: c(".dlvideos").find(".spotifymate-downloader-right").find("#none").eq(1).find("a").attr("href") ||
 c(".dlvideos").find(".spotifymate-downloader-right").find("#pop").eq(1).find("a").attr("href") || "",
 music: c(".dlvideos").find(".spotifymate-downloader-right").find("#none").eq(0).find("a").attr("href") ||
 c(".dlvideos").find(".spotifymate-downloader-right").find("#pop").eq(0).find("a").attr("href") || "",
 link: url,
 };
 sky.sendMessage(from, { audio: { url: e.music }, mimetype: "audio/mp4", fileName: `${e.title}.mp3`, ptt: false }, { quoted: m });
 resolve(e);
 })
 .catch(err => reject(err));
 });
 }

 spotify(q)
 .then(result => {
 m.reply(`Lagu berjudul "${result.title}" oleh ${result.author} berhasil diunduh!`);
 })
 .catch(err => {
 m.reply(`Gagal mengunduh lagu. Silakan coba lagi.\nError: ${err.message}`);
 });
}
break
case 'twitter': {
const axios = require('axios');
const cheerio = require('cheerio');
const qs = require('qs');
 if (!text) throw 'mana link?';
//avosky
 async function twitterDl(link) {
 return new Promise((resolve, reject) => {
 let config = { 'URL': link };
//avosky
 axios.post('https://twdown.net/download.php', qs.stringify(config), {
 headers: {
 "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
 "sec-ch-ua": '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
 "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
 "cookie": "_ga=GA1.2.1388798541.1625064838; _gid=GA1.2.1351476739.1625064838; __gads=ID=7a60905ab10b2596-229566750eca0064:T=1625064837:RT=1625064837:S=ALNI_Mbg3GGC2b3oBVCUJt9UImup-j20Iw; _gat=1"
 }
 })
 .then(({ data }) => {
 const $ = cheerio.load(data);
 resolve({
 desc: $('div:nth-child(1) > div:nth-child(2) > p').text().trim(),
 thumb: $('div:nth-child(1) > img').attr('src'),
 video_hd: $('tbody > tr:nth-child(1) > td:nth-child(4) > a').attr('href'),
 });
 })
 .catch(reject);
 });
 }
//avosky
 try {
 await m.reply('_tunggu ya bntr kok_');
 let res = await twitterDl(text);
 if (res.video_hd) {
 let caption = res.desc.replace(/https:\/\/t.co\/[a-zA-Z0-9]+/gi, '').trim();
 await sky.sendFile(m.chat, res.video_hd, '', caption, m);
 } else {
 m.reply('Sementara Gangguan Dulu.');
 }
 } catch (e) {
 m.reply(`Error: ${e}`);
 }
}
break
case 'tiktok':
case 'tiktoknowm':
case 'tt': {
 if (isBan) return m.reply('Maaf, kamu telah diblokir oleh owner.');
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply('Maaf, limit kamu habis.');

 if (!text) throw 'Masukkan link TikTok yang ingin diunduh!';

 m.reply('Sedang mengunduh video, harap tunggu sebentar...');

 // Function to get TikTok video data
 async function tiktokDl(url) {
 return new Promise(async (resolve, reject) => {
 try {
 let data = [];
 function formatNumber(integer) {
 let numb = parseInt(integer);
 return Number(numb).toLocaleString().replace(/,/g, '.');
 }
 
 function formatDate(n, locale = 'en') {
 let d = new Date(n);
 return d.toLocaleDateString(locale, {
 weekday: 'long',
 day: 'numeric',
 month: 'long',
 year: 'numeric',
 hour: 'numeric',
 minute: 'numeric',
 second: 'numeric'
 });
 }
 
 let domain = 'https://www.tikwm.com/api/';
 let res = await (await axios.post(domain, {}, {
 headers: {
 'Accept': 'application/json, text/javascript, */*; q=0.01',
 'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Origin': 'https://www.tikwm.com',
 'Referer': 'https://www.tikwm.com/',
 'Sec-Ch-Ua': '"Not)A;Brand" ;v="24" , "Chromium" ;v="116"',
 'Sec-Ch-Ua-Mobile': '?1',
 'Sec-Ch-Ua-Platform': 'Android',
 'Sec-Fetch-Dest': 'empty',
 'Sec-Fetch-Mode': 'cors',
 'Sec-Fetch-Site': 'same-origin',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36',
 'X-Requested-With': 'XMLHttpRequest'
 },
 params: {
 url: url,
 count: 12,
 cursor: 0,
 web: 1,
 hd: 1
 }
 })).data.data;
 
 if (!res.size) {
 res.images.map(v => {
 data.push({ type: 'photo', url: v });
 });
 } else {
 data.push({
 type: 'watermark',
 url: 'https://www.tikwm.com' + res.wmplay,
 }, {
 type: 'nowatermark',
 url: 'https://www.tikwm.com' + res.play,
 }, {
 type: 'nowatermark_hd',
 url: 'https://www.tikwm.com' + res.hdplay
 });
 }
 
 let json = {
 status: true,
 title: res.title,
 taken_at: formatDate(res.create_time).replace('1970', ''),
 region: res.region,
 id: res.id,
 durations: res.duration,
 duration: res.duration + ' Seconds',
 cover: 'https://www.tikwm.com' + res.cover,
 size_wm: res.wm_size,
 size_nowm: res.size,
 size_nowm_hd: res.hd_size,
 data: data,
 music_info: {
 id: res.music_info.id,
 title: res.music_info.title,
 author: res.music_info.author,
 album: res.music_info.album ? res.music_info.album : null,
 url: 'https://www.tikwm.com' + res.music || res.music_info.play
 },
 stats: {
 views: formatNumber(res.play_count),
 likes: formatNumber(res.digg_count),
 comment: formatNumber(res.comment_count),
 share: formatNumber(res.share_count),
 download: formatNumber(res.download_count)
 },
 author: {
 id: res.author.id,
 fullname: res.author.unique_id,
 nickname: res.author.nickname,
 avatar: 'https://www.tikwm.com' + res.author.avatar
 }
 };
 
 resolve(json);
 } catch (e) {
 reject(e);
 }
 });
 }

 // Fetching and sending the video separately
 try {
 const videoData = await tiktokDl(text);

 if (videoData.data && videoData.data.length > 0) {
 // Find the video without watermark
 const nowmVideo = videoData.data.find(v => v.type === 'nowatermark' || v.type === 'nowatermark_hd');
 if (nowmVideo) {
 // Sending video without watermark
 await sky.sendMessage(m.chat, { 
 video: { url: nowmVideo.url }, 
 mimetype: 'video/mp4', 
 caption: `Judul: ${videoData.title}\nDiupload pada: ${videoData.taken_at}\nDurasi: ${videoData.duration}`
 });
 } else {
 m.reply('Gagal mendapatkan video tanpa watermark.');
 }
 } else {
 m.reply('Gagal mendapatkan video dari TikTok.');
 }
 } catch (error) {
 console.error(error);
 m.reply('Gagal mengunduh video dari TikTok. Silakan coba lagi nanti.');
 }
}
break
case 'ttsearch': {
 if (!isPrem) return `lahh`;

 const axios = require('axios');
 const baileys = require("@whiskeysockets/baileys");
 const { proto } = baileys;

 const delay = (time) => new Promise((resolve) => setTimeout(resolve, time));

 const [query, count] = text.split(' | ');

 if (!query || !count || isNaN(count)) {
 return m.reply(`Contoh: ${prefix + command} video lucu | 3`);
 }

 const numVideosToSend = parseInt(count);

 m.reply(mess.wait);

 async function tiktoks(query) {
 try {
 const response = await axios({
 method: 'POST',
 url: 'https://tikwm.com/api/feed/search',
 headers: {
 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
 'Cookie': 'current_language=en',
 'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
 },
 data: {
 keywords: query,
 count: 10,
 cursor: 0,
 HD: 1
 }
 });

 if (response.data && response.data.data && response.data.data.videos) {
 const videos = response.data.data.videos;
 if (videos.length === 0) {
 throw new Error('Tidak ada video ditemukan.');
 }
 const gywee = Math.floor(Math.random() * videos.length);
 const videorndm = videos[gywee];

 return {
 title: videorndm.title,
 cover: videorndm.cover,
 origin_cover: videorndm.origin_cover,
 no_watermark: videorndm.play,
 watermark: videorndm.wmplay,
 music: videorndm.music
 };
 } else {
 throw new Error('Struktur data tidak sesuai.');
 }
 } catch (error) {
 throw new Error(`Terjadi kesalahan saat mengambil data: ${error.message}`);
 }
 }

 try {
 const results = [];
 for (let i = 0; i < numVideosToSend; i++) {
 // Delay antara pengambilan video
 await delay(2000);
 const result = await tiktoks(query);
 results.push(result);
 }

 if (results.length > 0) {
 const videos = [];

 for (let i = 0; i < results.length; i++) {
 const result = results[i];
 const videoUrl = result.no_watermark;
 const coverUrl = result.cover;
 const title = result.title;

 const createVideo = async (videoUrl, coverUrl, title) => {
 const { videoMessage } = await baileys.generateWAMessageContent({
 video: { url: videoUrl }
 }, { upload: sky.waUploadToServer });

 return videoMessage;
 };

 const videoMsg = await createVideo(videoUrl, coverUrl, title);

 let buttons = [];
 buttons.push({
 name: "cta_play",
 buttonParamsJson: `{"display_text":"Play Video","url":"${videoUrl}"}`
 });

 const card = {
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `Video ${i + 1}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: title,
 hasMediaAttachment: true,
 videoMessage: videoMsg
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: buttons
 })
 };

 videos.push(card);
 }

 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `Hasil pencarian untuk: ${query}`
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `${pushname}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Hasil pencarian ${query}\n`,
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: videos
 })
 })
 }
 }
 }, {});

 await sky.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });

 } else {
 m.reply('Tidak ada hasil yang ditemukan.');
 }
 } catch (error) {
 console.error(error);
 m.reply(`Terjadi kesalahan saat mengambil data: ${error.message}`);
 }
}
break
case 'ttslide': {
 if (!isPrem) return m.reply(mess.premium);
const baileys = require("@whiskeysockets/baileys");
const { proto } = baileys;


 const url = text.trim();

 if (!url || !url.startsWith('https://vt.tiktok.com/')) {
 return m.reply(`Contoh: ${prefix + command} https://vt.tiktok.com/ZS28mHYNk/`);
 }

 m.reply(mess.wait);

 const tiktokSlide = async (url) => {
 return new Promise(async (resolve, reject) => {
 try {
 const origin = "https://ttsave.app/";
 const options = {
 method: "POST",
 headers: {
 Accept: "application/json, text/plain, */*",
 "Accept-Encoding": "gzip, deflate, br, zstd",
 "Content-Type": "application/json",
 Origin: origin,
 Referer: `${origin}/en/slide`,
 "Sec-Fetch-Mode": "cors",
 "User-Agent":
 "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
 },
 body: JSON.stringify({
 language_id: "1",
 query: url,
 }),
 };
 const res = await fetch(`${origin}/download`, options).then((v) =>
 v.text()
 );
 const $ = cheerio.load(res);
 const data = {
 author: "",
 username: "",
 profile: "",
 caption: "",
 views: "0",
 likes: "0",
 comment: "0",
 save: "0",
 share: "0",
 music: "",
 thumbnail: "",
 slides: [],
 link: url,
 authorLink: "",
 };
 const download = $("div.items-center");
 const attr = $(download).find("div.gap-2").children("div");
 const slides = $(download).find("div#button-download-ready");
 data.author = $(download)
 .find("h2.font-extrabold.text-xl.text-center")
 .text()
 .trim();
 data.username = $(download).find("a[title]").text().trim();
 data.authorLink = $(download).find("a[title]").attr("href");
 data.caption = $(download).find("a[title] + p").text().trim();
 data.views = attr.eq(0).find("span").text().trim() || "0";
 data.likes = attr.eq(1).find("span").text().trim() || "0";
 data.comment = attr.eq(2).find("span").text().trim() || "0";
 data.save = attr.eq(3).find("span").text().trim() || "0";
 data.share = attr.eq(4).find("span").text().trim() || "0";
 data.music = $(download).find("div.mt-5 > span").text().trim() || "";
 $(slides)
 .children("div")
 .each((i, el) => {
 data.slides.push($(el).find("img").attr("src"));
 });
 data.profile = $(slides).find('a[type="profile"]').attr("href");
 data.thumbnail = $(slides).find('a[type="cover"]').attr("href");

 resolve(data);
 } catch (e) {
 reject(e);
 }
 });
 };

 let tiktokData;
 try {
 tiktokData = await tiktokSlide(url);
 } catch (error) {
 return m.reply(`Terjadi kesalahan saat mengambil data TikTok: ${error.message}`);
 }

 const generateImageMessage = async (imageUrl) => {
 const { imageMessage } = await baileys.generateWAMessageContent({
 image: { url: imageUrl }
 }, {
 upload: sky.waUploadToServer
 });
 return imageMessage;
 };

 const cards = [];
 for (const image of tiktokData.slides) {
 const imageMsg = await generateImageMessage(image);
 const card = {
 footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `Slide TikTok` }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Slide`,
 hasMediaAttachment: true,
 imageMessage: imageMsg
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
 buttons: [
 {
 name: "cta_url",
 buttonParamsJson: `{"display_text":"Lihat","url":"${image}"}`
 }
 ]
 })
 };
 cards.push(card);
 }

 if (cards.length === 0) {
 return m.reply('Tidak ada slide yang ditemukan.');
 }

 const msg = baileys.generateWAMessageFromContent(m.chat, {
 viewOnceMessage: {
 message: {
 messageContextInfo: {
 deviceListMetadata: {},
 deviceListMetadataVersion: 2
 },
 interactiveMessage: proto.Message.InteractiveMessage.fromObject({
 body: proto.Message.InteractiveMessage.Body.fromObject({
 text: `done hehe`
 }),
 footer: proto.Message.InteractiveMessage.Footer.fromObject({
 text: `${pushname}`
 }),
 header: proto.Message.InteractiveMessage.Header.fromObject({
 title: `Slide TikTok`,
 hasMediaAttachment: false
 }),
 carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
 cards: cards
 })
 })
 }
 }
 }, {});

 await sky.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break
case 'gpt': {
 if (!text) throw `Hello ${pushname}, may I help you?`;

 const { key } = await sky.sendMessage(from, { text: '_Please Wait..._', previewType: 0 });

 // Fungsi ChatGpt untuk memanggil API voc.ai
 const ChatGpt = async prompt => {
 try {
 const response = await fetch("https://apps.voc.ai/api/v1/plg/prompt_stream", {
 method: "POST",
 credentials: "include",
 mode: "cors",
 headers: {
 "Content-Type": "application/json"
 },
 body: JSON.stringify({
 prompt: prompt
 })
 });

 const dataArray = (await response.text()).split("\n\n");
 const regex = /data: (\{.*?\})/g;
 const jsonMatches = [];
 let match;

 for (; null !== (match = regex.exec(dataArray[0]));) {
 jsonMatches.push(match[1]);
 }

 const oregex = /"data": ({.*?})/;
 const endsTrueArray = jsonMatches.slice(-1);
 const output = endsTrueArray[0]?.match(oregex);

 return output ? JSON.parse(output[1]) : null;
 } catch (error) {
 console.error("Error fetching data:", error);
 return null;
 }
 };

 try {
 // Panggil fungsi ChatGpt dengan teks input
 const result = await ChatGpt(text);

 if (result && result.content) {
 await sky.sendMessage(from, { text: `${result.content}`.trim(), edit: key });
 } else {
 await sky.sendMessage(from, { text: 'Sorry, I could not get a response.', edit: key });
 }
 } catch (error) {
 await sky.sendMessage(from, { text: 'An error occurred while processing your request.', edit: key });
 }
}
break
case 'kamus': {
 if (!text) return m.reply('Format: kamus <kata>')
 const axios = require('axios')
 const cheerio = require('cheerio')
 
 const url = `https://kbbi.kemdikbud.go.id/entri/${encodeURIComponent(text)}`
 
 axios.get(url).then(response => {
 const $ = cheerio.load(response.data)
 let definitions = []
 
 $('ol li').each((i, elem) => {
 definitions.push($(elem).text().trim())
 })
 
 if (definitions.length === 0) {
 return m.reply('Kata tidak ditemukan dalam KBBI.')
 }
 
 let result = `Definisi dari *${text}*:\n`
 definitions.forEach((def, index) => {
 result += `${index + 1}. ${def}\n`
 })
 
 sky.sendMessage(m.chat, { text: result }, { quoted: m })
 }).catch(error => {
 m.reply('Terjadi kesalahan saat mencari definisi kata.')
 })
}
break
case 'aptoide': {
 if (!isPrem) return replyprem(mess.premium);
 const fetch = require('node-fetch');

 if (!text) throw 'Masukkan nama aplikasi yang ingin dicari.';

 // URL Aptoide API
 const API_URL = "http://ws75.aptoide.com/api/7";

 // Fungsi untuk mengambil hasil pencarian aplikasi dari Aptoide
 async function fetchSearchResults(query) {
 try {
 const url = `${API_URL}/apps/search?query=${encodeURIComponent(query)}&limit=1`;
 const response = await fetch(url);
 if (!response.ok) throw new Error('Gagal mengambil data pencarian.');
 const body = await response.json();
 const results = body.datalist.list.map(app => ({
 title: app.name,
 link: app.file?.path, // Link unduhan APK
 image: app.icon,
 developer: app.store.name
 }));
 return results;
 } catch (error) {
 console.error('Error fetching search results:', error);
 return [];
 }
 }

 try {
 const searchResults = await fetchSearchResults(text);
 if (searchResults.length === 0) {
 m.reply('Aplikasi tidak ditemukan.');
 return;
 }

 const appDetails = searchResults[0];
 if (!appDetails.link) {
 m.reply('Link download tidak ditemukan.');
 return;
 }

 m.reply(`Menyiapkan unduhan untuk ${appDetails.title}\n\nMohon tunggu sekitar 1-10 menit...`);

 const downloadResponse = await fetch(appDetails.link);
 if (!downloadResponse.ok) throw new Error('Gagal mengunduh APK.');

 // Kirim file sebagai lampiran langsung dari stream
 sky.sendMessage(m.chat, {
 document: {
 url: appDetails.link,
 data: downloadResponse.body,
 },
 mimetype: 'application/vnd.android.package-archive',
 fileName: `${appDetails.title}.apk`
 });

 } catch (error) {
 m.reply('Terjadi kesalahan: ' + error.message);
 }
}
break
case 'apkcombo': {
const fetch = require('node-fetch');
const cheerio = require('cheerio');

 class ApkCombo {
 constructor() {
 this.APIs = {
 1: "https://apkcombo.com",
 };
 this.Proxy = url => url ? `https://translate.google.com/translate?sl=en&tl=fr&hl=en&u=${encodeURIComponent(url)}&client=webapp` : "";
 }

 api(ID, path = "/", query = {}) {
 return (ID in this.APIs ? this.APIs[ID] : ID) + path + (Object.keys(query).length ? "?" + new URLSearchParams(query).toString() : "");
 }

 async searchApp(query) {
 try {
 let res = await fetch(this.Proxy(this.api(1, `/search/${encodeURIComponent(query.replace(" ", "-"))}`)));
 let html = await res.text();
 let $ = cheerio.load(html);
 let results = [];

 $("div.content-apps > a").each((i, element) => {
 let name = $(element).attr("title");
 let link = $(element).attr("href").replace("https://apkcombo-com.translate.goog/", "https://apkcombo.com/").replace("/?_x_tr_sl=en&_x_tr_tl=fr&_x_tr_hl=en&_x_tr_pto=wapp", "");
 results.push({ name, link });
 });

 return results;
 } catch (error) {
 throw new Error('Gagal mencari aplikasi: ' + error.message);
 }
 }

 async downloadApp(url) {
 try {
 let res = await fetch(url);
 let html = await res.text();
 let $ = cheerio.load(html);
 let img = $("div.app_header.mt-14 > div.avatar > img").attr("data-src");
 let developer = $("div.container > div > div.column.is-main > div.app_header.mt-14 > div.info > div.author > a").text();
 let appname = $("div.container > div > div.column.is-main > div.app_header.mt-14 > div.info > div.app_name > h1").text();
 let downloadLink = "https://apkcombo.com" + $("div.container > div > div.column.is-main > div.button-group.mt-14.mb-14.is-mobile-only > a").attr("href");
 res = await fetch(downloadLink);
 html = await res.text();
 $ = cheerio.load(html);
 return {
 img: img,
 developer: developer,
 appname: appname,
 link: $("#best-variant-tab > div:nth-child(1) > ul > li > ul > li > a").attr("href") + "&fp=945d4e52764ab9b1ce7a8fba0bb8d68d&ip=160.177.72.111"
 };
 } catch (error) {
 throw new Error('Gagal mengunduh aplikasi: ' + error.message);
 }
 }

 async handleRequest(m, text) {
 if (!text) {
 m.reply('Masukkan nama aplikasi yang ingin dicari.');
 return;
 }

 try {
 // Cari aplikasi berdasarkan nama
 const searchResults = await this.searchApp(text);
 if (searchResults.length === 0) {
 m.reply('Aplikasi tidak ditemukan.');
 return;
 }
 const appDetails = searchResults[0];
 if (!appDetails.link) {
 m.reply('Link aplikasi tidak ditemukan.');
 return;
 }
 // Siapkan unduhan
 m.reply(`Menyiapkan unduhan untuk ${appDetails.name}\n\nMohon tunggu...`);

 const downloadDetails = await this.downloadApp(appDetails.link);
 if (!downloadDetails.link) {
 m.reply('Link unduhan APK tidak ditemukan.');
 return;
 }

 // Kirim file APK 
 sky.sendMessage(m.chat, {
 document: {
 url: downloadDetails.link,
 },
 mimetype: 'application/vnd.android.package-archive',
 fileName: `${text}.apk`
 });

 } catch (error) {
 m.reply('Terjadi kesalahan: ' + error.message);
 }
 }
 }

 // Buat instance dari ApkCombo dan jalankan handleRequest
 const apkCombo = new ApkCombo();
 await apkCombo.handleRequest(m, text);
}
break
case 'sfile': {
async function sfileSearch(query, page = 1) {
let res = await fetch(`https://sfile.mobi/search.php?q=${query}&page=${page}`)
let $ = cheerio.load(await res.text())
let result = []
$('div.list').each(function () {
let title = $(this).find('a').text()
let size = $(this).text().trim().split('(')[1]
let link = $(this).find('a').attr('href')
if (link) result.push({ title, size: size.replace(')', ''), link })
})
return result
}
	
async function sfileDl(url) {
let res = await fetch(url)
let $ = cheerio.load(await res.text())
let filename = $('div.w3-row-padding').find('img').attr('alt')
let mimetype = $('div.list').text().split(' - ')[1].split('\n')[0]
let filesize = $('#download').text().replace(/Download File/g, '').replace(/\(|\)/g, '').trim()
let download = $('#download').attr('href') + '&k=' + Math.floor(Math.random() * (15 - 10 + 1) + 10)
return { filename, filesize, mimetype, download }
}
		
if (q.match(/(https:\/\/sfile.mobi\/)/gi)) {
let res = await sfileDl(q)
if (!res) return m.reply('Error :/')
await m.reply(Object.keys(res).map(v => `*• ${v}:* ${res[v]}`).join('\n') + '\n\n_Sending file..._')
sky.sendMessage(m.chat, { document: { url: res.download }, fileName: res.filename, mimetype: res.mimetype }, { quoted: m })
} else if (q) {
let [query, page] = q.split`|`
let res = await sfileSearch(query, page)
if (!res.length) return m.reply( `Query "${text}" not found :/`)
let rus = res.map((v) => `*Title:* ${v.title}\n*Size:* ${v.size}\n*Link:* ${v.link}`).join`\n\n`
m.reply(rus)
} else return m.reply( 'Input Query / Sfile Url!')
}
break
case 'ebay': {
 if (!q) return m.reply(`Mau cari apa?`);
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function azvxz(query) {
 try { // wm avs
 const url = `https://www.ebay.com/sch/i.html?_nkw=${encodeURIComponent(query)}`;
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const results = [];
 $('.s-item').each((index, element) => {
 const title = $(element).find('.s-item__title').text().trim();
 const price = $(element).find('.s-item__price').text().trim();
 const link = $(element).find('.s-item__link').attr('href');
 if (title && title !== "Shop on eBay") { // Jgn Di Hapus Ini
 results.push({ title, price, link });
 }
 });
 return results;
 } catch (error) {
 console.error('Error:', error);
 return [];
 }
 }
// wm avs
 const query = m.text;
 try {
 const results = await azvxz(query);
// wm avs
 if (results.length === 0) {
 m.reply("Tidak ada hasil ditemukan untuk pencarian Anda.");
 } else {
 let response = "Hasil pencarian eBay:\n\n";
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nHarga: ${item.price}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 } catch (error) {
 m.reply("Terjadi Error.");
 }
}
break
case 'manganelo': {
 if (!q) return m.reply(`Mau cari manga apa?`);

 const axios = require('axios');
 const cheerio = require('cheerio');

 async function searchManganelo(query) {
 try {
 const url = `https://manganelo.com/search/story/${encodeURIComponent(query)}`;
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const results = [];
 $('.search-story-item').each((index, element) => {
 const title = $(element).find('.item-title').text().trim();
 const link = $(element).find('.item-title a').attr('href');
 const description = $(element).find('.item-chapter').text().trim();
 const latestChapter = $(element).find('.item-chapter').text().trim();
 
 if (title && link) {
 results.push({
 title,
 description,
 latestChapter,
 link: `https://manganelo.com${link}` // Menggabungkan URL base dengan link relatif
 });
 }
 });
 return results;
 } catch (error) {
 console.error('Error scraping Manganelo:', error);
 return [];
 }
 }

 const query = m.text;
 try {
 const results = await searchManganelo(query);

 if (results.length === 0) {
 m.reply("Tidak ada hasil ditemukan untuk pencarian Anda.");
 } else {
 let response = "Hasil pencarian Manganelo:\n\n";
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nDeskripsi: ${item.description}\nBab Terbaru: ${item.latestChapter}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 } catch (error) {
 m.reply("Terjadi Error.");
 }
}
break
case 'animecharacter': {
 if (!text) {
 m.reply('Contoh: animecharacter naruto');
 return;
 }

 m.reply('_Sabar tuan, sedang mencari karakter anime..._');

 async function getCharacterInfo(characterName) {
 const query = `
 query ($search: String) {
 Character(search: $search) {
 name {
 full
 }
 description
 media {
 nodes {
 title {
 romaji
 }
 }
 }
 }
 }
 `;

 const variables = {
 search: characterName
 };

 const response = await fetch('https://graphql.anilist.co', {
 method: 'POST',
 headers: {
 'Content-Type': 'application/json',
 'Accept': 'application/json',
 },
 body: JSON.stringify({
 query: query,
 variables: variables
 })
 });

 if (!response.ok) {
 throw new Error('Gagal mengambil data karakter');
 }

 const data = await response.json();
 return data.data.Character;
 }

 try {
 const query = text.trim();
 const characterInfo = await getCharacterInfo(query);

 if (!characterInfo) {
 m.reply('Karakter anime tidak ditemukan.');
 return;
 }

 // Format hasil pencarian karakter
 const name = characterInfo.name.full;
 const description = characterInfo.description || 'Deskripsi tidak tersedia';
 const mediaTitles = characterInfo.media.nodes.map(node => node.title.romaji).join(', ');

 const formattedDescription = description
 .replace(/\n/g, '\n\n') // Menambahkan jarak antar paragraf
 .replace(/__([^__]+)__/g, '*$1*') // Mengganti underline dengan bold
 .replace(/~\!?\[([^\]]+)]\(([^)]+)\)~?/g, '*$1* ($2)') // Mengganti markdown gambar dengan teks dan link
 .replace(/^\s+/gm, ''); // Menghapus spasi ekstra di awal paragraf

 const result = `*Nama Karakter:* ${name}\n\n*Deskripsi:* ${formattedDescription}\n\n*Media Terkait:* ${mediaTitles}`;

 m.reply(result);

 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break
case 'ssweb': {
 const screenshotmachine = require('screenshotmachine');
 const fs = require('fs');
 const path = require('path');

 if (!q) return m.reply(`_Masukkan Link nya lah_`);

 async function captureScreenshot(url) {
 try {
 let customerKey = '182e99';
 let secretPhrase = ''; // leave secret phrase empty, if not needed
 let options = {
 url: url,
 dimension: '1366xfull', // or "1366xfull" for full length screenshot
 device: 'desktop',
 format: 'png',
 cacheLimit: '0',
 delay: '200',
 zoom: '100'
 };

 let apiUrl = screenshotmachine.generateScreenshotApiUrl(customerKey, secretPhrase, options);
 let output = path.resolve(__dirname, 'output.png');

 const screenshotStream = screenshotmachine.readScreenshot(apiUrl);
 
 // Gunakan stream untuk menulis file screenshot
 const writeStream = fs.createWriteStream(output);
 
 screenshotStream.pipe(writeStream);

 // Tunggu sampai proses penulisan selesai
 await new Promise((resolve, reject) => {
 writeStream.on('finish', resolve);
 writeStream.on('error', reject);
 });

 // Kirim pesan screenshot ke pengguna
 await sky.sendMessage(m.chat, { image: { url: output }, caption: 'Screenshot berhasil diambil!' }, { quoted: m });
 
 // Hapus file setelah dikirim untuk menghemat ruang
 fs.unlinkSync(output);

 } catch (error) {
 console.error(error);
 m.reply('Terjadi kesalahan saat mencoba menghasilkan gambar.');
 }
 }

 captureScreenshot(q);
}
break
case 'videyfind': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function videy(url) {
 try {
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 const videoSrc = $('source[type="video/mp4"]').attr('src');
 // Tambahkan pengecekan apakah videoSrc benar-benar ada dan valid
 if (videoSrc && videoSrc.startsWith('http')) {
 return videoSrc;
 } else {
 return null;
 }
 } catch (error) {
 console.error(`Error fetching the URL: ${error.message}`);
 return null;
 }
 }

 function generateRandomCode(length = 8) {
 const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
 let result = '';
 for (let i = 0; i < length; i++) {
 result += characters.charAt(Math.floor(Math.random() * characters.length));
 }
 return result;
 }

 async function findActiveVideyLinks(count) {
 let activeLinks = [];
 while (activeLinks.length < count) {
 const code = generateRandomCode();
 const url = `https://videy.co/v?id=${code}`;
 const videoSrc = await videy(url);
 if (videoSrc) {
 activeLinks.push({ url, videoSrc });
 }
 }
 return activeLinks;
 }

 async function main() {
 const jumlah = parseInt(m.text.split(' ')[1], 10);
 if (isNaN(jumlah) || jumlah <= 0) {
 return m.reply('Silakan masukkan jumlah yang valid.');
 }
 
 m.reply('Sedang mencari link Videy yang aktif...');
 const activeLinks = await findActiveVideyLinks(jumlah);
 if (activeLinks.length === 0) {
 return m.reply('Tidak ada link Videy yang aktif ditemukan.');
 }
 let response = 'Link Videy yang aktif:\n\n';
 activeLinks.forEach((item, index) => {
 response += `${index + 1}. ${item.url}\n`;
 });
 m.reply(response);
 }

 main();
}
break
case 'tourl12': {
 const axios = require('axios');
 const FormData = require('form-data');
 const fs = require('fs');
 m.reply('Tunggu sebentar...'); // Mengirim pesan 'wait' sementara proses berlangsung

 // Fungsi untuk mengunggah file ke ufile.io
 async function uploadToUFile(filePath) {
 try {
 if (!fs.existsSync(filePath)) {
 throw new Error("File tidak ditemukan");
 }

 const form = new FormData();
 form.append('file', fs.createReadStream(filePath));

 const response = await axios.post('https://ufile.io/upload', form, {
 headers: {
 ...form.getHeaders()
 }
 });

 if (response.status === 200 && response.data.status === "ok") {
 return `https://ufile.io/${response.data.file}`; // Mengembalikan URL file yang diunggah
 } else {
 throw new Error(`Upload gagal dengan status: ${response.status}`);
 }
 } catch (err) {
 throw new Error(`Upload gagal: ${err.message}`);
 }
 }

 try {
 // Mengunduh dan menyimpan media dari pesan
 let media = await sky.downloadAndSaveMediaMessage(qmsg);

 // Mengecek apakah tipe media adalah file (bisa gambar atau lainnya)
 if (/image|video|audio|document/.test(mime)) {
 let url = await uploadToUFile(media);
 m.reply(`Berhasil diunggah: ${url}`);
 } else {
 m.reply(`Maaf, hanya file media yang dapat diunggah.`);
 }

 // Menghapus file setelah diunggah
 await fs.unlinkSync(media);
 } catch (err) {
 m.reply(`Error: ${err.message}`);
 }
}
break

case 'cocodl': {
 if (isBan) return m.reply('Maaf, kamu sedang dibanned oleh owner.');
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply('Maaf, limit download kamu habis.');

 db.data.users[m.sender].limit -= 10; // Kurangi limit

 if (!text) return m.reply('Masukkan URL video yang ingin di-download!');

 m.reply('Sedang mengunduh video, harap tunggu sebentar...');

 async function cocofun(url) {
 return new Promise((resolve, reject) => {
 axios({
 url,
 method: 'get',
 headers: {
 'Cookie': 'client_id=1a5afdcd-5574-4cfd-b43b-b30ad14c230e',
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36',
 }
 }).then(data => {
 const $ = cheerio.load(data.data);
 let json;
 const res = $('script#appState').get();
 for (let i of res) {
 if (i.children && i.children[0] && i.children[0].data) {
 const ress = i.children[0].data.split('window.APP_INITIAL_STATE=')[1];
 json = JSON.parse(ress);
 }
 }
 const result = {
 status: 200,
 author: json.share.post.post.author,
 topic: json.share.post.post.content ? json.share.post.post.content : json.share.post.post.topic.topic,
 caption: $("meta[property='og:description']").attr('content'),
 play: json.share.post.post.playCount,
 like: json.share.post.post.likes,
 share: json.share.post.post.share,
 duration: json.share.post.post.videos[json.share.post.post.imgs[0].id].dur,
 thumbnail: json.share.post.post.videos[json.share.post.post.imgs[0].id].coverUrls[0],
 watermark: json.share.post.post.videos[json.share.post.post.imgs[0].id].urlwm,
 no_watermark: json.share.post.post.videos[json.share.post.post.imgs[0].id].url
 };
 resolve(result);
 }).catch(reject);
 });
 }

 try {
 const result = await cocofun(text);

 if (!result || !result.no_watermark) return m.reply('Video tidak ditemukan atau mungkin private.');

 await sky.sendMessage(m.chat, {
 video: { url: result.no_watermark },
 mimetype: 'video/mp4',
 caption: result.caption || 'Video'
 });
 } catch (error) {
 console.error('Error fetching video:', error);
 m.reply('Terjadi kesalahan saat mengambil video.');
 }
}
break
case 'fbdl': {
 if (isBan) return m.reply('Maaf, kamu sedang dibanned oleh owner.');
 if (!isPremium && global.db.data.users[m.sender].limit < 1) return m.reply('Maaf, limit download kamu habis.');

 db.data.users[m.sender].limit -= 10; // Kurangi limit

 if (!text) return m.reply('Masukkan URL video yang ingin di-download!');

 m.reply('Sedang mengunduh video, harap tunggu sebentar...');

 const axios = require('axios');

 const fbdl = async (videoUrl, cookie, useragent) => {
 try {
 const headers = {
 "sec-fetch-user": "?1",
 "sec-ch-ua-mobile": "?0",
 "sec-fetch-site": "none",
 "sec-fetch-dest": "document",
 "sec-fetch-mode": "navigate",
 "cache-control": "max-age=0",
 authority: "www.facebook.com",
 "upgrade-insecure-requests": "1",
 "accept-language": "en-GB,en;q=0.9,tr-TR;q=0.8,tr;q=0.7,en-US;q=0.6",
 "sec-ch-ua": '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
 "user-agent": useragent || "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.114 Safari/537.36",
 accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
 cookie: cookie || "sb=Rn8BYQvCEb2fpMQZjsd6L382; datr=Rn8BYbyhXgw9RlOvmsosmVNT; c_user=100003164630629; _fbp=fb.1.1629876126997.444699739; wd=1920x939; spin=r.1004812505_b.trunk_t.1638730393_s.1_v.2_; xs=28%3A8ROnP0aeVF8XcQ%3A2%3A1627488145%3A-1%3A4916%3A%3AAcWIuSjPy2mlTPuZAeA2wWzHzEDuumXI89jH8a_QIV8; fr=0jQw7hcrFdas2ZeyT.AWVpRNl_4noCEs_hb8kaZahs-jA.BhrQqa.3E.AAA.0.0.BhrQqa.AWUu879ZtCw",
 };

 const parseString = (string) => JSON.parse(`{"text": "${string}"}`).text;

 if (!videoUrl || !videoUrl.trim()) throw new Error("Please specify the Facebook URL");
 if (["facebook.com", "fb.watch"].every((domain) => !videoUrl.includes(domain))) throw new Error("Please enter a valid Facebook URL");

 const { data } = await axios.get(videoUrl, { headers });

 const sanitizedData = data.replace(/&quot;/g, '"').replace(/&amp;/g, "&");

 const hdMatch = sanitizedData.match(/"browser_native_hd_url":"(.*?)"/) || sanitizedData.match(/"playable_url_quality_hd":"(.*?)"/) || sanitizedData.match(/hd_src\s*:\s*"([^"]*)"/);
 const titleMatch = sanitizedData.match(/<meta\sname="description"\scontent="(.*?)"/);
 const thumbMatch = sanitizedData.match(/"preferred_thumbnail":{"image":{"uri":"(.*?)"/);

 if (hdMatch && hdMatch[1]) {
 return {
 hd: parseString(hdMatch[1]),
 title: titleMatch && titleMatch[1] ? parseString(titleMatch[1]) : "No title available",
 thumbnail: thumbMatch && thumbMatch[1] ? parseString(thumbMatch[1]) : "No thumbnail available"
 };
 } else {
 throw new Error("Unable to fetch video information at this time. Please try again.");
 }
 } catch (err) {
 console.error(err);
 throw new Error("Unable to fetch video information at this time. Please try again.");
 }
 };

 try {
 const result = await fbdl(text);

 if (!result || !result.hd) return m.reply('Video tidak ditemukan atau mungkin private.');

 await sky.sendMessage(m.chat, { 
 video: { url: result.hd }, 
 mimetype: 'video/mp4', 
 caption: result.title
 });
 } catch (error) {
 console.error('Error fetching video:', error);
 m.reply('Terjadi kesalahan saat mengambil video.');
 }
}
break
case 'qcv1': {
 try {
 if (!q) return m.reply(`Apa isinya?`);

 // Fungsi untuk mengambil profil avatar
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0];
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return { attrs: { url: 'https://telegra.ph/file/0b113db9d9e244ea22c81.jpg' } };
 }
 }

 const { createCanvas, loadImage } = require('canvas');
 const fs = require('fs');
 const path = require('path');
 const moment = require('moment-timezone');

 const canvasWidth = 1000;
 const canvasHeight = 500;
 const avatarSize = 120;
 const panelPadding = 30;

 // Ambil nama dan pesan
 const message = q.trim();
 if (!message) return m.reply(`Format yang benar: ${prefix + command} "Tweet"`);

 // Ambil nama pengirim dan avatar image menggunakan getPp
 const name = await sky.getName(m.sender);
 const target = m.sender;
 const avatarData = await getPp(sky, target);
 const avatarUrl = avatarData.attrs.url;
 const avatarImg = await loadImage(avatarUrl);

 // Buat canvas
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Background hitam dengan efek matrix atau kode
 ctx.fillStyle = '#0D0D0D';
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Efek matrix di background
 const matrixText = '010101001011010';
 ctx.font = '20px monospace';
 ctx.fillStyle = '#00FF41';
 for (let i = 0; i < canvasWidth; i += 100) {
 for (let j = 0; j < canvasHeight; j += 50) {
 ctx.fillText(matrixText, i, j);
 }
 }

 // Menggambar panel semi-transparan di atas background
 ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
 ctx.fillRect(panelPadding, panelPadding, canvasWidth - panelPadding * 2, canvasHeight - panelPadding * 2);

 // Menggambar avatar dengan efek glitch
 ctx.save();
 ctx.beginPath();
 ctx.arc(avatarSize / 2 + panelPadding, avatarSize / 2 + panelPadding, avatarSize / 2, 0, Math.PI * 2, true);
 ctx.closePath();
 ctx.clip();
 ctx.drawImage(avatarImg, panelPadding, panelPadding, avatarSize, avatarSize);
 ctx.restore();

 ctx.strokeStyle = '#FF0000'; // Glitch effect with red
 ctx.lineWidth = 5;
 ctx.beginPath();
 ctx.arc(avatarSize / 2 + panelPadding, avatarSize / 2 + panelPadding, avatarSize / 2 + 5, 0, Math.PI * 2);
 ctx.stroke();

 // Menggambar nama dengan efek glitch
 ctx.fillStyle = '#00FF41';
 ctx.font = 'bold 45px Arial';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'top';
 const nameX = avatarSize + panelPadding * 2;
 const nameY = panelPadding;
 ctx.shadowColor = '#FF0000';
 ctx.shadowBlur = 15;
 ctx.fillText(name, nameX, nameY);

 // Reset efek shadow
 ctx.shadowBlur = 0;

 // Menggambar centang biru dengan efek glitch
 const checkmarkSize = 35;
 const checkmarkX = nameX + ctx.measureText(name).width + 20;
 const checkmarkY = nameY + 10;
 const checkmarkImg = await loadImage('https://upload.wikimedia.org/wikipedia/commons/e/e4/Twitter_Verified_Badge.svg');
 ctx.drawImage(checkmarkImg, checkmarkX, checkmarkY, checkmarkSize, checkmarkSize);

 // Menggambar username di bawah nama
 const username = `@${name.toLowerCase().replace(/\s/g, '')}`;
 ctx.fillStyle = '#808080';
 ctx.font = '25px monospace';
 ctx.fillText(username, nameX, nameY + 50);

 // Menggambar tweet dengan font ala kode hacker
 ctx.fillStyle = '#FFFFFF';
 ctx.font = '45px Courier New';
 ctx.textBaseline = 'middle';
 const textX = panelPadding;
 const textY = avatarSize + panelPadding * 5;
 const maxTextWidth = canvasWidth - panelPadding * 5;

 const wrappedText = wrapText(ctx, message, maxTextWidth);
 wrappedText.forEach((line, index) => {
 ctx.fillText(line, textX, textY + index * 40);
 });

 // Menggambar waktu dan sumber dengan tampilan futuristik
 const time = moment().tz('Asia/Jakarta').format('HH:mm · MMM D, YYYY');
 const source = "Cyber Terminal";
 ctx.fillStyle = '#00FF41';
 ctx.font = 'italic 22px Arial';
 const timeText = `${time} · ${source}`;
 const timeX = panelPadding;
 const timeY = canvasHeight - panelPadding;
 ctx.fillText(timeText, timeX, timeY);

 // Simpan dan kirim gambar
 const outputPath = path.join(__dirname, 'qcv1-hacker.png');
 const out = fs.createWriteStream(outputPath);
 const stream = canvas.createPNGStream();
 stream.pipe(out);

 out.on('finish', async () => {
 await sky.sendImageAsSticker(m.chat, outputPath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(outputPath); // Menghapus file setelah dikirim
 });

 // Fungsi untuk membungkus teks agar sesuai dengan lebar maksimal
 function wrapText(ctx, text, maxWidth) {
 const words = text.split(' ');
 const lines = [];
 let currentLine = words[0];

 for (let i = 1; i < words.length; i++) {
 const word = words[i];
 const width = ctx.measureText(currentLine + ' ' + word).width;
 if (width < maxWidth) {
 currentLine += ' ' + word;
 } else {
 lines.push(currentLine);
 currentLine = word;
 }
 }
 lines.push(currentLine);
 return lines;
 }

 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam membuat tweet dengan efek hacker.');
 }
}
break
case 'qcv2': {
 try {
 if (!q) return m.reply(`Pesan nya?`);

 // Fungsi untuk mengambil profil avatar
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0];
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return { attrs: { url: 'https://telegra.ph/file/0b113db9d9e244ea22c81.jpg' } };
 }
 }

 const { createCanvas, loadImage } = require('canvas');
 const fs = require('fs');
 const path = require('path');
 const moment = require('moment-timezone');

 const canvasWidth = 600;
 const canvasHeight = 260; 
 const avatarSize = 80;
 const panelPadding = 20;

 // Ambil nama dan pesan
 const message = q.trim();
 if (!message) return m.reply(`Format yang benar: ${prefix + command} "Pesan"`);

 // Ambil nama pengirim dan avatar image menggunakan getPp
 const name = await sky.getName(m.sender);
 const target = m.sender;
 const avatarData = await getPp(sky, target);
 const avatarUrl = avatarData.attrs.url;
 const avatarImg = await loadImage(avatarUrl);

 // Buat canvas
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Background gradient
 const gradient = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
 gradient.addColorStop(0, '#232526');
 gradient.addColorStop(1, '#414345');
 ctx.fillStyle = gradient;
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Menggambar panel teknologi
 ctx.fillStyle = '#1f1f1f';
 ctx.strokeStyle = '#00FF00';
 ctx.lineWidth = 4;
 ctx.roundRect(avatarSize + panelPadding + 10, panelPadding, canvasWidth - avatarSize - panelPadding * 2 - 10, canvasHeight - panelPadding * 2, 20);
 ctx.fill();
 ctx.stroke();

 // Menggambar avatar
 ctx.save();
 ctx.beginPath();
 ctx.arc(avatarSize / 2 + panelPadding, canvasHeight / 2, avatarSize / 2, 0, Math.PI * 2, true);
 ctx.closePath();
 ctx.clip();
 ctx.drawImage(avatarImg, panelPadding, (canvasHeight - avatarSize) / 2, avatarSize, avatarSize);
 ctx.restore();

 // Menggambar nama di dalam panel
 ctx.fillStyle = '#00FF00';
 ctx.font = 'bold 25px Arial';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'top';
 const nameX = avatarSize + panelPadding * 2 + 10;
 const nameY = panelPadding + 10;
 ctx.fillText(name, nameX, nameY);

 // Menggambar pesan di dalam panel
 ctx.fillStyle = '#FFFFFF';
 ctx.font = 'bold 26px Arial';
 ctx.textBaseline = 'middle';
 const textX = avatarSize + panelPadding * 2 + 10;
 const textY = canvasHeight / 2;
 const maxTextWidth = canvasWidth - avatarSize - panelPadding * 3 - 10;

 const wrappedText = wrapText(ctx, message, maxTextWidth);
 wrappedText.forEach((line, index) => {
 ctx.fillText(line, textX, textY - (wrappedText.length - 1) * 14 + index * 28);
 });

 // Menggambar waktu di dalam panel
 const time = moment().tz('Asia/Jakarta').format('HH:mm');
 ctx.fillStyle = '#00FF00';
 ctx.font = 'italic 20px Arial';
 ctx.textAlign = 'right';
 ctx.textBaseline = 'bottom';
 const timeX = canvasWidth - panelPadding - 10;
 const timeY = canvasHeight - panelPadding - 10;
 ctx.fillText(time, timeX, timeY);

 const outputPath = path.join(__dirname, 'qcv2.png');
 const out = fs.createWriteStream(outputPath);
 const stream = canvas.createPNGStream();
 stream.pipe(out);

 out.on('finish', async () => {
 await sky.sendImageAsSticker(m.chat, outputPath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(outputPath); // Menghapus file setelah dikirim
 });

 // Fungsi untuk membungkus teks agar sesuai dengan lebar maksimal
 function wrapText(ctx, text, maxWidth) {
 const words = text.split(' ');
 const lines = [];
 let currentLine = words[0];

 for (let i = 1; i < words.length; i++) {
 const word = words[i];
 const width = ctx.measureText(currentLine + ' ' + word).width;
 if (width < maxWidth) {
 currentLine += ' ' + word;
 } else {
 lines.push(currentLine);
 currentLine = word;
 }
 }
 lines.push(currentLine);
 return lines;
 }

 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam membuat panel teknologi.');
 }
}
break
case 'qcv3': {
 try {
 if (!q) return m.reply(`Pesan nya?`);

 // Fungsi untuk mengambil profil avatar
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0];
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return { attrs: { url: 'https://telegra.ph/file/0b113db9d9e244ea22c81.jpg' } };
 }
 }

 const { createCanvas, loadImage } = require('canvas');
 const fs = require('fs');
 const path = require('path');
 const moment = require('moment-timezone');

 const canvasWidth = 500;
 const canvasHeight = 700; // Ukuran kartu qcv3
 const avatarSize = 400; // Ukuran foto qcv3
 const padding = 50; // Padding luar

 // Ambil nama dan pesan
 const message = q.trim();
 if (!message) return m.reply(`Format yang benar: ${prefix + command} "Pesan"`);

 // Ambil nama pengirim dan avatar image menggunakan getPp
 const name = await sky.getName(m.sender);
 const target = m.sender;
 const avatarData = await getPp(sky, target);
 const avatarUrl = avatarData.attrs.url;
 const avatarImg = await loadImage(avatarUrl);

 // Buat canvas
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Menggambar background putih untuk qcv3
 ctx.fillStyle = '#ffffff';
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Menggambar foto qcv3
 ctx.drawImage(avatarImg, padding, padding, avatarSize, avatarSize);

 // Menggambar nama di bawah foto qcv3
 ctx.fillStyle = '#000000';
 ctx.font = 'bold 30px Arial';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'middle';
 ctx.fillText(name, canvasWidth / 2, avatarSize + padding + 40);

 // Menggambar pesan di bawah nama
 ctx.fillStyle = '#000000';
 ctx.font = 'italic 24px Arial';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'top';
 const messageY = avatarSize + padding + 80;
 wrapText(ctx, message, canvasWidth - padding * 2, canvasWidth / 2, messageY);

 // Menggambar waktu di bawah pesan
 const time = moment().tz('Asia/Jakarta').format('HH:mm');
 ctx.fillStyle = '#000000';
 ctx.font = 'italic 20px Arial';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'bottom';
 ctx.fillText(time, canvasWidth / 2, canvasHeight - padding);

 const outputPath = path.join(__dirname, 'qcv3.png');
 const out = fs.createWriteStream(outputPath);
 const stream = canvas.createPNGStream();
 stream.pipe(out);

 out.on('finish', async () => {
 await sky.sendImageAsSticker(m.chat, outputPath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(outputPath); // Menghapus file setelah dikirim
 });

 // Fungsi untuk membungkus teks agar sesuai dengan lebar maksimal
 function wrapText(ctx, text, maxWidth, x, y) {
 const words = text.split(' ');
 let line = '';
 const lineHeight = 30; // Jarak antar baris
 let lineY = y;

 for (let i = 0; i < words.length; i++) {
 const testLine = line + words[i] + ' ';
 const metrics = ctx.measureText(testLine);
 const testWidth = metrics.width;

 if (testWidth > maxWidth && i > 0) {
 ctx.fillText(line, x, lineY);
 line = words[i] + ' ';
 lineY += lineHeight;
 } else {
 line = testLine;
 }
 }
 ctx.fillText(line, x, lineY);
 }

 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam membuat kartu qcv3.');
 }
}
break
case 'qcv4': {
 try {
 if (!q) return m.reply(`Pesan nya?`);

 // Fungsi untuk mengambil profil avatar
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0];
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return { attrs: { url: 'https://telegra.ph/file/0b113db9d9e244ea22c81.jpg' } };
 }
 }

 const { createCanvas, loadImage } = require('canvas');
 const fs = require('fs');
 const path = require('path');
 const moment = require('moment-timezone');

 const canvasWidth = 700;
 const canvasHeight = 800;
 const avatarSize = 150;
 const cardMargin = 30;
 const borderRadius = 30;
 const neonGlowWidth = 20;

 // Ambil nama dan pesan
 const message = q.trim();
 if (!message) return m.reply(`Format yang benar: ${prefix + command} "Pesan"`);

 // Ambil nama pengirim dan avatar image menggunakan getPp
 const name = await sky.getName(m.sender);
 const target = m.sender;
 const avatarData = await getPp(sky, target);
 const avatarUrl = avatarData.attrs.url;
 const avatarImg = await loadImage(avatarUrl);

 // Buat canvas
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Background gradient dengan efek teknologi
 const gradient = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
 gradient.addColorStop(0, '#002e2b');
 gradient.addColorStop(1, '#006d77');
 ctx.fillStyle = gradient;
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Draw card with neon glow
 ctx.strokeStyle = '#00bfae'; // Neon color
 ctx.lineWidth = neonGlowWidth;
 ctx.beginPath();
 ctx.roundRect(cardMargin, cardMargin, canvasWidth - cardMargin * 2, canvasHeight - cardMargin * 2, borderRadius);
 ctx.stroke();
 ctx.fillStyle = '#003d34'; // Dark background for the card
 ctx.beginPath();
 ctx.roundRect(cardMargin, cardMargin, canvasWidth - cardMargin * 2, canvasHeight - cardMargin * 2, borderRadius);
 ctx.fill();

 // Draw avatar with futuristic frame
 ctx.save();
 ctx.beginPath();
 ctx.arc(canvasWidth / 2, cardMargin + avatarSize / 2, avatarSize / 2 + 10, 0, Math.PI * 2, true);
 ctx.closePath();
 ctx.clip();
 ctx.drawImage(avatarImg, canvasWidth / 2 - avatarSize / 2, cardMargin, avatarSize, avatarSize);
 ctx.restore();

 // Draw futuristic frame around avatar
 ctx.strokeStyle = '#00bfae'; // Neon color
 ctx.lineWidth = 5;
 ctx.beginPath();
 ctx.arc(canvasWidth / 2, cardMargin + avatarSize / 2, avatarSize / 2 + 10, 0, Math.PI * 2, true);
 ctx.stroke();

 // Draw name
 ctx.fillStyle = '#00bfae'; // Neon color
 ctx.font = 'bold 36px "Roboto", sans-serif';
 ctx.textAlign = 'center';
 ctx.textBaseline = 'top';
 const nameX = canvasWidth / 2;
 const nameY = cardMargin + avatarSize + 20;
 ctx.fillText(name, nameX, nameY);

 // Draw message
 ctx.fillStyle = '#ffffff'; // White text color
 ctx.font = '24px "Roboto", sans-serif';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'top';
 const textX = cardMargin + 20;
 const textY = nameY + 40;
 const maxTextWidth = canvasWidth - cardMargin * 2 - 40;

 wrapText(ctx, message, maxTextWidth, textX, textY);

 // Draw time
 const time = moment().tz('Asia/Jakarta').format('HH:mm');
 ctx.fillStyle = '#00bfae'; // Neon color
 ctx.font = 'italic 22px "Roboto", sans-serif';
 ctx.textAlign = 'right';
 ctx.textBaseline = 'bottom';
 const timeX = canvasWidth - cardMargin - 20;
 const timeY = canvasHeight - cardMargin - 20;
 ctx.fillText(time, timeX, timeY);

 const outputPath = path.join(__dirname, 'qcv4.png');
 const out = fs.createWriteStream(outputPath);
 const stream = canvas.createPNGStream();
 stream.pipe(out);

 out.on('finish', async () => {
 await sky.sendImageAsSticker(m.chat, outputPath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(outputPath); // Menghapus file setelah dikirim
 });

 // Fungsi untuk membungkus teks agar sesuai dengan lebar maksimal
 function wrapText(ctx, text, maxWidth, x, y) {
 const words = text.split(' ');
 let line = '';
 const lineHeight = 30; // Jarak antar baris
 let lineY = y;

 for (let i = 0; i < words.length; i++) {
 const testLine = line + words[i] + ' ';
 const metrics = ctx.measureText(testLine);
 const testWidth = metrics.width;

 if (testWidth > maxWidth && i > 0) {
 ctx.fillText(line, x, lineY);
 line = words[i] + ' ';
 lineY += lineHeight;
 } else {
 line = testLine;
 }
 }
 ctx.fillText(line, x, lineY);
 }

 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam membuat kartu teknologi.');
 }
}
break
case 'loker': {
 if (!q) return m.reply('_mau cari loker apa? misalnya loker guru_');
// wm avs
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function searchJobs(query) {
 try {
// wm avs
 const url = `https://www.google.com/search?q=lowongan+pekerjaan+${encodeURIComponent(query)}`;
 const { data } = await axios.get(url, {
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
 }
 });
 const $ = cheerio.load(data);
// wm avs
 const results = [];
 $('.g').each((index, element) => {
 const title = $(element).find('h3').text();
 const link = $(element).find('a').attr('href');
 const description = $(element).find('.IsZvec').text();

 if (title && link) {
 results.push({ title, description, link });
 }
 });
// wm avs
 return results;
 } catch (error) {
 console.error('Error:', error);
 return [];
 }
 }
// wm avs
 const query = m.text;
 try {
 const results = await searchJobs(query);
// wm avs
 if (results.length === 0) {
 m.reply('Maaf, Loker Blm Ada.');
 } else {
 let response = `Hasil pencarian lowongan pekerjaan: ${q}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nDeskripsi: ${item.description}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 } catch (error) {
 m.reply('errr.');
 }
}
break
case 'faktanegara': {
 const axios = require('axios');

 async function getCountryFacts(country) {
 try {
 const url = `https://restcountries.com/v3.1/name/${encodeURIComponent(country)}?fullText=true`;
 const { data } = await axios.get(url);

 if (data && data.length > 0) {
 const countryData = data[0];
 const countryName = countryData.name.common;
 const capital = countryData.capital ? countryData.capital[0] : 'Tidak diketahui';
 const population = countryData.population;
 const languages = Object.values(countryData.languages).join(', ');

 return `Negara: ${countryName}\nIbukota: ${capital}\nPopulasi: ${population}\nBahasa: ${languages}`;
 } else {
 return "Maaf, data negara tidak ditemukan.";
 }
 } catch (error) {
 console.error('Error:', error);
 return "Terjadi kesalahan saat mengambil data negara.";
 }
 }

 const country = m.text.split(' ').slice(1).join(' ');

 if (!country) {
 m.reply("Silakan masukkan nama negara setelah perintah, contoh: faktanegara indonesia");
 } else {
 getCountryFacts(country).then(response => {
 m.reply(response);
 }).catch(error => {
 m.reply("Terjadi kesalahan saat memproses permintaan Anda.");
 });
 }
}
break
case 'bingsearch': {
 if (isBan) return m.reply('Lu Di Ban Owner Gausa So Asik');
 if (!text) throw `Example : ${prefix + command} avosky`;
 
 let axios = require('axios');
 let cheerio = require('cheerio');
 
 axios.get(`https://www.bing.com/search?q=${encodeURIComponent(text)}`)
 .then(response => {
 let $ = cheerio.load(response.data);
 let results = [];
 
 $('.b_algo').each((i, elem) => {
 let title = $(elem).find('h2').text();
 let link = $(elem).find('a').attr('href');
 let snippet = $(elem).find('.b_caption p').text();
 
 if (title && link) {
 results.push({ title, link, snippet });
 }
 });
 
 if (results.length === 0) return m.reply('Tidak ada hasil yang ditemukan.');
 
 let teks = `Bing Search From : ${text}\n\n`;
 for (let i = 0; i < Math.min(results.length, 5); i++) { // Batasi hasil ke 5
 let res = results[i];
 teks += `⭔ *Title* : ${res.title}\n`;
 teks += `⭔ *Description* : ${res.snippet}\n`;
 teks += `⭔ *Link* : ${res.link}\n\n────────────────────────\n\n`;
 }
 m.reply(teks);
 })
 .catch(err => {
 m.reply('Terjadi kesalahan saat melakukan pencarian.');
 console.error(err);
 });
}
break
case 'duckduckgosearch': {
 if (!text) throw `Example : ${prefix + command} avosky`;
// wm avs 
 let axios = require('axios');
 let cheerio = require('cheerio');
// wm avs 
 axios.get(`https://duckduckgo.com/html/?q=${encodeURIComponent(text)}`)
 .then(response => {
 let $ = cheerio.load(response.data);
 let results = [];
 // wm avs 
 $('.result').each((i, elem) => {
 let title = $(elem).find('.result__title').text();
 let link = $(elem).find('.result__url').attr('href');
 let snippet = $(elem).find('.result__snippet').text();
// wm avs 
 if (title && link) {
 results.push({ title, link, snippet });
 }
 });
// wm avs 
 if (results.length === 0) return m.reply('Tidak ada hasil.');
// wm avs 
 let teks = `DuckDuckGo Search From : ${text}\n\n`;
 for (let i = 0; i < Math.min(results.length, 5); i++) {
 let res = results[i];
 teks += `⭔ _Title_ : ${res.title}\n`;
 teks += `⭔ _Description_ : ${res.snippet}\n`;
 teks += `⭔ _Link_ : https:${res.link}\n\n────────────────────────\n\n`;
 }
 m.reply(teks);
 })
 .catch(err => {
 m.reply('Terjadi kesalahan.');
 console.error(err);
 });
}
break

case 'kamusnet': {
 if (!q) return m.reply("Masukkan kata yang ingin dicari.");

 const word = q.trim();

 async function searchIndonesianWord(word) {
 const config = {
 url: `https://www.kamus.net/indonesia/${word}`,
 result: {
 w: {
 selector: "#featured-term #featured-term-int"
 },
 prons: [
 {
 synthesis: "id-ID"
 }
 ],
 defs: {
 container: "#featured-term-trans",
 groups: ".trans-target",
 result: {
 def: {
 selector: "p",
 toArray: true,
 excludeChild: ".pron",
 includeArrayIndex: true
 }
 }
 }
 }
 };

 try {
 const { data } = await axios.get(config.url);
 const $ = cheerio.load(data);

 // Get the word
 const wordResult = $(config.result.w.selector).text().trim();

 // Get the definitions
 const definitions = [];
 $(config.result.defs.container).find(config.result.defs.groups).each((index, element) => {
 $(element).find(config.result.defs.result.def.selector).each((i, el) => {
 const defText = $(el).text().trim();
 if (defText && !definitions.includes(defText)) {
 definitions.push(defText);
 }
 });
 });

 return {
 word: wordResult,
 definitions: definitions.map((def, index) => `${index + 1}. ${def}`),
 numberOfDefinitions: definitions.length,
 pronunciations: config.result.prons
 };
 } catch (error) {
 console.error('Error:', error);
 return null;
 }
 }

 try {
 const result = await searchIndonesianWord(word);

 if (result) {
 let response = `**Kamus.net - ${result.word}**\n\n`;
 response += `Jumlah Definisi: ${result.numberOfDefinitions}\n\n`;
 response += `**Definisi:**\n`;
 result.definitions.forEach(def => response += `${def}\n`);
 response += `\n**Pengucapan:**\n`;
 result.pronunciations.forEach(pron => response += `${pron.synthesis}\n`);
 
 m.reply(response);
 } else {
 m.reply("Tidak ada hasil ditemukan untuk pencarian Anda.");
 }
 } catch (error) {
 m.reply("Terjadi Error saat mencari kata.");
 }
}
break
case 'hdvid': {
 const { TelegraPh } = require('./lib/uploader');
 const { exec } = require('child_process');
 const fs = require('fs');
 const util = require('util');
 const execPromise = util.promisify(exec);
 const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));
 
 const who = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.fromMe ? sky.user.jid : m.sender;
 const q = m.quoted ? m.quoted : m;
 const mime = (q.msg || q).mimetype || '';
 
 if (!mime || !mime.startsWith('video/')) return m.reply(`Mana video-nya bang?`);
 
 m.reply(mess.wait); // Assuming `mess.wait` is a message indicating that the process is in progress
 
 try {
 const media = await sky.downloadAndSaveMediaMessage(q);
 const url = await TelegraPh(media);
 const output = 'output.mp4'; // Nama file output

 // Menggunakan ffmpeg untuk meningkatkan resolusi video ke 720p
 await execPromise(`ffmpeg -i ${media} -s 1280x720 -c:v libx264 -c:a copy ${output}`);
 
 // Mengunggah video yang telah ditingkatkan resolusinya
 await sky.sendMessage(m.chat, { caption: `_Success To HD Video_`, video: { url: output }}, {quoted: m});
 
 // Menunggu sebentar sebelum menghapus file
 await sleep(60000);

 // Menghapus file yang sudah diproses
 fs.unlinkSync(output);
 fs.unlinkSync(media);

 } catch (error) {
 console.error('Error:', error);
 m.reply('Terjadi kesalahan saat memproses video.');
 }
}
break
case 'gore': {
 const intricateGore = async () => {
 const state = {
 status: null,
 message: "",
 pages: null,
 result: []
 };

 const randomPageGenerator = () => Math.floor(Math.random() * 723);

 const fetchPageContent = async (page) => {
 try {
 const response = await axios.get(`https://kaotic.com/?page=${page}`);
 return response.data;
 } catch (error) {
 throw new Error(`Fetch Error: ${error.message}`);
 }
 };

 const parsePageData = (data) => {
 const $ = cheerio.load(data);
 const extractInfo = (item) => ({
 title: $(item).find(".video > h2").text(),
 author: $(item).find(".video > .info > span > a").text(),
 views: $(item).find(".video > .info > .views-count > span").text(),
 comments: $(item).find(".video > .info > .comm-count > span").text(),
 url: $(item).find(".video > .video-image > a").attr("href"),
 thumbnail: $(item).find(".video > .video-image > a > img").attr("src")
 });

 return $(".row > div > div.tab-wrapper").toArray().flatMap(wrapper =>
 $(wrapper).find(".tab-content > .row > div.col-xs-6").toArray().map(extractInfo)
 );
 };

 const updateState = (entries) => {
 if (entries.length === 0) {
 return {
 status: false,
 message: "Unknown error occurred",
 pages: null,
 result: null
 };
 }
 return {
 status: true,
 message: "ok",
 pages: randomPageGenerator(), // Re-generating page number for complexity
 result: entries
 };
 };

 const handleError = (error) => ({
 status: false,
 message: `Caught Exception: ${error.message}`,
 pages: null,
 result: null
 });

 try {
 const page = randomPageGenerator();
 state.pages = page;
 const data = await fetchPageContent(page);
 const entries = parsePageData(data);
 return updateState(entries);
 } catch (error) {
 return handleError(error);
 }
 };

 try {
 const result = await intricateGore();

 if (result.status) {
 let response = `Hasil pencarian dari halaman ${result.pages}:\n\n`;
 result.result.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nPenulis: ${item.author}\nViews: ${item.views}\nKomentar: ${item.comments}\nURL: ${item.url}\nThumbnail: ${item.thumbnail}\n\n`;
 });
 m.reply(response);
 } else {
 m.reply(result.message);
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat memproses permintaan.");
 }
}
break
case 'randomgore': {
 // Mengambil jumlah dari input user, default ke 1 jika tidak ada input jumlah
 const jumlah = parseInt(m.text.split(' ')[1]) || 1;

 // Fungsi untuk mengambil link video gore secara acak
 async function gore() {
 return new Promise((resolve, reject) => {
 axios.get("https://seegore.com/gore/")
 .then(anu => {
 const $ = cheerio.load(anu.data);
 let ini = [];
 $("figure.media").each(function (a, b) {
 ini.push($(this).find("a").attr("href"));
 });
 const random = ini[Math.floor(Math.random() * ini.length)];
 axios.get(random)
 .then(result => {
 const $$ = cheerio.load(result.data);
 const hasilnya = $$("source[type='video/mp4']").attr("src");
 resolve(hasilnya);
 })
 .catch(error => reject(error));
 })
 .catch(error => reject(error));
 });
 }

 // Fungsi untuk mengirim video gore
 async function sendGoreVideos(count) {
 for (let i = 0; i < count; i++) {
 try {
 const videoUrl = await gore();
 await sky.sendMessage(m.chat, { video: { url: videoUrl }, caption: 'Video Gore' });
 } catch (error) {
 m.reply("Terjadi kesalahan saat mengambil video.");
 console.error('Error:', error);
 break; // Berhenti jika ada error
 }
 }
 }

 // Memanggil fungsi pengiriman video dengan jumlah yang diminta
 sendGoreVideos(jumlah);
}
break
case 'osintmail': {
 const { exec } = require('child_process');
 const { promisify } = require('util');
 let execAsync = promisify(exec);
 
const isMail = (text) => {
 return text.match(new RegExp(/^(?:(?!.*?[.]{2})[a-zA-Z0-9](?:[a-zA-Z0-9.+!%-]{1,64}|)|\"[a-zA-Z0-9.+!% -]{1,64}\")@[a-zA-Z0-9][a-zA-Z0-9.-]+(.[a-z]{2,}|.[0-9]{1,})$/, "gi"));
};

 if (!q) return m.reply(`Contoh :osintmail abc@example.com`);
 if (!isMail(q)) return m.reply("INVALID EMAIL");

m.reply('_mohon bersabar silahkan di tunggu_')

 let email = q;
 let output;

 try {
 output = await execAsync(`python py/Infoga/infoga.py --info ${email} --breach -v 3`);
 } catch (error) {
 output = error;
 } finally {
 const { stdout, stderr } = output;
 if (stdout.trim()) m.reply(stdout);
 if (stderr.trim()) m.reply(stderr);
 }
}
break
case 'igdl': {
 if (!q) return m.reply("Silakan masukkan URL Instagram.");

 async function igdl(url) {
 try {
 // Menggunakan RestAPI dari widipe.com
 const response = await axios.get(`https://widipe.com/download/igdl?url=${encodeURIComponent(url)}`);
 
 // Memeriksa apakah statusnya berhasil
 if (response.data.status && response.data.code === 200) {
 return {
 status: 200,
 media: response.data.result
 };
 } else {
 return {
 status: 400,
 message: "Gagal mendapatkan media"
 };
 }
 } catch (error) {
 console.error("Error fetching Instagram media:", error.message);
 return {
 status: 400,
 message: "Terjadi kesalahan saat mengunduh media"
 };
 }
 }

 try {
 const url = q; // URL dari query
 const result = await igdl(url);

 if (result.status === 200 && result.media.length > 0) {
 // Mengirimkan media pertama dari hasil yang ditemukan
 const video = result.media[0].url;
 sky.sendMessage(m.chat, { video: { url: video } }, { quoted: m });
 } else {
 m.reply("Tidak ada media yang ditemukan atau terjadi kesalahan.");
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat memproses permintaan.");
 }
}
break;

case 'tafsirweb': {
 if (!q) return m.reply(`masukan kata kunci yg mau di cari misalnya tafsirweb : sakit`);
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function scrapeTafsir(searchQuery) {
 const url = `https://tafsirweb.com/?s=${encodeURIComponent(searchQuery)}`;
// wm avs
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const tafsirResults = [];
 $('.entry-title a').each((index, element) => {
 const title = $(element).text();
 const link = $(element).attr('href');
 tafsirResults.push({ title, link });
 });
// wm avs
 return tafsirResults;
 } catch (error) {
 console.error('Error fetching data:', error);
 return [];
 }
 }
// wm avs
 scrapeTafsir(`${q}`)
 .then(results => {
 if (results.length === 0) {
 m.reply('Tidak ada hasil Di kata kuncu itu.');
 } else {
 let response = `Hasil pencarian Tafsirweb: ${q}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 })
 .catch(error => {
 m.reply('Terjadi 404.');
 });
}
 break
case 'rumaysho': {
 if (!q.trim()) return m.reply(`Masukkan kata kunci yang ingin dicari, misalnya: rumaysho : adam`);
 const axios = require('axios');
 const cheerio = require('cheerio');
 // wm avz
 async function scrapeTafsir(searchQuery) {
 const url = `https://rumaysho.com/?s=${encodeURIComponent(searchQuery)}`;
 // wm avz
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const tafsirResults = [];
 $('.post-title a').each((index, element) => {
 const title = $(element).text();
 const link = $(element).attr('href');
 tafsirResults.push({ title, link });
 });
 // wm avz
 return tafsirResults;
 } catch (error) {
 console.error('Error fetching data:', error.message);
 return [];
 }
 }
 // wm avz
 scrapeTafsir(q)
 .then(results => {
 if (results.length === 0) {
 m.reply('Tidak ada hasil ditemukan untuk kata kunci tersebut.');
 } else {
 let response = `Hasil pencarian Rumaysho untuk: ${q}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 })
 .catch(error => {
 m.reply('Terjadi kesalahan saat mengambil data.');
 });
 }
 break
case 'ypia': {
 if (!q.trim()) return m.reply(`Masukkan kata kunci yang ingin dicari, misalnya: ypia : masjid`);
 const axios = require('axios');
 const cheerio = require('cheerio');
 // wm avz
 async function scrapeTafsir(searchQuery) {
 const url = `https://ypia.or.id/?s=${encodeURIComponent(searchQuery)}`;
 // wm avz
 try {
 const { data } = await axios.get(url, {
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
 }
 });
 const $ = cheerio.load(data); 
 const tafsirResults = [];
 $('.entry-title a').each((index, element) => {
 const title = $(element).text().trim();
 const link = $(element).attr('href');
 tafsirResults.push({ title, link });
 });
 // wm avz
 return tafsirResults;
 } catch (error) {
 console.error('Error fetching data:', error.message);
 return [];
 }
 }
 // wm avz
 scrapeTafsir(q)
 .then(results => {
 if (results.length === 0) {
 m.reply('Tidak ada.');
 } else {
 let response = `Hasil pencarian YPIA untuk: ${q}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 })
 .catch(error => {
 m.reply('Terjadi ngehenk.');
 });
 }
 break
case 'goodreads': {
 if (!q.trim()) return m.reply(`Masukkan judul buku atau kata kunci yang ingin dicari, misalnya: goodreads : Harry Potter`);
 const axios = require('axios');
 const cheerio = require('cheerio');
 // wm avz
 async function avzzzz(query) {
 const url = `https://www.goodreads.com/search?q=${encodeURIComponent(query)}`;
 // wm avz
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const books = [];
 $('.tableList tr').each((index, element) => {
 const title = $(element).find('a.bookTitle span').text().trim();
 const link = $(element).find('a.bookTitle').attr('href');
 const rating = $(element).find('span.minirating').text().trim();
 // wm avz
 books.push({ title, link: `https://www.goodreads.com${link}`, rating });
 });
 // wm avz
 return books;
 } catch (error) {
 console.error('Error fetching data:', error.message);
 return [];
 }
 }
 // wm avz
 avzzzz(q)
 .then(results => {
 if (results.length === 0) {
 m.reply('ora eneng.');
 } else {
 let response = `Hasil pencarian Goodreads untuk: ${q}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}. ${item.title}\nRating: ${item.rating}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 })
 .catch(error => {
 m.reply('emror.');
 });
 }
 break
case 'wikiquote': {
 if (!q.trim()) return m.reply(`Masukkan kata kunci yang ingin dicari, misalnya: wikiquote : kebahagiaan`);
 const axios = require('axios');
 const cheerio = require('cheerio');
 // wm avz
 async function searchWikiquote(query) {
 const url = `https://id.m.wikiquote.org/wiki/Istimewa:Pencarian?search=${encodeURIComponent(query)}`;
 // wm avz
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const quotes = [];
 $('.mw-search-result-heading').each((index, element) => {
 const title = $(element).text().trim();
 const link = $(element).find('a').attr('href');
 quotes.push({
 title: title,
 link: `https://id.m.wikiquote.org${link}`
 });
 });
 // wm avz 
 $('.mw-search-result-data').each((index, element) => {
 const description = $(element).text().trim();
 if (quotes[index]) {
 quotes[index].description = description; 
 }
 });
 // wm avz
 return quotes.length > 0 ? quotes : []; 
 } catch (error) {
 console.error('Error fetching data:', error.message);
 return [];
 }
 }
 // wm avz
 searchWikiquote(q)
 .then(results => {
 if (results.length === 0) {
 m.reply('Tidak ada hasil.');
 } else {
 let response = `Hasil pencarian Wikiquote untuk: ${q}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}. Judul: ${item.title}\nDeskripsi: ${item.description ? item.description : 'Tidak ada deskripsi'}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 })
 .catch(error => {
 m.reply('Terjadi kesalahan.');
 });
 }
 break
case 'spairing': {
 if (!isPrem) return replyprem(mess.premium)
const pino = require("pino");
const { makeWASocket, useMultiFileAuthState, PHONENUMBER_MCC } = require("@whiskeysockets/baileys");
	let { state } = await useMultiFileAuthState("tmp"); 
	let config = {
		printQRInTerminal: false,
		browser: ["Ubuntu", "Chrome", "20.0.04"],
		auth: state
	};	
	global.ShiroSockets = makeWASocket(config)	
	let [num, jum, slep] = text.split(' ')
	let jumlah = jum ? jum : 1
	let jeda = slep ? slep : 2000	
	if (!num) return m.reply(`*Enter The Number Target!*\nExample Code: .spampairing nomor jumlah jeda\nExample: .spampairing 628xxx 10 2\n\n*[ N O T E ]*\nUntuk jeda, *1000* = 1 detik`)
	if (jeda < 1000) return m.reply("Waktu jeda minimal 1000!")
	if (num.includes('6283863727400')) return m.reply("Jangan Spam Ke Ownerku Paman!!!")
	try {
		await m.reply("_Sending Request..._")
		await sleep(jeda)
		let phoneNumber = num.replace(/[^0-9]/g, '');
		if (!Object.keys(PHONENUMBER_MCC)?.some(v => phoneNumber?.startsWith(v))) {
			phoneNumber = num.replace(/[^0-9]/g, '');
		};
		for (let i = 0; i < jumlah; i++) { 
			await ShiroSockets?.requestPairingCode(phoneNumber)
			await sleep(jeda)
		};
		await m.reply(`*Mission Succsess...*\n\n*• Target:* ${phoneNumber}\n*• Jumlah:* ${jum}\n*• Jeda:* ${slep} ms\n\n*[ N O T E ]*\nSegala Resiko Ditanggung Oleh Pengguna,\nJangan Disalah Gunakan Yaa Fiturnya!`)
	} catch(x) {
		m.reply(String(x))
	}
}
break
case 'ceklink': {
 if (!text) return m.reply('Please provide a group link!');

 // Ekstrak kode undangan dari URL
 const codeMatch = text.match(/chat.whatsapp.com\/([\w\d]+)/);
 if (codeMatch === null) return m.reply('No invite URL detected.');

 const code = codeMatch[1]; // Ambil kode undangan dari hasil match
 const link = `https://chat.whatsapp.com/${code}`;

 try {
 // Cek apakah link grup valid
 const groupInfo = await sky.groupGetInviteInfo(code);
 let { subject, id } = groupInfo;
 m.reply(`Valid link!\nLink: ${link}\nGroup Name: ${subject}\nGroup ID: ${id}`);
 } catch (error) {
 if (error?.output?.statusCode === 406) {
 m.reply('Link not found or invalid.');
 } else if (error?.output?.statusCode === 410) {
 m.reply('Group URL has been reset or expired.');
 } else {
 m.reply(`An error occurred: ${error.message}`);
 }
 }
}
break
case 'an1': {
 if (!q.trim()) return m.reply(`Masukkan kata kunci yang ingin dicari, misalnya: an1 : pou`); 
 const axios = require('axios');
 const cheerio = require('cheerio');
 const extractData = ($, selector, attr = 'text') => {
 return $(selector).map((_, el) => attr === 'text' ? $(el).text().trim() : $(el).attr(attr)).get();
 };
 const an1 = async (query) => {
 const url = `https://an1.com/tags/MOD/?story=${encodeURIComponent(query)}&do=search&subaction=search`;
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
// wm avs 
 const selectors = {
 nama: 'body > div.page > div > div > div.app_list > div > div > div.cont > div.data > div.name > a > span',
 rating: 'div > ul > li.current-rating',
 developer: 'body > div.page > div > div > div.app_list > div > div > div.cont > div.data > div.developer.xsmf.muted',
 thumb: 'body > div.page > div > div > div.app_list > div > div > div.img > img',
 link: 'body > div.page > div > div > div.app_list > div > div > div.cont > div.data > div.name > a'
 };
// wm avs
 const results = Object.keys(selectors).reduce((acc, key) => {
 acc[key] = extractData($, selectors[key], key === 'link' ? 'href' : 'text');
 return acc;
 }, {});
// wm avs
 const format = results.link.map((_, i) => ({
 judul: results.nama[i] || 'N/A',
 dev: results.developer[i] || 'N/A',
 rating: results.rating[i] || 'N/A',
 thumb: results.thumb[i] || 'N/A',
 link: results.link[i] || 'N/A'
 }));
// wm avs
 return {
 creator: "avosky",
 data: format
 };
 } catch (error) {
 throw new Error('Data retrieval failed');
 }
 };
// wm avs
 try {
 const result = await an1(q);

 if (result.data.length === 0) {
 m.reply('Tidak ada hasil.');
 } else {
 const response = result.data.reduce((msg, item, index) => (
 `${msg}${index + 1}. Judul: ${item.judul}\nDeveloper: ${item.dev}\nRating: ${item.rating}\nLink: ${item.link}\nThumbnail: ${item.thumb}\n\n`
 ), `Hasil pencarian dari an1 untuk: ${q}\n\n`);
// wm avs
 m.reply(response);
 }
 } catch (error) {
 m.reply('Terjadi kesalahan.');
 }
}
break
case 'alosehat': {
 if (!q) return m.reply("Apa yang ingin dicari?");

 const fetch = require('node-fetch');
 const cheerio = require('cheerio');

 /**
 * Mencari artikel di Hello Sehat berdasarkan query pencarian.
 * @param {string} query - Kata kunci pencarian.
 * @returns {Promise<object>} - Objek hasil pencarian.
 */
 async function searchhellosehat(query) {
 try {
 const url = `https://wp.hellosehat.com/?s=${encodeURIComponent(query)}`;
 const response = await fetch(url);
 
 if (!response.ok) {
 throw new Error(`HTTP error! Status: ${response.status}`);
 }
 
 const body = await response.text();
 const $ = cheerio.load(body);
 
 const articles = $(".card.article--card").map((index, element) => {
 const article = $(element);
 return {
 title: article.find("h2.entry-title a").text().trim(),
 link: article.find("h2.entry-title a").attr("href"),
 desc: article.find(".entry-summary p").text().trim(),
 author: article.find(".author.vcard a").text().trim(),
 time: article.find("time.entry-date.published").attr("datetime")
 };
 }).get().filter(article => article.title && article.desc);
 
 if (!articles.length) {
 throw new Error("No matching results found.");
 }
 
 const totalResults = parseInt($(".search--result-count").text(), 10) || 0;
 return { total: totalResults, results: articles };
 
 } catch (error) {
 throw new Error(`Error: ${error.message}`);
 }
 }

 try {
 const results = await searchhellosehat(q);
 const { total, results: articles } = results;
 
 if (total === 0) {
 return m.reply("Tidak ada hasil ditemukan untuk pencarian Anda.");
 }
 
 const response = articles.map((item, index) => (
 `${index + 1}. ${item.title}\nPenulis: ${item.author}\nTanggal: ${item.time}\nDeskripsi: ${item.desc}\nLink: ${item.link}\n\n`
 )).join('');

 m.reply(`Hasil pencarian Hello Sehat (${total} hasil):\n\n${response}`);
 
 } catch (error) {
 m.reply(`Terjadi kesalahan: ${error.message}`);
 }
}
break
case 'zerochan': {
 if (!q) return m.reply('Masukkan kata kunci pencarian.');
// wm avs
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function zeroAvos(avoskyy) {
 const url = `https://www.zerochan.net/search?q=${encodeURIComponent(avoskyy)}`;
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const imageUrls = [];
// wm avs
 $('.thumb img').each((index, element) => {
 const imgUrl = $(element).attr('data-src') || $(element).attr('src');
 if (imgUrl) {
 imageUrls.push(imgUrl);
 }
 });
// wm avs
 return {
 creator: 'avosky',
 links: imageUrls
 };
 } catch (error) {
 console.error('Error fetching data:', error);
 return {
 creator: 'avosky',
 links: []
 };
 }
 }
// wm avs
 const query = q;
 const result = await zeroAvos(query);
// wm avs
 if (result.links.length === 0) {
 m.reply('No images found.');
 } else {
// wm avs
 const randomIndex = Math.floor(Math.random() * result.links.length);
 const randomImage = result.links[randomIndex];

 sky.sendMessage(m.chat, { image: { url: randomImage }, caption: randomImage });
 }
}
break
case 'pornhubplay': {
 if (!q) return m.reply(`Masukkan judul video yang ingin dicari.`);

 const axios = require('axios');
 const cheerio = require('cheerio');

 async function searchVideo(query) {
 const url = `https://www.pornhub.com/video/search?search=${query}`;
 try {
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);
 return $("li[data-video-segment]").map((i, el) => {
 const $el = $(el);
 return {
 link: "https://www.pornhub.com" + $el.find(".title a").attr("href").trim(),
 title: $el.find(".title a").text().trim(),
 uploader: $el.find(".videoUploaderBlock a").text().trim(),
 views: $el.find(".views").text().trim(),
 duration: $el.find(".duration").text().trim()
 };
 }).get();
 } catch (error) {
 console.error("Error:", error.message);
 return [];
 }
 }

 async function getVideo(url) {
 try {
 const html = (await axios.get(url)).data;
 const metaPayload = ((startPattern, endPattern) => {
 const startIndex = html.search(startPattern);
 return html.substring(startIndex, html.indexOf(endPattern, startIndex));
 })(/var flashvars_\d{1,} = /, ";\n");
 return JSON.parse(metaPayload.substring(metaPayload.indexOf("{")));
 } catch (error) {
 console.error("Error fetching or parsing data:", error);
 return null;
 }
 }

 try {
 const query = m.text;
 const searchResults = await searchVideo(query);

 if (searchResults.length === 0) {
 m.reply("Tidak ada hasil ditemukan untuk pencarian Anda.");
 return;
 }

 const videoDetails = searchResults[0]; // Ambil video pertama dari hasil pencarian
 const videoData = await getVideo(videoDetails.link);

 if (!videoData || !videoData.mediaDefinitions) {
 m.reply("Gagal mendapatkan video.");
 return;
 }

 // Cari link video dengan kualitas 720p
 let videoQuality = videoData.mediaDefinitions.find(v => v.quality === '720' && v.format === 'hls');

 // Jika 720p tidak ada, cari kualitas lain yang tersedia
 if (!videoQuality) {
 videoQuality = videoData.mediaDefinitions.find(v => v.format === 'hls'); // Cari kualitas apa saja dengan format hls
 }

 if (!videoQuality) {
 m.reply("Video tidak tersedia dalam format yang dapat diunduh.");
 return;
 }

 const videoUrl = videoQuality.videoUrl;

 // Kirim video langsung
 await sky.sendMessage(m.chat, { 
 video: { 
 url: videoUrl 
 }, 
 caption: `Title: ${videoDetails.title}\nUploader: ${videoDetails.uploader}\nViews: ${videoDetails.views}\nDuration: ${videoDetails.duration}\nQuality: ${videoQuality.quality}p`
 });

 } catch (error) {
 m.reply("Terjadi error saat memproses permintaan Anda.");
 console.error(error);
 }
}
break
case 'gelbooru': {
 if (!q) return m.reply(`Masukkan tag pencarian.`);

 const axios = require('axios');

 async function fetchGelbooruData(query) {
 try {
 const { data } = await axios.get(`https://gelbooru.com/index.php?page=dapi&s=post&q=index&json=1&tags=${encodeURIComponent(query)}`);

 if (!data?.post || data.post.length === 0) {
 await m.reply(`Maaf, tidak ditemukan hasil untuk pencarian "${query}".`);
 return;
 }

 const randomInt = Math.floor(Math.random() * data.post.length);
 const imgUrl = data.post[randomInt].file_url;

 if (!imgUrl) {
 await m.reply('Gambar tidak tersedia.');
 return;
 }

 // Kirim gambar dan caption
 await sky.sendMessage(m.chat, {
 image: { url: imgUrl },
 caption: `creator: avosky\n\n>link: ${imgUrl}`
 });
 } catch (error) {
 console.error('Error fetching data:', error);
 await m.reply('Terjadi kesalahan saat mengambil data.');
 }
 }

 const query = m.text; // Ambil query pencarian dari pesan
 await fetchGelbooruData(query);
}
break
case 'aibooru': {
 if (!q) return m.reply("Apa yang ingin Anda cari?");

 async function avosky(query) {
 try { 
 const url = `https://aibooru.online/posts?tags=${query}&z=5`;
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const imageLinks = [];
 
 $('article').each((i, element) => {
 const highResLink = $(element).find('a').attr('href');
 if (highResLink) { 
 const fullHighResLink = highResLink.startsWith('http') ? highResLink : `https://aibooru.online${highResLink}`;
 imageLinks.push(fullHighResLink);
 }
 }); 
 
 if (imageLinks.length === 0) {
 await m.reply("Saya mohon maaf, tetapi saya tidak dapat menemukan apa pun.");
 return;
 }
 
 const randomInt = Math.floor(Math.random() * imageLinks.length);
 const selectedImagePage = imageLinks[randomInt];
 const { data: imagePageData } = await axios.get(selectedImagePage);
 const $$ = cheerio.load(imagePageData);
 const highResImageUrl = $$('img#image').attr('src');
 
 if (highResImageUrl) {
 const fullImageUrl = highResImageUrl.startsWith('http') ? highResImageUrl : `https://aibooru.online${highResImageUrl}`;
 const imageType = fullImageUrl.endsWith('.jpg') ? 'image/jpeg' : 'image/png'; // Determine MIME type based on URL
 
 const response = await axios.get(fullImageUrl, { responseType: 'arraybuffer' }); // Fetch the image as an array buffer
 const imageBuffer = Buffer.from(response.data, 'binary');
 
 const caption = `creator: avosky\n\n> link: ${fullImageUrl}`;
 await sky.sendMessage(m.chat, { image: imageBuffer, caption: caption }); // Send image as buffer with caption
 } else {
 await m.reply("Saya mohon maaf, tetapi saya tidak dapat menemukan gambar resolusi tinggi.");
 }

 } catch (error) {
 console.error('Error fetching data:', error);
 let errorMessage = 'Terjadi kesalahan saat mengambil data.';
 if (error.response) {
 errorMessage = `Kesalahan respons: ${error.response.status} - ${error.response.statusText}`;
 } else if (error.request) {
 errorMessage = 'Kesalahan permintaan: Tidak ada respons dari server.';
 } else {
 errorMessage = `Kesalahan: ${error.message}`;
 }
 await m.reply(errorMessage);
 }
 }

 await avosky(q);
}
break
case 'safebooru': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function scrapeImages(searchTerm) {
 const url = `https://safebooru.org/index.php?page=post&s=list&tags=${encodeURIComponent(searchTerm)}`;
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const imageUrls = [];

 $('.thumb img').each((index, element) => {
 const imgUrl = $(element).attr('data-src') || $(element).attr('src');
 if (imgUrl) {
 const baseUrl = 'https://safebooru.org/samples/256/sample';
 const imgCode = imgUrl.split('/').pop().split('?')[0].replace(/^thumbnail_/, '');
 const newUrl = `${baseUrl}_${imgCode}`;
 imageUrls.push(newUrl);
 }
 });

 return imageUrls.length > 0 ? imageUrls : null;
 } catch (error) {
 console.error('Error fetching data:', error);
 return null;
 }
 }

 if (!text) {
 return m.reply(`${prefix + command} <searchTerm>`);
 }

 try {
 const results = await scrapeImages(text);

 if (!results || results.length === 0) {
 m.reply('No results found');
 return;
 }

 const response = `*Results for:* ${text}\n\n` + results.map((url, index) => `${index + 1}. ${url}`).join('\n');
 m.reply(response);
 } catch (error) {
 console.error(error);
 m.reply('An error occurred');
 }
}
break

case 'galaxybooru': {
 if (!q) return m.reply('Masukkan query pencarian.');

 // Fungsi untuk mengambil URL gambar dari halaman
 const fetchImageUrls = async (url) => {
 try {
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);
 const images = $('img');
 const imageUrls = [];

 images.each((index, img) => {
 let src = $(img).attr('src');
 if (src && src.includes('/thumbnails/')) {
 src = src.replace('/thumbnails/', '/images/')
 .replace('thumbnail_', '');
 const imgUrl = new URL(src, url).href;
 imageUrls.push(imgUrl);
 }
 });

 return imageUrls;
 } catch (error) {
 console.error('Error fetching image URLs:', error);
 return [];
 }
 };

 const query = encodeURIComponent(q);
 const searchUrl = `https://galaxy.booru.org/index.php?page=post&s=list&tags=${query}`;
 let imageUrl = null;
 let attempts = 0;
 const maxAttempts = 5; // Maksimum percobaan

 while (!imageUrl && attempts < maxAttempts) {
 const imageUrls = await fetchImageUrls(searchUrl);
 if (imageUrls.length > 0) {
 imageUrl = imageUrls[Math.floor(Math.random() * imageUrls.length)];
 } else {
 attempts++;
 await new Promise(resolve => setTimeout(resolve, 2000)); // Tunggu 2 detik sebelum mencoba lagi
 }
 }

 if (imageUrl) {
 await sky.sendMessage(m.chat, {
 image: { url: imageUrl },
 caption: 'nih',
 quoted: m
 });

 // Kirim hasil pencarian sebagai pesan
 m.reply(`creator: avosky\nurl: ${imageUrl}`);
 } else {
 m.reply('Tidak ada gambar ditemukan setelah beberapa percobaan.');
 }
}
break

case 'tbib': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function fetchImageUrls(url) {
 try {
 // Mengambil HTML dari URL
 const { data } = await axios.get(url);

 // Memuat HTML ke cheerio
 const $ = cheerio.load(data);

 // Menyeleksi semua elemen gambar
 const images = $('img');
 const imageUrls = [];

 // Mengambil URL gambar
 images.each((index, img) => {
 let src = $(img).attr('src');
 if (src && src.includes('/thumbnails/')) {
 // Mengubah URL thumbnail menjadi URL sampel
 src = src.replace('/thumbnails/', '/samples/').replace('thumbnail_', 'sample_');
 const imgUrl = new URL(src, url).href;
 imageUrls.push(imgUrl);
 }
 });

 // Mengambil URL acak dari hasil
 const randomImageUrl = imageUrls[Math.floor(Math.random() * imageUrls.length)];

 return {
 creator: 'avosky',
 url: randomImageUrl || 'No URL found'
 };
 } catch (error) {
 console.error('Error fetching image URLs:', error);
 return {
 creator: 'avosky',
 url: 'Error occurred'
 };
 }
 }

 if (!text) return m.reply(`${prefix + command} yuri`);
 const url = `https://tbib.org/index.php?page=post&s=list&tags=${encodeURIComponent(text)}`;
 try {
 const result = await fetchImageUrls(url);
 if (result.url === 'No URL found' || result.url === 'Error occurred') {
 m.reply(result.url); // Handle errors or no results
 } else {
 const message = `*Results From TBIB for:* ${text}\n*Creator:* ${result.creator}`;
 sky.sendFile(m.chat, result.url, 'tbib.jpg', message, m); // Send the image
 }
 } catch (error) {
 console.error('Error in command execution:', error);
 m.reply('An error occurred while processing your request.');
 }
}
break
case 'azm': {
 if (!q) return m.reply(`film apa?`);
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 async function fetchvz(url) {
 try {
 const response = await axios.get(url, {
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36'
 }
 });
 return response.data;
 } catch (error) {
 console.error("Failed to fetch HTML:", error.message);
 throw new Error('Error dulu');
 }
 }
// wm avs
 function parseAvosky(html) {
 const $ = cheerio.load(html);
 const results = [];
// wm avs 
 $(".col-3.col-tb-4.col-p-6.col-md-2.poster-col").each((index, element) => {
 try {
 const $element = $(element);
 const title = $element.find(".poster__title").text().trim();
 const rilis = $element.find(".poster__year .badge").text().trim();
 const durasi = $element.find(".poster__year .has-icon").text().trim();
 const thumbImg = $element.find(".poster__img").attr("data-src");
 const link = "https://azm.to" + $element.find(".poster").attr("href");
 // wm avs 
 if (title && link) {
 results.push({ title, rilis, durasi, thumbImg, link });
 }
 } catch (parseError) {
 console.warn(`Error parsing element at index ${index}:`, parseError.message);
 }
 });

 return results;
 }
// wm avs
 async function az(query) {
 const url = `https://azm.to/search/${encodeURIComponent(query)}`;
 const html = await fetchvz(url);
 const results = parseAvosky(html);
// wm avs 
 if (results.length === 0) {
 console.log("No results found for the query:", query);
 m.reply(`Tidak ada hasil yang ditemukan untuk: ${query}`);
 } else {
 console.log(`Found ${results.length} results for the query:`, query);
 let message = `Ditemukan ${results.length} hasil untuk: ${query}\n\n`;
 results.forEach((result, index) => {
 message += `${index + 1}.\n${result.title}\nRilis: ${result.rilis}\nDurasi: ${result.durasi}\nLink: ${result.link}\n\n`;
 });
 m.reply(message);
 }
 }
// wm avs
 const userQuery = args.join(' ');
 if (!userQuery) { 
 } else {
 az(userQuery).catch(err => {
 console.error("Error:", err.message);
 m.reply("Terjadi kesalahan saat mencari data. Silakan coba lagi.");
 });
 }
}
break
case 'temposearch': {
 if (!q.trim()) return m.reply("Silakan masukkan kata kunci pencarian.");
// wm avs
 const axios = require('axios');
 const cheerio = require('cheerio');
// wm avs
 const basenya = `https://www.tempo.co/search?q=`;
// wm avs
 async function tempoSearch(keyword) {
 try {
 const { data: htmlRaw } = await axios.get(`${basenya}${encodeURIComponent(keyword)}&page=1`);
 const $ = cheerio.load(htmlRaw);

 const news = {
 judul: keyword,
 data: []
 };
// wm avs
 $('.card-box.ft240.margin-bottom-sm').each((i, el) => {
 news.data.push({
 index: i + 1,
 judul: $(el).find('article h2.title').text().trim(),
 url: $(el).find('figure a').attr('href'),
 gambar: $(el).find('figure img').attr('src'),
 deskripsi: $(el).find('article p').text().trim()
 });
 });
// wm avs
 return news;
 } catch (error) {
 console.error("Error fetching data:", error.message);
 return { judul: keyword, data: [] };
 }
 }
// wm avs
 tempoSearch(q)
 .then(result => {
 if (result.data.length === 0) {
 m.reply('Tidak ada hasil ditemukan untuk pencarian Anda.');
 } else {
 let response = `Hasil pencarian berita Tempo untuk: ${result.judul}\n\n`;
 result.data.forEach(item => {
 response += `${item.index}. ${item.judul}\nLink: ${item.url}\nDeskripsi: ${item.deskripsi}\nGambar: ${item.gambar}\n\n`;
 });
 m.reply(response);
 }
 })
 .catch(error => {
 console.error(`!: ${error.message}`);
 m.reply('aaaaaaaaaa eror.');
 });
}
 break
case 'chord': {
 if (!q.trim()) return m.reply("Silakan masukkan judul lagu yang ingin dicari.");

 const axios = require('axios');
 const cheerio = require('cheerio');

 async function chord(query) {
 return new Promise(async (resolve, reject) => {
 const head = {
 "User-Agent": "Mozilla/5.0 (Linux; Android 9; CPH1923) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.62 Mobile Safari/537.36",
 "Cookie": "__gads=ID=4513c7600f23e1b2-22b06ccbebcc00d1:T=1635371139:RT=1635371139:S=ALNI_MYShBeii6AFkeysWDKiD3RyJ1106Q; _ga=GA1.2.409783375.1635371138; _gid=GA1.2.1157186793.1635371140; _fbp=fb.1.1635371147163.1785445876"
 };

 try {
 // Mencari lagu berdasarkan query
 let { data } = await axios.get(`http://app.chordindonesia.com/?json=get_search_results&exclude=date,modified,attachments,comment_count,comment_status,thumbnail,thumbnail_images,author,excerpt,content,categories,tags,comments,custom_fields&search=${encodeURIComponent(query)}`, { headers: head });
 
 // Cek apakah ada hasil pencarian
 if (!data.posts || !data.posts.length) {
 return resolve({ title: null, chord: 'Chord tidak ditemukan.' });
 }

 // Mengambil detail chord dari post pertama yang ditemukan
 let postId = data.posts[0].id;
 let { data: postData } = await axios.get(`http://app.chordindonesia.com/?json=get_post&id=${postId}`, { headers: head });

 let $ = cheerio.load(postData.post.content);
 let title = $("img").attr("alt") || "Judul tidak ditemukan";
 let chord = $("pre").text().trim() || "Chord tidak ditemukan";

 resolve({
 title: title,
 chord: chord
 });
 } catch (error) {
 reject(error);
 }
 });
 }

 chord(q)
 .then(result => {
 if (!result.title || !result.chord) {
 m.reply('Chord tidak ditemukan.');
 } else {
 m.reply(`Chord:\n\n${result.chord}`);
 }
 })
 .catch(error => {
 console.error(`Kesalahan terjadi: ${error.message}`);
 m.reply('Terjadi kesalahan saat mencari chord.');
 });
}
 break
case 'spekhp': {
 // Import library yang diperlukan
 const axios = require('axios');
 const cheerio = require('cheerio');

 // Fungsi untuk mencari link berdasarkan query
 async function spek(query) {
 return new Promise((resolve, reject) => {
 let result = axios.get('https://carisinyal.com/hp/?_sf_s=' + query).then(v => {
 let $ = cheerio.load(v.data);
 let list = $("div.oxy-posts > div.oxy-post");
 let index = [];
 list.each((v, i) => {
 let title = $(i).find("a.oxy-post-title").text();
 let harga = $(i).find("div.harga").text();
 let link = $(i).find("a.oxy-post-image").attr('href');
 let res = {
 title: title,
 harga: harga,
 link: link
 };
 index.push(res);
 });
 return index;
 }).catch(err => reject(err));
 resolve(result);
 });
 }

 // Fungsi untuk mengambil detail spesifikasi dari link
 async function speklengkap(link) {
 return new Promise((resolve, reject) => {
 let result = axios.get(link).then(v => {
 let $ = cheerio.load(v.data);
 let fitur = [];
 let spesifikasi = [];
 let list = $("div#_dynamic_list-777-114924 > div.ct-div-block");
 list.each((v, i) => {
 let fitur_unggulan = $(i).find("span.ct-span").text();
 fitur.push({
 desc: fitur_unggulan
 });
 });
 let spek = $("div.ct-code-block > div > table.box-info");
 spek.each((v, i) => {
 let name = $(i).find("tr.box-baris > td.kolom-satu").text().trim();
 let fitur = $(i).find("tr.box-baris > td.kolom-dua").text().trim();
 spesifikasi.push({
 name: name,
 fitur: fitur
 });
 });
 let img = $("meta[name='twitter:image']").attr('content');
 return {
 fitur: fitur,
 spek: spesifikasi,
 img: img
 };
 }).catch(err => reject(err));
 resolve(result);
 });
 }

 // Ambil query dari input pengguna
 let query = m.body.slice(7).trim(); // Misalnya: "!spekhp nama hp"

 // Cek jika query kosong
 if (!query) {
 return m.reply("Silakan masukkan nama HP yang ingin dicari spesifikasinya.");
 }

 // Panggil fungsi spek untuk mencari link berdasarkan query
 spek(query)
 .then(results => {
 // Jika tidak ada hasil
 if (results.length === 0) {
 return m.reply("Maaf, tidak ditemukan HP dengan nama tersebut.");
 }

 // Ambil link pertama dari hasil pencarian
 let firstResult = results[0];
 let link = firstResult.link;

 // Panggil fungsi speklengkap untuk mengambil detail dari link tersebut
 return speklengkap(link).then(detail => {
 // Susun pesan detail spesifikasi
 let message = `*Spesifikasi ${firstResult.title}*\n`;
 message += `Harga: ${firstResult.harga}\n\n`;
 message += `*Fitur Unggulan:*\n`;
 detail.fitur.forEach((f, index) => {
 message += `${index + 1}. ${f.desc}\n`;
 });
 message += `\n*Spesifikasi Lengkap:*\n`;
 detail.spek.forEach(spec => {
 message += `${spec.name}: ${spec.fitur}\n`;
 });

 // Jika ada gambar, tambahkan gambar ke pesan
 if (detail.img) {
 message += `\nGambar: ${detail.img}`;
 }

 // Kirim pesan dengan spesifikasi lengkap
 m.reply(message);
 });
 })
 .catch(error => {
 // Tangani error jika terjadi masalah saat scraping
 console.error("Error saat mencari spesifikasi HP:", error);
 m.reply("Terjadi kesalahan saat mencari spesifikasi HP. Silakan coba lagi.");
 });
}
 break
case 'liputan6': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function avzz() {
 try {
// wm avs 
 const response = await axios.get('https://www.liputan6.com/');
 const $ = cheerio.load(response.data);
// wm avs
 const latestNews = $('.articles--iridescent-list').eq(2).find('article');
// wm avs
 const results = [];
 latestNews.each(function () {
 try {
 const title = $(this).find('figure a').attr('title');
 const link = $(this).find('figure a').attr('href');
 const image = $(this).find('figure a picture img').attr('data-src');
 const tag = $(this).find('aside header a').text();
// wm avs
 results.push({ title, link, tag, image, source: 'liputan6' });
 } catch (e) {
// wm avs
 console.error('Error scraping article:', e);
 }
 });
// wm avs
 return results;
 } catch (error) {
 console.error('Error fetching:', error);
 return [];
 }
 }
// wm avs
 avzz()
 .then(results => {
 if (results.length === 0) {
 m.reply('Tidak ada berita terbaru yang ditemukan.');
 } else {
 let message = 'Berita Terbaru dari Liputan6:\n\n';
 results.forEach((news, index) => {
 message += `${index + 1}. ${news.title}\n`;
 message += `Tag: ${news.tag}\n`;
 message += `Link: ${news.link}\n`;
 message += `Gambar: ${news.image}\n\n`;
 });
 m.reply(message);
 }
 })
 .catch(error => {
 console.error('ada bug:', error.message);
 m.reply('Terjadi kesalahan...');
 });
}
 break
case 'techradar': {
 if (!q) return m.reply(`Mau cari apa? misal techradar: infinix`);
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function tech(query) {
 const articleTitles = [];
 const articleHrefs = [];

 const url = `https://www.techradar.com/search?searchTerm=${encodeURIComponent(text)}`;

 try {
 const response = await axios.get(url);
 const $ = cheerio.load(response.data);

 // Mengambil semua artikel yang relevan
 $('.listingResult').each((index, element) => {
 const articleLink = $(element).find('a.article-link');
 const articleTitle = articleLink.find('h3.article-name').text().trim();
 const articleHref = articleLink.attr('href');

 if (articleTitle && articleHref) {
 articleTitles.push(articleTitle);
 articleHrefs.push(articleHref.startsWith('/') ? `https://www.techradar.com${articleHref}` : articleHref);
 }
 });

 // Format hasil agar lebih rapi
 return articleTitles.map((title, index) => ({
 title,
 href: articleHrefs[index]
 }));
 } catch (error) {
 console.error('Error fetching data:', error);
 return [];
 }
 }
 const results = await tech(q);

 if (results.length === 0) {
 m.reply('Maaf, tidak ada hasil ditemukan untuk pencarian tersebut.');
 } else {
 let message = 'Hasil pencarian TechRadar:\n\n';
 results.forEach((result, index) => {
 message += `${index + 1}. ${result.title}\n ${result.href}\n\n`;
 });
 m.reply(message);
 }
}
break
case 'konsultasisyariah': {
 if (!q) return m.reply(`_contoh konsultasisyariah: puasa`);
 // wm avs
 async function AvoskyBaik(query) {
 try {
 const response = await axios.get(`https://konsultasisyariah.com/?s=${query}`); // wm avs
 const html = response.data; // wm avs
 const $ = cheerio.load(html); // wm avs
 let results = []; // wm avs
 $('.post').each((index, element) => { // wm avs
 const title = $(element).find('h2 a').text(); // wm avs
 const link = $(element).find('h2 a').attr('href'); // wm avs
 results.push({ title, link }); // wm avs
 });
 return results; // wm avs
 } catch (error) {
 console.error('Error:', error); // wm avs
 return []; // wm avs
 }
 }
 // wm avs 
 AvoskyBaik(`${q}`).then(results => {
 if (results.length === 0) {
 m.reply("Tidak ada hasil."); // wm avs
 } else {
 let responseMessage = "Hasil pencarian untuk konsultasi syariah:\n"; // wm avs
 results.forEach((result, index) => { // wm avs
 responseMessage += `${index + 1}. ${result.title}\n${result.link}\n\n`; // wm avs
 });
 m.reply(responseMessage); // wm avs
 }
 }).catch(error => {
 m.reply("Terjadi kesalahan."); // wm avs
 console.error(error); // wm avs
 });
}
 break
case 'darussalam': {
 if (!q) return m.reply(`cari apa? masukan QUERY`); 
 async function AvoskyBaik(keyword) {
 try {
 const response = await axios.get(`https://darussalaf.or.id/?s=${keyword}`); // wm avs
 const html = response.data; // wm avs
 const $ = cheerio.load(html); // wm avs
 let results = []; // wm avs
 $('.entry-title a').each((index, element) => { // wm avs
 const title = $(element).text(); // wm avs
 const link = $(element).attr('href'); // wm avs
 const date = $(element).closest('.post').find('.entry-date').text(); // wm avs
 results.push({ title, link, date }); // wm avs
 });
 return results; // wm avs
 } catch (error) {
 console.error('Error fetching data:', error); // wm avs
 return []; // wm avs
 }
 }
 // wm avs
 AvoskyBaik(`${q}`).then(results => {
 if (results.length === 0) {
 m.reply("Tidak ada hasil yang ditemukan."); // wm avs
 } else {
 let responseMessage = "Hasil pencarian untuk Darussalaf:\n"; // wm avs
 results.forEach((result, index) => { // wm avs
 responseMessage += `${index + 1}. ${result.title}\nTanggal Up: ${result.date}\nLink: ${result.link}\n\n`; // wm avs
 });
 m.reply(responseMessage); // wm avs
 }
 }).catch(error => {
 m.reply("Terjadi kesalaham."); // wm avs
 console.error(error); // wm avs
 });
}
 break
case 'numberparser': {
 const number = args[0]; // misalnya "6283***"
 if (!number) {
 m.reply("Harap masukkan nomor yang ingin dicari.");
 break;
 }

 async function findUserByNumber(phoneNumber) {
 try {
 // Mengubah nomor telepon menjadi format pencarian Facebook
 const url = `https://www.facebook.com/search/top/?q=${phoneNumber}`;

 // Menggunakan axios untuk melakukan permintaan HTTP
 const response = await axios.get(url, {
 headers: {
 // User-Agent diperlukan untuk menyamar sebagai browser
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
 }
 });

 const html = response.data;
 const $ = cheerio.load(html);

 // Ini hanyalah contoh cara mencari beberapa elemen. Penyesuaian mungkin diperlukan berdasarkan struktur halaman sebenarnya.
 const userElement = $('a[href*="/profile.php?id="]').first();
 const userName = userElement.text();
 const userId = userElement.attr('href').split('=')[1];

 if (userName && userId) {
 m.reply(`Pengguna ditemukan: ${userName}\nLink Profil: https://facebook.com/profile.php?id=${userId}`);
 } else {
 m.reply("Pengguna tidak ditemukan.");
 }
 } catch (error) {
 console.error("Error:", error);
 m.reply("Terjadi kesalahan saat mencari pengguna.");
 }
 }

 findUserByNumber(number);
}
break
case 'metronews': {
 async function smetronews() {
 try {
 const response = await axios.get('https://www.metrotvnews.com/news');
 const $ = cheerio.load(response.data);

 const judul = [];
 const desc = [];
 const link = [];
 const thumb = [];

 $('h3 > a').each((index, element) => {
 judul.push($(element).attr('title'));
 link.push('https://www.metrotvnews.com' + $(element).attr('href'));
 });

 $('p').each((index, element) => {
 desc.push($(element).text());
 });

 $('img').each((index, element) => {
 thumb.push($(element).attr('src').replace('w=300', 'w=720'));
 });

 const result = judul.map((judul, index) => ({
 judul,
 link: link[index],
 thumb: thumb[index],
 deskripsi: desc[index]
 }));

 let message = 'Berita Terkini dari MetroTV News:\n\n';
 result.forEach(item => {
 message += `Judul: ${item.judul}\n`;
 message += `Deskripsi: ${item.deskripsi}\n`;
 message += `Link: ${item.link}\n`;
 message += `Thumbnail: ${item.thumb}\n\n`;
 });

 m.reply(message);
 } catch (error) {
 console.error('Error:', error.message);
 m.reply('Maaf, terjadi kesalahan saat mengambil data berita.');
 }
 }

 // Panggil fungsi async
 smetronews();
}
break
case 'globalnews': {
 async function getGlobalNews() {
 try {
 const response = await axios.get('https://api.gdeltproject.org/api/v2/doc/doc?query=latest&mode=artlist&format=json');
 const articles = response.data.articles;

 let message = 'Berita Global Terkini:\n\n';
 articles.slice(0, 5).forEach(article => { // Mengambil 5 artikel terbaru
 message += `Judul: ${article.title}\n`;
 message += `Deskripsi: ${article.seendate || 'Tidak ada deskripsi.'}\n`;
 message += `Link: ${article.url}\n\n`;
 });

 m.reply(message);
 } catch (error) {
 console.error('Error:', error.message);
 m.reply('Maaf, terjadi kesalahan saat mengambil data berita.');
 }
 }

 // Panggil fungsi async
 getGlobalNews();
}
break
case 'okezonenews': {
 async function okeAvos() {
 try {
 const titids = await axios.get('https://news.okezone.com/');
 const $ = cheerio.load(titids.data);
// wm avs
 const judul = [];
 const desc = [];
 const link = [];
 const thumb = [];
// wm avs
 $('h2 > a').each((index, element) => {
 const title = $(element).text().trim();
 const href = $(element).attr('href');
 if (title && href) {
 judul.push(title);
 link.push(href);
 }
 });
// wm avs
 $('p').each((index, element) => {
 const text = $(element).text().trim();
 if (text) {
 desc.push(text);
 }
 });
// wm avs
 $('img').each((index, element) => {
 const src = $(element).attr('src');
 if (src) {
 thumb.push(src.replace('w=300', 'w=720'));
 }
 });
// wm avs
 const result = judul.map((judul, index) => ({
 judul,
 link: link[index],
 thumb: thumb[index],
 deskripsi: desc[index]
 }));
// wm avs
 let message = 'Berita Terkini dari Okezone News:\n\n';
 result.forEach(item => {
 message += `Judul: ${item.judul}\n`;
 message += `Deskripsi: ${item.deskripsi}\n`;
 message += `Link: ${item.link}\n`;
 message += `Thumbnail: ${item.thumb}\n\n`;
 });
// wm avs
 m.reply(message);
 } catch (error) {
 console.error('Error:', error.message);
 m.reply('erorrrrrrrrrr.');
 }
 }
// wm avs
 okeAvos();
}
break
case 'thestarmalaysia': {
 async function theStarAvos() {
 try {
 const response = await axios.get('https://www.thestar.com.my/');
 const $ = cheerio.load(response.data);
 
 // Menyimpan data
 const judul = [];
 const desc = [];
 const link = [];
 const thumb = [];

 // Mengambil judul dan link
 $('h2 > a').each((index, element) => {
 const title = $(element).text().trim();
 const href = $(element).attr('href');
 if (title && href) {
 judul.push(title);
 link.push(href);
 }
 });

 // Mengambil deskripsi (jika tersedia)
 $('p').each((index, element) => {
 const text = $(element).text().trim();
 if (text) {
 desc.push(text);
 }
 });

 // Mengambil thumbnail
 $('img').each((index, element) => {
 const src = $(element).attr('src');
 if (src) {
 thumb.push(src.replace('w=300', 'w=720'));
 }
 });

 // Menggabungkan data
 const result = judul.map((judul, index) => ({
 judul,
 link: link[index],
 thumb: thumb[index],
 deskripsi: desc[index] || 'Deskripsi tidak tersedia.'
 }));

 // Membuat pesan
 let message = 'Berita Terkini dari The Star:\n\n';
 result.forEach(item => {
 message += `Judul: ${item.judul}\n`;
 message += `Deskripsi: ${item.deskripsi}\n`;
 message += `Link: ${item.link}\n`;
 message += `Thumbnail: ${item.thumb}\n\n`;
 });

 m.reply(message);
 } catch (error) {
 console.error('Error:', error.message);
 m.reply('Terjadi kesalahan saat mengambil berita.');
 }
 }

 theStarAvos();
}
break
case 'qcv5': {
 try {
 if (!q) return m.reply(`Apa isinya?`);

 // Fungsi untuk mengambil profil avatar
 async function getPp(sky, target) {
 try {
 const response = await sky.query({
 tag: "iq",
 attrs: {
 target: target,
 to: "@s.whatsapp.net",
 type: "get",
 xmlns: "w:profile:picture"
 },
 content: [{
 tag: "picture",
 attrs: {
 type: "image",
 query: "url"
 }
 }]
 });
 return response.content[0];
 } catch (error) {
 console.error('Error fetching profile picture:', error);
 return { attrs: { url: 'https://telegra.ph/file/0b113db9d9e244ea22c81.jpg' } };
 }
 }

 const { createCanvas, loadImage } = require('canvas');
 const fs = require('fs');
 const path = require('path');
 const moment = require('moment-timezone');

 const canvasWidth = 800;
 const canvasHeight = 400; 
 const avatarSize = 80;
 const panelPadding = 20;

 // Ambil nama dan pesan
 const message = q.trim();
 if (!message) return m.reply(`Format yang benar: ${prefix + command} "Tweet"`);

 // Ambil nama pengirim dan avatar image menggunakan getPp
 const name = await sky.getName(m.sender);
 const target = m.sender;
 const avatarData = await getPp(sky, target);
 const avatarUrl = avatarData.attrs.url;
 const avatarImg = await loadImage(avatarUrl);

 // Buat canvas
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');

 // Background putih seperti tema Twitter
 ctx.fillStyle = '#FFFFFF';
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);

 // Menggambar avatar
 ctx.save();
 ctx.beginPath();
 ctx.arc(avatarSize / 2 + panelPadding, avatarSize / 2 + panelPadding, avatarSize / 2, 0, Math.PI * 2, true);
 ctx.closePath();
 ctx.clip();
 ctx.drawImage(avatarImg, panelPadding, panelPadding, avatarSize, avatarSize);
 ctx.restore();

 // Menggambar nama dan centang biru
 ctx.fillStyle = '#000000';
 ctx.font = 'bold 30px Arial';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'top';
 const nameX = avatarSize + panelPadding * 2;
 const nameY = panelPadding;
 ctx.fillText(name, nameX, nameY);

 // Menggambar centang biru
 const checkmarkSize = 25;
 const checkmarkX = nameX + ctx.measureText(name).width + 10;
 const checkmarkY = nameY + 5;
 const checkmarkImg = await loadImage('https://upload.wikimedia.org/wikipedia/commons/e/e4/Twitter_Verified_Badge.svg');
 ctx.drawImage(checkmarkImg, checkmarkX, checkmarkY, checkmarkSize, checkmarkSize);

 // Menggambar username di bawah nama
 const username = `@${name.toLowerCase().replace(/\s/g, '')}`;
 ctx.fillStyle = '#8899A6';
 ctx.font = '20px Arial';
 ctx.fillText(username, nameX, nameY + 35);

 // Menggambar tweet di dalam panel
 ctx.fillStyle = '#000000';
 ctx.font = '37px Arial';
 ctx.textBaseline = 'middle';
 const textX = panelPadding;
 const textY = avatarSize + panelPadding * 5;
 const maxTextWidth = canvasWidth - panelPadding * 5;

 const wrappedText = wrapText(ctx, message, maxTextWidth);
 wrappedText.forEach((line, index) => {
 ctx.fillText(line, textX, textY + index * 30);
 });

 // Menggambar waktu dan sumber di bawah tweet
 const time = moment().tz('Asia/Jakarta').format('HH:mm · MMM D, YYYY');
 const source = "Twitter for iPhone";
 ctx.fillStyle = '#8899A6';
 ctx.font = 'italic 18px Arial';
 ctx.textAlign = 'left';
 ctx.textBaseline = 'bottom';
 const timeText = `${time} · ${source}`;
 const timeX = panelPadding;
 const timeY = canvasHeight - panelPadding;
 ctx.fillText(timeText, timeX, timeY);

 const outputPath = path.join(__dirname, 'qcv5.png');
 const out = fs.createWriteStream(outputPath);
 const stream = canvas.createPNGStream();
 stream.pipe(out);

 out.on('finish', async () => {
 await sky.sendImageAsSticker(m.chat, outputPath, m, { packname: global.packname, author: global.author });
 fs.unlinkSync(outputPath); // Menghapus file setelah dikirim
 });

 // Fungsi untuk membungkus teks agar sesuai dengan lebar maksimal
 function wrapText(ctx, text, maxWidth) {
 const words = text.split(' ');
 const lines = [];
 let currentLine = words[0];

 for (let i = 1; i < words.length; i++) {
 const word = words[i];
 const width = ctx.measureText(currentLine + ' ' + word).width;
 if (width < maxWidth) {
 currentLine += ' ' + word;
 } else {
 lines.push(currentLine);
 currentLine = word;
 }
 }
 lines.push(currentLine);
 return lines;
 }

 } catch (err) {
 console.error(err);
 m.reply('Terjadi kesalahan dalam membuat tweet.');
 }
}
break
case 'capcut': {
 if (!q) return m.reply("Silakan masukkan URL CapCut.");

 async function getCapcutVideo(url) {
 try {
 const response = await axios.get("https://ssscap.net/api/download/get-url?url=" + url, {
 headers: {
 cookie: "sign=94b3b2331a3515b3a031f161e6ce27a7; device-time=1693144685653"
 }
 });
 
 const templateUrl = response.data.url;
 const id = new URL(templateUrl).searchParams.get("template_id");
 
 const downloadResponse = await axios("https://ssscap.net/api/download/" + id, {
 headers: {
 cookie: "sign=4b0366645cd40cbe10af9aa18331a488; device-time=1693145535913"
 }
 });
 
 const baseUrl = "https://ssscap.net/";
 const result = {
 avosky: baseUrl + downloadResponse.data.originalVideoUrl
 };

 return result;
 } catch (error) {
 console.error("Error fetching CapCut video:", error.message);
 throw new Error("Failed to retrieve video");
 }
 }

 try {
 const result = await getCapcutVideo(q);

 if (result && result.avosky) {
 sky.sendMessage(m.chat, { video: { url: result.avosky } }, { quoted: m });
 } else {
 m.reply("Tidak ada video yang ditemukan atau terjadi kesalahan.");
 }
 } catch (error) {
 m.reply("Terjadi kesalahan saat memproses permintaan.");
 }
}
break


case 'aigenerator': {
 if (!isPrem) return replyprem(mess.premium)
 if (!q) return m.reply(`mana Query Nya?\nContoh: aigenerator Tintin Comic | a beautiful woman in a blue dress\n\nList Effect here\n> RANDOM\n> Cartoon\n> Tintin-Comic\n> Franco-Belgian-Comic\n> Vintage-Comic\n> 3D-Emoji\n> Furry-Cinematic\n> Furry-Drawn\n> Furry-Painted\n> Claymation\n> Flat-Style-Logo\n> Cute-3D-Icon-Set\n> Cute-3D-Icon\n> Concept-Art-Icon\n> Digital-Painting-Icon\n> Game-Art-Icon\n> Flat-Style-Icon\n> 3D-Isometric-Icon\n> Old-World-Map\n> Fantasy-City-Map\n> Fantasy-World-Map\n> Manga\n> 1920s-Photo\n> 1930s-Photo\n> 1940s-Photo\n> 1950s-Photo\n> 1960s-Photo\n> 1970s-Photo\n> 1980s-Photo\n> 1990s-Photo\n> Cursed-Photo\n> Professional-Photo\n> Casual-Photo\n> Oil-Painting-V1\n> Oil-Painting-Realism\n> Oil-Painting-V2\n> Concept-Sketch\n> Disney-Sketch\n> 2D-Disney-Character\n> 3D-Disney-Character\n> 2D-Pokemon\n> Painted-Pokemon\n> 3D-Pokemon\n> Waifu\n> Studio-Ghibli\n> Neon-Vintage-Anime\n> Vintage-Anime\n> 50s-Infomercial-Anime\n> Soft-Anime\n> Cute-Anime\n> Drawn-Anime\n> Painted-Anime\n> Anime\n> Tattoo-Design\n> Cinematic\n> Digital-Painting\n> Concept-Art\n> Painterly\n> Fantasy-Painting\n> Fantasy-Landscape\n> Fantasy-Portrait\n> 50s-Enamel-Sign\n> Medieval\n> Pixel-Art\n> Cute-Figurine\n> Illustration\n> Flat-Illustration\n> Watercolor\n> Vintage-Pulp-Art\n> Crayon-Drawing\n> Pencil\n> YuGiOh-Art\n> Traditional-Japanese\n> Nihonga-Painting\n> MTG-Card\n> No-Style`)
kyy = text.split(' | ')[0] ? text.split(' | ')[0] : '-'
ky = text.split(' | ')[1] ? text.split(' | ')[1] : '-'
 const axios = require('axios');
 async function avz(prompt) {
 try {
 return await new Promise(async (resolve, reject) => {
 if (!prompt) return reject("failed reading undefined prompt!");
 axios.post("https://aiimagegenerator.io/api/model/predict-peach", {
 prompt,
 negativePrompt: "uncensored, hd, sexy",
 key: `${kyy}`,
 width: 1024,
 height: 1024,
 quantity: 1,
 size: "512x768"
 }).then(res => {
 const data = res.data;
 if (data.code !== 0) return reject(data.message);
 if (data.data.safetyState === "RISKY") return reject("nsfw image was generated, you try create other image again!");
 if (!data.data?.url) return reject("failed generating image!");
 return resolve({
 status: true,
 image: data.data.url
 });
 }).catch(reject);
 });
 } catch (e) {
 return {
 status: false,
 message: e
 };
 }
 }
 avz(`${ky}`).then(result => {
 if (result.status && result.image) { 
 sky.sendMessage(m.chat, { image: { url: result.image } }, { caption: `> ${q}` });
 } else {
 m.reply('Gagal membuat gambar: ' + (result.message || 'Tidak diketahui.'));
 }
 }).catch(error => {
 m.reply('Terjadi kesalahan: ' + error);
 });
}
break
case 'google': {
 if (!q) return m.reply('_cari apaan?_');

 const axios = require('axios');
 const cheerio = require('cheerio');

 async function searchJobs(query) {
 try {
 const url = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
 const { data } = await axios.get(url, {
 headers: {
 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
 }
 });
 const $ = cheerio.load(data);

 const results = [];
 $('.g').each((index, element) => {
 const title = $(element).find('h3').text();
 const link = $(element).find('a').attr('href');
 const date = $(element).find('span.f').text() || 'Tanggal tidak tersedia';

 if (title && link) {
 results.push({ title, date, link });
 }
 });

 return results;
 } catch (error) {
 console.error('Error:', error);
 return [];
 }
 }

 const query = m.text;
 try {
 const results = await searchJobs(query);

 if (results.length === 0) {
 m.reply('Maaf, tidak ditemukan hasil untuk pencarian ini.');
 } else {
 let response = `Hasil pencarian untuk: ${query}\n\n`;
 results.forEach((item, index) => {
 response += `${index + 1}.Jdul: ${item.title}\nLink: ${item.link}\n\n`;
 });
 m.reply(response);
 }
 } catch (error) {
 m.reply('Terjadi kesalahan saat mencari.');
 }
}
break
case 'pornhub': {
 async function getVideo(url) {
 try {
 const html = (await axios.get(url)).data;
 const metaPattern = /var\s+flashvars_\d+\s*=\s*({.*?});/;
 const match = html.match(metaPattern);
 if (match && match[1]) {
 const metaPayload = match[1];
 const metadata = JSON.parse(metaPayload);

 const videoUrls = metadata.mediaDefinitions.filter(item => item.videoUrl.includes('cv-h'));
 
 if (videoUrls.length > 0) {
 return {
 title: metadata.video_title || 'No title found',
 image_url: metadata.image_url || 'No image URL found',
 link: url,
 ...videoUrls.reduce((acc, item) => {
 acc[item.quality] = item.videoUrl;
 return acc;
 }, {})
 };
 } else {
 return null;
 }
 } else {
 console.error("Metadata pattern not found in the HTML.");
 return null;
 }
 } catch (error) {
 console.error("Error fetching or parsing data:", error);
 return null;
 }
 }

 async function searchVideo(query) {
 const url = `https://www.pornhub.com/video/search?search=${query}`;
 const response = await axios.get(url);
 const html = response.data;
 const $ = cheerio.load(html);

 let videoList = [];

 $('li[data-video-segment]').each((index, element) => {
 const $element = $(element);
 const link = $element.find('.title a').attr('href').trim();
 const title = $element.find('.title a').text().trim();
 const uploader = $element.find('.videoUploaderBlock a').text().trim();
 const views = $element.find('.views').text().trim();
 const duration = $element.find('.duration').text().trim();

 const videoUrl = "https://www.pornhub.com" + link;

 // Fetch video details
 getVideo(videoUrl).then(videoData => {
 if (videoData) {
 videoData.link = videoUrl;
 videoList.push(videoData);
 }
 });
 });

 // Wait for all video details to be fetched
 await new Promise(resolve => setTimeout(resolve, 5000));

 // Filter out videos that don't have any found qualities and return the first one
 const filteredVideoList = videoList.filter(video => Object.values(video).some(value => value !== 'No video found for'));
 
 return filteredVideoList.length > 0 ? filteredVideoList[0] : null;
 }

 // Call the search function with the provided query
 const query = text.split(' ').slice(1).join(' ');
 if (!query) {
 m.reply('cari apa.');
 }

 searchVideo(query).then(video => {
 if (video) {
 const message = `Judul: ${video.title}\nUploader: ${video.uploader || 'Tidak diketahui'}\nViews: ${video.views || 'Tidak diketahui'}\nDurasi: ${video.duration || 'Tidak diketahui'}\n\nLink Video: ${video.link}\n\nLink Kualitas:\n720p: ${video['720p'] || 'Tidak ditemukan'}\n480p: ${video['480p'] || 'Tidak ditemukan'}\n360p: ${video['360p'] || 'Tidak ditemukan'}`;
 m.reply(message);
 } else {
 m.reply('Tidak ada video ditemukan dengan query tersebut.');
 }
 }).catch(err => {
 m.reply('Terjadi kesalahan saat mencari video.');
 console.error(err);
 });
}
break
case 'fontart': {
 const query = args.join(" ");
 if (!query) return m.reply("Masukkan teks yang ingin dibuat font art.");

 // Fungsi untuk scraping dari TextFancy
 const scrapeTextFancy = async (query) => {
 try {
 const { data } = await axios.get(`https://textfancy.com/text-art/?text=${encodeURIComponent(query)}`);
 const $ = cheerio.load(data);
 const fontArt = $('pre').first().text().trim(); // Mengambil font art pertama
 return fontArt;
 } catch (error) {
 return "Gagal mengambil font art dari TextFancy.";
 }
 };

 // Fungsi untuk scraping dari CodeItBro
 const scrapeCodeItBro = async (query) => {
 try {
 const { data } = await axios.get(`https://www.codeitbro.com/ascii-art-generator/?text=${encodeURIComponent(query)}`);
 const $ = cheerio.load(data);
 const fontArt = $('pre').first().text().trim(); // Mengambil font art pertama
 return fontArt;
 } catch (error) {
 return "Gagal mengambil font art dari CodeItBro.";
 }
 };

 (async () => {
 const artFromTextFancy = await scrapeTextFancy(query);
 const artFromCodeItBro = await scrapeCodeItBro(query);

 const message = `Font Art dari TextFancy:\n${artFromTextFancy}\n\nFont Art dari CodeItBro:\n${artFromCodeItBro}`;
 m.reply(message);
 })();
}
break
case 'ustad': {
if (!q) return m.reply(`ada apa`)
 const { key } = await sky.sendMessage(from, { text: '_Please Wait..._', previewType: 0 });

 // Fungsi untuk memanggil API ansari.chat
 const ansari = async messages => {
 try {
 // Memeriksa apakah input messages valid
 if (!messages) return { success: false, errors: ["missing messages input"] };
 if (!Array.isArray(messages)) return { success: false, errors: ["invalid array messages input"] };

 // Mengirim permintaan POST ke API
 const response = await axios.post("https://api.ansari.chat/api/v1/complete", {
 messages: [
 {
 role: "user",
 content: "tolong gunakan bahasa Indonesia sepenuhnya mulai sekarang dan gunakan sedikit gurauan dan lucu lucuan!"
 },
 {
 role: "assistant",
 content: "baik, saya mengerti!"
 }, ...messages
 ]
 }, {
 headers: {
 'Content-Type': 'application/json',
 origin: "https://ansari.chat",
 referer: "https://ansari.chat/"
 }
 });

 // Memeriksa apakah API mengembalikan hasil yang diinginkan
 const text = response.data;
 if (/failed/.test(text)) return { success: false, errors: ["Internal API error"] };

 return { success: true, answer: text };
 } catch (e) {
 return { success: false, errors: [e.message] };
 }
 };

 try {
 // Panggil fungsi ansari dengan teks input sebagai pesan
 const result = await ansari([{ role: "user", content: text }]);

 if (result.success && result.answer) {
 await sky.sendMessage(from, { text: `${result.answer}`.trim(), edit: key });
 } else {
 await sky.sendMessage(from, { text: 'Sorry, I could not get a response.', edit: key });
 }
 } catch (error) {
 await sky.sendMessage(from, { text: 'An error occurred while processing your request.', edit: key });
 }
}
break
case 'ttp2': {
 if (!q) return m.reply(`input teks`)
// wm avz
 const { createCanvas, loadImage } = require('canvas');
 const { Buffer } = require('buffer');
 const canvasWidth = 800;
 const canvasHeight = 600;
 const backgroundColor = '#f0f0f0';
// wm avz
 const canvas = createCanvas(canvasWidth, canvasHeight);
 const ctx = canvas.getContext('2d');
// wm avz
 const backgroundImage = 'https://example.com/background-image.jpg';
 try {
 const img = await loadImage(backgroundImage);
 ctx.drawImage(img, 0, 0, canvasWidth, canvasHeight);
 } catch (error) {
 ctx.fillStyle = backgroundColor;
 ctx.fillRect(0, 0, canvasWidth, canvasHeight);
 }
// wm avz
 ctx.strokeStyle = '#000';
 ctx.lineWidth = 4;
 ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
 ctx.shadowBlur = 10;
 ctx.strokeRect(20, 20, canvasWidth - 40, canvasHeight - 40);
// wm avz
 let fontSize = 80;
 ctx.font = `${fontSize}px 'Arial'`;
 ctx.textAlign = 'center';
 ctx.textBaseline = 'middle';
 ctx.fillStyle = '#333';
// wm avz 
 const textGradient = ctx.createLinearGradient(0, 0, canvasWidth, canvasHeight);
 textGradient.addColorStop(0, '#ff0000');
 textGradient.addColorStop(1, '#0000ff');
 ctx.fillStyle = textGradient;
// wm avz
 let textWidth = ctx.measureText(text).width;
 while (textWidth > canvasWidth - 40) {
 fontSize--;
 ctx.font = `${fontSize}px 'Arial'`;
 textWidth = ctx.measureText(text).width;
 }
// wm avz
 ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
 ctx.shadowBlur = 10;
 ctx.fillText(text, canvasWidth / 2, canvasHeight / 2);
// wm avz
 const buffer = canvas.toBuffer('image/png');
// wm avz
 sky.sendImageAsSticker(m.chat, buffer, m, { packname: global.packname, author: global.author });
}
break

  case 'updatepesan': {
 if (!m.isGroup || m.fromMe) return;

 if (!db.data.chats[m.chat].total) {
 db.data.chats[m.chat].total = {};
 }
 const participantCounts = db.data.chats[m.chat];
 global.cht = {};
 const messages = conn.chats[m.chat].messages;

 Object.values(messages).forEach(({ key }) => {
 global.cht[key.participant] = (global.cht[key.participant] || 0) + 1;
 });

 participantCounts.total = global.cht;
}
 break
case 'ttsv1': {
if (!q) return m.reply(`text ny?`)
 const axios = require('axios');

 // Class TTS yang diperlukan untuk generate TTS
 class TTS {
 constructor() {
 this.api = 'https://arting.ai/api/cg/text-to-voice';
 this.headers = {
 'authority': 'arting.ai',
 'accept': 'application/json',
 'content-type': 'application/json',
 'origin': 'https://arting.ai',
 'referer': 'https://arting.ai/text-to-singing-voice-generator',
 'user-agent': 'Postify/1.0.0',
 'x-forwarded-for': Array.from({ length: 4 }, () => Math.floor(Math.random() * 256)).join('.'),
 'cookie': this.gc(),
 };
 }

 gc() {
 const uuid = this.uuid();
 return `NUXT_LOCALE=en; nlg_id=${uuid}`;
 }

 uuid() {
 return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => {
 const r = Math.random() * 16 | 0;
 return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
 });
 }

 async create(prompt, initAudio, language = "english", emotion = "neutral", speed = 1) {
 return this.request(`${this.api}/create`, { prompt, init_audio: initAudio, language, emotion, speed });
 }

 async getVoice(requestId) {
 return this.request(`${this.api}/get`, { request_id: requestId });
 }

 async request(url, data, retries = 3) {
 try {
 const response = await axios.post(url, data, { headers: this.headers });
 return response.data;
 } catch (error) {
 if (error.response?.status === 504 && retries > 0) {
 return this.request(url, data, retries - 1);
 }
 throw error;
 }
 }
 }

 // Inisialisasi class dan konfigurasi permintaan TTS
 const ae = new TTS();
 const prompt = `${q}`; // Sesuaikan prompt
 const initAudio = "1000001"; // ID audio awal (sesuaikan)
 const language = "english";
 const emotion = "happy";
 const speed = 1;

 ae.create(prompt, initAudio, language, emotion, speed)
 .then(response => {
 const requestId = response.data.request_id;
 if (requestId) {
 setTimeout(() => {
 ae.getVoice(requestId)
 .then(result => {
 m.reply(JSON.stringify(result)); // Kirim hasil ke pengguna
 })
 .catch(error => {
 m.reply(`Error: ${error.message}`);
 });
 }, response.data.eta * 1000); // Tunggu waktu estimasi
 }
 })
 .catch(error => {
 m.reply(`Error: ${error.message}`);
 });
}
break


case 'linkweb': {
 const axios = require('axios');
 const cheerio = require('cheerio');

 async function getAllLinks(url) {
 try {
 // Fetch website content
 const { data } = await axios.get(url);
 const $ = cheerio.load(data);

 // Check if data is loaded properly
 if (!data || data.length === 0) {
 m.reply("Halaman tidak memiliki konten yang bisa diakses.");
 return;
 }

 // Get all 'a' tag href attributes
 const links = [];
 $('a').each((index, element) => {
 const link = $(element).attr('href');
 if (link && link.startsWith('http')) {
 links.push(link);
 }
 });

 // Check if links are found
 if (links.length > 0) {
 m.reply(`Ditemukan ${links.length} link di halaman tersebut:\n\n` + links.join('\n'));
 } else {
 m.reply("Tidak ada link yang ditemukan di halaman tersebut.");
 }

 } catch (error) {
 console.error(error);
 m.reply("Terjadi kesalahan saat mengakses halaman tersebut.");
 }
 }

 // Get the URL from the user's message
 const url = m.message.slice(m.command.length).trim();
 if (!url || url.length === 0) {
 m.reply("Mohon berikan URL yang valid.");
 } else {
 getAllLinks(url);
 }
}
break

case 'ci': {
const { getBinaryNodeChildString } = require('@whiskeysockets/baileys');
const linkRegex = /https:\/\/whatsapp\.com\/channel\/([0-9A-Za-z]*)/i;
 let [_, code] = text.match(linkRegex) || [];
 if (!code) throw `ci https://whatsapp.com/channel/`;

 await sky.sendMessage(m.chat, { react: { text: '🕒', key: m.key }});
 try {
 let result = await newsletterInviteInfo(code);
 let thumbnailUrl = result.profileUrl;
 result.creation = new Date(result.creation).toISOString().replace('T', ' ').split('.')[0];
 result.subjectTime = new Date(result.subjectTime).toISOString().replace('T', ' ').split('.')[0];
 delete result.profileUrl;

 if (result.settings['[object Promise]']) {
 result.settings = "Reaction Codes"
 }
 let settings = result.settings;

 let capt = 'SHOW INFORMATION CHANNEL\n\n';
 capt += `ID : ${result.id}\n`;
 capt += `Name : ${result.subject}\n`;
 capt += `Dibuat Pada : ${result.creation}\n`;
 capt += `Subject Diubah : ${result.subjectTime}\n`;
 capt += `Followers : ${result.followers ? Func.formatter(result.followers) : 'Tidak Diketahui'}\n`;
 capt += `Status : ${result.status}\n`;
 capt += `Settings : ${result.settings}\n`;
 capt += `Verifed : ${result.verified}\n`;
 capt += `Description : ${result.desc}`;

 await sky.sendMessage(m.chat, { image: { url: thumbnailUrl }, caption: capt }, { quoted: m })
 await sky.sendMessage(m.chat, { react: { text: '😁', key: m.key }});
 } catch (error) {
 await m.reply(String(error))
 await sky.sendMessage(m.chat, { react: { text: '😈', key: m.key }});
 }

async function toUpper(str) {
 return str.toUpperCase();
}

const extractNewsLetter = async (data = {}) => {
 const parseSetting = settings => {
 const entries = Object.entries(settings);
 const transformedSettings = entries.reduce((acc, [key, value]) => {
 acc[toUpper(key.replace(/_/g, ' '))] = typeof value === 'object' ? !!value.value : value;
 return acc;
 }, {});
 return Object.fromEntries(Object.entries(transformedSettings));
 };

 return {
 id: data.id,
 inviteCode: data.thread_metadata.invite,
 subject: data.thread_metadata.name?.text || '',
 subjectTime: Number(data.thread_metadata.name?.update_time / 1000) || 0,
 status: data.state.type || false,
 creation: Number(data.thread_metadata.creation_time * 1000),
 desc: data.thread_metadata.description?.text || '',
 descTime: Number(data.thread_metadata.description?.update_time / 1000) || 0,
 settings: (data.thread_metadata.settings && parseSetting(data.thread_metadata.settings)) || null,
 followers: Number(data.thread_metadata.subscribers_count) || false,
 verified: /verified/i.test(data.thread_metadata.verification) || false,
 profileUrl: data.thread_metadata.picture ? 'https://pps.whatsapp.net' + data.thread_metadata.picture.direct_path : 'https://pps.whatsapp.net' + data.thread_metadata.preview.direct_path || false,
 };
};

async function newsletterInviteInfo(code) {
 let payload = {
 variables: {
 input: {
 key: code,
 type: 'INVITE',
 view_role: 'GUEST',
 },
 fetch_viewer_metadata: false,
 fetch_full_image: true,
 fetch_creation_time: true,
 },
 };

 let data = await sky.query({
 tag: 'iq',
 attrs: {
 id: sky.generateMessageTag(),
 to: '@s.whatsapp.net',
 type: 'get',
 xmlns: 'w:mex',
 },
 content: [
 {
 tag: 'query',
 attrs: {
 query_id: '6620195908089573',
 },
 content: Buffer.from(JSON.stringify(payload)),
 },
 ],
 });

 let result = JSON.parse(getBinaryNodeChildString(data, 'result'));
 return extractNewsLetter(result.data.xwa2_newsletter);
}
}
break
//ADDF	    
            default:
                if (budy.startsWith('=👉')) {
                    if (!isCreator) return m.reply(mess.owner)
                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                            if (sat == undefined) {
                                bang = util.format(sul)
                            }
                            return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                }

                if (budy.startsWith('👉')) {
                    if (!isCreator) return m.reply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }

                if (budy.startsWith('💲')) {
                    if (!isCreator) return m.reply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return m.reply(`${err}`)
                        if (stdout) return m.reply(stdout)
                    })
                }			
                        }
	} catch (err) {
    // Format error menggunakan util.format
    let formattedError = util.format(err);
    // Log error ke console
    console.log(formattedError);
    // Ubah error menjadi string jika belum
    let errorMessage = String(formattedError);
    // Dapatkan stack trace untuk mengetahui lokasi error
    let stackTrace = err.stack ? err.stack : "Stack trace not available";
    // Kirim pesan error ke WhatsApp dengan keterangan dan stack trace
    sky.sendMessage("628386484120@s.whatsapp.net", {
        text: `Alo ketua, ada error nih:\n\nKeterangan Error: ${errorMessage}\n\nStack Trace:\n${stackTrace}`,
        contextInfo: {
            forwardingScore: 9999999,
            isForwarded: true
        }
    })
}
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})